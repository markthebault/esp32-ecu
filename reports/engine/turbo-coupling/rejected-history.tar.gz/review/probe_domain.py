"""Exercise actual state-domain rejections, without injecting exceptions."""
from pathlib import Path
import sys,json,copy
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from turbo_gas_path import TurboGasPath
records=[]
for name in ('excess_heat','excess_negative_pumping','overspeed_candidate'):
    p=TurboGasPath(initial_turbo_rad_s=23999 if name=='overspeed_candidate' else 0)
    if name=='excess_heat':p.sources(0,1e8)
    elif name=='excess_negative_pumping':p.sources(0,0,0,-1e8)
    else:
        n=2*p.index['exhaust'];temp=1500
        p.state[n]=400000*p.graphs['exhaust'].env['V']/p.graphs['exhaust'].env['R']/temp;p.state[n+1]=temp
    before=list(p.state);latest=copy.deepcopy(p.latest)
    try:p.step(0,.001,30,20)
    except Exception as error:
        frames=[];tb=error.__traceback__
        while tb:
            local=tb.tb_frame.f_locals;row=dict(function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno)
            for key in ('omega','mass','temp','pressure','time','elapsed'):
                if type(local.get(key)) in (int,float):row[key]=local[key]
            frames.append(row);tb=tb.tb_next
        records.append(dict(case=name,rejected=True,error=str(error),state_unchanged=p.state==before,time=p.time,latest_unchanged=p.latest==latest,frames=frames))
    else:records.append(dict(case=name,rejected=False,omega=p.state[12]))
    p.close()
assert all(r['rejected'] and r['state_unchanged'] and r['latest_unchanged'] and r['time']==0 for r in records),records
(OUT/'real-domain-failure-probes.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
