"""Same charged coil/cylinder fixture, two adapter representations of GPIO low."""
from pathlib import Path
import json,math,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from boost_research_plant import BoostResearchPlant

def prepare():
    plant=BoostResearchPlant()
    # Authored warmed cylinder-state fixture, not an engine-start trajectory.
    # Its trapped charge is stoichiometric and its initial rotor energy is
    # explicitly supplied, so only the cut representation differs.
    plant.rpm=1000.;plant.angle=62.;plant.charge_mg[0]=10.;plant.air_charge_mg[0]=147.
    plant.fuel_mg=10.;plant.starter_j=.5*plant.rotor_inertia*(plant.rpm*math.pi/30)**2
    plant.edge(4,True,0)
    for n in range(6):plant.integrate(n*.0005,.0005,load=0)
    return plant

rows=[]
for method in ('global_cut','observed_falling_edge'):
    plant=prepare()
    before=dict(rpm=plant.rpm,angle=plant.angle,coil_on=plant.coil_on.copy(),charge_mg=plant.charge_mg.copy(),air_charge_mg=plant.air_charge_mg.copy(),chemical_j=plant.burned_chemical_j)
    if method=='global_cut':plant.cut()
    else:plant.edge(4,False,.003,10,10,2800)
    immediate=dict(coil_on=plant.coil_on.copy(),sparks=plant.sparks,chemical_j=plant.burned_chemical_j,burned_mg=plant.burned_mg,pending_shaft_j=sum(p['remaining']for p in plant.combustions),pending_exhaust_heat_j=sum(p['remaining']for p in plant.heat_pulses),dwell_events=plant.dwell_events.copy())
    for n in range(10):plant.integrate(.003+n*.0005,.0005,load=0)
    rows.append(dict(method=method,before=before,immediate=immediate,after5ms=dict(rpm=plant.rpm,chemical_j=plant.burned_chemical_j,shaft_work_j=plant.combustion_shaft_j,exhaust_heat_delivered_j=plant.heat_delivered_j,coil_on=plant.coil_on.copy())))
    plant.close()
assert rows[0]['before']==rows[1]['before']
assert rows[0]['immediate']['coil_on']==rows[1]['immediate']['coil_on']==[None]*4
assert rows[0]['immediate']['sparks']==0 and rows[1]['immediate']['sparks']==1
assert rows[0]['immediate']['chemical_j']==0 and rows[1]['immediate']['chemical_j']>400
(OUT/'charged-coil-cut-asymmetry.json').write_text(json.dumps(dict(scope='Actuator-hypothesis counterexample with authored identical charged-cylinder state; not a full controller trajectory',time_us=3000,rows=rows),indent=2)+'\n')
print(json.dumps(rows,indent=2))
