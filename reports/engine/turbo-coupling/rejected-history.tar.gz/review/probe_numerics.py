"""Independent exact-coordinate, physical-invariant and failure-atomicity probes."""
from pathlib import Path
import copy,json,math,random,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from turbo_gas_path import TurboGasPath
from boost_research_plant import BoostResearchPlant

def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

# Analytic two-volume mass/energy transfer tests the coordinate transform, not
# a duplicate implementation of its RK stages. All remaining volumes rest.
exact=[]
for ambient in (270.,298.15,325.):
    plant=TurboGasPath(ambient_k=ambient)
    initial=list(plant.state);m0,m1=initial[0],initial[2]
    cp=plant.gas('filter')['cp'];cv=plant.gas('filter')['cv']
    u0=m0*(cv*initial[1]-cp*ambient);u1=m1*(cv*initial[3]-cp*ambient)
    flow=.001;enthalpy_rate=20.;duration=.004
    def transfer(t,state,omega,tps,idle):
        derivative=[0.]*len(state)
        for n,dm,du in ((0,-flow,-enthalpy_rate),(1,flow,enthalpy_rate)):
            mass,temp=state[2*n:2*n+2];specific=cv*temp-cp*ambient
            derivative[2*n]=dm;derivative[2*n+1]=(du-specific*dm)/(mass*cv)
        return derivative,dict(turbine=dict(torque_nm=0.),compressor=dict(torque_nm=0.))
    plant.rates=transfer
    for n in range(4):plant.step(n*.001,.001,0,0)
    expected_m=(m0-flow*duration,m1+flow*duration)
    expected_t=((u0-enthalpy_rate*duration)/expected_m[0]/cv+cp*ambient/cv,(u1+enthalpy_rate*duration)/expected_m[1]/cv+cp*ambient/cv)
    error=max(abs(plant.state[2*n+1]-expected_t[n])for n in (0,1))
    energy_error=plant.total_energy(plant.state)-plant.total_energy(initial)
    assert error<2e-12 and abs(energy_error)<2e-11,(error,energy_error)
    exact.append(dict(case='constant_mass_and_enthalpy_transfer',ambient_k=ambient,maximum_temperature_error_k=error,energy_error_j=energy_error))
    plant.close()

# Linear drag and constant external drive have exact rotor trajectories. Drive
# power is explicitly an authored source counter; this is not engine heat.
for initial_omega,torque in ((0.,0.),(1000.,0.),(0.,.03),(20000.,.03)):
    plant=TurboGasPath(initial_turbo_rad_s=initial_omega);p=plant.components.parameters
    inertia=p['inertia_kg_m2'];bearing=p['bearing_nm_s'];a=bearing/inertia
    def rotor(t,state,omega,tps,idle):
        derivative=[0.]*len(state);w=state[12]
        derivative[12]=(torque-bearing*w)/inertia
        derivative[plant.offset['bearing']]=bearing*w*w
        derivative[plant.offset['heat']]=torque*w
        return derivative,dict(turbine=dict(torque_nm=torque),compressor=dict(torque_nm=0.))
    plant.rates=rotor
    for n in range(100):plant.step(n*.001,.001,0,0)
    duration=.1;expected=initial_omega*math.exp(-a*duration)+(torque/bearing)*(-math.expm1(-a*duration))
    error=abs(plant.state[12]-expected);residual=plant.ledger()['energy_residual_j']
    assert error<3e-10 and abs(residual)<2e-8,(initial_omega,torque,error,residual)
    if initial_omega==torque==0:assert plant.state[12]==0
    exact.append(dict(case='analytic_linear_bearing_and_external_drive',initial_omega=initial_omega,external_torque_nm=torque,expected_omega=expected,actual_omega=plant.state[12],omega_error=error,energy_residual_j=residual))
    plant.close()
dump('analytic-coordinate-probes.json',exact)

rng=random.Random(308401);plant=TurboGasPath();records=[]
for index in range(180):
    pressures=[rng.uniform(95,105),rng.uniform(110,160),rng.uniform(108,150),rng.uniform(80,130),rng.uniform(130,200),rng.uniform(100,105)]
    temperatures=[rng.uniform(280,330),rng.uniform(310,440),rng.uniform(300,360),rng.uniform(280,350),rng.uniform(500,1000),rng.uniform(350,650)]
    state=[0.]*len(plant.state)
    for n,(name,_,_)in enumerate(plant.VOLUMES):
        graph=plant.graphs[name];state[2*n]=pressures[n]*1000*graph.env['V']/graph.env['R']/temperatures[n];state[2*n+1]=temperatures[n]
    state[12]=rng.uniform(1000,20000);engine=rng.uniform(30,150);throttle=rng.uniform(5,70)
    plant.sources(rng.random(),rng.uniform(0,5000),rng.uniform(0,.0005),rng.uniform(-100,300))
    derivative,obs=plant.rates(0,state,engine,throttle,0)
    energy_rate=plant.components.parameters['inertia_kg_m2']*state[12]*derivative[12]
    for n,(name,_,_)in enumerate(plant.VOLUMES):
        gas=plant.gas(name);mass,temp=state[2*n:2*n+2]
        energy_rate+=(gas['cv']*temp-gas['cp']*plant.ambient_k)*derivative[2*n]+mass*gas['cv']*derivative[2*n+1]
    expected=derivative[plant.offset['boundary_h']]+plant.heat_w+plant.pumping_w-derivative[plant.offset['cooler_heat']]-derivative[plant.offset['bearing']]
    residual=energy_rate-expected
    assert abs(residual)<2e-8,(index,residual)
    plant.state=state;plant.time=0;plant.latest={};plant.initial_total_mass=plant.total_mass(state);plant.initial_energy=plant.total_energy(state)
    before=list(state);before_e=plant.total_energy(before)
    plant.step(0,1e-6,engine,throttle)
    ledger=plant.ledger()
    assert abs(ledger['energy_residual_j'])<2e-8,(index,ledger['energy_residual_j'])
    assert abs(ledger['mass_residual_kg'])<2e-14,(index,ledger['mass_residual_kg'])
    records.append(dict(index=index,instantaneous_residual_w=residual,step_residual_j=ledger['energy_residual_j'],mass_residual_kg=ledger['mass_residual_kg']))
plant.close();dump('random-physical-invariant-probes.json',records)

# A raw source profile must retain its documented Cp mismatch rather than
# having the new integrator renormalize the total energy to its counters.
negative=[]
for profile in ('source','conservative'):
    plant=TurboGasPath(profile=profile,initial_turbo_rad_s=20000)
    for n,(name,_,_)in enumerate(plant.VOLUMES):
        pressure=200000 if name=='exhaust' else 180000 if name in('charge','cooler')else 101300
        temp=900 if name in('exhaust','tail')else 350 if name in('charge','cooler')else 298.15
        plant.state[2*n]=pressure*plant.graphs[name].env['V']/plant.graphs[name].env['R']/temp;plant.state[2*n+1]=temp
    plant.initial_total_mass=plant.total_mass(plant.state);plant.initial_energy=plant.total_energy(plant.state)
    for n in range(10):plant.step(n*1e-6,1e-6,100,30)
    ledger=plant.ledger();defect=ledger['source_power_defect'];residual=ledger['energy_residual_j']
    assert abs(residual-defect)<2e-8,(profile,residual,defect)
    if profile=='source':assert abs(residual)>1e-5
    else:assert abs(residual)<2e-8
    negative.append(dict(profile=profile,energy_residual_j=residual,declared_source_defect_j=defect));plant.close()
dump('source-defect-negative-control.json',negative)

# Reject every failed stage without publishing a partial numerical state.
atomic=[]
for scope in ('gas','complete'):
    for failing_call in range(1,6):
        whole=BoostResearchPlant()if scope=='complete'else None;plant=whole.air if whole else TurboGasPath()
        if whole:
            whole.edge(9,True,0);whole.edge(0,True,0)
            whole.heat_j=whole.heat_seen=1/whole.EXHAUST_HEAT_FRACTION;whole.wall_heat_j=whole.heat_j-1
            whole.heat_pulses=[dict(start=0,end=1,rate=1,remaining=1)];whole.pending_fuel_kg=1e-6;whole.pending_pumping_j=.01
        snapshot=copy.deepcopy(whole.ledger()if whole else plant.ledger());state=list(plant.state);latest=copy.deepcopy(plant.latest)
        original=plant.rates;calls=[0]
        def fail(*args):
            calls[0]+=1
            if calls[0]==failing_call:raise ValueError('Independent injected stage failure')
            return original(*args)
        plant.rates=fail
        try:
            if whole:whole.integrate(0,.00025,starter=True)
            else:plant.step(0,.00025,30,20)
        except ValueError as error:assert 'Independent injected'in str(error)
        else:raise AssertionError((scope,failing_call,'did not reject'))
        assert plant.state==state and plant.latest==latest and plant.time==0
        assert (whole.ledger()if whole else plant.ledger())==snapshot,(scope,failing_call)
        del plant.__dict__['rates']
        if whole:whole.integrate(0,.00025,starter=True);assert whole.air.time==.00025
        else:plant.step(0,.00025,30,20);assert plant.time==.00025
        atomic.append(dict(scope=scope,failing_call=failing_call,rollback_and_retry_pass=True))
        if whole:whole.close()
        else:plant.close()
dump('stage-atomicity-probes.json',atomic)

startup=[]
for mode in ('normal','stuck_gate_open'):
    for dt in (.0005,.00025,.000125,.0000625):
        plant=BoostResearchPlant(actuator_mode=mode);minimum_omega=math.inf;maximum_omega=0.
        for n in range(round(.01/dt)):
            plant.integrate(n*dt,dt,starter=True);minimum_omega=min(minimum_omega,plant.air.state[12]);maximum_omega=max(maximum_omega,plant.air.state[12])
        ledger=plant.ledger()
        assert minimum_omega>=0 and maximum_omega<.01 and ledger['burned_chemical_j']==0 and ledger['exhaust_heat_delivered_j']==0
        assert abs(ledger['coupled_energy_residual_j'])<1e-8
        startup.append(dict(mode=mode,step_us=dt*1e6,minimum_omega=minimum_omega,maximum_omega=maximum_omega,coupled_energy_residual_j=ledger['coupled_energy_residual_j']));plant.close()
dump('gate-open-startup-probes.json',startup)

invalid=[]
for t in (float('nan'),float('inf'),-1.,1.):
    plant=TurboGasPath();state=list(plant.state)
    try:plant.step(t,.00025,0,0)
    except Exception as error:invalid.append(dict(time=repr(t),rejected=True,error=type(error).__name__,state_unchanged=state==plant.state,time_after=repr(plant.time)))
    else:invalid.append(dict(time=repr(t),rejected=False,state_unchanged=state==plant.state,time_after=repr(plant.time)))
    plant.close()
dump('invalid-time-probes.json',invalid)
dump('numerical-probe-summary.json',dict(analytic_cases=len(exact),continuous_and_step_physical_states=len(records),maximum_continuous_energy_residual_w=max(abs(r['instantaneous_residual_w'])for r in records),maximum_step_energy_residual_j=max(abs(r['step_residual_j'])for r in records),atomic_stage_cases=len(atomic),startup_cases=len(startup),invalid_time_cases=invalid))
print((OUT/'numerical-probe-summary.json').read_text())
