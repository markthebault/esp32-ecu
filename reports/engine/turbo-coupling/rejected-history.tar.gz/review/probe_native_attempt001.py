"""Independent fixed-calendar subdivision, tie-order, ADC and binary probes."""
from pathlib import Path
import ctypes,hashlib,json,math,random,shlex,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from speeduino_turbo_runtime import SpeeduinoTurboRuntime
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

reference_dir=OUT/'runtime/reference';reference_dir.mkdir(parents=True,exist_ok=False)
source=ROOT/'.cache/engine/speeduino-turbo-008/speeduino-turbo-sim';reference=reference_dir/source.name
shutil.copy2(source,reference);shutil.copy2(source.with_name('build-manifest.json'),reference.with_name('build-manifest.json'))

def sensor(t):
    return dict(map_kpa=150 if t<2000000 else 400 if t<2100000 else 145,
                tps_pct=60 if t<1700000 else 20,
                clt_c=85,iat_c=-100 if 2000000<=t<2200000 else 25,battery_v=14,**{'lambda':1})

# Every subdivision gets identical sensor writes and real60-2 callbacks at
# exact timestamps. Timer/loop work always precedes raw input updates and ISR
# edges at equal times, just as the full controller runner orders them.
histories=[]
for division in ('250','500','1000','irregular'):
    rng=random.Random(8271);times=[];t=0
    if division=='irregular':
        while t<3600000:t=min(3600000,t+rng.randrange(1,1124));times.append(t)
    else:times=list(range(int(division),3600001,int(division)))
    program={(t,0)for t in times}
    program.update((t,0)for t in range(0,3600001,5000))
    program.update((t,1)for t in range(0,3600001,5000))
    # A non-grid77us phase verifies subdivision independence at fractional
    # timer/loop boundaries while preserving the exact60-2 interval sequence.
    program.update((n*1000+77,2)for n in range(1,3600)if n%60<58)
    runtime=SpeeduinoTurboRuntime(reference,'closed_loop');events=[];status=[];adc=[]
    try:
        assert runtime.profile['main_loop_period_us']==1000
        for stamp,kind in sorted(program):
            if kind==0:events+=runtime.advance(stamp)
            elif kind==1:
                runtime.sensors(sensor(stamp));adc.append((stamp,runtime.raw_adc_counts))
                status.append((stamp,runtime.status(),runtime.boost_status()))
            else:events+=runtime.advance(stamp,tooth=True)
        histories.append(dict(division=division,events=events,status=status,adc=adc,profile=runtime.profile))
    finally:runtime.close()
for row in histories[1:]:
    assert row['events']==histories[0]['events'],('edge subdivision changed',row['division'])
    assert row['status']==histories[0]['status'],('status subdivision changed',row['division'])
    assert row['adc']==histories[0]['adc'],('ADC subdivision changed',row['division'])
assert any(e[1]==9 for e in histories[0]['events'])
dump('subdivision-calendar-probes.json',histories)

controls=[]
for unarmed in (False,True):
    runtime=SpeeduinoTurboRuntime(reference,'open_loop',default_unarmed_compare=unarmed)
    try:
        runtime.sensors(sensor(0));events=[]
        for n in range(1,501):events+=runtime.advance(n*1000,tooth=n%60<58)
        boost=[e for e in events if e[1]==9];state=runtime.boost_status()
        assert state['duty_pct']==40 and bool(boost)is(not unarmed)
        controls.append(dict(unarmed=unarmed,boost_edges=boost,status=state))
    finally:runtime.close()
dump('unarmed-timer-negative-control.json',controls)

temperature=[]
runtime=SpeeduinoTurboRuntime(reference,'open_loop')
try:
    for temp in (-273.15,-150,-100,-40,25,200,1000,2000):
        sample=sensor(0);sample['iat_c']=temp;sample['clt_c']=temp;runtime.sensors(sample)
        counts=runtime.raw_adc_counts.copy()
        expected=max(0,min(1023,math.floor((temp+40)*33/8+.5)))
        assert counts['iat']==counts['clt']==expected,(temp,counts,expected)
        temperature.append(dict(temperature_c=temp,adc=counts))
    for temp in (-273.151,2000.001,float('nan'),float('inf'),1e308):
        sample=sensor(0);sample['iat_c']=temp
        try:runtime.sensors(sample)
        except ValueError:pass
        else:raise AssertionError(('bad temperature accepted',repr(temp)))
        assert runtime.now==0 and runtime.process.poll()is None
finally:runtime.close()
dump('temperature-rail-probes.json',temperature)

raw={}
commands={'cold':'sensors 150 60 -150 -100 14 14.7\nadvance 10000\nadcstatus\nquit\n',
          'hot':'sensors 150 60 2000 1000 14 14.7\nadvance 10000\nadcstatus\nquit\n',
          'bad_cold':'sensors 150 60 -273.151 25 14 14.7\n',
          'bad_hot':'sensors 150 60 85 2000.001 14 14.7\n',
          'huge':'sensors 150 60 85 1e308 14 14.7\n',
          'nan':'sensors 150 60 85 nan 14 14.7\n','backward':'advance 1000\nadvance 999\n'}
for name,text in commands.items():
    run=subprocess.run([str(reference),'open_loop','40','150'],input=text,text=True,capture_output=True,timeout=10)
    raw[name]=dict(input=text,returncode=run.returncode,stdout=run.stdout,stderr=run.stderr)
    assert (run.returncode==0)is(name in ('cold','hot'))
dump('raw-native-rejection-probes.json',raw)

# Independent source-bound own-controller rebuild and live file mapping.
run=ROOT/'.cache/engine/boost-coupled-study-003/off-ours/run'
own=json.loads((run/'provenance/manifest.json').read_text())['own_runtime'];build=OUT/'runtime/own';build.mkdir(parents=True)
commands=[]
for index,old in enumerate(own['commands']):
    args=[part.replace(str(run/'provenance'),str(build))for part in old]
    done=subprocess.run(args,text=True,capture_output=True,timeout=90)
    (build/f'command-{index}.log').write_text(done.stdout+done.stderr);assert done.returncode==0
    commands.append(args)
assert sha(build/'libtarget_engine.so')==sha(own['loaded_library'])==own['binary_sha256']
bridge=ctypes.CDLL(own['loaded_library']);address=ctypes.cast(bridge.engine_create,ctypes.c_void_p).value;mapping=None
for line in Path('/proc/self/maps').read_text().splitlines():
    fields=line.split(maxsplit=5);low,high=[int(v,16)for v in fields[0].split('-')]
    if low<=address<high:
        file=Path(own['loaded_library']);status=file.stat();major,minor=[int(v,16)for v in fields[3].split(':')]
        assert Path(fields[5]).resolve()==file.resolve()and status.st_ino==int(fields[4])and(os.major(status.st_dev),os.minor(status.st_dev))==(major,minor)
        mapping=line;break
assert mapping
dependencies=set()
for name in ('cJSON.d','target.d'):
    content=(build/name).read_text().replace('\\\n',' ')
    dependencies.update(str(Path(p).resolve())for p in shlex.split(content.split(':',1)[1]))
expected={str(build/'cJSON.o')if p==str(run/'provenance/cJSON.o')else p for p in own['dependencies']}
assert dependencies==expected
dump('independent-native-rebuild.json',dict(binary_sha256=sha(build/'libtarget_engine.so'),dependency_count=len(dependencies),mapping=mapping,commands=commands,compiler_identity={name:dict(path=c['path'],sha256=sha(c['path']))for name,c in own['compiler'].items()}))
dump('native-probe-summary.json',dict(calendar_subdivisions_equal=[h['division']for h in histories],observed_engine_edges=len([e for e in histories[0]['events']if e[1]!=9]),observed_boost_edges=len([e for e in histories[0]['events']if e[1]==9]),same_time_policy='Calendar/timers then sensor writes then ISR at equal time',unarmed_boost_counts=[len(r['boost_edges'])for r in controls],temperature_rail_cases=len(temperature),raw_native_cases=len(raw),fresh_own_rebuild_equal=True,reference_binary_sha256=sha(reference),reference_manifest_sha256=sha(reference.with_name('build-manifest.json'))))
print((OUT/'native-probe-summary.json').read_text())
