"""Independent native configuration/action and baseline-neutrality witnesses."""
from pathlib import Path
import json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from speeduino_turbo_runtime import SpeeduinoTurboRuntime
runtime_dir=OUT/'runtime/protection';runtime_dir.mkdir(parents=True,exist_ok=False)
references={}
for version in ('008','011'):
    folder=runtime_dir/version;folder.mkdir();original=ROOT/f'.cache/engine/speeduino-turbo-{version}'
    for name in ('speeduino-turbo-sim','build-manifest.json'):shutil.copy2(original/name,folder/name)
    references[version]=folder/'speeduino-turbo-sim'

neutral=[]
program=['sensors 150 60 85 25 14 14.7','profile','boostmaps','adcstatus']
for n in range(1,3601):
    if n==1700:program.append('sensors 400 20 85 -100 14 14.7')
    if n==1900:program.append('sensors 145 60 85 25 14 14.7')
    program.append(('tooth 'if n%60<58 else'advance ')+str(n*1000))
    if n%500==0:program+=['status','booststatus']
program+=['status','booststatus','halt','quit'];wire='\n'.join(program)+'\n'
for mode in ('off','open_loop','closed_loop'):
    results=[]
    for version in ('008','011'):
        completed=subprocess.run([str(references[version]),mode,'40','150','--loop-period-us=1000'],input=wire,text=True,capture_output=True,timeout=20)
        assert completed.returncode==0,completed.stderr
        results.append(completed.stdout)
    assert results[0]==results[1],mode
    neutral.append(dict(mode=mode,exact_all_output_streams_equal=True,stdout=results[1]))
(OUT/'native-default-neutrality.json').write_text(json.dumps(neutral,indent=2)+'\n')

cases=[]
for cut,rpm_gate,pressure,expected in ((220,6500,150,False),(140,6500,150,False),(140,0,150,True),(140,0,130,False)):
    runtime=SpeeduinoTurboRuntime(references['011'],'open_loop',target=130,cut_kpa=cut,protection_rpm=rpm_gate)
    try:
        runtime.sensors(dict(map_kpa=pressure,tps_pct=60,clt_c=85,iat_c=25,battery_v=14,**{'lambda':1}))
        events=[];states=[]
        for n in range(1,1001):
            events+=runtime.advance(n*1000,tooth=n%60<58)
            if n%100==0:states.append(dict(time_us=n*1000,engine=runtime.status(),boost=runtime.boost_status()))
        final=states[-1]
        assert final['boost']['rpm']==1000
        assert bool(final['boost']['boost_cut'])is expected
        assert (final['engine']['fuel_channels']==0)is expected
        assert (final['engine']['ignition_channels']==0)is expected
        actual_engine_rises=[e for e in events if e[1]<8 and e[2]and e[0]>=200000]
        assert bool(actual_engine_rises)is(not expected),(cut,rpm_gate,pressure,actual_engine_rises)
        cases.append(dict(cut_kpa=cut,protection_rpm=rpm_gate,authored_pressure_kpa=pressure,expected_immediate_engine_cut=expected,profile=runtime.profile,states=states,all_observed_edges=events,actual_engine_rises_after200ms=len(actual_engine_rises)))
    finally:runtime.close()
(OUT/'native-protection-action-probes.json').write_text(json.dumps(cases,indent=2)+'\n')

invalid=[]
for kwargs in (dict(cut_kpa=139),dict(cut_kpa=301),dict(cut_kpa=True),dict(protection_rpm=99),dict(protection_rpm=6600),dict(protection_rpm=True)):
    try:SpeeduinoTurboRuntime(references['011'],**kwargs)
    except ValueError as error:invalid.append(dict(input=kwargs,rejected=True,error=str(error)))
    else:raise AssertionError(kwargs)
for options in (['--cut-kpa=141'],['--protect-rpm100=66'],['--cut-kpa=140','--cut-kpa=140'],['--protect-rpm100=0','--protect-rpm100=0']):
    completed=subprocess.run([str(references['011']),'open_loop','40','130',*options],input='quit\n',text=True,capture_output=True,timeout=10)
    assert completed.returncode!=0
    invalid.append(dict(options=options,rejected=True,stderr=completed.stderr))
(OUT/'new-profile-invalid-input-probes.json').write_text(json.dumps(invalid,indent=2)+'\n')
print(json.dumps(dict(neutral_modes=[r['mode']for r in neutral],protection_cases=[dict(cut=c['cut_kpa'],rpm_gate=c['protection_rpm'],pressure=c['authored_pressure_kpa'],flag=c['states'][-1]['boost']['boost_cut'],fuel_mask=c['states'][-1]['engine']['fuel_channels'],ignition_mask=c['states'][-1]['engine']['ignition_channels'],engine_rises=c['actual_engine_rises_after200ms'])for c in cases],new_argument_rejections=len(invalid)),indent=2))
