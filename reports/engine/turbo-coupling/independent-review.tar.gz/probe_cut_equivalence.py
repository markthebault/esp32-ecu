"""Independent scalar/global cut comparison, preserving the old3000us fixture."""
from pathlib import Path
import copy,json,math,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from boost_research_plant import BoostResearchPlant

def prepare(dwell,multi):
    p=BoostResearchPlant();p.rpm=1000;p.angle=62
    cylinders=(0,3)if multi else(0,)
    for cylinder in cylinders:p.charge_mg[cylinder]=10;p.air_charge_mg[cylinder]=147
    p.fuel_mg=10*len(cylinders);p.starter_j=.5*p.rotor_inertia*(p.rpm*math.pi/30)**2
    activation=.003-dwell;active=[4,7]if multi else[4]
    if multi:active=[0,3]+active+[9]
    ends=sorted(set([n*.0005 for n in range(7)]+[activation]))
    for left,right in zip(ends,ends[1:]):
        if left==activation:
            for channel in active:p.edge(channel,True,left)
        p.integrate(left,right-left,load=0)
    if activation==.003:
        for channel in active:p.edge(channel,True,p.air.time)
    return p,active

def physical(p):
    ledger=copy.deepcopy(p.ledger());ledger.pop('global_cut_discharges')
    return dict(ledger=ledger,gas=p.air.state.copy(),rpm=p.rpm,angle=p.angle,coil_on=p.coil_on.copy(),injector_on=p.injector_on.copy(),sparks=p.sparks,
                combustions=copy.deepcopy(p.combustions),heat_pulses=copy.deepcopy(p.heat_pulses),dwell_events=copy.deepcopy(p.dwell_events),
                charge_mg=p.charge_mg.copy(),air_charge_mg=p.air_charge_mg.copy(),port_mg=p.port_mg.copy(),wall_mg=p.wall_mg.copy(),
                cylinder_fuel_mg=p.cylinder_fuel_mg.copy(),cylinder_shaft_j=p.cylinder_shaft_j.copy())

rows=[]
for dwell,multi in ((.003,False),(.003,True),(.0001,False),(0.,False)):
    global_plant,active=prepare(dwell,multi);scalar,_=prepare(dwell,multi)
    assert physical(global_plant)==physical(scalar)
    global_plant.cut()
    for channel in active:scalar.edge(channel,False,scalar.air.time)
    assert physical(global_plant)==physical(scalar),(dwell,multi,'immediate physical mismatch')
    first=physical(global_plant);diagnostic=copy.deepcopy(global_plant.cut_discharges)
    global_plant.cut();assert physical(global_plant)==first and global_plant.cut_discharges==diagnostic
    immediate=dict(sparks=global_plant.sparks,chemical_j=global_plant.burned_chemical_j,cut_discharges=diagnostic)
    for n in range(10):
        for p in (global_plant,scalar):p.integrate(.003+n*.0005,.0005,load=0)
    assert physical(global_plant)==physical(scalar),(dwell,multi,'subsequent physical mismatch')
    if dwell==.003:assert global_plant.burned_chemical_j==440 and global_plant.sparks==(2 if multi else 1)
    if dwell in(.0001,0):assert global_plant.burned_chemical_j==0
    rows.append(dict(time_us=3000,requested_dwell_us=dwell*1e6,multiple_actuators=multi,active_channels=active,immediate=immediate,
                     exact_subsequent_physical_state_equal=True,repeated_cut_idempotent=True,rpm_after5ms=global_plant.rpm,shaft_work_after5ms_j=global_plant.combustion_shaft_j,exhaust_heat_delivered_j=global_plant.heat_delivered_j))
    global_plant.close();scalar.close()
(OUT/'global-scalar-cut-equivalence.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
