"""Independent read-only audit, with exact boundary diagnostics and RL replay."""
from pathlib import Path
import hashlib, json, math, statistics, sys

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def require(condition,message,**context):
    if not condition: raise AssertionError(dict(check=message,**context))

class CoilReplay:
    # Independent closed-form integration: fixed14V,36ohm,30mH,0.7V diode.
    def __init__(self,mode):
        self.t=0;self.high=False;self.current=0.;self.on_s=0.;self.mode=mode;self.edges=0
    def advance(self,t):
        require(t>=self.t,'Replay time',time_us=t,previous=self.t)
        dt=(t-self.t)/1e6;self.t=t
        on=self.high if self.mode!='inverted_drive' else not self.high
        self.on_s+=dt*on
        if self.mode=='disconnected': self.current=0.;return
        r=36.;l=.03;diode=.7;tau=l/r
        if on:
            steady=14/r;self.current=steady+(self.current-steady)*math.exp(-dt/tau)
        elif self.current:
            stop=tau*math.log1p(r*self.current/diode)
            self.current=0. if dt>=stop else -diode/r+(self.current+diode/r)*math.exp(-dt/tau)
    def edge(self,t,high):
        self.advance(t);self.high=high;self.edges+=1

def audit(folder,current=True):
    folder=Path(folder);result=json.loads((folder/'result.json').read_text())
    manifest=json.loads((folder/'provenance/manifest.json').read_text())
    own=result['controller']=='ours';stop=round(result['duration_s']*1e6)
    edges=[json.loads(x) for x in (folder/'edges.jsonl').read_text().splitlines()]
    traces=[json.loads(x) for x in (folder/'trace.jsonl').read_text().splitlines()]
    teeth=[json.loads(x) for x in (folder/'trigger-stimuli.jsonl').read_text().splitlines()]
    require(digest(folder/'provenance/manifest.json')==result['provenance_manifest_sha256'],'Manifest SHA')
    require(manifest['source_hashes']==result['source_hashes'],'Sources bound')
    for prefix,key in (('sources','source_hashes'),('model-inputs','model_inputs')):
        for name,expected in manifest[key].items():
            require(digest(folder/'provenance'/prefix/name)==expected,'Snapshot digest',file=name)
    mismatches=[]
    if current:
        for name,expected in manifest['stable_input_hashes'].items():
            if not Path(name).is_file() or digest(name)!=expected:mismatches.append(name)
        require(not mismatches,'Stable inputs',files=mismatches)
    runtime=manifest['own_runtime' if own else 'reference_runtime']
    if own:
        require(digest(folder/'provenance/libtarget_engine.so')==runtime['binary_sha256']==runtime['freshly_rebuilt_sha256'],'Own native binary')
        require(digest(runtime['loaded_library'])==runtime['binary_sha256'],'Actual loaded binary path')
        for name,compiler in runtime['compiler'].items():require(digest(compiler['path'])==compiler['sha256'],'Compiler identity',name=name)
        require(len(runtime['dependencies'])>=200,'Transitive compiler dependencies')
    else:
        ref=json.loads((folder/'provenance/reference-build-manifest.json').read_text())
        require(digest(folder/'provenance/reference-build-manifest.json')==runtime['manifest_sha256'],'Reference manifest')
        require(digest(runtime['executable'])==runtime['binary_sha256']==ref['binary_sha256'],'Reference native binary')
        require(ref['unit_test'] is False and ref['speeduino_sha']=='9ff5aae44de51fdc00d3fb1c7c2bfc1f0d0b3e20' and ref['original_objects_reused']==108,'Production binding')
        for name,expected in ref['locked_original_input_hashes'].items():require(digest(name)==expected,'Locked reference input',file=name)
    state=[False]*10;previous=-1;boost=0;cut_edges=[]
    for seq,edge in enumerate(edges,1):
        t,ch,value=edge['time_us'],edge['ch'],edge['high']
        context=dict(sequence=seq,time_us=t,channel=ch)
        require(edge['sequence']==seq,'Sequence',**context)
        require(type(t)is int and 0<=previous<=t<=stop if previous>=0 else type(t)is int and 0<=t<=stop,'Ordered bounded time',**context)
        require(type(ch)is int and 0<=ch<10 and ch!=8,'Channel',**context)
        require(type(value)is bool and state[ch]!=value,'Distinct transition',**context)
        require(edge['cause'] in ('dispatcher','fixture_halt','cut:simulation_end','cut:control','cut:trigger','cut:deadline'),'Edge cause',**context)
        if edge['cause']!='dispatcher':
            require(not value,'Cut must go low',**context);cut_edges.append(edge)
        if edge['cause'] in ('fixture_halt','cut:simulation_end'):require(t==stop,'Terminal-only manual cut',**context)
        boost+=ch==9 and edge['cause']=='dispatcher'
        state[ch]=value;previous=t
    require(len(edges)==result['edges'] and boost==result['boost_edges'],'Event totals')
    require(not any(state),'Final all low')
    state=[False]*10;cursor=0;replay=CoilReplay(result['actuator']);maximum_current_error=maximum_on_error=0.
    def consume_to(n,t):
        nonlocal cursor
        require(type(n)is int and cursor<=n<=len(edges),'Consumed count',time_us=t,count=n,previous_count=cursor)
        while cursor<n:
            e=edges[cursor];require(e['time_us']<=t,'Future consumed edge',time_us=t,edge=e)
            state[e['ch']]=e['high']
            if e['ch']==9:replay.edge(e['time_us'],e['high'])
            cursor+=1
        require(cursor==len(edges) or edges[cursor]['time_us']>t or t==stop,'Same-time queue not drained',time_us=t,sequence=cursor+1,next_edge=edges[cursor] if cursor<len(edges) else None)
    def snapshot(row,t):
        nonlocal maximum_current_error,maximum_on_error
        coil=row['valve']['coil'];replay.advance(t)
        context=dict(time_us=t,consumed=cursor,boost_edges=replay.edges)
        require(coil['gpio_high']==state[9]==replay.high,'Coil GPIO',**context)
        require(coil['edges']==replay.edges,'Coil exact edge count',actual=coil['edges'],**context)
        observed=row['dispatcher']['virtual_high'] if own else bool(row['dispatcher']['pin_high'])
        require(observed==state[9],'Dispatcher GPIO',**context)
        if own:require(row['dispatcher']['physical_policy_enabled'] is False and row['dispatcher']['physical_command_high'] is False,'Physical outputs inhibited',**context)
        require(abs(row['valve']['time_s']-t/1e6)<1e-8,'Actuator clock',**context)
        current_error=abs(coil['current_a']-replay.current);on_error=abs(coil['energized_s']-replay.on_s)
        maximum_current_error=max(maximum_current_error,current_error);maximum_on_error=max(maximum_on_error,on_error)
        require(current_error<2e-10,'Independent analytic current',actual=coil['current_a'],expected=replay.current,**context)
        require(on_error<2e-10,'Independent energized time',actual=coil['energized_s'],expected=replay.on_s,**context)
        require(abs(coil['electrical_residual_j'])<1e-8,'Coil energy',**context)
    for i,row in enumerate(traces):
        t=row['time_us'];require(t==i*20000 and t<stop,'Trace cadence',time_us=t,index=i)
        require(row['sensor_input']['battery_v']==14,'Battery replay datum',time_us=t)
        if not own:
            sample=row['sensor_input'];inputs=[sample[k]for k in('map_kpa','tps_pct','clt_c','iat_c','battery_v')]+[sample['lambda']*14.7]
            m,tps,clt,iat,bat,afr=[float(format(x,'.12g'))for x in inputs]
            raw=(m/400*1023,tps/100*1023,(clt+40)*33/8,(iat+40)*33/8,bat*10/245*1024,(afr*10-80)*33/5)
            lround=lambda x:math.floor(x+.5)if x>=0 else math.ceil(x-.5)
            expected=dict(zip(('map','tps','clt','iat','battery','wideband'),(max(0,min(1023,lround(x)))for x in raw)))
            require(row['input_adc_counts']==expected,'Actual raw ADC conversion',time_us=t,expected=expected,actual=row['input_adc_counts'])
            require(result['reference_profile']['main_loop_period_us']==1000,'Declared calendar period')
        consume_to(row['edges_consumed'],t);snapshot(row,t)
        require(row['boost_dispatcher_edges_consumed']==sum(e['ch']==9 and e['cause']=='dispatcher' for e in edges[:cursor]),'Dispatcher consumed count',time_us=t)
    before=result['before_halt'];consume_to(before['edges_consumed'],stop)
    require(state==before['high'],'Pre-halt engine states',time_us=stop)
    snapshot(dict(valve=before['ledger']['boost_valve'],dispatcher=before['dispatcher']),stop)
    require(all(e['time_us']==stop and e['cause'] in ('fixture_halt','cut:simulation_end') for e in edges[cursor:]),'Synthetic edges after prehalt only')
    require(sum(t['delivered'] for t in teeth)==result['trigger_edges'],'Delivered trigger count')
    require(sum(not t['delivered'] for t in teeth)==result['suppressed_teeth'],'Suppressed trigger count')
    last_angle=-1;last_time=-1
    for tooth in teeth:
        require(type(tooth['delivered'])is bool and tooth['tooth_angle_deg']>last_angle and 0<=last_time<=tooth['time_us']<=stop if last_time>=0 else type(tooth['delivered'])is bool and tooth['tooth_angle_deg']>last_angle and 0<=tooth['time_us']<=stop,'Trigger order',tooth=tooth)
        require(tooth['slot']==round(tooth['tooth_angle_deg']/6)%60 and tooth['slot']<58,'60-2 trigger geometry',tooth=tooth)
        last_angle=tooth['tooth_angle_deg'];last_time=tooth['time_us']
    require(traces[0]['plant_rpm']==0 and traces[0]['gas']['turbo_rad_s']==0,'True rest initial condition')
    # Match every nonterminal inferred coil-low to the actual previous rise
    # and common current/discharge model. Terminal diagnostics are excluded.
    discharges=before['cut_discharges'];coil_cuts=[e for e in edges if 4<=e['ch']<8 and e['time_us']<stop and e['cause'].startswith('cut:')]
    require(len(discharges)==len(coil_cuts)==before['ledger']['global_cut_discharges'],'Pre-terminal discharge count')
    for row,event in zip(discharges,coil_cuts):
        stamp=event['time_us'];ch=event['ch']
        require(row['channel']==ch and abs(row['time_s']-stamp/1e6)<1e-9,'Discharge event identity',time_us=stamp,channel=ch)
        rise=next(e['time_us']for e in reversed(edges[:event['sequence']-1])if e['ch']==ch and e['high'])
        dwell=(stamp-rise)/1e6;current=min(6.,12.5/.7*(-math.expm1(-.7*dwell/.003)));expected_energy=.5*.003*current*current
        require(abs(row['dwell_us']-dwell*1e6)<1e-6,'Discharge actual dwell',time_us=stamp,channel=ch)
        require(abs(row['energy_j']-expected_energy)<1e-12 and row['chemical_delta_j']>=0,'Common coil energy law',time_us=stamp,channel=ch)
    stimulus=result['stimulus'];scenario=stimulus['scenario']
    if scenario=='charged_map_rail':
        start=stimulus['charged_fault_start_us'];channels=stimulus['charged_channels_at_start']
        require(type(start)is int and 6000000<=start<stop and channels,'Reachable charged fault')
        for channel in channels:
            history=[e for e in edges if e['ch']==channel and (e['time_us']<start or e['time_us']==start and e['cause']=='dispatcher')]
            require(history and history[-1]['high'] and start-history[-1]['time_us']>=1500,'Actual charged channel at fault',time_us=start,channel=channel)
        if own:
            actual=[r for r in discharges if abs(r['time_s']-start/1e6)<1e-9]
            require(actual and any(r['energy_j']>.002 for r in actual),'Reachable energetic coil cut',time_us=start)
    if stimulus['cut_kpa']==140:
        require(stimulus['map_sensor_override_kpa']is None,'Genuine gas overboost without sensor override')
        require(all(r['sensor_input']['map_kpa']==r['gas']['map_kpa']for r in traces),'Actual gas sensor input')
        require(max(r['gas']['map_kpa']for r in traces)>140,'Actual pressure threshold crossing')
        if own:
            raw=before['control']['boost_control']['overboost_events']
            require(type(raw)is str and raw.isdigit() and 0<int(raw)<2**64,'Declared U64 overboost counter')
            require(any(r['control']['boost_control']['inhibit_engine'] and r['control']['fuel_cut'] and r['control']['spark_cut']for r in traces),'Own real engine inhibit')
        else:
            require(result['reference_profile']['protection_max_rpm']==0,'Explicit immediate-cut reference profile')
            require(any(r['control']['boost_control']['boost_cut']==1 and r['control']['fuel_channels']==0 and r['control']['ignition_channels']==0 for r in traces),'Production pressure protection and real channel masks')
    steady=[e for e in edges if e['ch']==9 and e['cause']=='dispatcher' and e['time_us']>=6000000]
    rise=[e['time_us'] for e in steady if e['high']]
    periods=[b-a for a,b in zip(rise,rise[1:])]
    durations=[b['time_us']-a['time_us'] for a,b in zip(steady,steady[1:]) if a['high'] and not b['high']]
    ledger=before['ledger']
    gas=ledger['turbo_gas']
    supplied=ledger['starter_j']+ledger['burned_chemical_j']+gas['boundary_h']
    exported=ledger['friction_j']+ledger['external_load_j']+ledger['wall_heat_j']+gas['cooler_heat']+gas['bearing']
    stored=ledger['kinetic_j']+gas['inventory_energy_j']-gas['initial_energy_j']+ledger['pending_work_j']+ledger['pending_exhaust_heat_j']+ledger['pending_pumping_exchange_j']
    independent_energy=supplied-exported-stored
    independent_mass=gas['inventory_mass_kg']-gas['initial_mass_kg']+(ledger['stored_mg']-ledger['fuel_in_mg'])/1e6+ledger['pending_exhaust_fuel_kg']-gas['boundary_mass']
    require(abs(independent_energy-ledger['coupled_energy_residual_j'])<1e-8,'Recomputed complete energy budget')
    require(abs(independent_mass-ledger['coupled_mass_residual_kg'])<1e-12,'Recomputed complete mass budget')
    require(abs(independent_energy)<.02,'Unchanged complete energy gate',residual_j=independent_energy)
    require(abs(independent_mass)<1e-9,'Complete mass gate',residual_kg=independent_mass)
    for key,tolerance in (('fuel_residual_mg',1e-6),('chemical_residual_j',1e-5),('shaft_residual_j',1e-5),('heat_partition_residual_j',1e-5),('exhaust_fuel_transport_residual_kg',1e-10)):
        require(abs(ledger[key])<tolerance,'Other complete budget gate',name=key,value=ledger[key])
    return dict(folder=str(folder),audit_passed=True,snapshots=len(traces),edges=len(edges),boost_edges=boost,
        natural_cut_edges=[e for e in cut_edges if e['time_us']<stop],terminal_cut_edges=[e for e in cut_edges if e['time_us']==stop],
        source_count=len(result['source_hashes']),tracked_input_count=len(manifest['stable_input_hashes']),
        own_compiler_dependency_count=len(runtime.get('dependencies',{})),
        maximum_independent_current_error_a=maximum_current_error,maximum_independent_energized_error_s=maximum_on_error,
        last_rpm=before['rpm'],last_map_kpa=before['map_kpa'],last_turbo_rad_s=before['turbo_rad_s'],
        maximum_tooth_quantization_deg=result['maximum_tooth_quantization_deg'],
        coupled_mass_residual_kg=ledger['coupled_mass_residual_kg'],coupled_energy_residual_j=ledger['coupled_energy_residual_j'],independent_energy_budget_j=independent_energy,independent_mass_budget_kg=independent_mass,
        steady_period_range_us=[min(periods),max(periods)] if periods else None,
        steady_high_range_us=[min(durations),max(durations)] if durations else None,
        trace_sha256=digest(folder/'trace.jsonl'),edges_sha256=digest(folder/'edges.jsonl'),trigger_sha256=digest(folder/'trigger-stimuli.jsonl'),provenance_sha256=digest(folder/'provenance/manifest.json'))

if __name__=='__main__':
    records=[]
    for value in sys.argv[1:]:
        try:records.append(audit(ROOT/value))
        except Exception as error:records.append(dict(folder=value,audit_passed=False,error=type(error).__name__,detail=str(error)))
    output=OUT/'independent-audit.json';output.write_text(json.dumps(records,indent=2,allow_nan=False)+'\n')
    print(json.dumps(records,indent=2,allow_nan=False))
    sys.exit(any(not r['audit_passed'] for r in records))
