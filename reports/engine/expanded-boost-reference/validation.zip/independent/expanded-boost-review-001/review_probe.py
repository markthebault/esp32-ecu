"""Independent review probes. Executes only private copied native binaries.

Python runtime inputs are copied from001 into source-freeze so concurrent
fixture-source edits cannot silently relabel historical001 evidence.
"""
from pathlib import Path
import collections,contextlib,gzip,hashlib,json,math,os,shutil,subprocess,sys
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'source-freeze/tools'))
from engine_geometry import EngineGeometry,channel_kind
from speeduino_profiles_turbo_runtime import SpeeduinoProfilesTurboRuntime,validate_profile
from speeduino_turbo_runtime import SpeeduinoTurboRuntime
NEW=R/'current/speeduino-profiles-turbo';OLD=R/'historical/speeduino-turbo-sim'
results={}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,data):
 (R/(name+'.json.gz')).write_bytes(gzip.compress(json.dumps(data,separators=(',',':'),allow_nan=False).encode(),mtime=0))
def sample(**kw):return dict(dict(map_kpa=150,tps_pct=60,clt_c=85,iat_c=25,battery_v=14,**{'lambda':1}),**kw)
def run_new(n=8,engine='sequential',**kwargs):return SpeeduinoProfilesTurboRuntime(NEW,EngineGeometry(n,(1,*range(n,1,-1)),500*n),engine_mode=engine,**kwargs)
def drive(r,until=600000,rpm=1000,partition=1000,cam=True):
 events=[];tooth=1
 while round(tooth*1e6/rpm)<=until:
  stamp=round(tooth*1e6/rpm)
  if tooth%60<58:
   events.append((stamp,1,0,True))
   if stamp+100<=until:events.append((stamp+100,1,0,False))
  tooth+=1
 if cam:
  angle=540
  while round(angle*1e6/(rpm*6))<=until:
   stamp=round(angle*1e6/(rpm*6));events.append((stamp,1,1,True))
   if stamp+100<=until:events.append((stamp+100,1,1,False))
   angle+=720
 events += [(stamp,0,0,False)for stamp in range(partition,until+1,partition)]
 rows=[]
 for stamp,kind,ch,level in sorted(events):rows+=r.input_edge(stamp,ch,level)if kind else r.advance(stamp)
 if r.now<until:rows+=r.advance(until)
 return rows

def historical_equivalence():
 out={}
 for mode in ('off','open_loop','closed_loop'):
  new=SpeeduinoProfilesTurboRuntime(NEW,EngineGeometry(4,(1,3,4,2),1800),engine_mode='wasted_cop',mode=mode)
  old=SpeeduinoTurboRuntime(OLD,mode=mode)
  try:
   assert new.required_fuel_raw==96
   old.sensors(sample());new.sensors(sample());ae=[];be=[];states=[]
   for tooth in range(1,3601 if mode=='closed_loop'else 1201):
    stamp=tooth*1000
    if tooth in (200,350,450,800):
     s=sample(**({200:dict(map_kpa=130,iat_c=75),350:dict(map_kpa=100,tps_pct=0,**{'lambda':1.2}),450:dict(map_kpa=150,tps_pct=60),800:dict(map_kpa=180,iat_c=-10)}[tooth]));old.sensors(s);new.sensors(s);assert old.raw_adc_counts==new.raw_adc_counts
    a=old.advance(stamp,tooth=tooth%60<58);b=new.advance(stamp,tooth=tooth%60<58)
    assert a==b,('edge mismatch',mode,tooth,a,b)
    ae+=a;be+=b
    if tooth%100==0:
     a=old.status();b=new.status();assert a=={k:b[k]for k in a},('status mismatch',mode,tooth,a,b)
     a=old.boost_status();b=new.boost_status();assert a==b,('boost mismatch',mode,tooth,a,b);states.append([stamp,a])
   assert old.halt()==new.halt()
   post_time=old.now+40000;a=old.advance(post_time);b=new.advance(post_time);assert a==b
   out[mode]=dict(edges=len(ae),boost_edges=sum(e[1]==9 for e in ae),sampled_statuses=len(states),raw96=True,exact_edges_status_boost_adc_halt=True)
   save('historical-'+mode,dict(profile=new.profile,edges=ae,statuses=states,post_halt_edges=a))
  finally:old.close();new.close()
 return out

def all_modes():
 out={}
 for n in range(1,9):
  for mode in ('sequential','semi','wasted_cop'):
   r=run_new(n,mode,mode='open_loop');r.sensors(sample())
   try:
    rows=drive(r,cam=mode=='sequential');s=r.status();bs=r.boost_status();used={x[1]for x in rows if x[1]!=9};expected=set(r.geometry.injector_channels+r.geometry.coil_channels)
    if n==7 and mode!='sequential':expected={r.pin_map[p]for p in (22,23,25,31,32,33)}
    assert used==expected,(n,mode,used,expected)
    assert s['rpm']==1000 and s['sync']==2,(n,mode,s)
    assert bs['duty_pct']==40 and any(row[1]==9 for row in rows)
    errors=[];pairs={};high={};widths=[]
    for us,ch,v,_,_ in rows:
     if ch==9:continue
     if v:
      assert ch not in high,(n,mode,'duplicate rise',us,ch);high[ch]=us
     else:
      assert ch in high,(n,mode,'fall without rise',us,ch);widths.append([ch,us-high.pop(ch)])
      kind,index=channel_kind(ch)
      if kind=='coil'and us>=400000:
       em=r.edge_modes[(us,ch,False)];error=math.remainder(r.geometry.compression_tdc_deg[index]-us*0.006-10,720 if em['effective_sequential']else 360);errors.append(error)
    assert errors
    max_error=max(map(abs,errors))
    if r.profile['representable_ignition_geometry']:assert max_error<(6.1 if n==7 else 1),(n,mode,max_error)
    else:assert max_error>30,(n,mode,max_error)
    falls=r.halt();assert {x[1]for x in falls}==set(high),(n,mode,'halt incomplete',falls,high)
    post=r.advance(620000);assert all(x[1]==9 for x in post),(n,mode,'engine edge after halt',post)
    g=r.geometry_status();assert g['halted']
    key=f'{n}-{mode}';out[key]=dict(engine_edges=sum(x[1]!=9 for x in rows),boost_edges=sum(x[1]==9 for x in rows),actual_channels=sorted(used),max_spark_error_deg=max_error,physical_geometry_issues=r.profile['physical_geometry_issues'],effective_initial=r.profile['effective_before_start'],effective_final=s['reference_effective'],mode_history=r.mode_history)
    save('profile-'+key,dict(profile=r.profile,edges=rows,status=s,boost_status=bs,halt=falls,post_halt_edges=post,widths_us=widths))
   finally:r.close()
 return out

def calendar_and_timer():
 histories=[]
 for step in (250,500,1000):
  r=run_new(mode='closed_loop');r.sensors(sample())
  try:rows=drive(r,until=3600000,partition=step);histories.append((rows,r.status(),r.boost_status()));save('partition-'+str(step),dict(edges=rows,status=histories[-1][1],boost_status=histories[-1][2]))
  finally:r.close()
 assert histories[0]==histories[1]==histories[2]
 assert any(x[1]==9 for x in histories[0][0])
 timers=[]
 for unarmed in (False,True):
  r=run_new(mode='open_loop',default_unarmed_compare=unarmed);r.sensors(sample())
  try:
   rows=drive(r);bs=r.boost_status();boost=[x for x in rows if x[1]==9];assert bs['duty_pct']==40
   if unarmed:assert not boost and bs['timer_compare']==4294967295
   else:
    assert len(boost)>10 and all(x[0]%4==0 for x in boost)
    rise=[x[0]for x in boost if x[2]];assert all(b-a==41664 for a,b in zip(rise,rise[1:]))
   timers.append(dict(unarmed=unarmed,boost_edges=len(boost),status=bs))
  finally:r.close()
 return dict(exact_calendar_partition_250_500_1000=True,negative_control=timers)

def guards():
 # These constructor inputs must fail before invoking the operating system.
 import speeduino_profiles_turbo_runtime as rt
 actual=rt.subprocess.Popen;calls=[]
 rt.subprocess.Popen=lambda *a,**kw:(calls.append(a),(_ for _ in ()).throw(AssertionError('Popen reached')))[1]
 checked=0
 try:
  valid=EngineGeometry(8,tuple(range(1,9)),4000)
  for key,values in {'engine_mode':('unknown',True),'mode':('unknown',True),'duty':(-2,92,41,True,1.0),'target':(49,212,151,True),'loop_period_us':(99,10001,True,1000.0),'cut_kpa':(98,302,221,True),'protection_rpm':(-100,6600,6501,True),'default_unarmed_compare':(0,1,None),'wiring_order':((1,2),(1,2,3,4,5,6,7,7),(True,2,3,4,5,6,7,8))}.items():
   for value in values:
    try:SpeeduinoProfilesTurboRuntime(NEW,valid,**{key:value})
    except ValueError:checked+=1
    else:raise AssertionError(('constructor accepted',key,value))
  for g in (None,EngineGeometry(tooth1_tdc_deg=89),EngineGeometry(cam_edge_deg=539),EngineGeometry(1,(1,),12000)):
   try:SpeeduinoProfilesTurboRuntime(NEW,g)
   except ValueError:checked+=1
   else:raise AssertionError(('geometry accepted',g))
  assert not calls
 finally:rt.subprocess.Popen=actual
 r=run_new(mode='open_loop');sent=[];actual=r.command
 def spy(s):sent.append(s);return actual(s)
 r.command=spy;r.sensors(sample());sent.clear();before=r.now;bad=0
 try:
  for key,values in dict(map_kpa=(-1,401),tps_pct=(-1,101),clt_c=(-274,2001),iat_c=(-274,2001),battery_v=(-1,25),**{'lambda':(0,3)}).items():
   for v in (*values,float('nan'),float('inf'),True,'1'):
    try:r.sensors(sample(**{key:v}))
    except ValueError:bad+=1
    else:raise AssertionError(('sensor accepted',key,v))
  for t in (-1,60000001,True,.5):
   try:r.advance(t)
   except ValueError:bad+=1
   else:raise AssertionError(('time accepted',t))
  for args in ((1000,2,True),(1000,0,1),(True,0,True),(1000,True,True),(-1,0,False),(60000001,0,False)):
   try:r.input_edge(*args)
   except ValueError:bad+=1
   else:raise AssertionError(('input accepted',args))
  assert not sent and r.now==before and r.process.poll()is None
  r.sensors(sample(iat_c=-100,map_kpa=400));assert r.raw_adc_counts['iat']==0 and r.raw_adc_counts['map']==1023
  r.sensors(sample(iat_c=1000,**{'lambda':2}));assert r.raw_adc_counts['iat']==1023 and r.raw_adc_counts['wideband']==1023
  r.advance(1000)
 finally:r.close()
 # Any launch with rejected arguments inherits a private prefix, independently
 # of the entry's late001 internal redirect.
 raw=[];args0=[str(NEW),'8','sequential','open_loop','40','150']
 for i,extra in enumerate((['--duty=42'],['--required-fuel=0'],['--required-fuel=256'],['--loop-period-us=99'],['--cut-kpa=221'],['--loop-period-us=1000','--loop-period-us=1000'])):
  env=os.environ.copy();env['GCOV_PREFIX']=str(R/'invalid-cli-gcov'/str(i));p=subprocess.run(args0+extra,input='quit\n',text=True,capture_output=True,env=env,timeout=8);assert p.returncode==2 and p.stderr.strip();raw.append(dict(argv=extra,returncode=p.returncode,stderr=p.stderr))
 malformed=['advance -1','advance 60000001','advance 1000\nadvance 999','input 1000 2 1','input 1000 0 2','sensors 401 60 85 25 14 14.7','sensors 100 60 85 nan 14 14.7','sensors 100 60 85 25 14','unknown']
 for i,command in enumerate(malformed):
  env=os.environ.copy();env['GCOV_PREFIX']=str(R/'malformed-gcov'/str(i));p=subprocess.run(args0,input=command+'\n',text=True,capture_output=True,env=env,timeout=8);assert p.returncode==2 and p.stderr.strip();raw.append(dict(command=command,returncode=p.returncode,stderr=p.stderr))
 return dict(pre_Popen_constructor_rejections=checked,pre_IPC_live_input_rejections=bad,raw_rejections=raw)

for name,test in [('historical',historical_equivalence),('profiles',all_modes),('calendar_timer',calendar_and_timer),('guards',guards)]:
 try:
  results[name]=test();print(name,'PASS',flush=True)
 except BaseException as e:
  results[name]={'FAILED':repr(e)};print(name,'FAIL',repr(e),flush=True)
 (R/'probe-results.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
print('results',R/'probe-results.json',flush=True)
raise SystemExit(any(isinstance(v,dict)and'FAILED'in v for v in results.values()))
