from pathlib import Path
import json,os,subprocess,gzip
R=Path(__file__).resolve().parent
binary=R/'current/speeduino-profiles-turbo'
base=['sensors 150 60 85 25 14 14.7']
base += [('tooth 'if t%60<58 else'advance ')+str(t*1000)for t in range(1,601)]
results=[]
for n,command in enumerate(('advance 640000oops','input 640000 0 1oops','sensors 300 60 85 25 14 14.7oops')):
 env=os.environ.copy();env['GCOV_PREFIX']=str(R/'raw-prefix-gcov'/str(n))
 p=subprocess.run([str(binary),'8','sequential','open_loop','40','150'],input='\n'.join(base+[command])+'\n',text=True,capture_output=True,env=env,timeout=10)
 tail=p.stdout.split('ok\n')[-2:];after=[line for line in p.stdout.splitlines()if line.startswith(('edge ','boostedge '))and int(line.split()[1])>600000]
 assert p.returncode==2
 results.append(dict(command=command,returncode=p.returncode,stderr=p.stderr,post_600ms_output_edges=after,tail=tail))
 (R/f'raw-prefix-{n}.log.gz').write_bytes(gzip.compress((p.stdout+'\nSTDERR\n'+p.stderr).encode(),mtime=0))
(R/'raw-prefix-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
