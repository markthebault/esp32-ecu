from pathlib import Path
import hashlib,json,os,shutil,subprocess
R=Path(__file__).resolve().parent;build=R.parent/'expanded-boost-build-002';D=R/'revision002';D.mkdir()
for n in ('speeduino-profiles-turbo','build-manifest.json'):shutil.copy2(build/n,D/n)
new=D/'speeduino-profiles-turbo';old=R/'current/speeduino-profiles-turbo'
rows=[]
for n,mode,boost in ((4,'wasted_cop','off'),(4,'wasted_cop','open_loop'),(4,'wasted_cop','closed_loop'),(8,'sequential','open_loop'),(8,'sequential','closed_loop')):
 program=['sensors 150 60 85 25 14 14.7','adcstatus','boostprofile','boostmaps','geometry']
 for t in range(1,3601):
  if n==8 and t%120==90:program+=['input '+str(t*1000)+' 1 1','input '+str(t*1000)+' 1 0']
  program+=[('tooth 'if t%60<58 else'advance ')+str(t*1000)]
 program+=['status','booststatus','halt','advance 3640000','quit'];wire='\n'.join(program)+'\n'
 outputs=[]
 for b in (old,new):
  p=subprocess.run([str(b),str(n),mode,boost,'40','150','--required-fuel=96'if n==4 else'--required-fuel=107'],input=wire,text=True,capture_output=True,timeout=20)
  assert p.returncode==0,p.stderr;outputs.append(p.stdout)
 assert outputs[0]==outputs[1],(n,mode,boost,'valid output difference')
 rows.append(dict(n=n,mode=mode,boost=boost,identical_raw_output=True,raw_sha256=hashlib.sha256(outputs[0].encode()).hexdigest(),lines=len(outputs[0].splitlines())))
 # Keep exact raw response bytes for independent rerun inspection.
 (D/f'{n}-{mode}-{boost}.log').write_text(outputs[1])
errors=[]
for args in ([],['0','sequential','open_loop','40','150'],['8','sequential','open_loop','40','150','--required-fuel=0']):
 env=os.environ.copy();env.pop('GCOV_PREFIX',None);p=subprocess.run([str(new),*args],input='quit\n',text=True,capture_output=True,env=env,timeout=10)
 assert p.returncode==2 and p.stderr and not p.stdout
 errors.append(dict(argv=args,returncode=p.returncode,stderr=p.stderr))
gcov=list((D/'gcov').rglob('*.gcda'));assert gcov
result=dict(binary_sha256=hashlib.sha256(new.read_bytes()).hexdigest(),numerical_relink_sha256=json.loads((D/'build-manifest.json').read_text())['numerical_relink_sha256'],valid001_to002=rows,invalid_CLI_without_external_prefix=errors,local_gcda_files=len(gcov))
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
