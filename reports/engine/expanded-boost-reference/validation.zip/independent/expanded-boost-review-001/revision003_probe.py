"""Independent closure of parser, metadata and coverage findings in003."""
from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];build=R.parent/'expanded-boost-build-003';D=R/'revision003';D.mkdir()
for n in ('speeduino-profiles-turbo','build-manifest.json'):shutil.copy2(build/n,D/n)
new=D/'speeduino-profiles-turbo';old=R/'current/speeduino-profiles-turbo';model=json.loads((D/'build-manifest.json').read_text())
# Verify complete build/transform object graph again for this exact revision.
for k in ('locked_original_input_hashes','object_hashes','library_hashes','generated_sources'):
 for p,h in model[k].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,(k,p)
text=(ROOT/'tools/speeduino_profiles_sim.cpp').read_text()
for before,after in model['adapter_symbol_replacements'].items():assert text.count(before)==1;text=text.replace(before,after)
assert Path(next(iter(model['generated_sources']))).read_text()==text
assert model['numerical_relink_sha256']=='046389d754c996c34cb7e7171b1e42088f5ae6c0615133a3c5e74743f9f6d52c'
# Preserve the exact runtime inputs independently of the parent's future work.
F=D/'source-freeze'
for name in model['fixture_sources']:
 p=F/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(build/'sources'/name,p)
for name in ('speeduino_profiles_turbo_runtime.py','speeduino_profiles_runtime.py','speeduino_turbo_runtime.py','speeduino_runtime.py','engine_geometry.py','profile_config.py'):
 p=F/'tools'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/'tools'/name,p)
(F/'config').mkdir();shutil.copyfile(ROOT/'config/engine-profile.json',F/'config/engine-profile.json')
rows=[]
for n,mode,boost in ((4,'wasted_cop','off'),(4,'wasted_cop','open_loop'),(4,'wasted_cop','closed_loop'),(8,'sequential','open_loop'),(8,'sequential','closed_loop')):
 program=['sensors 150 60 85 25 14 14.7','adcstatus','boostprofile','boostmaps','geometry']
 for t in range(1,3601):
  if n==8 and t%120==90:program+=['input '+str(t*1000)+' 1 1','input '+str(t*1000)+' 1 0']
  program+=[('tooth 'if t%60<58 else'advance ')+str(t*1000)]
 program+=['status','booststatus','halt','advance 3640000','quit'];wire='\n'.join(program)+'\n';outputs=[]
 for b in (old,new):
  p=subprocess.run([str(b),str(n),mode,boost,'40','150','--required-fuel=96'if n==4 else'--required-fuel=107'],input=wire,text=True,capture_output=True,timeout=20)
  assert p.returncode==0,p.stderr;outputs.append(p.stdout)
 assert outputs[0]==outputs[1],(n,mode,boost,'valid output difference')
 rows.append(dict(n=n,mode=mode,boost=boost,identical_raw_output=True,raw_sha256=hashlib.sha256(outputs[0].encode()).hexdigest(),lines=len(outputs[0].splitlines())))
 (D/f'{n}-{mode}-{boost}.log.gz').write_bytes(gzip.compress(outputs[1].encode(),mtime=0))
# Malformed single-line commands must contribute no output or acknowledgements
# at all after the last accepted600ms frame.
base=['sensors 150 60 85 25 14 14.7']+ [('tooth 'if t%60<58 else'advance ')+str(t*1000)for t in range(1,601)]
args=[str(new),'8','sequential','open_loop','40','150'];wire='\n'.join(base)+'\n';baseline=subprocess.run(args,input=wire+'quit\n',text=True,capture_output=True,timeout=10);assert baseline.returncode==0
bad=['advance 640000oops','advance 640000.5','advance +640000','advance -1','advance 60000001','advance 18446744073709551616','advance 640000 extra','advance','input 640000 0 1oops','input 640000 0.0 1','input 640000 2 1','input 640000 0 2','input 640000 0 1 extra','input 640000 0','sensors 300 60 85 25 14 14.7oops','sensors 300 60 85 25 14 NaN','sensors 300 60 85 25 14 inf','sensors 300 60 85 25 14 1e309','sensors 300 60 85 25 14 1e-9999','sensors 401 60 85 25 14 14.7','sensors 300 60 85 25 14 14.7 extra','sensors 300 60 85 25 14','status extra','boostmaps extra','geometry extra','halt extra','quit extra','advance 640000\x00','advance 640000'+' '*4096]
rejections=[]
for i,command in enumerate(bad):
 p=subprocess.run(args,input=wire+command+'\n',text=True,capture_output=True,timeout=10)
 assert p.returncode==2 and p.stderr,(i,repr(command),p.returncode,p.stderr)
 assert p.stdout==baseline.stdout,(i,repr(command),'output/acknowledgement after malformed frame',p.stdout[len(baseline.stdout):])
 rejections.append(dict(command=repr(command)if len(command)<100 else'overlong4096+ wire line',returncode=p.returncode,stderr=p.stderr,exact_accepted_prefix_only=True))
(D/'raw-rejections.json').write_text(json.dumps(rejections,indent=2)+'\n')
# Review new Python metadata through the same isolated complete source root.
sys.path.insert(0,str(F/'tools'))
from speeduino_profiles_turbo_runtime import SpeeduinoProfilesTurboRuntime
from engine_geometry import EngineGeometry
metadata=[]
for n in range(1,9):
 for mode in ('sequential','semi','wasted_cop'):
  r=SpeeduinoProfilesTurboRuntime(new,EngineGeometry(n,(1,*range(n,1,-1)),500*n),engine_mode=mode,mode='open_loop')
  try:
   caveat=r.profile['injection_bank_caveat'];issues=r.profile['physical_geometry_issues']
   assert bool(caveat)==(n==5 and mode!='sequential')
   assert bool(issues)==(n in (2,7)and mode!='sequential')
   metadata.append(dict(n=n,mode=mode,injection_bank_caveat=caveat,geometry_issues=issues,native_boost_pin=r.profile['native_boost_pin'],required_fuel_raw=r.required_fuel_raw))
  finally:r.close()
# Invalid process argv must self-isolate even when the parent has no prefix.
errors=[]
for argv in ([],['0','sequential','open_loop','40','150'],['8','sequential','open_loop','40','150','--required-fuel=0']):
 env=os.environ.copy();env.pop('GCOV_PREFIX',None);p=subprocess.run([str(new),*argv],input='quit\n',text=True,capture_output=True,env=env,timeout=10)
 assert p.returncode==2 and p.stderr and not p.stdout;errors.append(dict(argv=argv,stderr=p.stderr))
assert list((D/'gcov').rglob('*.gcda'))
result=dict(binary_sha256=hashlib.sha256(new.read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256((D/'build-manifest.json').read_bytes()).hexdigest(),numerical_relink_sha256=model['numerical_relink_sha256'],whole_object_graph_hashes_and_exact_two_symbol_bridge=True,valid001_to003=rows,raw_pre_mutation_rejections=len(rejections),N5_and_N2_N7_metadata_24_profiles=metadata,invalid_CLI_without_external_prefix=errors,runtime_sources={str(p.relative_to(F)):hashlib.sha256(p.read_bytes()).hexdigest()for p in F.rglob('*')if p.is_file()})
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',result['binary_sha256'],'valid histories',len(rows),'raw guarded commands',len(rejections),'metadata profiles',len(metadata))
