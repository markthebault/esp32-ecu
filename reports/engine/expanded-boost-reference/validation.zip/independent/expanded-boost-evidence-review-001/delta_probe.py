from pathlib import Path
import copy,difflib,hashlib,json,math,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];B=ROOT/'.cache/engine/expanded-boost-pair-001';D=ROOT/'.cache/engine/expanded-boost-diagnose-001'
sys.path.insert(0,str(R/'sources/tools'))
from verify_boost_engine import verify
from analyse_boost_runs import run,compare_refinement
from engine_geometry import channel_kind

def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def lines(p):return [(json.loads(raw),raw)for raw in Path(p).read_bytes().splitlines(keepends=True)]
# Reuse the independent reviewer's algebra and pulse-reconstruction function,
# excluding any old execution or mutation driver. It imports no plant runtime.
prior=(ROOT/'.cache/engine/expanded-boost-coupling-review-001/audit_probe.py').read_text();definition=prior[prior.index('def independent('):prior.index("names=['ours-eight-open'")].replace(" assert set(g['injector_channels']+g['coil_channels'])<=used\n",'')
exec(compile(definition,'prior-independent-ledger-method','exec'),globals())
parent_analysis=read(ROOT/'.cache/engine/expanded-boost-analysis-003/comparison.json');ordinary=[Path(d['path'])for d in parent_analysis['records']];assert len(ordinary)==9
audits={}
for p in ordinary+[D/'step250',D/'step500']:
 name=p.name if p.parent==B else'diagnostic-'+p.name
 audits[name]=dict(current_input=verify(p,True),independent=independent(p),raw_inputs={name:sha(p/name)for name in('result.json','progress.json','trace.jsonl','edges.jsonl','trigger-stimuli.jsonl','provenance/manifest.json')})
write(R/'all-positive-audits.json',audits)
report=run(ordinary,R/'analysis-replay');assert report==parent_analysis,'Analysis003 exact replay mismatch';write(R/'analysis-replay-check.json',dict(exact_report_object=True,exact_report_bytes=(R/'analysis-replay/comparison.json').read_bytes()==(ROOT/'.cache/engine/expanded-boost-analysis-003/comparison.json').read_bytes(),refinement=report['refinement']))
# Independently recompute the new250→125 sensitivity from raw3..4s snapshots.
metric=[]
for name in('reference-eight-open','reference-eight-open-125'):
 folder=B/name;d=read(folder/'result.json');recent=[e for e,_ in lines(folder/'trace.jsonl')if 3000000<=e['time_us']<4000000];n=len(recent)
 metric.append(dict(last_second_mean_rpm=math.fsum(e['plant_rpm']for e in recent)/n,last_second_mean_map_kpa=math.fsum(e['gas']['map_kpa']for e in recent)/n,last_second_mean_turbo_rad_s=math.fsum(e['gas']['turbo_rad_s']for e in recent)/n,fuel_in_mg=d['before_halt']['ledger']['fuel_in_mg']))
relative={k:abs(metric[0][k]-metric[1][k])/max(abs(metric[1][k]),1)for k in metric[0]};record=next(r for r in report['refinement']if r['controller']=='speeduino'and r['fine_us']==125);assert all(abs(v-record['relative_difference'][k])<1e-12 for k,v in relative.items());assert not record['within_declared_two_percent']
# Policy grouping must keep identical geometry and controls at0 and6500cap
# in two distinct refinement groups; no cross-policy pair may be created.
a=copy.deepcopy(next(r for r in report['records']if Path(r['path']).name=='reference-eight-open-500'));b=copy.deepcopy(next(r for r in report['records']if Path(r['path']).name=='reference-eight-open'));c=copy.deepcopy(a);d=copy.deepcopy(b);c['reference_protection_rpm']=d['reference_protection_rpm']=0
policy=compare_refinement([a,b,c,d]);assert len(policy)==2 and{r['reference_protection_rpm']for r in policy}=={0,6500};assert compare_refinement([a,d])==[]
write(R/'sensitivity-policy-checks.json',dict(raw250_metric=metric[0],raw125_metric=metric[1],relative_difference=relative,within_two_percent=False,policy_grouping_0_and6500_separated=True))
# Rail inference correction comes from actual rawADC, production status and
# physical gas traces, not from the configured protection cap alone.
rail={};rail_edge_bytes=[]
for name in('reference-eight-rail','reference-eight-rail-zero-cap'):
 p=B/name;d=read(p/'result.json');window=[e for e,_ in lines(p/'trace.jsonl')if 6000000<=e['time_us']<6250000];prior=[e for e,_ in lines(p/'trace.jsonl')if e['time_us']<6000000][-1]
 assert window and all(e['input_adc_counts']['map']==1023 and e['sensor_input']['map_kpa']==400 for e in window)
 assert {e['dispatcher']['map_kpa']for e in window}=={47} and{e['dispatcher']['boost_cut']for e in window}=={0}
 assert all(e['control']['boost_control']['map_kpa']==47 and e['control']['boost_control']['boost_cut']==0 for e in window)
 rail[name]=dict(reference_protection_rpm=d['stimulus']['reference_protection_rpm'],samples=len(window),window_us=[6000000,6250000],raw_adc_values=sorted({e['input_adc_counts']['map']for e in window}),requested_input_kpa=400,production_map_values=sorted({e['dispatcher']['map_kpa']for e in window}),production_boost_cut_values=sorted({e['dispatcher']['boost_cut']for e in window}),last_pre_rail_production_map_kpa=prior['dispatcher']['map_kpa'],physical_map_range_kpa=[min(e['gas']['map_kpa']for e in window),max(e['gas']['map_kpa']for e in window)],edge_sha256=sha(p/'edges.jsonl'))
 rail_edge_bytes.append((p/'edges.jsonl').read_bytes())
assert rail_edge_bytes[0]==rail_edge_bytes[1],'Changing cap alone changed these rail output histories'
source=(R/'sources/production-sensors.cpp').read_text();assert 'VALID_MAP_MAX=1022U'in source and'return (reading < VALID_MAP_MAX) && (reading > VALID_MAP_MIN);'in source and'return prior;'in source
write(R/'rail-correction.json',dict(cases=rail,raw_output_histories_byte_identical=True,production_source_sha256=sha(R/'sources/production-sensors.cpp'),source_behavior='ADC1023 fails the strict2<reading<1022 MAP validation; validateFilterMapSensorReading returns the previous reading.',correction='The earlier6500rpm-cap explanation was unsupported. Both cap values hold production MAP47kPa and boost_cut0; these cases do not exercise the same overpressure-detection path as the project rail fault.'))
# Diagnostic observer forwards edge execution once, and records deep-copied
# post-edge combustion state. Verify its claims independently against full raw
# ordinary prefixes, including physical gas/controller snapshots and crank/cam.
diagnostics={}
for step,ordinary_name in((250,'reference-eight-open'),(500,'reference-eight-open-500')):
 p=D/('step'+str(step));base=B/ordinary_name;data=read(p/'diagnostic.json');horizon=1650000;matches={}
 for filename in('edges.jsonl','trace.jsonl','trigger-stimuli.jsonl'):
  before=[raw for e,raw in lines(base/filename)if e['time_us']<=horizon and(filename!='edges.jsonl'or e['cause']=='dispatcher')]
  observed=[raw for e,raw in lines(p/filename)if(filename!='edges.jsonl'or e['cause']=='dispatcher')]
  assert observed==before,(step,filename,'observer changed ordinary prefix');matches[filename]=dict(byte_identical=True,rows=len(observed),sha256=hashlib.sha256(b''.join(observed)).hexdigest())
 events=[e for e,_ in lines(p/'combustion-observations.jsonl')];d=read(p/'result.json');edges=[e for e,_ in lines(p/'edges.jsonl')];coils=d['plant_geometry']['coil_channels'];last=-1
 for e in events:
  event=e['event'];stamp=round(event['time_s']*1e6);assert last<=stamp<=horizon;last=stamp;channel=coils[event['cylinder']-1]
  assert any(x['time_us']==stamp and x['ch']==channel and not x['high']for x in edges),'Observation without actual coil fall'
  lam=event['air_mg']/(14.7*event['fuel_mg'])if event['fuel_mg']>1e-9 and event['air_mg']>1e-9 else None
  assert event['lambda_value']==lam;assert event['scheduled_work_j']>=0
 assert len(events)==data['events']and data['observer_sha256']==sha(R/'sources/tools/diagnose_boost_sensitivity.py')
 mode=d['reference_profile']['mode_history'];full=next(e for e in mode if e['sync_status']==2 and e['ignition_span_deg']==720)
 diagnostics[str(step)]=dict(audit=audits['diagnostic-step'+str(step)]['current_input'],matches=matches,events=len(events),event_stream_sha256=sha(p/'combustion-observations.jsonl'),first_full720_observation_us=full['time_us'],mode_history=mode)
# Quantify when a substantial trajectory difference appears; earlier small
# numeric/edge differences exist, so "first separate" is not literal equality.
x={e['time_us']:e for e,_ in lines(D/'step250/trace.jsonl')};y={e['time_us']:e for e,_ in lines(D/'step500/trace.jsonl')};deviation=[dict(time_us=t,rpm250=x[t]['plant_rpm'],rpm500=y[t]['plant_rpm'],relative_rpm=abs(x[t]['plant_rpm']-y[t]['plant_rpm'])/max(abs(x[t]['plant_rpm']),1))for t in sorted(x.keys()&y.keys())]
thresholds={str(k):next((e for e in deviation if e['relative_rpm']>k),None)for k in(.01,.05,.1)}
write(R/'diagnostic-prefix-checks.json',dict(cases=diagnostics,rpm_separation_thresholds=thresholds,qualification='Observer is passive by source inspection and byte-identical ordinary dispatcher/trace/capture prefixes. Step-dependent firing/mixture differences accompany sync-mode transition; this does not isolate a decoder, controller or plant bug. Earlier small numeric differences already exist.'))
print('PASS',len(audits),'audits; exact analysis003 replay; independent125us sensitivity; cap grouping; both rail holds; two full-byte diagnostic prefixes',flush=True)
