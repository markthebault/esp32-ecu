from pathlib import Path
import copy,json,math,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'source-freeze/tools'))
import analyse_boost_runs as A
from engine_geometry import EngineGeometry
p=json.loads((R/'analysis/comparison.json').read_text());base=p['records'][0]
# Recalculate the saved500/250 sensitivity directly from raw trace values.
raw={}
for names in [('ours-eight-open-500','ours-eight-open'),('reference-eight-open-500','reference-eight-open')]:
 metrics=[]
 for name in names:
  folder=R.parent/'expanded-boost-pair-001'/name;d=json.loads((folder/'result.json').read_text());traces=[json.loads(x)for x in(folder/'trace.jsonl').read_text().splitlines()];rows=[e for e in traces if 3000000<=e['time_us']<4000000];n=len(rows)
  metrics.append(dict(last_second_mean_rpm=math.fsum(e['plant_rpm']for e in rows)/n,last_second_mean_map_kpa=math.fsum(e['gas']['map_kpa']for e in rows)/n,last_second_mean_turbo_rad_s=math.fsum(e['gas']['turbo_rad_s']for e in rows)/n,fuel_in_mg=d['before_halt']['ledger']['fuel_in_mg']))
 rel={k:abs(metrics[0][k]-metrics[1][k])/max(abs(metrics[1][k]),1)for k in metrics[0]};matching=next(e for e in p['refinement']if e['controller']==('ours'if names[0].startswith('ours')else'speeduino'))
 assert all(abs(v-matching['relative_difference'][k])<1e-12 for k,v in rel.items());raw[names[0].split('-eight')[0]]=dict(coarse500=metrics[0],fine250=metrics[1],relative_difference=rel,passes_two_percent=all(v<.02 for v in rel.values()))
# Geometry-specific grouping controls use identical dummy measurements so only
# group formation determines the expected number of comparisons.
records=[]
for n in (1,7,8):
 g=EngineGeometry(n,tuple(range(1,n+1)),500*n).summary()
 for step in (500,250):
  d=copy.deepcopy(base);d.update(cylinders=n,plant_geometry=g,strategy='sequential',step_us=step,controller='speeduino');records.append(d)
groups=A.compare_refinement(records);assert len(groups)==3 and{d['cylinders']for d in groups}=={1,7,8}
a=copy.deepcopy(records[-2]);b=copy.deepcopy(records[-1]);b['plant_geometry']=EngineGeometry(8,(1,8,7,6,5,4,3,2),4000).summary();assert A.compare_refinement([a,b])==[]
b=copy.deepcopy(records[-1]);b['plant_geometry']=EngineGeometry(8,tuple(range(1,9)),3800).summary();assert A.compare_refinement([a,b])==[]
# Test aggregate-source guards after the individual packet-verification layer.
original=A.summarize;checks=[]
def mix(name,mutation,should_pass):
 ds=copy.deepcopy(p['records'][:2]);mutation(ds);A.summarize=lambda folder:ds[int(folder.name)]
 try:
  A.run([Path('0'),Path('1')],R/('mix-'+name));passed=True;error=None
 except AssertionError as e:passed=False;error=str(e)
 finally:A.summarize=original
 assert passed==should_pass,(name,passed,error);checks.append(dict(name=name,accepted=passed,diagnostic=error))
mix('shared-source-change',lambda ds:ds[1]['source_hashes'].__setitem__('tools/engine_geometry.py','0'*64),False)
mix('unannounced-omission',lambda ds:ds[0]['source_hashes'].pop('tools/speeduino_profiles_turbo_runtime.py'),False)
mix('own-only-extra',lambda ds:ds[0]['source_hashes'].__setitem__('tools/undeclared.py','0'*64),False)
result=dict(raw_refinement=raw,geometry_group_counts=len(groups),wrong_wiring_and_displacement_not_compared=True,aggregate_source_controls=checks)
(R/'analyzer-probe-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
