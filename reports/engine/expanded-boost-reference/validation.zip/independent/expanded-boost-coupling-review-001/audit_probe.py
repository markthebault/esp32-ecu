"""Independent packet audit probes and negative mutation controls.

Only reviewer-owned packet copies mutate. Project/author packets remain read-only.
"""
from pathlib import Path
import copy,gzip,hashlib,json,math,shutil,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];B=ROOT/'.cache/engine/expanded-boost-pair-001'
sys.path.insert(0,str(R/'source-freeze/tools'))
from verify_boost_engine import verify
from analyse_boost_runs import summarize,run,compare_refinement
from engine_geometry import EngineGeometry,channel_kind

def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def independent(folder):
 d=read(folder/'result.json');g=d['plant_geometry'];n=g['cylinders'];edges=[json.loads(s)for s in (folder/'edges.jsonl').read_text().splitlines()];stop=round(d['duration_s']*1e6);high={};fuel=[0.]*n;rise={};used=set();widths={};before=d['before_halt'];after=d['after_halt'];flow=300*.745/60*1000
 for i,e in enumerate(edges,1):
  ch=e['ch'];used.add(ch);kind=channel_kind(ch);assert e['sequence']==i
  assert type(e['time_us'])is int and 0<=e['time_us']<=stop and type(e['high'])is bool
  assert high.get(ch,False)!=e['high'];high[ch]=e['high']
  if e['high']:rise[ch]=e['time_us']
  else:
   start=rise.pop(ch);widths.setdefault(ch,[]).append(e['time_us']-start)
   if kind and kind[0]=='injector':fuel[kind[1]]+=flow*max(0,(e['time_us']-start)/1e6-.0009)
 assert not rise and not any(high.values())
 assert set(g['injector_channels']+g['coil_channels'])<=used
 errs={}
 for name,z in [('before',before),('after',after)]:
  L=z['ledger'];T=L['turbo_gas'];C=L['boost_valve']['coil']
  computed=dict(fuel_residual_mg=L['fuel_in_mg']-L['burned_mg']-L['unburned_mg']-L['stored_mg'],chemical_residual_j=L['burned_chemical_j']-L['combustion_shaft_j']-L['heat_j']-L['pending_work_j'],shaft_residual_j=L['starter_j']+L['combustion_shaft_j']-L['friction_j']-L['load_j']-L['kinetic_j'],heat_partition_residual_j=L['heat_j']-L['wall_heat_j']-L['exhaust_heat_delivered_j']-L['pending_exhaust_heat_j'],exhaust_fuel_transport_residual_kg=(L['burned_mg']+L['unburned_mg'])/1e6-L['pending_exhaust_fuel_kg']-T['fuel_mass'],coupled_mass_residual_kg=T['inventory_mass_kg']-T['initial_mass_kg']+L['stored_mg']/1e6+L['pending_exhaust_fuel_kg']-L['fuel_in_mg']/1e6-T['boundary_mass'],coupled_energy_residual_j=L['starter_j']+L['burned_chemical_j']+T['boundary_h']-L['friction_j']-L['external_load_j']-L['wall_heat_j']-T['cooler_heat']-T['bearing']-L['kinetic_j']-(T['inventory_energy_j']-T['initial_energy_j'])-L['pending_work_j']-L['pending_exhaust_heat_j']-L['pending_pumping_exchange_j'])
  tolerances=dict(fuel_residual_mg=1e-6,chemical_residual_j=1e-5,shaft_residual_j=1e-5,heat_partition_residual_j=1e-5,exhaust_fuel_transport_residual_kg=1e-10,coupled_mass_residual_kg=1e-9,coupled_energy_residual_j=.02)
  for k,v in computed.items():assert abs(v)<tolerances[k],(folder,name,k,v);assert abs(v-L[k])<tolerances[k],(folder,name,'claimed residual mismatch',k,v,L[k])
  assert abs(L['kinetic_j']-.5*.18*(before['rpm']*math.pi/30)**2)<1e-5
  assert abs(C['source_j']-C['copper_j']-C['flyback_j']-C['disconnect_j']-C['stored_j'])<1e-8
  assert len(z['cylinder_fuel_mg'])==len(z['cylinder_burned_mg'])==len(z['cylinder_shaft_j'])==n
  assert max(abs(a-b)for a,b in zip(fuel,z['cylinder_fuel_mg']))<1e-6,(folder,name,'raw pulse fuel',fuel,z['cylinder_fuel_mg'])
  assert abs(sum(z['cylinder_fuel_mg'])-L['fuel_in_mg'])<1e-6
  assert abs(sum(z['cylinder_burned_mg'])-L['burned_mg'])<1e-6
  assert abs(sum(z['cylinder_shaft_j'])-L['combustion_shaft_j'])<1e-5
  errs[name]=computed
 assert after['high']==[False]*len(after['high']) and after['injector_on']==[None]*n and after['coil_on']==[None]*n and not after['boost_command_high']
 if d['controller']=='speeduino':assert before['dispatcher']==after['reference_boost_status'],'Engine-only fixture halt unexpectedly changed independent boost observation'
 captures=[json.loads(s)for s in (folder/'trigger-stimuli.jsonl').read_text().splitlines()];cams=[e for e in captures if e.get('kind')=='cam'];crank=[e for e in captures if e.get('kind','crank')=='crank'];last=-1
 for e in captures:
  assert type(e['time_us'])is int and last<=e['time_us']<=stop and type(e['delivered'])is bool;last=e['time_us'];assert e.get('kind','crank')in('crank','cam')
  if e.get('kind')=='cam':assert e['cam_angle_deg']>=540 and(e['cam_angle_deg']-540)%720==0
  else:assert 0<=e['slot']<58 and e['tooth_angle_deg']>=0 and e['tooth_angle_deg']%6==0
 assert sum(e['delivered']for e in cams)==d['cam_edges'];assert sum(e['delivered']for e in crank)==d['trigger_edges']
 return dict(edges=len(edges),channels=sorted(used),cylinders=n,raw_pulse_fuel_mg=fuel,max_pulse_us={str(k):max(v)for k,v in widths.items()},independent_residuals=errs,cam_records=len(cams),final_rpm=before['rpm'],final_map_kpa=before['map_kpa'],all_cylinders_burned=all(x>0 for x in before['cylinder_burned_mg']),before_and_after_reference_boost_identical=d['controller']=='speeduino')

names=['ours-eight-open','reference-eight-open','reference-one-batch','ours-eight-open-500','reference-eight-open-500'];results={}
for name in names:
 p=B/name
 if(p/'result.json').exists():results[name]=dict(current_input_audit=verify(p,True),independent=independent(p))
write(R/'independent-audits.json',results)
folders=[B/n for n in names if(B/n/'result.json').exists()];report=run(folders,R/'analysis');write(R/'analysis-summary.json',dict(runs=len(report['records']),refinement=report['refinement'],common_source_count=len(report['common_source_hashes'])))
W=R/'tamper-packet';shutil.copytree(B/'reference-eight-open',W);assert verify(W)['audit_passed'];original={str(p.relative_to(W)):p.read_bytes()for p in W.rglob('*')if p.is_file()};probes=[]
def reset():
 for name,data in original.items():(W/name).write_bytes(data)
def check(name,mutate,analysis=False):
 reset();mutate();caught=None
 try:(summarize if analysis else verify)(W)
 except (AssertionError,KeyError,ValueError,TypeError,FileNotFoundError)as e:caught=type(e).__name__+': '+str(e)
 probes.append(dict(probe=name,rejected=caught is not None,diagnostic=caught));print(name,'REJECTED'if caught else'ACCEPTED',caught or'',flush=True)
def result_change(fn):
 d=read(W/'result.json');fn(d);write(W/'result.json',d)
def manifest_change(fn):
 p=W/'provenance/manifest.json';d=read(p);fn(d);write(p,d);result_change(lambda r:r.update(provenance_manifest_sha256=sha(p)))
def edge_change(fn):
 p=W/'edges.jsonl';d=[json.loads(s)for s in p.read_text().splitlines()];fn(d);p.write_text(''.join(json.dumps(e)+'\n'for e in d))
def captures_change(fn):
 p=W/'trigger-stimuli.jsonl';d=[json.loads(s)for s in p.read_text().splitlines()];fn(d);p.write_text(''.join(json.dumps(e)+'\n'for e in d))
M=read(W/'provenance/manifest.json');generated=W/'provenance'/next(iter(M['reference_runtime']['generated_inputs'].values()))['snapshot']
check('generated snapshot byte change',lambda:generated.write_bytes(generated.read_bytes()+b'\n// altered\n'))
check('generated inventory removal',lambda:manifest_change(lambda m:m['reference_runtime'].update(generated_inputs={})))
check('loaded layout mutation',lambda:manifest_change(lambda m:m['loaded_engine_profile_layout']['coil_channels'].__setitem__(7,8)))
check('upper channel reserved8',lambda:edge_change(lambda es:next(e for e in es if e['ch']==17).__setitem__('ch',8)))
check('upper channel duplicate16',lambda:edge_change(lambda es:next(e for e in es if e['ch']==17).__setitem__('ch',16)))
check('upper post-cut high17',lambda:result_change(lambda d:d['after_halt']['high'].__setitem__(17,True)))
check('upper post-cut coil still active',lambda:result_change(lambda d:d['after_halt']['coil_on'].__setitem__(7,3.999)))
check('post-cut ledger declared residual',lambda:result_change(lambda d:d['after_halt']['ledger'].__setitem__('coupled_energy_residual_j',1)))
check('post-cut entire observation removed',lambda:result_change(lambda d:d.pop('after_halt')))
check('reference native boost state changed',lambda:result_change(lambda d:d['after_halt']['reference_boost_status'].__setitem__('pin_high',0)))
check('post-cut underlying starter energy changed',lambda:result_change(lambda d:d['after_halt']['ledger'].__setitem__('starter_j',d['after_halt']['ledger']['starter_j']+1000)))
check('cam timestamp beyond duration',lambda:captures_change(lambda es:next(e for e in es if e.get('kind')=='cam').__setitem__('time_us',5000000)),analysis=True)
check('cam timestamp negative',lambda:captures_change(lambda es:next(e for e in es if e.get('kind')=='cam').__setitem__('time_us',-1)),analysis=True)
reset();write(R/'tamper-results.json',dict(verifier_sha256=sha(R/'source-freeze/tools/verify_boost_engine.py'),analyzer_sha256=sha(R/'source-freeze/tools/analyse_boost_runs.py'),probes=probes))
print('Audits',len(results),'source common',len(report['common_source_hashes']),'refinements',report['refinement'],flush=True)
