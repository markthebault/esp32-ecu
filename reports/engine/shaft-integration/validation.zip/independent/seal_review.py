from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
load=lambda name:json.loads((R/name).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources=load('revision4-sources.json');integrity=load('final-integrity.json')
maths=load('revision4-probe-results.json');composition=load('revision4-composition-results.json')
transport=load('revision4-intake-transport-results.json');duration=load('revision4-duration-result.json')
oracle=load('revision4-boundary-oracle-results.json');boundary=load('revision4-fractional-integration-results.json')
audits=load('revision4-coupled-audits.json');tamper=load('revision4-event-tamper-results.json')
assessment={
 'status':'passed_scoped_numerical_shaft_intake_and_artifact_review',
 'accepted_revision':4,
 'head_baseline':'bbf7ba55a29932c8fdccad7c7a9c63c79c095c65',
 'scope':'Declared numerical shaft integration, resolved intake/source boundaries, transport/rollback and inventory/event audits. No physical qualification, Speeduino parity, whole-project completion or full coupled convergence is accepted.',
 'open_findings':0,'no_open_findings':True,
 'reviewed_source_sha256':sources,'source_hash_inventory':'revision4-sources.json',
 'derivation':'derivation.json',
 'final_case_path':str((R/'reference-one-batch-v4').resolve()),
 'historical_v3_case_path':str((R/'reference-one-batch-v3').resolve()),
 'reviewer_owned_case_versions_preserved':['reference-one-batch','reference-one-batch-v2','reference-one-batch-v3','reference-one-batch-v4'],
 'reviewer_processes_terminal':True,'process_terminal_flag':True,
 'integrity':integrity,
}
assessment['independent_proof']={
 'analytical_decimal_cases':maths['analytic_cases'],
 'exact_stopping_cases':len(maths['stopping_cases']),
 'independent_RK4_cases':len(maths['independent_ode_cases']),
 'normal_envelope_cases':maths['normal_envelope_cases'],
 'normal_envelope_max_energy_residual_j':maths['normal_envelope_max_energy_residual_j'],
 'smooth_midpoint_refinement':maths['midpoint_refinement'],
 'asymmetric_allocation_cases':composition['allocation_cases'],
 'causal_wall_film_cases':transport['causal_wall_film_cases'],
 'deadtime_controls':len(transport['deadtime_cases']),
 'distinct_power_source_partitions':len(transport['per_source_work']),
 'rollback':transport['rollback'],'original_duration_accumulator':duration,
 'canonical_boundary_oracle':oracle,
 'bounded_actual_integration':{k:boundary[k]for k in('cases','failed','max_solver_calls')},
 'event_tamper_rejections':len(tamper),
 'all_event_tampering_rejected':all(x['rejected']for x in tamper),
}
assessment['findings']=[
 {
  'id':'SHAFT-ASYMPTOTE-001','status':'resolved','found_by':'independent reviewer',
  'problem':'A valid 10 s API interval approaching an exact 20 rad/s equilibrium rounded onto a boundary and called log1p(-1).',
  'resolution':'Exclude linear equilibrium from finite crossing detection; the counterexample now completes with the limiting state.',
  'rejected_evidence':['source-freeze/tools/shaft_dynamics.py','revision1-probe-results.json'],
 },
 {
  'id':'INTAKE-CAUSALITY-001','status':'resolved','found_by':'parent; independently reproduced',
  'problem':'Fuel delivered after intake closing entered the frozen charge. N1/N3/N8 probes trapped 0.88492/1.77030 mg against a 0.000620834 mg pre-closing delivery bound.',
  'resolution':'Split intake, pulse and dead-time boundaries; solve constant-source wall/port transport and freeze charge at the physical root.',
  'rejected_evidence':['source-freeze/tools/engine_research_plant.py','revision1-composition-results.json'],
 },
 {
  'id':'SOURCE-DURATION-001','status':'resolved','found_by':'parent full-case audit; independently isolated',
  'problem':'Revision2 absolute-time subtraction accumulated 1.398057e-7 J error in 1000 one-microsecond calls at 6 s. Parent cases exceeded the unchanged 1e-7 J pumping-exchange gate.',
  'resolution':'Partition original duration in local elapsed coordinates and compute injection/pulse overlaps locally. The accumulator now has zero residual; final coupled gates pass.',
  'rejected_evidence':['revision2-source-freeze/tools/engine_research_plant.py','revision2-duration-counterexample.json','author-revision2-audit-failures.json'],
 },
 {
  'id':'PHYSICAL-EVENT-AUDIT-001','status':'resolved','found_by':'independent reviewer',
  'problem':'Revision2 accepted duplicate zero-work combustion, impossible intake fuel, 1e9 J scheduled work and editable-result downgrade of the event contract.',
  'resolution':'Consume distinct actual falls, replay injector/dead-time/wall/port/frozen charge, bind the contract through provenance/source snapshots and check chemical/work partitions.',
  'rejected_evidence':['revision2-source-freeze/tools/verify_boost_engine.py','revision2-event-tamper-results.json'],
  'closure':'revision4-event-tamper-results.json',
 },
 {
  'id':'NEXT-INTAKE-FRACTION-001','status':'resolved','found_by':'parent N7 regression; independent two-direction counterexamples',
  'problem':'Quotient rounding could return the current closing repeatedly or silently skip the nearest future closing. Independent v3 integration found six repeated cases and four omissions.',
  'resolution':'Recompute canonical phase+720*cycle candidates from the floor cycle until strictly ahead. 648000 exact/adjacent, 100000 random and 2700 integration fixtures have zero failures.',
  'rejected_evidence':['revision3-source-freeze/tools/engine_research_plant.py','author-fractional-boundary-failure.json','fractional-guard-counterexamples.json','revision3-fractional-integration-results.json','author-evidence/shaft-profile-regression-003.log'],
  'note':'The incomplete one-sided +720 proposal was rejected analytically and was not an accepted repository revision.',
 },
]
assessment['final_coupled_audits']=audits
assessment['final_coupled_totals']={
 'cases':len(audits),'reviewer_owned_final_cases':1,
 'snapshots':sum(v['snapshots']for v in audits.values()),
 'transitions':sum(v['edges']for v in audits.values()),
}
assessment['n1_guard_neutrality']=load('n1-guard-neutrality.json')
assessment['convergence_accepted']=False
assessment['convergence_limitation']={
 'unchanged_relative_gate':.02,
 'measured':load('revision4-measured-refinement.json'),
 'statement':'Both final reference checks fail: 500→250 us mean RPM 5.6763% / turbo 7.9245%; 250→125 us mean RPM 7.5957% / turbo 13.8987%. The selected own check passes. No full coupled convergence, uniform order, parity or isolated causal bug claim is accepted.',
}
assessment['author_owned_final_regression_logs']=load('author-final-log-identities.json')
assessment['limits']=[
 'Fixed empirical starter/friction/work-ramp and transport hypotheses were numerically reviewed; this is not engine/actuator calibration.',
 'The normal shaft sweep uses I=.18 kg m², 0..800 rad/s and ≤1 ms. A separate long-interval equilibrium corner was checked.',
 'Constant-power midpoint trajectories are approximate. Pure-shaft refinement does not establish coupled convergence.',
 'Native CPU/IRQ execution time is zero; physical outputs remain inhibited.',
 'No devices, services, flashing or child agents. The reviewer changed no project or upstream sources.',
 'Earlier reviews remain unchanged. Rejected revisions1–3 and their actual source snapshots are retained.',
 'Curated artifacts omit compiled runtime/coverage duplicates and original external model ZIP/MDL payloads. Hashes identify those required external inputs; this is not a standalone complete coupled runtime.',
]
(R/'assessment.json').write_text(json.dumps(assessment,indent=2,allow_nan=False)+'\n')
files=[];excluded=[]
for p in sorted(R.rglob('*')):
 if not p.is_file()or p.name=='whitelist.json':continue
 rel=p.relative_to(R);reason=None
 if any(part.startswith('event-tamper-packet')for part in rel.parts):reason='duplicate mutation workspace'
 elif any('gcov'in part for part in rel.parts)or p.suffix in('.gcda','.gcno','.pyc'):reason='coverage or bytecode'
 elif p.suffix=='.o'or p.read_bytes()[:4]==b'\x7fELF':reason='compiled runtime/object'
 elif p.name=='TCSISimTestbed.zip'or p.suffix=='.mdl':reason='original external model payload'
 if reason:
  if reason not in('coverage or bytecode','duplicate mutation workspace'):
   excluded.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p),'reason':reason})
  continue
 files.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)})
whitelist={
 'scope':assessment['scope'],'file_count':len(files),
 'total_bytes':sum(x['bytes']for x in files),'files':files,
 'identified_excluded_payloads':excluded,
 'excluded_categories':['duplicate mutation workspaces','coverage and bytecode','compiled executables/libraries/objects','original external model ZIP/MDL'],
 'standalone_complete_runtime':False,
}
(R/'whitelist.json').write_text(json.dumps(whitelist,indent=2)+'\n')
print('ASSESSMENT',sha(R/'assessment.json'))
print('OPEN FINDINGS',assessment['open_findings'])
print('FINAL CASE',assessment['final_case_path'])
print('TERMINAL',assessment['reviewer_processes_terminal'])
print('WHITELIST',len(files),'files',whitelist['total_bytes'],'bytes')
