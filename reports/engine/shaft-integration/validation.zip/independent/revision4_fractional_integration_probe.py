from pathlib import Path
import json,math,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];sys.path.insert(0,str(R/'revision4-source-freeze/tools'));sys.path.append(str(ROOT/'tools'))
from engine_research_plant import ResearchPlant
from engine_geometry import EngineGeometry
class SafetyStop(Exception):pass
class Air:
 def __init__(self,g):
  self.geometry=g;self.time=0.;self.initial=dict(map_kpa=100.,temperature_k=298.15,cylinder_air_kg_s=0.,inventory_kg=0.,inventory_j=0.,accumulated_inlet_kg=0.,accumulated_outlet_kg=0.,accumulated_inlet_j=0.,accumulated_outlet_j=0.)
 def step(self,t,h,*args):self.time=t+h;return dict(self.initial)
 def close(self):pass
class Bounded(ResearchPlant):
 def _shaft_interval(self,*args):
  self.probe_calls+=1
  if self.probe_calls>200:raise SafetyStop('Probe safety cap: impossible repeated closing in1us')
  return super()._shaft_interval(*args)
failures=[];cases=0;max_calls=0
for n in range(1,9):
 g=EngineGeometry(n,tuple(range(1,n+1)),500*n)
 for i,tdc in enumerate(g.compression_tdc_deg):
  phase=tdc-180
  for cycle in range(1,26):
   boundary=phase+720*cycle
   for kind,angle,wanted in(('before',math.nextafter(boundary,-math.inf),1),('exact',boundary,0),('after',math.nextafter(boundary,math.inf),0)):
    p=Bounded(air_path=Air(g),geometry=g);p.probe_calls=0;p.rpm=1000;p.angle=angle;p.port_mg[i]=p.fuel_mg=1;p.cylinder_fuel_mg[i]=1;p.starter_j=.5*.18*(1000*math.pi/30)**2;error=None
    try:p.integrate(0,.000001,False,5.)
    except SafetyStop as e:error=str(e)
    observed=len(p.intake_events);max_calls=max(max_calls,p.probe_calls);cases+=1
    valid=error is None and observed==wanted
    if valid and wanted:valid=p.intake_events[0]['cylinder']==i+1 and abs(p.intake_events[0]['shaft_angle_deg']-boundary)<1e-8 and p.charge_mg[i]==1
    if not valid:failures.append(dict(n=n,cylinder=i+1,cycle=cycle,angle=angle,kind=kind,expected_events=wanted,observed_events=observed,guarded_error=error,solver_calls=p.probe_calls))
    p.close()
result=dict(cases=cases,failed=len(failures),max_solver_calls=max_calls,failures=failures,scope='Exact and adjacent physical closing starts; probe-only call cap prevents an owned process from hanging')
(R/'revision4-fractional-integration-results.json').write_text(json.dumps(result,indent=2)+'\n');print('SOURCE REPLAY',cases,'cases',len(failures),'failures;max solver calls',max_calls)

assert not failures,failures
