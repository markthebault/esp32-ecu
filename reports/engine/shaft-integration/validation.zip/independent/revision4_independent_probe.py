"""Independent dimensional/closed-form/RK4 checks of the frozen shaft revision.

No new project tests are rerun. A constant-air algebra fixture checks the
ResearchPlant composition without opening an FMU or controller process.
"""
from pathlib import Path
import decimal,hashlib,json,math,random,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];sys.path.insert(0,str(R/'revision4-source-freeze/tools'));sys.path.append(str(ROOT/'tools'))
from shaft_dynamics import advance_shaft,INTEGRATOR
from engine_research_plant import ResearchPlant
from engine_geometry import EngineGeometry
D=decimal.Decimal;decimal.getcontext().prec=70
pi=D('3.1415926535897932384626433832795028841971693993751058209749445923078164');fric=D('.006')*30/pi;limit=350*pi/30

def closed(w,h,I,a,b):
 w,h,I,a,b=map(lambda x:D(str(x)),(w,h,I,a,b));k=b/I;q=a/b;e=(-k*h).exp();e2=(-2*k*h).exp();z=w-q
 return float(q+z*e),float(q*h+z*(1-e)/k),float(q*q*h+2*q*z*(1-e)/k+z*z*(1-e2)/(2*k))
def energy(w,z,I=.18):return I/2*(z['omega_rad_s']**2-w**2)-z['starter_j']+z['friction_j']+z['load_j']-z['combustion_work_j']
def record(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
exact=[]
for w in (0.,.1,1.,10.,19.999,20.,20.001,30.,float(limit),40.,100.,700.):
 for starter in(False,True):
  for load in(-70.,5.,100.):
   for h in(.000001,.001):
    active=starter and(w<float(limit)or w==float(limit)and -12-load-float(fric)*w<0);a=(55 if active else 0)-12-load;b=float(fric)+(55/float(limit)if active else 0)
    v,theta,sq=closed(w,h,.18,a,b)
    if v<0 or starter and(w-float(limit))*(v-float(limit))<0:continue
    z=advance_shaft(w,h,.18,0,starter,load);expected=dict(omega_rad_s=v,rotation_rad=theta,starter_j=(55*theta-55/float(limit)*sq if active else 0),friction_j=12*theta+float(fric)*sq,load_j=load*theta)
    err={k:z[k]-x for k,x in expected.items()};assert max(map(abs,err.values()))<1e-10,(w,h,starter,load,err);assert abs(energy(w,z))<2e-8
    exact.append(dict(w=w,h=h,starter=starter,load=load,error=err))
# Stops use their exact time, not an assumed full-step mean speed.
stops=[]
for w in(.0001,.1,10.,19.9):
 k=fric/D('.18');a=D(17);wd=D(str(w));ts=(1+fric*wd/a).ln()/k;theta=(wd-a/fric*(1+fric*wd/a).ln())/k
 z=advance_shaft(w,float(ts)+.1,.18,0,False,5);assert z['omega_rad_s']==0 and abs(z['rotation_rad']-float(theta))<1e-11
 assert abs(energy(w,z))<2e-8;stops.append(dict(w=w,stop_s=float(ts),rotation_rad=float(theta),actual=z))
# These published constants define the independent ODE. The implementation's
# quadratic root, speed integral and boundary-time equations are not reused.
def ode(w,T,P,starter,load,N):
 h=T/N;y=[w,0.,0.,0.,0.,0.];limit=350*math.pi/30;f=.006*30/math.pi
 def rate(v):
  q=max(v[0],0.);S=55*max(0.,1-q/limit)if starter else 0.;F=12+f*q;C=P*min(1.,q/20);net=S-F-load+(P/20 if q<=20 else P/q)
  return [max(0.,net/.18)if q==0 else net/.18,q,S*q,F*q,load*q,C]
 for _ in range(N):
  a=rate(y);b=rate([v+h*x/2 for v,x in zip(y,a)]);c=rate([v+h*x/2 for v,x in zip(y,b)]);d=rate([v+h*x for v,x in zip(y,c)])
  y=[v+h*(q+2*r+2*s+t)/6 for v,q,r,s,t in zip(y,a,b,c,d)];y[0]=max(y[0],0.)
 return dict(zip(('omega_rad_s','rotation_rad','starter_j','friction_j','load_j','combustion_work_j'),y))
def integrate(w,T,P,starter,load,N):
 h=T/N;totals={k:0. for k in('rotation_rad','starter_j','friction_j','load_j','combustion_work_j','heat_j')}
 for _ in range(N):
  z=advance_shaft(w,h,.18,P*h,starter,load);assert abs(energy(w,z))<2e-8;w=z['omega_rad_s']
  for k in totals:totals[k]+=z[k]
 return dict(totals,omega_rad_s=w)
L=350*math.pi/30
fixtures=[(0,.003,6000,False,5),(0,.01,50,False,5),(19.95,.01,1000,False,5),(20.05,.003,200,False,100),(L-.01,.003,2000,True,5),(L+.01,.003,50,True,100),(50,.02,10000,False,5),(50,.01,1000,True,60),(1,.02,500,False,100),(35,.001,100000,True,5),(20,.005,20000,False,5),(20,.005,50,True,100),(L,.005,2000,True,5),(L,.005,50,True,100),(.0001,.001,0,False,5),(19.9999,.001,100000,True,5)]
nodes=[]
for w,T,P,starter,load in fixtures:
 expected=ode(w,T,P,starter,load,16384);reference_check=ode(w,T,P,starter,load,8192);ode_error={k:abs(expected[k]-reference_check[k])for k in expected}
 refined=integrate(w,T,P,starter,load,256);difference={k:refined[k]-expected[k]for k in expected}
 assert abs(difference['omega_rad_s'])<.0002 and abs(difference['rotation_rad'])<2e-6,(w,T,P,difference,ode_error)
 assert abs(refined['combustion_work_j']+refined['heat_j']-P*T)<1e-9
 nodes.append(dict(initial_omega=w,duration=T,power=P,starter=starter,load=load,reference_self_check=ode_error,refined_error=difference,expected=expected))
# A smooth constant-power interval exhibits the expected second-order trend.
expected=ode(50,.02,10000,False,5,32768);trend=[]
for n in(20,40,80,160):
 z=integrate(50,.02,10000,False,5,n);trend.append(dict(n=n,omega_error=abs(z['omega_rad_s']-expected['omega_rad_s']),rotation_error=abs(z['rotation_rad']-expected['rotation_rad'])))
assert all(a['omega_error']/b['omega_error']>3.8 for a,b in zip(trend,trend[1:])),trend
# Dense normal-envelope counterexamples include exact/adjacent thresholds.
rng=random.Random(280013);maximum=0.;envelope=[]
for i in range(3000):
 w=(rng.choice([0.,math.nextafter(20.,0),20.,math.nextafter(20.,math.inf),math.nextafter(L,0),L,math.nextafter(L,math.inf)])if i<1000 else rng.uniform(0,800));h=10**rng.uniform(-7,-3);P=0. if i%7==0 else 10**rng.uniform(-5,5);starter=bool(i%2);load=rng.uniform(-70,200)
 z=advance_shaft(w,h,.18,P*h,starter,load);e=abs(energy(w,z));maximum=max(maximum,e);assert e<2e-8 and z['omega_rad_s']>=0 and z['rotation_rad']>=0 and z['heat_j']>=-1e-9
 envelope.append(dict(w=w,h=h,power=P,starter=starter,load=load,energy_residual=e))
# Frozen revision1 asymptote counterexample is preserved as a reported failure.
b=55/L+.006*30/math.pi;bad=dict(omega=20.001,duration=10.,inertia=.18,available_work_j=0.,starter=True,load_nm=55-12-20*b)
try:bad_result=advance_shaft(**bad);failure=None
except Exception as e:bad_result=None;failure=type(e).__name__+': '+str(e)
assert failure is None
assert abs(bad_result['omega_rad_s']-20)<1e-12
assert abs(energy(bad['omega'],bad_result))<2e-8
record(R/'revision4-probe-results.json',dict(method=INTEGRATOR,analytic_cases=len(exact),analytic_errors=exact,stopping_cases=stops,independent_ode_cases=nodes,midpoint_refinement=trend,normal_envelope_cases=len(envelope),normal_envelope_max_energy_residual_j=maximum,normal_envelope=envelope,asymptote_counterexample=dict(inputs=bad,failure=failure),scope='Uniform released work per interval and fixed empirical torque curve; no coupled convergence or physical qualification'))
print('PASS proofs:',len(exact),'analytical,',len(nodes),'ODE,',len(envelope),'normal-envelope cases; resolved asymptote result',flush=True)
