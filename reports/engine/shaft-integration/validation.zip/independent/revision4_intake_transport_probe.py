from pathlib import Path
import copy,decimal,json,math,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];sys.path.insert(0,str(R/'revision4-source-freeze/tools'));sys.path.append(str(ROOT/'tools'))
from engine_research_plant import ResearchPlant
from engine_geometry import EngineGeometry
from boost_research_plant import BoostResearchPlant
D=decimal.Decimal;decimal.getcontext().prec=70;PI=D('3.1415926535897932384626433832795028841971693993751058209749445923078164');b=D('.006')*30/PI;I=D('.18')
class Air:
 def __init__(self,g,flow=.01):
  self.geometry=g;self.time=0.;self.calls=[];self.initial=dict(map_kpa=100.,temperature_k=298.15,cylinder_air_kg_s=flow,inventory_kg=0.,inventory_j=0.,accumulated_inlet_kg=0.,accumulated_outlet_kg=0.,accumulated_inlet_j=0.,accumulated_outlet_j=0.)
 def step(self,t,h,*args):self.calls.append((t,h));self.time=t+h;return dict(self.initial)
 def close(self):pass
def linear(w,h,a):
 h=D(str(h));q=D(str(a))/b;k=b/I;e=(-k*h).exp();w=D(str(w));return q+(w-q)*e,q*h+(w-q)*(1-e)/k
def crossing(w,deg):
 low=D(0);high=D('.001');target=D(str(deg))*PI/180
 for _ in range(150):
  t=(low+high)/2;_,theta=linear(w,t,-17)
  if theta<target:low=t
  else:high=t
 return high
w=1000*PI/30;cross=crossing(w,.001);F=D('3725');cases=[]
for n in(1,3,8):
 for h in(.000125,.00025,.0005):
  for cold in(False,True):
   for initial in(False,True):
    g=EngineGeometry(n,tuple(range(1,n+1)),500*n);p=ResearchPlant(air_path=Air(g),geometry=g);p.rpm=1000.;p.angle=629.999;p.injector_on[0]=0.;p.clt=0 if cold else 85
    before_wall=D(7)if initial else D(0);before_port=D(3)if initial else D(0);discard=D(2)if initial else D(0)
    p.wall_mg[0]=float(before_wall);p.port_mg[0]=float(before_port);p.charge_mg[0]=float(discard);p.fuel_mg=float(before_wall+before_port+discard);p.cylinder_fuel_mg[0]=p.fuel_mg;p.starter_j=.5*.18*float(w)**2
    fraction=D('.45')if cold else D('.05');tau=D('1.5')if cold else D('.05');e=(-cross/tau).exp();expected=before_port+F*cross+before_wall*(1-e)-fraction*F*tau*(1-e)
    p.integrate(.0009,h,False,5.);event=p.intake_events[0];assert len(p.intake_events)==1
    assert abs(p.charge_mg[0]-float(expected))<1e-9,(n,h,cold,initial,p.charge_mg[0],expected)
    assert abs(event['time_s']-(.0009+float(cross)))<1e-13 and abs(event['shaft_angle_deg']-630)<1e-8
    assert p.unburned_mg==float(discard);frozen=p.charge_mg[0];p.integrate(.0009+h,h,False,5.);assert p.charge_mg[0]==frozen
    finalwall=before_wall*(-D(str(2*h))/tau).exp()+fraction*F*tau*(1-(-D(str(2*h))/tau).exp());assert abs(p.wall_mg[0]-float(finalwall))<1e-10
    assert abs(p.ledger()['fuel_residual_mg'])<1e-10
    cases.append(dict(n=n,h=h,cold=cold,seeded_fuel=initial,expected_charge_mg=float(expected),actual_charge_mg=frozen,event=event,wall_error_mg=p.wall_mg[0]-float(finalwall)))
    p.close()
# A source that activates after the intake boundary cannot feed its frozen charge.
dead=[]
for n in(1,3,8):
 g=EngineGeometry(n,tuple(range(1,n+1)),500*n);p=ResearchPlant(air_path=Air(g),geometry=g);p.rpm=1000;p.angle=629.999;p.injector_on[0]=0.;p.integrate(.0008,.0005)
 assert p.charge_mg[0]==0 and p.port_mg[0]>0;assert len(p.intake_events)==1 and p.intake_events[0]['time_s']<.0009
 assert any(abs(t-.0009)<1e-15 for t,h in p.air.calls);dead.append(dict(n=n,charge_mg=p.charge_mg[0],post_close_port_mg=p.port_mg[0],event=p.intake_events[0]));p.close()
# Three overlapping work sources have distinct starts/ends. Low-speed torque
# is linear on each physical interval, giving exact per-cylinder integrals.
streams=[(D(0),D('.0002'),D(100)),(D(0),D('.0006'),D(200)),(D('.00035'),D('.0009'),D(300))];points=sorted({D(0),D('.001')}|{x for s,e,p in streams for x in(s,e)});expected_work=[D(0)]*3;speed=D(10);angle=D(0)
for lo,hi in zip(points,points[1:]):
 active=[p if s<=(lo+hi)/2<e else D(0)for s,e,p in streams];speed,theta=linear(speed,hi-lo,sum(active)/20-17);angle+=theta
 for i,power in enumerate(active):expected_work[i]+=power*theta/20
powers=[]
for partition in(1,2,4,8):
 g=EngineGeometry(3,(1,2,3),1500);p=ResearchPlant(air_path=Air(g,0),geometry=g);p.rpm=10*30/math.pi;p.angle=70.;p.combustions=[dict(start=float(s),end=float(e),rate=float(q),remaining=float((e-s)*q),cylinder=i)for i,(s,e,q)in enumerate(streams)];total=sum(float((e-s)*q)for s,e,q in streams);p.cylinder_scheduled_work_j=[float((e-s)*q)for s,e,q in streams];p.burned_mg=p.fuel_mg=total/44;p.cylinder_burned_mg=[q/44 for q in p.cylinder_scheduled_work_j];p.cylinder_fuel_mg=list(p.cylinder_burned_mg);p.burned_chemical_j=total;p.starter_j=.5*.18*10**2
 for j in range(partition):p.integrate(j*.001/partition,.001/partition,False,5.)
 assert max(abs(v-float(q))for v,q in zip(p.cylinder_shaft_j,expected_work))<1e-10;assert abs(p.rpm-float(speed)*30/math.pi)<1e-10;assert abs((p.angle-70)*math.pi/180-float(angle))<1e-12
 assert abs(p.ledger()['chemical_residual_j'])<1e-10 and abs(p.ledger()['shaft_residual_j'])<1e-10
 L=p.ledger();assert abs(L['scheduled_combustion_work_j']-L['combustion_shaft_j']-L['pending_work_j']-L['shaft_conversion_heat_j'])<1e-10
 powers.append(dict(partitions=partition,shaft_by_cylinder=p.cylinder_shaft_j,expected_by_cylinder=list(map(float,expected_work)),shaft_speed_rad_s=p.rpm*math.pi/30));p.close()
# Inject a failure only once a complete gas subinterval and its intake event
# have occurred; the live composition must retain every original inventory.
p=BoostResearchPlant(geometry=EngineGeometry(1,(1,),500));p.rpm=1000;p.angle=629.999;p.starter_j=.5*.18*(1000*math.pi/30)**2;before=copy.deepcopy(p.ledger());physical={k:copy.deepcopy(getattr(p,k))for k in('rpm','angle','fuel_mg','wall_mg','port_mg','charge_mg','intake_events','combustions','heat_pulses')};state=list(p.air.state);cls=type(p.air);original=cls.rates;calls=0;failure_time=None
class Controlled(Exception):pass
def fail(self,*args,**kwargs):
 global calls,failure_time
 calls+=1
 if self.time>0:
  failure_time=self.time;raise Controlled('after completed first physical subinterval')
 return original(self,*args,**kwargs)
cls.rates=fail
try:
 try:p.integrate(0,.0005)
 except Controlled:pass
 else:raise AssertionError('Fault not reached')
finally:cls.rates=original
print('ROLLBACK DIAGNOSTIC',calls,failure_time,flush=True)
assert calls>=5 and failure_time is not None and failure_time>0
assert p.ledger()==before and p.air.state==state and p.air.time==0 and all(getattr(p,k)==v for k,v in physical.items());p.close()
result=dict(causal_wall_film_cases=len(cases),causal_wall_film=cases,deadtime_cases=dead,per_source_work=powers,rollback=dict(rate_calls=calls,failure_after_time_s=failure_time,all_original_inventories_unchanged=True),scope='Independent analytical intake/source/rollback fixtures; not engine reachability or coupled convergence')
(R/'revision4-intake-transport-results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(cases),'causal wall-film fixtures,',len(dead),'dead-time cases,',len(powers),'per-source power partitions, rollback after closing')
