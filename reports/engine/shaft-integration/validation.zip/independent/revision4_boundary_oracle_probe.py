from pathlib import Path
import json,math,random,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'revision4-source-freeze/tools'))
from engine_geometry import EngineGeometry
from engine_research_plant import next_intake_closing
cases=0
for n in range(1,9):
 for tdc in EngineGeometry(n,tuple(range(1,n+1)),500*n).compression_tdc_deg:
  phase=tdc-180
  for k in range(1,6001):
   boundary=phase+720*k
   for angle in(math.nextafter(boundary,-math.inf),boundary,math.nextafter(boundary,math.inf)):
    expected=min(phase+720*j for j in(k-1,k,k+1,k+2)if phase+720*j>angle)
    actual=next_intake_closing(angle,phase);assert actual==expected,(n,phase,k,angle,actual,expected);cases+=1
rng=random.Random(170720);random_cases=0
for _ in range(100000):
 phase=rng.choice([v-180 for n in range(1,9)for v in EngineGeometry(n,tuple(range(1,n+1)),500*n).compression_tdc_deg]);angle=rng.uniform(0,4320720);k=math.floor((angle-phase)/720)
 expected=min(phase+720*j for j in(k-1,k,k+1,k+2)if phase+720*j>angle);assert next_intake_closing(angle,phase)==expected;random_cases+=1
result=dict(exact_adjacent_cases=cases,random_cases=random_cases,wrong_next_closings=0,angle_range_degrees=[0,4320720],scope='Actual frozen helper versus independently enumerated canonical physical boundaries')
(R/'revision4-boundary-oracle-results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',cases,'exact/adjacent plus',random_cases,'random oracle cases')
