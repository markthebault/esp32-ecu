from pathlib import Path
import decimal,json,math,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];sys.path.insert(0,str(R/'source-freeze/tools'));sys.path.append(str(ROOT/'tools'))
from engine_research_plant import ResearchPlant
from engine_geometry import EngineGeometry
D=decimal.Decimal;decimal.getcontext().prec=70;PI=D('3.1415926535897932384626433832795028841971693993751058209749445923078164')
class Air:
 def __init__(self,g,flow=0.):
  self.geometry=g;self.time=0.;self.initial=dict(map_kpa=100.,temperature_k=298.15,cylinder_air_kg_s=flow,inventory_kg=0.,inventory_j=0.,accumulated_inlet_kg=0.,accumulated_outlet_kg=0.,accumulated_inlet_j=0.,accumulated_outlet_j=0.)
 def step(self,t,dt,*unused):self.time=t+dt;return dict(self.initial)
 def close(self):pass
cases=[]
for n in range(1,9):
 g=EngineGeometry(n,tuple(range(1,n+1)),500*n);phases=sorted((x-180)%720 for x in g.compression_tdc_deg);start_angle=(phases[0]+((phases[1]if n>1 else phases[0]+720)-phases[0])/2)%720
 for omega in(0.,10.,19.99,20.,350*math.pi/30,100.):
  for starter in(False,True):
   for load in(-20.,5.,100.):
    for powered in(False,True):
     p=ResearchPlant(air_path=Air(g),geometry=g);p.rpm=omega*30/math.pi;p.angle=start_angle
     weights=[.01*(i+1)if powered else 0. for i in range(n)];total=math.fsum(weights)
     p.combustions=[dict(start=0.,end=.001,rate=w/.001,remaining=w,cylinder=i)for i,w in enumerate(weights)if w]
     p.burned_chemical_j=total;p.burned_mg=p.fuel_mg=total/44;p.cylinder_fuel_mg=p.cylinder_burned_mg=[w/44 for w in weights];p.starter_j=.5*.18*omega**2
     p.integrate(0.,.001,starter,load);L=p.ledger();assert not p.combustions
     assert abs(L['chemical_residual_j'])<1e-10 and abs(L['shaft_residual_j'])<2e-8
     assert abs(math.fsum(p.cylinder_shaft_j)-L['combustion_shaft_j'])<1e-12
     if total:
      ratios=[v/w for v,w in zip(p.cylinder_shaft_j,weights)];assert max(ratios)-min(ratios)<1e-12
     assert L['shaft_integrator'].startswith('piecewise_exact_linear_and_energy_midpoint')
     cases.append(dict(n=n,initial_omega=omega,starter=starter,load=load,powered=powered,chemical_residual_j=L['chemical_residual_j'],shaft_residual_j=L['shaft_residual_j'],shaft_by_cylinder=p.cylinder_shaft_j,shaft_work_j=L['combustion_shaft_j'],heat_j=L['heat_j']))
     p.close()
# A new independent causality fixture starts an injector exactly at the end
# of its0.9ms opening delay; no delivery predates the prepared initial state.
# Closing occurs0.001deg later. The maximum new trapped mass is bounded by
# flow * the independently solved exact linear shaft crossing time.
causality=[]
for n in(1,3,8):
 for h in(.00025,.0005):
  g=EngineGeometry(n,tuple(range(1,n+1)),500*n);p=ResearchPlant(air_path=Air(g,.01),geometry=g);p.rpm=1000.;p.angle=629.999;p.injector_on[0]=.0001
  w=D(1000)*PI/30;I=D('.18');b=D('.006')*30/PI;a=D(-17);k=b/I;q=a/b;target=PI*D('.001')/180;lo=D(0);hi=D(str(h))
  for _ in range(150):
   t=(lo+hi)/2;theta=q*t+(w-q)*(1-(-k*t).exp())/k
   if theta<target:lo=t
   else:hi=t
  crossing=float(hi);p.starter_j=.5*.18*float(w)**2;p.integrate(.001,h,False,5.);bound=300*.745/60*1000*crossing
  causality.append(dict(n=n,h=h,independent_closing_after_s=crossing,maximum_new_trapped_fuel_mg=bound,actual_charge_mg=p.charge_mg[0],causal_bound_met=p.charge_mg[0]<=bound+1e-10,total_fuel_mg=p.fuel_mg,port_mg=p.port_mg[0],wall_mg=p.wall_mg[0]))
  p.close()
(R/'revision1-composition-results.json').write_text(json.dumps(dict(allocation_cases=len(cases),allocations=cases,intake_causality=causality),indent=2)+'\n');print('PASS',len(cases),'asymmetric per-cylinder allocation/energy fixtures;',sum(not x['causal_bound_met']for x in causality),'retained intake causality failures')
