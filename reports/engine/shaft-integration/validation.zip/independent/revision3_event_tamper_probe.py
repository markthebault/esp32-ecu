from pathlib import Path
import copy,hashlib,json,shutil,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'revision3-source-freeze/tools'));sys.path.append(str(R.parents[2]/'tools'))
from verify_boost_engine import verify
W=R/'event-tamper-packet-v3';shutil.copytree(R/'reference-one-batch-v3',W);original={str(p.relative_to(W)):p.read_bytes()for p in W.rglob('*')if p.is_file()};out=[]
def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def reset():
 for n,b in original.items():(W/n).write_bytes(b)
def change(name,fn):
 p=W/name;rows=[json.loads(x)for x in p.read_text().splitlines()];fn(rows);p.write_text(''.join(json.dumps(e)+'\n'for e in rows));d=read(W/'result.json');d['physical_event_files'][name]=dict(events=len(rows),sha256=hashlib.sha256(p.read_bytes()).hexdigest());write(W/'result.json',d)
def result(fn):d=read(W/'result.json');fn(d);write(W/'result.json',d)
def check(name,fn):
 reset();fn();error=None
 try:verify(W)
 except (AssertionError,ValueError,KeyError,TypeError)as e:error=type(e).__name__+': '+str(e)
 out.append(dict(name=name,rejected=error is not None,error=error));print(name,'REJECT'if error else'ACCEPT',error or'',flush=True)
check('raw intake bytes',lambda:(W/'intake-events.jsonl').write_bytes((W/'intake-events.jsonl').read_bytes()+b'\n'))
check('intake phase',lambda:change('intake-events.jsonl',lambda rows:rows[0].__setitem__('shaft_angle_deg',rows[0]['shaft_angle_deg']+1)))
check('intake air basis',lambda:change('intake-events.jsonl',lambda rows:rows[0].__setitem__('trapped_air_mg',rows[0]['trapped_air_mg']+1)))
check('intake clock',lambda:change('intake-events.jsonl',lambda rows:rows[0].__setitem__('time_s',-1)))
check('combustion no coil fall',lambda:change('combustion-events.jsonl',lambda rows:rows[0].__setitem__('time_s',rows[0]['time_s']+.000003)))
check('combustion mixture',lambda:change('combustion-events.jsonl',lambda rows:rows[-1].__setitem__('lambda_value',999)))
check('physical event inventory deleted',lambda:result(lambda d:d.__setitem__('physical_event_files',{})))
check('duplicate zero-work combustion',lambda:change('combustion-events.jsonl',lambda rows:rows.insert(next(i for i,x in enumerate(rows)if x['scheduled_work_j']==0),copy.deepcopy(next(x for x in rows if x['scheduled_work_j']==0)))))
check('intake fuel plus1000mg',lambda:change('intake-events.jsonl',lambda rows:rows[0].__setitem__('trapped_fuel_mg',rows[0]['trapped_fuel_mg']+1000)))
check('scheduled work plus1e9J',lambda:change('combustion-events.jsonl',lambda rows:next(x for x in rows if x['scheduled_work_j']>0).__setitem__('scheduled_work_j',1e9)))
def strip(d):
 d['physical_event_files']={}
 for k in ('before_halt','after_halt'):d[k]['ledger']['intake_integration']='legacy'
check('event audit downgraded to legacy via result',lambda:result(strip))
reset();(R/'revision3-event-tamper-results.json').write_text(json.dumps(out,indent=2)+'\n')

assert all(x["rejected"]for x in out),out
