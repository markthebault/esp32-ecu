from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent;ROOT=R.parents[2];sys.path.insert(0,str(R/'revision3-source-freeze/tools'));sys.path.append(str(ROOT/'tools'))
from engine_research_plant import ResearchPlant
from engine_geometry import EngineGeometry
class Accumulator:
 def __init__(self,g):
  self.geometry=g;self.time=6.;self.energy_j=0.;self.rate=1e6;self.initial=dict(map_kpa=100.,temperature_k=298.15,cylinder_air_kg_s=0.,inventory_kg=0.,inventory_j=0.,accumulated_inlet_kg=0.,accumulated_outlet_kg=0.,accumulated_inlet_j=0.,accumulated_outlet_j=0.)
 def step(self,t,dt,*unused):self.energy_j+=self.rate*dt;self.time=t+dt;return dict(self.initial)
 def close(self):pass
g=EngineGeometry(1,(1,),500);a=Accumulator(g);p=ResearchPlant(air_path=a,geometry=g)
for i in range(1000):p.integrate((6000000+i)/1e6,.000001,False,5.)
result=dict(calls=1000,source_j_per_call=1,original_duration_s=.000001,absolute_start_s=6,expected_energy_j=1000.,delivered_energy_j=a.energy_j,absolute_energy_residual_j=a.energy_j-1000.,scope='Constant-source duration accumulator isolates interval arithmetic, not a physically reachable engine case')
(R/'revision3-duration-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

assert abs(result["absolute_energy_residual_j"])<1e-12
