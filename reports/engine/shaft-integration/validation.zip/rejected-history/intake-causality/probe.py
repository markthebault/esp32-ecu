"""Authored valve-closing causality fixture, not an engine reachability run."""
import hashlib,json,math,sys
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools'))
from engine_geometry import EngineGeometry
from engine_research_plant import ResearchPlant
from shaft_dynamics import advance_shaft

class ConstantAir:
 def __init__(self,geometry):
  self.geometry=geometry;self.time=.001
  self.initial=dict(map_kpa=100.,temperature_k=298.15,cylinder_air_kg_s=.01,
   inventory_kg=0.,inventory_j=0.,accumulated_inlet_kg=0.,accumulated_outlet_kg=0.,
   accumulated_inlet_j=0.,accumulated_outlet_j=0.)
 def step(self,t,dt,*args):self.time=t+dt;return dict(self.initial)
 def close(self):pass

records=[]
for dt in (.0005,.00025):
 g=EngineGeometry(1,(1,),500);p=ResearchPlant(air_path=ConstantAir(g),geometry=g)
 p.rpm=1000.;p.angle=629.999;p.edge(0,True,0.)
 omega=p.rpm*math.pi/30;low=0.;high=dt;needed=math.pi*.001/180
 for _ in range(60):
  middle=(low+high)/2
  if advance_shaft(omega,middle,.18,0.,False,5.)['rotation_rad']<needed:low=middle
  else:high=middle
 flow=300*.745/60*1000;causal_max=flow*high
 p.integrate(.001,dt,False,5.)
 records.append(dict(step_s=dt,intake_crossing_after_s=high,causal_max_trapped_new_fuel_mg=causal_max,
  actual_trapped_fuel_mg=p.charge_mg[0],fuel_delivered_over_entire_step_mg=p.fuel_mg,
  causal_bound_met=p.charge_mg[0]<=causal_max+1e-10))
data=dict(scope=__doc__,records=records,passed=all(r['causal_bound_met']for r in records),
 sources={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()for n in
 ('tools/engine_research_plant.py','tools/shaft_dynamics.py',str(Path(__file__).relative_to(ROOT)))})
(Path(__file__).parent/'result.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2));raise SystemExit(not data['passed'])
