"""Freeze this schema6 checkpoint with exact payload hashes. No device access."""
import argparse,gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path,PurePosixPath
R=Path('/home/mark/persospace/esp32-ecu');W=R/'.cache/engine'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def safe(name):
 p=PurePosixPath(name)
 if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe name')
 return p.as_posix()
VERIFY='''"""Verify frozen schema6 payloads; optional current project source comparison."""
import argparse,gzip,hashlib,json,tarfile
from pathlib import Path,PurePosixPath
def sha(b):return hashlib.sha256(b).hexdigest()
def safe(name):
 p=PurePosixPath(name)
 if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe payload path')
 return p.as_posix()
def verify(root,repo=None):
 m=json.loads((root/'artifact-manifest.json').read_text());names={r['path'] for r in m['files']}
 assert len(names)==len(m['files'])
 assert not any(p.is_symlink() for p in root.rglob('*'))
 assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}==names|{'artifact-manifest.json'}
 for r in m['files']:
  b=(root/safe(r['path'])).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
 for archive in m['archives']:
  rows={r['path']:r for r in archive['payloads']};assert len(rows)==len(archive['payloads'])
  with tarfile.open(root/safe(archive['path']),'r:gz') as tar:
   members=tar.getmembers();assert len(members)==len(rows) and {x.name for x in members}==set(rows)
   for member in members:
    assert member.isfile() and safe(member.name)==member.name
    b=tar.extractfile(member).read();r=rows[member.name];assert len(b)==r['bytes'] and sha(b)==r['sha256'],member.name
 s=json.loads((root/'summary.json').read_text());assert s['checks_passed'] and not s['full_speeduino_parity'] and not s['actual_RF'] and not s['flashed']
 if repo:
  for name,digest in s['source_hashes'].items():assert sha((repo/safe(name)).read_bytes())==digest,name
 return {'passed':True,'archives':len(m['archives']),'payloads':sum(len(a['payloads']) for a in m['archives']),'live_sources_checked':bool(repo)}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path);a=p.parse_args();print(json.dumps(verify(Path(__file__).resolve().parent,a.repo)))
'''
def run(review,output):
 review=review.resolve();accept=read(review/'review.json');assert accept['accepted'] is True and accept['open_findings']==[]
 whitelist=read(review/'archive-whitelist.json');assert Path(whitelist['root']).resolve()==review
 for row in whitelist['files']:
  b=(review/safe(row['path'])).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 build=W/'schema6-firmware-002';b=read(build/'summary.json');assert b['exit_code']==0 and b['source_inputs_unchanged'] and b['default_cache_unchanged'] and not b['flashed']
 assert all(x['current_index_in_flash_rodata'] for x in b['embedded_UI'])
 assert (W/'schema6-radio-007/2.log').read_text().strip()=='radio_service_checks 6972'
 ui=read(W/'schema6-browser-003/ui-tests.json');assert ui['passed'] and len(ui['checks'])==13 and not ui['page_errors']
 interop=read(W/'schema6-interop-003.json');assert interop['passed'] and interop['sender_fairness']['all_six_metadata_channels']
 for filename,count in [('schema6-python-regressions-001.log',212),('schema6-final-radio-python.log',89)]:
  text=(W/filename).read_text();assert 'Ran '+str(count)+' tests in ' in text and text.rstrip().endswith('OK')
 envs=b['environments'];assert set(envs)=={'compact_a3_web','compact_n16r8_web','compact_n16r8_flex_dev'}
 firmware=[]
 for e in envs:
  isr=read(W/('schema6-isr-'+e)/'closure.json');engine=read(W/('schema6-engine-'+e)/'audit.json');usb=read(W/('schema6-usb-'+e+'.json'))
  assert isr['passed_static_placement'] and engine['passed'] and usb['exclusive_usb']
  elf=build/'build'/e/'firmware.elf';image=elf.with_suffix('.bin');assert sha(elf.read_bytes())==isr['elf_sha256']==engine['elf_sha256']==usb['elf_sha256']
  assert sha(image.read_bytes())==engine['binary_sha256']==usb['binary_sha256']
  firmware.append(dict(environment=e,binary_bytes=image.stat().st_size,binary_sha256=sha(image.read_bytes()),elf_sha256=sha(elf.read_bytes()),physical_policy=engine['policy']))
 base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert base=='74a186d721b50c6eec1fc7a89e80fda082c0dea8'
 changed=subprocess.check_output(['git','diff','--name-only','-z','HEAD'],cwd=R).split(b'\0')
 names={x.decode() for x in changed if x};assert all(n.startswith(('firmware/','web/','config/','scripts/','tools/','docs/')) for n in names)
 names.add('firmware/main/web_assets.hpp');names.update(accept['source_hashes'])
 hashes={n:sha((R/safe(n)).read_bytes()) for n in sorted(names)}
 assert all(hashes[n]==v for n,v in accept['source_hashes'].items())
 assert ui['source_sha256']['web/index.html']==hashes['web/index.html']
 assert b['web_index_sha256']==hashes['web/index.html'] and b['generated_assets_sha256']==hashes['firmware/main/web_assets.hpp']
 output.mkdir(parents=True,exist_ok=False);archives=[]
 def archive(name,items):
  rows=[];seen=set()
  with (output/name).open('xb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0,compresslevel=9) as z,tarfile.open(fileobj=z,mode='w') as tar:
   for path,value in sorted(items,key=lambda x:x[0]):
    path=safe(path);assert path not in seen;seen.add(path)
    if isinstance(value,Path):assert not value.is_symlink();value=value.read_bytes()
    info=tarfile.TarInfo(path);info.size=len(value);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(value));rows.append(dict(path=path,bytes=len(value),sha256=sha(value)))
  archives.append(dict(path=name,payloads=rows))
 source=[('project/'+n,R/n) for n in sorted(names)]+[('reconstruct.patch',subprocess.check_output(['git','diff','--binary','HEAD'],cwd=R)),('base-commit.txt',(base+'\n').encode())]
 archive('sources.tar.gz',source)
 archive('independent-review.tar.gz',[(r['path'],review/r['path']) for r in whitelist['files']]+[('archive-whitelist.json',review/'archive-whitelist.json')])
 validation=[]
 for directory,label in [(W/'schema6-radio-007','actual-radio-service'),(W/'schema6-browser-003','browser-radio')]:
  validation += [(label+'/'+p.name,p) for p in directory.iterdir() if p.is_file() and p.suffix in ('.json','.bin','.log','.png')]
 validation += [('regressions/'+n,W/n) for n in ('schema6-python-regressions-001.log','schema6-final-radio-python.log','schema6-native-suite.log','schema6-interop-003.json')]
 validation += [('build/'+n,build/n) for n in ('summary.json','sources-before.json','sources-after.json','build.log','embed-web.log')]
 validation += [('package-schema6.py',Path(__file__))]
 for e in envs:
  validation += [('static/'+e+'/'+n,W/(prefix+e)/n) for prefix,n in [('schema6-isr-','closure.json'),('schema6-engine-','audit.json')]]
  validation.append(('static/'+e+'/usb.json',W/('schema6-usb-'+e+'.json')))
 archive('validation.tar.gz',validation)
 images=[]
 for e in envs:
  images += [(e+'/firmware.bin',build/'build'/e/'firmware.bin'),(e+'/firmware.elf.gz',build/'elf-archives'/(e+'.elf.gz'))]
 archive('inhibited-firmware.tar.gz',images)
 summary=dict(scope='coherent_boost_radio_software',checks_passed=True,base_commit=base,source_hashes=hashes,independent_review_sha256=sha((review/'review.json').read_bytes()),independent_review_accepted=True,firmware=firmware,final_radio_service_assertions=6972,broader_python_tests=212,final_relevant_python_tests=89,browser_radio_checks=13,broader_native_suite='Passed before final scheduler/status fixes; final dedicated service suite6972 and review supersede its radio portion.',slot_model=interop['sender_fairness'],full_speeduino_parity=False,actual_RF=False,screen_application=False,flashed=False,physical_qualification=False,coupled_turbo_wastegate_comparison=False)
 (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(output/'verify.py').write_text(VERIFY)
 (output/'README.md').write_text('''# Authenticated boost telemetry checkpoint

Schema6 carries BASE, FLEX and BOOST as one authenticated observation. Only the complete set may update display/liveness or be acknowledged. All three parts preserve the original source/time context; both extensions bind the full BASE MAC. Schemas1..5 retain exact bytes for representable legacy samples.

Independent review found metadata starvation. Reserving both metadata and sensor slots fixes it; a metadata-only mutation still fails. Final review also verifies the corrected no-ACK sentinel, clock-order readback and browser states. The15s/four-peer native sender model supplies all6 metadata channels,30 sensor and30 metadata frames per peer,80 complete observations per peer and a maximum200ms assembly span within the250ms deadline.

Validation includes6972 final actual-service assertions under ASan/UBSan, independent codec/state/clock and legacy-byte comparisons,212 broader Python tests,89 final relevant tests,13 Chrome radio checks and the reviewer's current boost-page rerun. The earlier full native suite is included; final service/review evidence supersedes its radio portion. Three fresh Linux firmware builds pass static engine-inhibition, interrupt-placement and USB-ownership audits. Build001 is superseded by build002 after the ACK-age fix; no rejected/intermediate firmware is shipped here.

The archives contain changed/reviewed sources plus the base-Git patch, bounded independent evidence, validation and three inhibited firmware images/ELFs. All payloads are individually hashed. `summary.json` binds source hashes and accepted image identities. The frozen review retains the original starvation witness and the failing partial fix.

```sh
python3 reports/engine/boost-radio/verify.py
python3 reports/engine/boost-radio/verify.py --repo .
```

The second command additionally compares the current project sources; future engineering may legitimately differ. Reconstruct sources from base commit74a186d721b50c6eec1fc7a89e80fda082c0dea8 and `reconstruct.patch`, or overlay the archived project files, then use the reproduction commands in `docs/espnow-engine.md`.

This is an ECU sender/reference receiver contract. No actual screen application, RF/RTOS timing measurement, device flashing, physical valve actuation or vehicle/environmental qualification is provided. Physical engine outputs remain inhibited. Coupled turbo/wastegate simulation, protected boost hardware, desktop tuning acceptance and broader Speeduino feature coverage remain unfinished.
''')
 files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(output.iterdir()) if p.is_file()]
 (output/'artifact-manifest.json').write_text(json.dumps(dict(scope=summary['scope'],files=files,archives=archives),indent=2)+'\n')
 subprocess.run(['python3','-B',str(output/'verify.py'),'--repo',str(R)],check=True,cwd=R)
 print(json.dumps(dict(output=str(output),source_files=len(hashes),archive_bytes=sum((output/a['path']).stat().st_size for a in archives))))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('review',type=Path);p.add_argument('output',type=Path);a=p.parse_args();run(a.review,a.output)
