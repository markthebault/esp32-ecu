"""Independent review probes against frozen schema6 sources. No RF/device."""
import ctypes,hashlib,hmac,itertools,json,math,random,struct,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'sources/tools'))
from engine_receiver import EngineReceiver,derive_engine_key
from boost_radio import engine_boost_fragment
from espnow_protocol import header
LMK=bytes(range(16));BOOT=bytes(range(16,32));SESSION=7;MAC='02:11:22:33:44:55'
KEY=derive_engine_key(LMK,BOOT,SESSION)
counts={};details={}
def expect(value,kind):
 counts[kind]=counts.get(kind,0)+1
 assert value,kind
def signed(p,key=KEY):return bytes(p[:-32])+hmac.digest(key,p[:-32],'sha256')
def reply(request,counter,features,schema,floor=50,sent=5010000,boot=BOOT):
 b=header(8,108)+struct.pack('<II16sIII16sQQ',SESSION,counter,request[16:32],features,schema,0,boot,floor,sent)
 return b+hmac.digest(LMK,b,'sha256')
def receiver(schema=6):
 r=EngineReceiver(MAC,LMK,schema=schema);q=r.query(100,b'a'*16);r.receive_reply(reply(q,0,0,0,sent=5000000),MAC,110)
 q=r.update(True,120,b'b'*16);r.receive_reply(reply(q,1,1,schema),MAC,125);return r
def changed(parts,index,offset,fmt,value):
 p=list(parts);raw=bytearray(p[index]);struct.pack_into('<'+fmt,raw,offset,value);p[index]=signed(raw)
 if index==0:
  for n in (1,2):
   raw=bytearray(p[n]);raw[24:56]=p[0][-32:];p[n]=signed(raw)
 return tuple(p)
def fails(call,kind):
 try:call()
 except ValueError:expect(True,kind)
 else:expect(False,kind)
def complete(r,parts,start=140,step=10,order=(0,1,2)):
 result=None
 for i,n in enumerate(order):result=r.receive(parts[n],MAC,start+i*step)
 return result

def main():
 parts=tuple((OUT/'current'/f'schema6-{n}.bin').read_bytes() for n in range(3))
 expect(tuple(map(len,parts))==(250,232,144),'native_sizes')
 for p in parts:expect(hmac.compare_digest(p[-32:],hmac.digest(KEY,p[:-32],'sha256')),'native_full_mac')
 for p in parts[1:]:expect(p[24:56]==parts[0][-32:],'native_base_binding')
 for order in itertools.permutations(range(3)):
  r=receiver()
  for n,index in enumerate(order):
   data=r.receive(parts[index],MAC,140+n*10)
   expect((data is not None)==(n==2),'assembly_orders')
   expect((r.latest is not None)==(n==2),'assembly_publish')
   if n<2:fails(r.acknowledgement,'assembly_no_ack')
  expect(r.status(160)['boost_observation_fresh'],'assembly_fresh')
 # An independent schedule model tracks the first copy of each part. No
 # partial arrival or exact duplicate may create a completed observation.
 rng=random.Random(6192)
 for trial in range(400):
  r=receiver();schedule=list(range(3))+[rng.randrange(3) for _ in range(rng.randrange(6))];rng.shuffle(schedule);seen=set();when=140
  for index in schedule:
   if len(seen)==3:break
   seen.add(index);value=r.receive(parts[index],MAC,when)
   expect((value is not None)==(len(seen)==3),'random_schedule_model');when+=rng.randrange(1,20)
 for missing in range(3):
  r=receiver();indices=[i for i in range(3) if i!=missing]
  for n in indices:r.receive(parts[n],MAC,140)
  r.receive(parts[indices[0]],MAC,380)
  expect(r.partials[51]['started_ms']==140,'absolute_assembly_deadline')
  fails(lambda:r.receive(parts[missing],MAC,391),'expired_fragment_retired')
  expect(r.latest is None and r.last_packet==50,'expired_no_publication');fails(r.acknowledgement,'expired_no_ack')
 for index in range(3):
  r=receiver();r.receive(parts[index],MAC,140);p=bytearray(parts[index]);p[-33]^=1
  fails(lambda:r.receive(signed(p),MAC,150),'signed_conflict')
  expect(r.retired_through==51 and r.last_packet==50,'conflict_retires_without_ack')
 # Unsigned tamper cannot consume partial capacity or alter last complete.
 r=receiver()
 for part in parts:
  for n in range(len(part)):
   p=bytearray(part);p[n]^=128;fails(lambda:r.receive(p,MAC,140),'tamper_bytes')
   expect(not r.partials and r.last_packet==50,'tamper_no_state')
 # Replay/query: changing a repeated proposal must fail after refreshing the
 # sequence floor and sender clock. An unknown control age remains unknown.
 p=changed(parts,0,28,'I',2**32-1);flags=struct.unpack_from('<H',p[0],22)[0]&~32768;p=changed(p,0,22,'H',flags)
 r=receiver();complete(r,p);q=r.query(200,b'c'*16);r.receive_reply(reply(q,1,1,6,floor=51,sent=5090000),MAC,210)
 p=changed(parts,0,12,'Q',52)
 for n in (1,2):p=changed(p,n,12,'Q',52)
 p=changed(p,0,92,'Q',5100000)
 complete(r,p,start=220)
 expect(r.status(240)['boost_control_age_ms'] is None,'unknown_age_survives_query')
 # Metadata changes are not time refresh. Fully bound and signed altered
 # boost counters cannot change a repeated source proposal.
 p=changed(p,0,12,'Q',53)
 for n in (1,2):p=changed(p,n,12,'Q',53)
 p=changed(p,0,92,'Q',5110000);p=changed(p,2,88,'Q',1)
 fails(lambda:complete(r,p,start=250),'immutable_boost_across_query')
 # Independent physical-clock model: derive source age from a source clock
 # anywhere within the documented2% drift assumption; use the local clock
 # for actual fragment delay, then demand a conservative bound on completion.
 for n in range(1200):
  gp_rate=rng.uniform(.98,1.02);esp_rate=rng.uniform(.98,1.02);actual_history=rng.uniform(0,2000)
  sender_elapsed=rng.uniform(0,40);wire_elapsed=round(sender_elapsed*esp_rate*1000)
  query_delay=rng.uniform(0,10);wait=rng.uniform(0,150);now=math.ceil(120+query_delay+sender_elapsed+wait)
  age=math.ceil(actual_history*gp_rate);p=changed(parts,0,24,'I',age);p=changed(p,0,28,'I',age)
  flags=struct.unpack_from('<H',p[0],22)[0];flags=flags|32768 if age<=1000 else flags&~32768;p=changed(p,0,22,'H',flags)
  p=changed(p,0,92,'Q',5010000+wire_elapsed);r=receiver();d=complete(r,p,start=now,step=0)
  actual=actual_history+now-(120+query_delay+sender_elapsed)
  expect(d['bounded_control_age_ms']+1e-7>=actual,'clock_bound_model')
 # Compare native C++ valid_record to the Python fragment validator on the
 # same F32s, bools, counters and finite numeric edge cases. Signed frames here
 # are deliberate trusted-producer negative controls.
 lib=ctypes.CDLL(str(OUT/'libreview.so'));fn=lib.valid_boost
 fn.argtypes=[ctypes.POINTER(ctypes.c_float),ctypes.c_uint64,ctypes.c_uint64,ctypes.c_uint32,ctypes.c_uint,ctypes.c_uint,ctypes.c_uint];fn.restype=ctypes.c_int
 def compare(values,updates,events,flags,reason,mode,bits):
  vals=(ctypes.c_float*8)(*values);expected=bool(fn(vals,updates,events,flags,reason,mode,bits))
  raw=bytearray(parts[2]);struct.pack_into('<8f',raw,56,*vals);struct.pack_into('<QQIBBB',raw,88,updates,events,flags,reason,mode,bits)
  try:engine_boost_fragment(signed(raw),KEY);actual=True
  except ValueError:actual=False
  expect(actual==expected,'cpp_python_record_parity')
 for bits,mode,reason,flags in itertools.product(range(8),range(4),range(18),(0,1,2,3,4,5,7,255,256,511,1024,2047,2048,2**32-1)):
  values=[40,-1000,150,50,-350,-500,-600,100] if bits&1 else [math.nan]*8
  compare(values,0,0,flags,reason,mode,bits)
 limits={0:(-1e-6,0,100,100.00001,math.nan,math.inf),1:(-1e20,1e20,math.nan,math.inf),2:(49.999996,50,400,400.00003,math.nan),3:(-1e-6,0,100,100.00001,math.nan),4:(-400.00003,-400,400,400.00003,math.nan),5:(-1e20,1e20,math.nan,math.inf),6:(-1e20,1e20,math.nan,math.inf),7:(-1e20,1e20,math.nan,math.inf)}
 for index,items in limits.items():
  for v in items:
   values=[40,-1000,150,50,-350,-500,-600,100];values[index]=v;compare(values,2**64-1,2**53+9,7,1,1,3)
 details['qualified_scope']='Frozen native sources and reference Python decoder only; no RTOS/ESP-IDF transport, RF, physical LED/valve or screen application.'
 details['counts']=counts;details['passed']=True
 (OUT/'independent-probes.json').write_text(json.dumps(details,indent=2)+'\n');print(json.dumps(details,indent=2))
if __name__=='__main__':main()
