#include "ecu/engine_radio_flex.hpp"
#include <openssl/hmac.h>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
using namespace ecu;
namespace w=radio::wire;
static unsigned checks=0;
static void require(bool value){++checks;assert(value);}
static std::array<std::uint8_t,32> key{};
static bool mac(const std::uint8_t*p,unsigned n,std::uint8_t*out){unsigned written=0;return HMAC(EVP_sha256(),key.data(),32,p,n,out,&written)&&written==32;}
static engine::RuntimeSample sample(){
 engine::RuntimeSample r;r.sequence=(UINT64_C(1)<<53)+1;r.control_us=1000000;r.sampled_us=995000;
 r.tune_revision=7;r.sensor_revision=9;r.source=engine::DataSource::Synthetic;
 r.flags=engine::Present|engine::StorageOk|engine::InputsFresh|engine::CrankSynced|engine::ProposedActive|engine::Pump;
 r.state=3;r.input_valid=255;r.inputs={2000,80,50,85,25,1,14,5};
 r.proposals={2000,80,1,25,4,3,1,300,1,1,1,1,30,0};return r;
}
extern "C" int valid_boost(const float*values,std::uint64_t updates,std::uint64_t events,std::uint32_t flags,unsigned reason,unsigned mode,unsigned bits){
 boost::Record b;for(unsigned n=0;n<8;++n)b.values[n]=values[n];b.counters={updates,events};b.flags=flags;b.reason=reason;b.mode=mode;
 b.available=bits&1;b.pressure_enabled=bits&2;b.inhibit_engine=bits&4;return boost::valid_record(b);
}
static void file(const std::string&name,const std::uint8_t*p,unsigned n){std::ofstream f(name,std::ios::binary);require(f.good());f.write(reinterpret_cast<const char*>(p),n);require(f.good());}
int main(int argc,char**argv){
 require(argc==2);const std::string dir=argv[1];const std::uint8_t lmk[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};std::uint8_t nonce[16];for(unsigned n=0;n<16;++n)nonce[n]=n+16;
 const auto transcript=w::engine_key_transcript(nonce,7);unsigned length=0;require(HMAC(EVP_sha256(),lmk,16,transcript.data(),transcript.size(),key.data(),&length)&&length==32);
 for(unsigned schema=1;schema<=5;++schema){
  auto r=sample();std::uint8_t bytes[250]{};
  if(schema<5){require(w::engine_body(bytes,r,7,51,10,8,UINT32_MAX,5030000,schema));const auto n=w::engine_frame_body_size(schema);require(mac(bytes,n,bytes+n));file(dir+"/legacy-"+std::to_string(schema)+".bin",bytes,n+32);}
  else {w::EnginePair pair;require(pair.prepare(r,7,51,10,8,UINT32_MAX,UINT32_MAX,5030000,mac));unsigned part=0;while(pair.pending()){file(dir+"/legacy-5-"+std::to_string(part++)+".bin",pair.data(),pair.size());pair.submitted();}require(part==2);}
 }
#ifdef REVIEW_SCHEMA6
 auto r=sample();r.inputs[engine::MapKpa]=150;r.boost_control.available=r.boost_control.pressure_enabled=true;r.boost_control.mode=1;
 r.boost_control.flags=boost::Enabled|boost::PressureValid|boost::ValveAllowed;r.boost_control.reason=1;r.boost_control.values={40,40,NAN,40,NAN,0,0,0};
 require(w::engine_schema_supports(6,r));for(unsigned s=1;s<=5;++s)require(!w::engine_schema_supports(s,r));
 for(unsigned failure=1;failure<=3;++failure){
  w::EnginePair pair;unsigned calls=0;
  require(!pair.prepare(r,7,51,10,8,UINT32_MAX,UINT32_MAX,5030000,[&](const auto*p,unsigned n,auto*out){return ++calls!=failure&&mac(p,n,out);},6));
  require(!pair.pending()&&pair.data()==nullptr&&pair.size()==0&&calls==failure);
  require(pair.prepare(r,7,52,10,8,UINT32_MAX,UINT32_MAX,5030000,mac,6));pair.cancel();require(!pair.pending());
 }
 w::EnginePair pair;require(pair.prepare(r,7,51,10,8,UINT32_MAX,UINT32_MAX,5030000,mac,6));require(sizeof(pair)<=672);
 require(!pair.expired(5280000)&&pair.expired(5280001)&&pair.expired(5029999));
 unsigned part=0;while(pair.pending()){
  const auto n=pair.size();std::vector<std::uint8_t> before(pair.data(),pair.data()+n);const auto sequence=pair.sequence();
  r.boost_control.counters[0]++;r.boost_control.values[0]=90;
  require(!pair.prepare(r,7,52,1,1,1,UINT32_MAX,5030100,mac,6));require(pair.sequence()==sequence&&std::memcmp(before.data(),pair.data(),n)==0);
  file(dir+"/schema6-"+std::to_string(part)+".bin",pair.data(),n);const bool complete=pair.submitted();require(complete==(part==2));++part;
 }
 require(part==3&&pair.prepared_us()==5030000&&pair.sequence()==51&&!pair.submitted());
 std::cout<<"pending_bytes "<<sizeof(pair)<<"\n";
#endif
 std::cout<<"native_checks "<<checks<<"\n";
}
