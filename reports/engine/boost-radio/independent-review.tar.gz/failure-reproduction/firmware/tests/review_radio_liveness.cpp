// Actual sender/handlers/health/JSON execute against a deterministic native
// API model. The infinite RTOS task, SDK, RF and physical LED do NOT execute.
#include "../main/espnow.cpp"
#include <fstream>
#include <iostream>
namespace ecu::engine_target {std::uint64_t clock_us(){return fake_now;}}
inline ecu::status_led::Pattern requested_pattern=ecu::status_led::Pattern::Problem;
namespace ecu::board_status {
void request(status_led::Pattern p){requested_pattern=p;}
cJSON*snapshot(){auto*j=cJSON_CreateObject();cJSON_AddBoolToObject(j,"available",false);cJSON_AddStringToObject(j,"source","native_api_model_no_i2c");return j;}
}
namespace r=ecu::radio;namespace w=ecu::radio::wire;
static unsigned checks=0;static std::string output_directory;
static void verify(bool v,const char*expression,unsigned line){++checks;if(!v)std::cerr<<line<<": "<<expression<<'\n';assert(v);}
#define check(v) verify((v),#v,__LINE__)
static void at(std::int64_t t){fake_radio_now=t;fake_now=21000+t-5000000;}
static void finish(){r::sent(nullptr,ESP_NOW_SEND_SUCCESS);}
static void binary(const char*name,const std::vector<std::uint8_t>&bytes){if(!output_directory.empty()){std::ofstream f(output_directory+"/"+name,std::ios::binary);check(f.good());f.write(reinterpret_cast<const char*>(bytes.data()),bytes.size());}}
static void fixture(const char*name){r::update_view(r::radio_fault(5000000));auto*j=r::status();check(j);char*text=cJSON_Print(j);check(text);cJSON_Delete(j);if(!output_directory.empty()){std::ofstream f(output_directory+"/"+name+".json");check(f.good());f<<text<<'\n';}cJSON_free(text);}
static ecu::engine::RuntimeSample captured(){
 using namespace ecu;engine::Tune t;t.flex_fuel.input_confirmed=true;t.flex_fuel.correction.enabled=true;t.flex_fuel.capture.cycles=2;
 flex::Capture c(t.flex_fuel.capture);c.edge(1000,true,flex::Source::TargetCapture);
 for(unsigned n=1;n<=2;++n){c.edge(1000+n*10000-3000,false,flex::Source::TargetCapture);c.edge(1000+n*10000,true,flex::Source::TargetCapture);}
 engine::Inputs in;in.rpm=0;in.map_kpa=50;in.tps_pct=10;in.clt_c=85;in.iat_c=25;in.lambda=1;in.battery_v=14;in.sensor_v=5;in.sensors_valid=in.lambda_ready=true;in.sampled_us=21000;in.flex_sample={c.observe(21000),t.flex_fuel.capture,t.revision};
 engine::Controller controller;auto output=controller.step(t,in,21000);auto data=engine::synthetic_data(t,in,output,1,21000);data.source=engine::DataSource::Target;return data;
}
static void publish(ecu::engine::RuntimeSample data){
 ecu::web::Sample s;s.engine=data;s.adc_ok=true;s.raw.fill(2000);s.raw[7]=3723;ecu::config::Config c;std::array<double,6> filtered{};filtered.fill(2.7);
 r::publish(s,c,filtered);check(xQueueReceive(r::samples,&r::live,0)==pdTRUE);
}
static std::vector<std::uint8_t> capability(unsigned counter,unsigned schema,unsigned nonce){
 std::vector<std::uint8_t> p(76);w::header(p.data(),w::Capabilities,76);w::u32(p.data()+8,counter?r::session_id.load():0);w::u32(p.data()+12,counter);std::memset(p.data()+16,nonce,16);w::u32(p.data()+32,counter?1:0);w::u32(p.data()+36,schema);check(r::hmac(r::saved.peers[0].key,p.data(),44,p.data()+44));return p;
}
static void input(const std::vector<std::uint8_t>&p){r::Rx packet;packet.size=p.size();std::memcpy(packet.mac,r::saved.peers[0].mac,6);std::memcpy(packet.data,p.data(),p.size());r::handle(packet);}
static std::vector<std::uint8_t> acknowledgement(std::uint64_t seq){std::vector<std::uint8_t> p(56);w::header(p.data(),w::EngineAck,56);w::u32(p.data()+8,r::session_id);w::u64(p.data()+12,seq);check(r::hmac_key(r::streams[0].key.data(),32,p.data(),24,p.data()+24));input(p);return p;}
static void sensor_acknowledgement(std::uint32_t seq){std::vector<std::uint8_t> p(52);w::header(p.data(),w::Ack,52);w::u32(p.data()+8,r::session_id);w::u32(p.data()+12,seq);check(r::hmac(r::saved.peers[0].key,p.data(),20,p.data()+20));input(p);}
static void slot(unsigned round,std::int64_t sampled_time=-1){const auto n=fake_datagrams.size();r::service_peer(0,round,sampled_time<0?r::now():sampled_time);check(fake_datagrams.size()<=n+1);}
int main(){
 for(unsigned schema:{5U,6U}){
  r::start();at(5000000);r::radio_ok=r::storage_ok=true;r::saved=r::Store{};r::streams[0]=r::StreamPeer{};r::sending=false;
  auto&peer=r::saved.peers[0];const std::uint8_t screen[]={2,170,187,204,221,238};std::memcpy(peer.mac,screen,6);std::strcpy(peer.name,"Independent review");for(unsigned n=0;n<16;++n)peer.key[n]=n;
  r::session_id=0x12345678;esp_fill_random(r::engine_nonce,16);esp_wifi_get_mac(0,r::own);r::engine_sequence=0;check(r::prepare_stream(0));
  ecu::engine::Tune tune;ecu::engine::Controller controller;ecu::engine::Inputs in;in.rpm=2000;in.map_kpa=50;in.tps_pct=20;in.clt_c=85;in.iat_c=25;in.lambda=1;in.battery_v=14;in.sensor_v=5;in.sensors_valid=in.lambda_ready=in.synced=in.phase_synced=true;
  auto fresh=[&](unsigned seq){in.sampled_us=fake_now;auto result=controller.step(tune,in,fake_now);auto data=ecu::engine::synthetic_data(tune,in,result,seq,fake_now);data.source=ecu::engine::DataSource::Target;publish(data);};
  fresh(1);input(capability(1,schema,1));slot(2);finish();const auto begin=fake_datagrams.size();
  for(unsigned round=2;round<302;++round){at(5000000+50000*(round-1));fresh(round);slot(round);if(r::sending)finish();}
  std::array<unsigned,13> counts{};for(unsigned n=begin;n<fake_datagrams.size();++n)++counts[fake_datagrams[n].bytes[5]];
  std::cout<<"schema "<<schema<<" metadata "<<counts[5]<<" sensor "<<counts[4]<<" base "<<counts[9]<<" flex "<<counts[11]<<" boost "<<counts[12]<<"\n";
 }
}
