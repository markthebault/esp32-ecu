function radioLinkText(p){
 if(typeof p?.connected!=='boolean')return 'Link status unknown';
 if(!Number.isSafeInteger(p.last_ack_ms)||p.last_ack_ms< -1||p.connected&&(p.last_ack_ms<0||p.last_ack_ms>=3000)||!p.connected&&p.last_ack_ms>=0&&p.last_ack_ms<3000)return 'Link acknowledgement unknown';
 return p.connected?'Link connected':'Link offline';
}
function radioEnginePeerText(p){
 const unknown='Engine observation ACK status unknown';
 if(typeof p?.engine_telemetry!=='boolean')return unknown;
 if(!p.engine_telemetry)return 'legacy sensor stream';
 const schema=p.engine_schema;if(!Number.isInteger(schema)||schema<1||schema>6)return unknown;
 const parts=schema===6?3:schema===5?2:1;
 if(typeof p.engine_connected!=='boolean'||!Number.isInteger(p.last_engine_ack_ms)||p.last_engine_ack_ms< -1||p.last_engine_ack_ms>9007199254740991||p.engine_parts_per_observation!==parts||typeof p.engine_pair_pending!=='boolean'||typeof p.engine_base_submitted!=='boolean'||p.engine_base_submitted&&(!p.engine_pair_pending||schema<5)||p.engine_pair_pending&&schema<5)return unknown;
 const next=p.engine_next_part??(schema<6?(p.engine_pair_pending?(p.engine_base_submitted?'flex':'base'):'none'):null);
 if(!p.engine_pair_pending&&next!=='none'||p.engine_pair_pending&&(!p.engine_base_submitted?next!=='base':next!=='flex'&&(schema!==6||next!=='boost')))return unknown;
 if(p.engine_connected&&(p.last_engine_ack_ms<0||p.last_engine_ack_ms>=3000)||!p.engine_connected&&p.last_engine_ack_ms>=0&&p.last_engine_ack_ms<3000)return unknown;
 const pending=!p.engine_pair_pending?'':next==='base'?' / observation submission pending':next==='flex'?(schema===6?' / base submitted, flex and boost submission pending':' / base submitted, flex submission pending'):' / base and flex submitted, boost submission pending';
 return 'engine schema'+schema+' / '+parts+' datagram'+(parts>1?'s':'')+' per observation / '+(p.engine_connected?'complete engine observation ACK '+p.last_engine_ack_ms+' ms ago':p.last_engine_ack_ms<0?'no complete engine observation acknowledged':'engine observation ACK is stale')+pending;
}
