"""Check the review's exact software evidence; --root also binds a live tree."""
import argparse,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent
def read(name):return json.loads((P/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify(root=None):
 hashes=read('source-hashes.json')
 for name,digest in hashes.items():
  assert sha(P/'sources'/name)==digest,name
  if root is not None:assert sha(root/name)==digest,'Live source differs: '+name
 rows=read('commands.json');required={'core-run','boost-test-run','service-run','liveness-run','mutation-run','independent-probes'}
 assert required<=set(row['label'] for row in rows)
 for row in rows:assert (row['returncode']!=0)==row['expected_failure'],row['label']
 for name,expected in (('core-run.log','native_checks 61'),('boost-test-run.log','engine_radio_boost_checks 62'),('service-run.log','radio_service_checks 6972')):assert expected in (P/name).read_text()
 positive=(P/'liveness-run.log').read_text();negative=(P/'mutation-run.log').read_text()
 assert 'schema 6 metadata 30 sensor 30 base 80 flex 80 boost 80 channels 63' in positive
 assert 'schema 6 metadata 30 sensor 0' in negative and 'counts[5]==30&&counts[4]==30&&channels==63' in negative
 fairness=read('service/schema6-fairness.json');assert fairness['passed'] and fairness['all_six_metadata_channels'] and fairness['maximum_assembly_us']==200000
 assert read('interop.json')['passed'] and read('independent-probes.json')['passed'] and read('ui-state-review.json')['passed']
 assert read('ui-state-review.json')['link_checks']==90 and read('ui-state-review.json')['engine_checks']==716
 for name,count in (('browser-boost-current/ui-tests.json',7),('external-evidence/radio-browser/ui-tests.json',13)):
  report=read(name);assert report['passed'] and len(report['checks'])==count
  for source,digest in report['source_sha256'].items():assert hashes[source]==digest,source
 radio=read('external-evidence/radio-browser/ui-tests.json')
 for name,digest in radio['fixture_sha256'].items():assert sha(P/'external-evidence/radio-fixtures'/name)==digest,name
 assert read('browser-fixture-equivalence.json')['passed']
 assets=read('asset-verification.json');header=(P/'sources/firmware/main/web_assets.hpp').read_text();assert assets['passed'] and assets['asset_count']==15
 for item in assets['assets']:
  source=P/'sources'/item['path'];assert sha(source)==item['sha256'];pattern=r'inline constexpr char '+item['name']+r'\[\]=R"ECU_ASSET\((.*?)\)ECU_ASSET";'
  match=re.search(pattern,header,re.S);assert match and match.group(1)==source.read_text(),item['path']
 result=dict(passed=True,source_files=len(hashes),live_tree_checked=root is not None,scope='Frozen software review and source-bound native/browser evidence only; no RF/device or physical qualification.')
 (P/'verification-final.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path);args=parser.parse_args();verify(args.root.resolve() if args.root else None)
