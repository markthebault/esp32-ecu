// Independent allowed-state table for the frozen UI functions.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
vm.runInThisContext(fs.readFileSync(__dirname+'/ui-functions.js','utf8'));
let linkChecks=0,engineChecks=0;
const ages=[-2,-1,0,1,2999,3000,3001,Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER+1,Infinity,NaN,null,undefined,'0',.1];
for(const connected of [true,false,null,undefined,'true',1])for(const age of ages){
 const allowed=typeof connected==='boolean'&&Number.isSafeInteger(age)&&age>=-1&&(connected?age>=0&&age<3000:age===-1||age>=3000);
 const result=radioLinkText({connected,last_ack_ms:age});assert.strictEqual(!result.includes('unknown'),allowed);linkChecks++;
 if(allowed)assert.strictEqual(result,connected?'Link connected':'Link offline');
}
function peer(schema){return {engine_telemetry:true,engine_schema:schema,engine_parts_per_observation:schema===6?3:schema===5?2:1,engine_connected:false,last_engine_ack_ms:-1,engine_pair_pending:false,engine_base_submitted:false,engine_next_part:'none'};}
for(let schema=1;schema<=6;schema++)for(const pending of [false,true])for(const submitted of [false,true])for(const next of ['none','base','flex','boost',null,undefined,'unknown']){
 const p={...peer(schema),engine_pair_pending:pending,engine_base_submitted:submitted,engine_next_part:next};
 let state=next;
 // Missing legacy optional status is supported; schema6 always requires it.
 if(state==null&&schema<6)state=pending?(submitted?'flex':'base'):'none';
 const known=schema<5?!pending&&!submitted&&state==='none':(!pending&&!submitted&&state==='none')||(pending&&!submitted&&state==='base')||(pending&&submitted&&(state==='flex'||schema===6&&state==='boost'));
 const result=radioEnginePeerText(p);assert.strictEqual(!result.includes('unknown'),known,JSON.stringify(p));engineChecks++;
 if(known)assert(result.includes('engine schema'+schema));
}
for(let schema=1;schema<=6;schema++)for(const connected of [true,false,null,undefined,'true',1])for(const age of ages){
 const allowed=typeof connected==='boolean'&&Number.isSafeInteger(age)&&age>=-1&&(connected?age>=0&&age<3000:age===-1||age>=3000);
 const result=radioEnginePeerText({...peer(schema),engine_connected:connected,last_engine_ack_ms:age});assert.strictEqual(!result.includes('unknown'),allowed);engineChecks++;
}
for(const patch of [{engine_telemetry:'true'},{engine_schema:0},{engine_schema:7},{engine_parts_per_observation:2},{engine_pair_pending:'false'},{engine_base_submitted:'false'},{engine_next_part:null},{engine_next_part:'boost'}]){
 assert(radioEnginePeerText({...peer(6),...patch}).includes('unknown'));engineChecks++;
}
const report={passed:true,link_checks:linkChecks,engine_checks:engineChecks,scope:'Frozen JavaScript state functions in Node only; actual Chrome evidence is separately source-bound.'};
fs.writeFileSync(__dirname+'/ui-state-review.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
