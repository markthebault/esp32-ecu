Independent schema6 telemetry review, final supersession.

The reviewed sender, receiver, contract and diagnostics pass the archived software checks. R1 is closed: both metadata and sensor slots remain bounded. The final sender also fixes the parent-discovered unknown/reversed ACK-age readback. No RF, target execution, physical LED/valve/screen or vehicle qualification was performed. Firmware builds and linked-image placement audits are the parent's separate evidence.

The initial failed scheduler is preserved under `failure-reproduction/`, with its initial review and output under `previous-review/`. The fixed sender sends30 metadata and30 sensor packets over300 per-peer slots; the original sends0 metadata. The deliberate metadata-only mutation still sends0 sensor packets and fails the acceptance assertion. All three cases use real sender code against native SDK API models, with fresh real controller publications.

`source-hashes.json` binds the final source snapshot. `supersession/` preserves the earlier embedded-assets snapshot and review provenance. Final generated assets were independently compared with all15 source inputs. Native tests do not depend on the embedded-assets header; current Chrome reports bind the final page and controls.

To verify the archive, run `python3 -B verify_final.py`, optionally with `--root /path/to/esp32-ecu` to compare a checkout. For execution replay, copy `sources/`, `legacy/`, `mutation/`, `review.cpp`, `probes.py` and `build_review.py` to an empty scratch directory and run `python3 -B build_review.py`. GCC, OpenSSL and the project's installed cJSON source are required. The tiny legacy baseline packets were independently generated from commit74a186d721b50c6eec1fc7a89e80fda082c0dea8 in the initial review. `node ui-state-review.js` reruns the independent UI allowed-state table.

Only entries in `archive-whitelist.json` belong in the bounded review archive. Intermediate compiler binaries and object files are intentionally excluded; source, commands, logs, native wire fixtures, browser results and screenshots are retained.
