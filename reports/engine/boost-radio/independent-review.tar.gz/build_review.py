"""Rebuild frozen-source review checks. Needs GCC, OpenSSL and installed cJSON."""
import json,os,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;F=P/'sources/firmware';C=Path.home()/'.platformio/packages/framework-espidf/components/json/cJSON'
FLAGS=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'];ROWS=[]
def run(label,cmd,expected_failure=False):
 with (P/(label+'.log')).open('xb') as log:r=subprocess.run(list(map(str,cmd)),stdout=log,stderr=subprocess.STDOUT,cwd=P)
 ROWS.append(dict(label=label,command=list(map(str,cmd)),returncode=r.returncode,expected_failure=expected_failure));(P/'commands.json').write_text(json.dumps(ROWS,indent=2)+'\n')
 if expected_failure:assert r.returncode!=0,label
 else:assert r.returncode==0,label
def main():
 for name in ('native','current','service','liveness'): (P/name).mkdir()
 run('cjson-build',['cc',*FLAGS,'-c',C/'cJSON.c','-o',P/'native/cjson.o'])
 common=['g++','-std=c++17',*FLAGS,'-Wall','-Wextra','-Werror','-pedantic','-I'+str(F/'include')]
 run('core-build',[*common,'-DREVIEW_SCHEMA6=1',P/'review.cpp','-lcrypto','-o',P/'current/probe'])
 run('core-run',[P/'current/probe',P/'current'])
 run('codec-library-build',['g++','-std=c++17','-O2','-shared','-fPIC','-I'+str(F/'include'),P/'review.cpp','-lcrypto','-o',P/'libreview.so'])
 equal=[]
 for old in (P/'legacy').glob('*.bin'):
  assert old.read_bytes()==(P/'current'/old.name).read_bytes(),old.name;equal.append(old.name)
 (P/'legacy-byte-parity.json').write_text(json.dumps(dict(passed=True,files=equal,baseline_commit='74a186d721b50c6eec1fc7a89e80fda082c0dea8',baseline_provenance='../boost-radio-independent-review-001/legacy-byte-parity.json'),indent=2)+'\n')
 run('boost-test-build',[*common,F/'tests/engine_radio_boost_test.cpp','-o',P/'native/boost-test'])
 run('boost-test-run',[P/'native/boost-test'])
 service=[*common,'-pthread','-DECU_COMPACT_A3=1','-DECU_SELECTED_N16R8=1','-DECU_FLEX_G38_DRAFT=1','-I'+str(C),'-I'+str(F/'tests/radio_fakes'),'-I'+str(F/'tests/target_fakes')]
 run('service-build',[*service,F/'tests/radio_service_test.cpp',P/'native/cjson.o','-lcrypto','-o',P/'native/service-test'])
 run('service-run',[P/'native/service-test',P/'service'])
 run('liveness-build',[*service,'-Wno-unused-function',F/'tests/review_radio_liveness.cpp',P/'native/cjson.o','-lcrypto','-o',P/'native/liveness-test'])
 run('liveness-run',[P/'native/liveness-test'])
 run('mutation-build',[*service,'-Wno-unused-function',P/'mutation/firmware/tests/review_radio_liveness.cpp',P/'native/cjson.o','-lcrypto','-o',P/'native/mutation-test'])
 run('mutation-run',[P/'native/mutation-test'],expected_failure=True)
 text=(P/'mutation-run.log').read_text();assert 'schema 6 metadata 30 sensor 0' in text and 'counts[5]==30&&counts[4]==30&&channels==63' in text,'Mutation failed for another reason'
 run('independent-probes',[sys.executable,'-B',P/'probes.py'])
 print('Frozen source, actual sender, liveness, negative mutation and independent probes passed')
if __name__=='__main__':main()
