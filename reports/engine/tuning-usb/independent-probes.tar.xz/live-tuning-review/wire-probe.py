import sys,importlib.util,copy,json,struct,zlib,threading,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
root=Path.cwd();sys.path.insert(0,str(root/'tools'));base=root/'.cache/engine/live-tuning-review'
spec=importlib.util.spec_from_file_location('own003_reviewed',base/'reviewed-engine_protocol.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
class Store:
 def __init__(self):self.tune=copy.deepcopy(p.DEFAULT);self.lock=threading.RLock();self.last_run=None;self.saves=0;self.force_code=0
 def save(self,body):
  self.saves+=1;c=json.loads(body)
  if self.force_code:return self.force_code,{'error':'injected persistent condition'}
  if c['revision']!=self.tune['revision']:return 409,{'error':'stale revision'}
  c['revision']+=1;self.tune=c;return 200,copy.deepcopy(c)
def unwrap(frame):
 n=struct.unpack_from('>H',frame)[0];assert len(frame)==n+6
 body=frame[2:2+n];assert struct.unpack_from('>I',frame,2+n)[0]==zlib.crc32(body)&0xffffffff
 return body
store=Store();stream=p.Stream(store);assert stream.feed(b'')==[]
raw={cmd.decode():p.Stream(Store()).feed(cmd)[0].decode() for cmd in (b'F',b'Q',b'S')}
framed={cmd.hex():unwrap(p.Stream(Store()).feed(p.envelope(cmd))[0]).hex() for cmd in (b'F',b'I',b'f\0',b'f\xff',b'Q',b'S')}
assert raw['Q']==p.SIGNATURE.decode();assert raw['S']==p.VERSION.decode()
request=b'p'+struct.pack('<BBHH',0,2,128,4);frame=p.envelope(request);expected=b'\0'+struct.pack('<f',p.DEFAULT['maps']['ve']['cells'][0])
for split in range(len(frame)+1):
 s=p.Stream(Store());responses=s.feed(frame[:split])+s.feed(frame[split:]);assert len(responses)==1 and unwrap(responses[0])==expected
coalesced=p.Stream(Store()).feed(b'F'+p.envelope(b'I')+frame);assert len(coalesced)==3 and unwrap(coalesced[-1])==expected
bad=bytearray(frame);bad[-1]^=1;assert unwrap(p.Stream(Store()).feed(bytes(bad))[0])==b'\x82'
dtr=p.Stream(Store()).feed(b'\xf0F');partial=p.Stream(Store());assert partial.feed(frame[:3])==[];partial_retry=partial.feed(b'F')
session=p.Session(store);old_page1=bytes(session.buffers[1]);old_crc=session.command(b'd\0\1')[1:];old_revision=store.tune['revision'];old_ve=store.tune['maps']['ve']['cells'][0]
assert session.command(b'M'+struct.pack('<BBHH',0,2,128,4)+struct.pack('<f',86))==b'\0'
staged_read=session.command(request);assert struct.unpack('<f',staged_read[1:])[0]==86 and store.tune['maps']['ve']['cells'][0]==old_ve
burn=session.command(b'b\0\2');assert burn==b'\4' and store.tune['maps']['ve']['cells'][0]==86
new_page1=bytes(session.buffers[1]);changed=[i for i,(a,b) in enumerate(zip(old_page1,new_page1)) if a!=b];new_crc=session.command(b'd\0\1')[1:]
# Simulate the client resending its cached second256-byte block including read-only baseRevision.
assert session.command(b'M'+struct.pack('<BBHH',0,1,256,256)+old_page1[256:])==b'\0';stale_block_burn=session.command(b'b\0\1')
# Independent writer makes another session's fixed revision stale.
concurrent_store=Store();writer=p.Session(concurrent_store);stale=p.Session(concurrent_store)
assert writer.command(b'M'+struct.pack('<BBHH',0,2,128,4)+struct.pack('<f',86))==b'\0';assert writer.command(b'b\0\2')==b'\4'
assert stale.command(b'M'+struct.pack('<BBHH',0,2,132,4)+struct.pack('<f',87))==b'\0';conflict=[stale.command(b'b\0\2').hex() for _ in range(2)]
persistent={}
for code in (503,507):
 f=Store();s=p.Session(f);s.command(b'M'+struct.pack('<BBHH',0,2,128,4)+struct.pack('<f',86));f.force_code=code;persistent[str(code)]=[s.command(b'b\0\2').hex() for _ in range(2)]
result={'qualification':'In-memory API/CAS store fixture; executes exact copied production Python transport. No socket/PTY/app/vendor message or native bridge build. Fake store does not model full validation/flash/engine execution.','source_sha256':hashlib.sha256((base/'reviewed-engine_protocol.py').read_bytes()).hexdigest(),'raw_discovery':raw,'version_info_bytes':len(p.VERSION),'own_signature_bytes':len(p.SIGNATURE),'framed_status_plus_payload_hex':framed,'fragment_boundaries_checked':len(frame)+1,'coalesced_discovery_and_binary_responses':len(coalesced),'silence_on_empty_feed':True,'bad_crc_code':'82','dtr_f0_plus_f_response_hex':[x.hex() for x in dtr],'partial_frame_then_raw_f_responses':[x.hex() for x in partial_retry],'partial_buffer_bytes_retained':len(partial.buffer),'staging':{'M_ack':'00','staged_read_ve':86,'active_store_before_burn_ve':old_ve,'burn_ack':burn.hex(),'active_store_after_burn_ve':store.tune['maps']['ve']['cells'][0]},'burn_changes_unwritten_page1_offsets':changed,'revision_before_burn':old_revision,'revision_after_burn':store.tune['revision'],'page1_crc_before':old_crc.hex(),'page1_crc_after':new_crc.hex(),'resending_cached_revision_block_then_burn_code':stale_block_burn.hex(),'stale_session_retry_codes':conflict,'persistent_store_retry_codes':persistent}
(base/'wire-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
