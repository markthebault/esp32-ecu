#include "tuning_bridge.cpp"
#include <cassert>
#include <fstream>
#include <sstream>
#include <iostream>
#include <climits>
struct Model{std::string tune;int sample_result=1;unsigned commits=0;};
int load(void*o,char*p,std::size_t n){const auto&s=static_cast<Model*>(o)->tune;if(s.size()+1>n)return int(Result::Invalid);std::memcpy(p,s.c_str(),s.size()+1);return int(Result::Ok);}
int current(void*,std::uint32_t*r){*r=1;return int(Result::Ok);}
int commit(void*o,const char*,std::size_t,std::uint32_t*){++static_cast<Model*>(o)->commits;assert(false);return int(Result::Invalid);}
int sample(void*o,std::uint8_t*p,std::size_t n){std::memset(p,0xa5,n);const auto result=static_cast<Model*>(o)->sample_result;if(result==0){std::memset(p,0,n);put_u32(p+52,1);put_u32(p+60,1);put_u32(p+64,123);put_u32(p+68,1);put_u32(p+72,1);put_u32(p+208,255);put_u32(p+212,1);}return result;}
const std::uint8_t* read(void*p){std::uint8_t r[]={'r',0,0x30,0,0,216,0};std::size_t n=0;const auto*b=tuning_command(p,r,sizeof r,&n);assert(b&&n==217&&b[0]==0);return b+1;}
void fallback(const std::uint8_t*b){assert(get_u32(b+52)==1&&get_u32(b+64)==UINT32_MAX);for(unsigned i=0;i<184;++i)if(i!=52&&!(i>=64&&i<68))assert(b[i]==0);assert(get_u32(b+60)==0&&get_u32(b+72)==0&&get_u32(b+208)==0&&get_u32(b+212)==0);}
int main(int argc,char**argv){assert(argc==2);Model m;std::ifstream in(argv[1]);std::ostringstream text;text<<in.rdbuf();m.tune=text.str();auto*p=tuning_create(&m,load,current,commit,sample);assert(p);Page before;std::copy_n(tuning_page(p),before.size(),before.data());Host raw(&m,load,current,commit,sample);std::array<std::uint8_t,live_bytes>block{},expected{};put_u32(expected.data()+52,1);put_u32(expected.data()+64,UINT32_MAX);
 for(auto error:{-1,1,2,3,4,5,INT_MAX}){m.sample_result=error;block.fill(0x5a);raw.sample(block);assert(block==expected);const auto*b=read(p);fallback(b);assert(get_u32(b+184)==1&&get_u32(b+188)==1&&get_u32(b+192)==1&&get_u32(b+196)==0);}
 m.sample_result=0;const auto*valid=read(p);assert(get_u32(valid+52)==1&&get_u32(valid+60)==1&&get_u32(valid+64)==123&&get_u32(valid+72)==1&&get_u32(valid+208)==255&&get_u32(valid+212)==1);
 m.sample_result=4;fallback(read(p));assert(std::equal(before.begin(),before.end(),tuning_page(p))&&m.commits==0);assert(std::strstr(tuning_status(p),"\"dirty\":false"));tuning_destroy(p);std::cout<<"{\"raw_failed_callback_codes\":7,\"full_poisoned_callback_data_discarded\":true,\"physical_inhibited\":1,\"unknown_age_ms\":4294967295,\"source_present_validity_flags_zero\":true,\"r_reply_session_metadata_retained\":true,\"valid_then_failed_observation_has_no_stale_fields\":true,\"page_unchanged\":true,\"commits\":0}\n";}
