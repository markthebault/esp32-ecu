import sys,ctypes,copy,json,struct,threading,importlib.util,hashlib
from pathlib import Path
sys.dont_write_bytecode=True;root=Path.cwd();base=root/'.cache/engine/live-tuning-review';sys.path.insert(0,str(root/'tools'))
spec=importlib.util.spec_from_file_location('own003_reviewed',base/'reviewed-engine_protocol.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
lib_path=root/'.cache/engine/libengine.so';lib=ctypes.CDLL(str(lib_path));lib.engine_validate.argtypes=[ctypes.c_char_p];lib.engine_validate.restype=ctypes.c_int
class Store:
 def __init__(self):self.lock=threading.RLock();self.tune=copy.deepcopy(p.DEFAULT);self.tune['strategy']='sequential_4cyl';self.tune['cylinder_trims']['enabled']=True
 def save(self,body):
  c=json.loads(body)
  if not lib.engine_validate(body):return 422,{}
  if c['revision']!=self.tune['revision']:return 409,{}
  c['revision']+=1;self.tune=c;return 200,copy.deepcopy(c)
s=Store();assert lib.engine_validate(json.dumps(s.tune).encode());session=p.Session(s)
# Desired valid target tune is batch with trims disabled, mapped across pages1 and5.
desired=copy.deepcopy(s.tune);desired['strategy']='batch_wasted_4cyl';desired['cylinder_trims']['enabled']=False;assert lib.engine_validate(json.dumps(desired).encode())
assert session.command(b'M'+struct.pack('<BBHH',0,1,272,4)+struct.pack('<I',0))==b'\0'
first=session.command(b'b\0\1');assert first==b'\x84';assert s.tune['strategy']=='sequential_4cyl'
assert session.command(b'M'+struct.pack('<BBHH',0,5,784,4)+struct.pack('<I',0))==b'\0';second=session.command(b'b\0\5');assert second==b'\x04' and s.tune['strategy']=='batch_wasted_4cyl'
r={'qualification':'Command ordering follows documented auto-burn-on-page-change; in-memory CAS store calls existing unchanged native engine_validate. No native rebuild or real app/session/flash use.','native_validator_sha256':hashlib.sha256(lib_path.read_bytes()).hexdigest(),'initial_sequential_with_trims_is_valid':True,'desired_batch_without_trims_is_valid':True,'page1_write_ack':'00','page1_automatic_burn_before_page5_code':first.hex(),'store_unchanged_after_failed_intermediate_burn':True,'manually_staging_page5_then_final_burn_code':second.hex(),'final_batch_without_trims_committed':True}
(base/'page-transition-probe.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
