#pragma once
namespace ecu::web::assets {extern const char* engine_defaults;}
