#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
using esp_err_t=int;using nvs_handle_t=unsigned;
constexpr int ESP_OK=0,ESP_ERR_NO_MEM=1,ESP_ERR_NVS_NOT_FOUND=2,ESP_ERR_NVS_INVALID_LENGTH=3,NVS_READONLY=1,NVS_READWRITE=2;
inline const char*esp_err_to_name(int){return "fake error";}
namespace fake_nvs {inline int result=0;inline unsigned sets=0,commits=0;inline char pending[24577],saved[24577];inline std::size_t pending_size=0,saved_size=0;}
inline int nvs_open(const char*,int,nvs_handle_t*h){*h=1;return ESP_OK;}
inline int nvs_open_from_partition(const char*,const char*,int,nvs_handle_t*h){*h=1;return ESP_OK;}
inline int nvs_get_str(nvs_handle_t,const char*,char*,std::size_t*){return ESP_ERR_NVS_NOT_FOUND;}
inline int nvs_get_blob(nvs_handle_t,const char*,void*,std::size_t*){return ESP_ERR_NVS_NOT_FOUND;}
inline void nvs_close(nvs_handle_t){}
inline int nvs_set_blob(nvs_handle_t,const char*,const void*p,std::size_t n){++fake_nvs::sets;std::memcpy(fake_nvs::pending,p,n);fake_nvs::pending[n]=0;fake_nvs::pending_size=n;return fake_nvs::result;}
inline int nvs_commit(nvs_handle_t){++fake_nvs::commits;if(fake_nvs::result)return fake_nvs::result;std::memcpy(fake_nvs::saved,fake_nvs::pending,fake_nvs::pending_size+1);fake_nvs::saved_size=fake_nvs::pending_size;return ESP_OK;}
