#include "recheck/tuning_bridge.cpp"
#include <cassert>
#include <iostream>
int full(void*,char*p,std::size_t n){std::memset(p,'X',n);return int(Result::Ok);}
int current(void*,std::uint32_t*r){*r=1;return int(Result::Ok);}
int commit(void*,const char*,std::size_t,std::uint32_t*){assert(false);return int(Result::Invalid);}
int sample(void*,std::uint8_t*p,std::size_t n){std::memset(p,0,n);return 0;}
int main(){auto*p=tuning_create(nullptr,full,current,commit,sample);assert(p);const auto*status=tuning_status(p);assert(status&&std::strstr(status,"\"initialized\":false")&&std::strstr(status,"\"state\":\"invalid_tune\""));std::uint8_t burn[]={'b',0,1};std::size_t n=0;auto*r=tuning_command(p,burn,3,&n);assert(r&&n==1&&r[0]==0x84);tuning_destroy(p);std::cout<<"{\"full_nonterminated_backend_load_rejected\":true,\"uninitialized_invalid_session_cannot_burn\":true}\n";}
