#include "recheck/engine_service.cpp"
#include <cassert>
#include <fstream>
#include <sstream>
#include <iostream>
#include <thread>
#include <atomic>
std::mutex*review_mutex=nullptr;
namespace ecu::web::assets {const char*engine_defaults=nullptr;}
namespace fake_target {unsigned begins=0,finishes=0;std::uint32_t finished_revision=0;}
namespace ecu::engine_target {
std::uint64_t clock_us(){return 4000;}Measurement measurement(){return {};}
bool submit(const timing::Command&){return true;}cJSON*snapshot(){return cJSON_CreateObject();}
void begin_configuration(){++fake_target::begins;}
void finish_configuration(std::uint32_t r,std::uint32_t){++fake_target::finishes;fake_target::finished_revision=r;}
}
extern "C" void*__real_malloc(std::size_t);
static bool fail_copy_malloc=false;
extern "C" void*__wrap_malloc(std::size_t n){if(fail_copy_malloc&&n==ecu::engine::tune_maximum+1){fail_copy_malloc=false;return nullptr;}return __real_malloc(n);}
static std::size_t calls=0,fail_at=0,live_allocs=0;
static void(*race_action)()=nullptr;
void*allocate(std::size_t n){if(race_action){auto fn=race_action;race_action=nullptr;fn();}if(++calls==fail_at)return nullptr;void*p=std::malloc(n);if(p)++live_allocs;return p;}
void release(void*p){if(p){assert(live_allocs);--live_allocs;std::free(p);}}
using namespace ecu;
void reset(const engine::Tune&original){engine_service::document.reset();engine_service::active=original;engine_service::storage_ok=true;engine_service::stamp=123;engine_service::latest_data=engine::RuntimeSample{};engine_service::latest_data.sequence=99;fake_nvs::result=0;fake_nvs::sets=fake_nvs::commits=0;fake_nvs::saved_size=fake_nvs::pending_size=0;fake_target::begins=fake_target::finishes=fake_target::finished_revision=0;calls=fail_at=0;assert(live_allocs==0);}
void unchanged(const engine::Tune&original){assert(engine_service::active.revision==original.revision&&engine_service::active.ve.cells==original.ve.cells&&engine_service::stamp==123&&engine_service::latest_data.sequence==99&&!engine_service::document&&fake_target::begins==0&&fake_target::finishes==0&&fake_nvs::sets==0&&engine_service::storage_ok&&live_allocs==0);}
void valid_saved(const engine::Tune&candidate){assert(engine_service::active.ve.cells==candidate.ve.cells&&engine_service::active.revision==candidate.revision+1&&engine_service::stamp==0&&!engine_service::latest_data.sequence&&fake_target::begins==1&&fake_target::finishes==1&&fake_target::finished_revision==candidate.revision+1&&fake_nvs::commits==1&&live_allocs==1);auto*j=cJSON_ParseWithOpts(fake_nvs::saved,nullptr,true);engine::Tune t;assert(j&&engine::parse_tune(j,t)&&t.revision==candidate.revision+1&&t.ve.cells==candidate.ve.cells);cJSON_Delete(j);assert(live_allocs==1);}
std::string external_text;
void competing_save(){std::string reason;assert(engine_service::save(external_text.c_str(),reason)==200);}
int main(int argc,char**argv){assert(argc==2);std::ifstream in(argv[1]);std::ostringstream out;out<<in.rdbuf();auto original_text=out.str();web::assets::engine_defaults=original_text.c_str();engine_service::init();engine::Tune original;assert(engine_service::tuning_load(original)==tuning::Result::Ok);auto candidate=original;candidate.ve.cells[0]=86;cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);
 reset(original);std::uint32_t saved=0;assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::Ok&&saved==2);const auto baseline=calls;valid_saved(candidate);reset(original);
 unsigned oom=0,success=0;for(unsigned point=1;point<=baseline+2;++point){reset(original);calls=0;fail_at=point;saved=77;const auto result=engine_service::tuning_commit(candidate,saved);fail_at=0;if(result==tuning::Result::NoMemory){++oom;unchanged(original);assert(saved==77);assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::Ok&&saved==2);valid_saved(candidate);}else{++success;assert(result==tuning::Result::Ok&&saved==2);valid_saved(candidate);}}
 reset(original);fail_copy_malloc=true;saved=77;assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::NoMemory&&!fail_copy_malloc);unchanged(original);
 reset(original);fake_nvs::result=17;saved=77;assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::StorageBlocked&&saved==77);assert(engine_service::active.revision==1&&engine_service::active.ve.cells[0]==85&&!engine_service::document&&!engine_service::storage_ok&&engine_service::stamp==123&&engine_service::latest_data.sequence==99&&fake_target::begins==1&&fake_target::finishes==1&&fake_target::finished_revision==1&&live_allocs==0);assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::StorageBlocked&&fake_target::begins==1);
 reset(original);std::atomic<bool>locked=false,done=false;std::thread holder([&]{review_mutex->lock();locked=true;while(!done)std::this_thread::yield();review_mutex->unlock();});while(!locked)std::this_thread::yield();assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::Busy);done=true;holder.join();unchanged(original);
 reset(original);auto*tree=cJSON_Parse(original_text.c_str());assert(tree);auto external=original;external.ve.cells[0]=90;tuning::Document doc(tree);assert(tuning::update_document(doc,external));auto*encoded=cJSON_PrintUnformatted(tree);assert(encoded);external_text=encoded;cJSON_free(encoded);cJSON_Delete(tree);assert(live_allocs==0);race_action=competing_save;saved=77;assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::Conflict&&saved==77);assert(engine_service::active.revision==2&&engine_service::active.ve.cells[0]==90&&fake_target::begins==1&&fake_target::finishes==1&&live_allocs==1);
 reset(original);candidate=original;candidate.strategy=engine::Strategy::Sequential;candidate.cylinder_trims_enabled=true;assert(engine_service::tuning_commit(candidate,saved)==tuning::Result::Ok);valid_saved(candidate);engine_service::document.reset();assert(live_allocs==0);cJSON_InitHooks(nullptr);delete review_mutex;
 std::cout<<"{\"actual_service_source\":true,\"fake_RTOS_NVS_target_boundaries\":true,\"baseline_cjson_allocations\":"<<baseline<<",\"injected_failure_positions\":"<<baseline+2<<",\"preserved_then_retry_success\":"<<oom<<",\"uninjected_success_cases\":"<<success<<",\"checked_copy_malloc_failure\":true,\"storage_failure_retains_active_and_finishes_old_revision\":true,\"nonblocking_initial_mutex_busy\":true,\"external_HTTP_commit_during_preparation_conflicts_at_final_CAS\":true,\"whole_tune_strategy_trim_transition\":true,\"cjson_allocations_after_cleanup\":0}\n";
}
