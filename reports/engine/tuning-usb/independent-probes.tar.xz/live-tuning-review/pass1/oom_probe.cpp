#include "snapshot/tools/tuning_bridge.cpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
namespace {
std::size_t calls=0,fail_at=0,live_allocs=0;
void* hooked_malloc(std::size_t n){if(++calls==fail_at)return nullptr;void*p=std::malloc(n);if(p)++live_allocs;return p;}
void hooked_free(void*p){if(p){assert(live_allocs);--live_allocs;std::free(p);}}
struct Model{std::string original,committed;std::uint32_t revision=1;unsigned saves=0;};
int load(void*o,char*p,std::size_t capacity){auto&m=*static_cast<Model*>(o);if(m.original.size()+1>capacity)return int(Result::Invalid);std::memcpy(p,m.original.c_str(),m.original.size()+1);return int(Result::Ok);}
int current(void*o,std::uint32_t*r){*r=static_cast<Model*>(o)->revision;return int(Result::Ok);}
int commit(void*o,const char*p,std::size_t n,std::uint32_t*r){auto&m=*static_cast<Model*>(o);m.committed.assign(p,n);*r=++m.revision;++m.saves;return int(Result::Ok);}
int sample(void*,std::uint8_t*p,std::size_t n){std::memset(p,0,n);return 0;}
void stage(void*p){std::array<std::uint8_t,11>m={'M',0,1,128,2,4,0};put_float(m.data()+7,86);std::size_t n=0;auto*r=tuning_command(p,m.data(),m.size(),&n);assert(r&&n==1&&r[0]==0);}
std::uint8_t burn(void*p){std::uint8_t b[]={'b',0,1};std::size_t n=0;auto*r=tuning_command(p,b,3,&n);assert(r&&n==1);return r[0];}
void committed_valid(const Model&m){assert(m.saves==1&&m.revision==2);auto*j=cJSON_ParseWithOpts(m.committed.c_str(),nullptr,true);assert(j);ecu::engine::Tune t;assert(ecu::engine::parse_tune(j,t)&&t.ve.cells[0]==86&&t.revision==1);cJSON_Delete(j);}
}
int main(int argc,char**argv){assert(argc==2);std::ifstream f(argv[1]);std::stringstream text;text<<f.rdbuf();Model base;base.original=text.str();assert(!base.original.empty());cJSON_Hooks hooks{hooked_malloc,hooked_free};cJSON_InitHooks(&hooks);
 auto baseline=base;auto*p=tuning_create(&baseline,load,current,commit,sample);assert(p);stage(p);calls=0;assert(burn(p)==4);const auto total=calls;committed_valid(baseline);tuning_destroy(p);assert(live_allocs==0);
 unsigned failures=0,successes=0;for(std::size_t point=1;point<=total+2;++point){auto m=base;p=tuning_create(&m,load,current,commit,sample);assert(p);stage(p);calls=0;fail_at=point;const auto status=burn(p);fail_at=0;assert(live_allocs==0);if(status==0x85){++failures;assert(m.saves==0&&m.revision==1);assert(std::strstr(tuning_status(p),"\"dirty\":true"));assert(burn(p)==4);committed_valid(m);}else{++successes;assert(status==4);committed_valid(m);}tuning_destroy(p);assert(live_allocs==0);}
 cJSON_InitHooks(nullptr);std::cout<<"{\"baseline_burn_cjson_allocations\":"<<total<<",\"failure_positions_tested\":"<<total+2<<",\"transient_85_preserved_and_retry_success_cases\":"<<failures<<",\"success_cases\":"<<successes<<",\"cjson_live_allocations_after_each_case\":0}\n";
}
