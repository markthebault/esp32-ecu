import sys
sys.dont_write_bytecode=True
import ctypes,hashlib,json,pathlib,shutil,struct,threading,weakref
root=pathlib.Path.cwd();out=root/'.cache/engine/live-tuning-review/pass1';lib=out/'callback-bridge.so';shutil.copy2(root/'.cache/engine/tuning-native/libtuning.so',lib)
sys.path.insert(0,str(root/'tools'))
import tuning_runtime as runtime
b=ctypes.CDLL(str(lib));P=ctypes.c_void_p;Z=ctypes.c_size_t;B=ctypes.POINTER(ctypes.c_uint8)
for name,(args,result) in {'tuning_create':([P,runtime.LOAD,runtime.CURRENT,runtime.COMMIT,runtime.SAMPLE],P),'tuning_destroy':([P],None),'tuning_command':([P,P,Z,ctypes.POINTER(Z)],B),'tuning_feed':([P,P,Z,ctypes.c_uint64,ctypes.POINTER(Z)],B),'tuning_page':([P],B),'tuning_status':([P],ctypes.c_char_p),'tuning_buffered':([P],Z),'tuning_disconnect':([P],None)}.items():
 fn=getattr(b,name);fn.argtypes=args;fn.restype=result
runtime.load_bridge=lambda:b
class Store:
 def __init__(self):
  self.tune=json.loads((root/'config/engine/defaults.json').read_text());self.lock=threading.RLock();self.storage_ok=True;self.tuning_registry_lock=threading.Lock();self.tuning_sessions=weakref.WeakSet();self.commits=0
 def save(self,body):
  value=json.loads(body)
  if value['revision']!=self.tune['revision']:return 409,{}
  value['revision']+=1;self.tune=value;self.commits+=1;return 200,value
store=Store();session=runtime.Session(store);assert session.diagnostics()['initialized'];original_deepcopy=runtime.copy.deepcopy
calls=0
def no_copy(*args,**kwargs):
 global calls
 calls+=1
 raise MemoryError('Injected post-commit compatibility copy failure')
runtime.copy.deepcopy=no_copy
try:
 assert session.command(b'M\x00\x01'+struct.pack('<HHf',640,4,86))==b'\x00'
 result=session.command(b'b\x00\x01');diagnostics=session.diagnostics()
 assert result==b'\x04' and calls==0 and store.commits==1 and store.tune['revision']==2 and store.tune['maps']['ve']['cells'][0]==86
 assert diagnostics['base_revision']==2 and diagnostics['origin_revision']==1 and not diagnostics['dirty'] and not diagnostics['callback_error']
finally:
 runtime.copy.deepcopy=original_deepcopy;session.close()
print(json.dumps({'current_callback_no_post_commit_deepcopy':True,'injected_deepcopy_calls':calls,'response_hex':result.hex(),'store_commits':store.commits,'origin_revision':diagnostics['origin_revision'],'base_revision':diagnostics['base_revision'],'source_sha256':hashlib.sha256((root/'tools/tuning_runtime.py').read_bytes()).hexdigest(),'read_only_copied_shared_library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest()}))
