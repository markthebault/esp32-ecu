#include "ecu/tuning_stream.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace ecu::tuning;
struct Store:Backend {
 ecu::engine::Tune tune;Result mode=Result::Ok,commit_result=Result::Ok;unsigned commits=0;
 Result load(ecu::engine::Tune&t)override{t=tune;return mode;}
 Result current(std::uint32_t&r)override{r=tune.revision;return mode;}
 Result commit(const ecu::engine::Tune&t,std::uint32_t&r)override{if(t.revision!=tune.revision)return Result::Conflict;if(commit_result!=Result::Ok)return commit_result;tune=t;r=++tune.revision;++commits;return Result::Ok;}
 void sample(std::array<std::uint8_t,live_bytes>&b)override{b.fill(0);}
};
std::vector<std::uint8_t> frame(std::vector<std::uint8_t>p){auto crc=Session::crc32(p.data(),p.size());std::vector<std::uint8_t>v={std::uint8_t(p.size()>>8),std::uint8_t(p.size())};v.insert(v.end(),p.begin(),p.end());for(unsigned i=0;i<4;++i)v.push_back(std::uint8_t(crc>>(24-8*i)));return v;}
std::vector<std::uint8_t> write(unsigned offset,std::vector<std::uint8_t>v){std::vector<std::uint8_t>p={'M',0,1,std::uint8_t(offset),std::uint8_t(offset>>8),std::uint8_t(v.size()),std::uint8_t(v.size()>>8)};p.insert(p.end(),v.begin(),v.end());return p;}
Reply command(Session&s,std::vector<std::uint8_t>p){return s.command(p.data(),p.size());}
int main(){
 Store original;Session reference(original);assert(reference.open()==Result::Ok);std::vector<std::uint8_t>chunk(reference.staged_page().begin()+512,reference.staged_page().begin()+768);put_float(chunk.data()+128,86);auto packet=frame(write(512,chunk));assert(packet.size()==269);
 for(unsigned split=0;split<=packet.size();++split){Store store;Session session(store);session.open();Stream stream(session);std::vector<std::vector<std::uint8_t>>out;auto send=[&](const std::uint8_t*p,std::size_t n){out.emplace_back(p,p+n);return true;};stream.feed(packet.data(),split,100,send);stream.feed(packet.data()+split,packet.size()-split,200,send);assert(out.size()==1&&out[0]==frame({0}));assert(session.stats().dirty&&store.commits==0&&store.tune.ve.cells[0]==85);assert(command(session,{'b',0,1}).bytes[0]==4&&store.tune.ve.cells[0]==86);}
 unsigned corrupt_cases=0;for(unsigned pos=0;pos<packet.size()-2;++pos){Store store;Session session(store);session.open();Stream stream(session);auto bad=packet;bad[pos+2]^=1;auto send=[](const std::uint8_t*,std::size_t){return true;};stream.feed(bad.data(),bad.size(),100,send);assert(!session.stats().dirty&&store.commits==0&&store.tune.ve.cells[0]==85);++corrupt_cases;}
 Store store;Session s(store);s.open();Stream stream(s);std::vector<std::vector<std::uint8_t>>out;auto send=[&](const std::uint8_t*p,std::size_t n){out.emplace_back(p,p+n);return true;};stream.feed(packet.data(),packet.size(),100,send);assert(s.stats().dirty);const auto resets=s.stats().resets;std::uint8_t reset[]={0xf0,'F'};stream.feed(reset,2,30000,send);const bool f0_recovers=s.stats().resets==resets+1&&!s.stats().dirty&&out.back()==std::vector<std::uint8_t>({'0','0','2'});
 // No-op burn must conflict after an external save, even without dirty staging.
 Store external;Session clean(external);clean.open();++external.tune.revision;assert(command(clean,{'b',0,1}).bytes[0]==0x84&&external.commits==0);
 // Keep original page bytes while advancing internal backend CAS repeatedly.
 Store series;Session steps(series);steps.open();for(unsigned k=0;k<25;++k){std::uint8_t v[4];put_float(v,86+k);assert(command(steps,write(640,{v,v+4})).bytes[0]==0);auto pending=steps.staged_page();assert(command(steps,{'b',0,1}).bytes[0]==4);assert(steps.staged_page()==pending&&steps.stats().origin_revision==1&&steps.stats().base_revision==k+2);}
 std::cout<<"{\"all_max_frame_split_positions\":270,\"bad_payload_crc_no_effect_cases\":"<<corrupt_cases<<",\"clean_external_conflict\":true,\"successive_stable_origin_burns\":25,\"idle_F0_then_F_recovers\":"<<(f0_recovers?"true":"false")<<",\"sizes\":{\"Tune\":"<<sizeof(ecu::engine::Tune)<<",\"Session\":"<<sizeof(Session)<<",\"Stream\":"<<sizeof(Stream)<<",\"Reply\":"<<sizeof(Reply)<<"}}\n";
}
