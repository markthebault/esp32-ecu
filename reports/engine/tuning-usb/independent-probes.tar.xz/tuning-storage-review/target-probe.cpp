#include "../../../../firmware/main/engine_service.cpp"
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <thread>
#include <functional>
namespace {
long budget=-1,live=0;
void*allocate(std::size_t n){if(budget==0)return nullptr;if(budget>0)--budget;void*p=std::malloc(n);if(p)++live;return p;}
void release(void*p){if(p){--live;std::free(p);}}
esp_err_t write_error=ESP_OK,commit_error=ESP_OK,open_error=ESP_OK;
std::string blob;unsigned writes=0,commits=0,closes=0,begins=0,finishes=0;std::uint32_t finished_revision=0;

}
// A facade model only: this does not emulate physical NVS algorithms.
esp_err_t nvs_flash_init_partition(const char*){return ESP_OK;}
esp_err_t nvs_open(const char*,nvs_open_mode_t,nvs_handle_t*){return ESP_ERR_NVS_NOT_FOUND;}
esp_err_t nvs_open_from_partition(const char*,const char*,nvs_open_mode_t,nvs_handle_t*h){*h=2;return open_error;}
esp_err_t nvs_get_str(nvs_handle_t,const char*,char*,std::size_t*){return ESP_ERR_NVS_NOT_FOUND;}
esp_err_t nvs_get_blob(nvs_handle_t,const char*,void*,std::size_t*){return ESP_ERR_NVS_NOT_FOUND;}
esp_err_t nvs_set_blob(nvs_handle_t,const char*,const void*p,std::size_t n){++writes;if(write_error)return write_error;blob.assign(static_cast<const char*>(p),n);return ESP_OK;}
esp_err_t nvs_commit(nvs_handle_t){++commits;return commit_error;}
void nvs_close(nvs_handle_t){++closes;}
namespace ecu::engine_target {
std::uint64_t clock_us(){return 1000000;}
Measurement measurement(){return {};}
bool submit(const timing::Command&){return true;}
void begin_configuration(){++begins;}
void finish_configuration(std::uint32_t r,std::uint32_t){++finishes;finished_revision=r;}
cJSON*snapshot(){return cJSON_CreateObject();}
}
namespace {
void reset(){
 using namespace ecu::engine_service;
 document.reset();budget=-1;active=ecu::engine::Tune{};
 assert(parse_text(ecu::web::assets::engine_defaults,active));
 storage_ok=true;stamp=123;latest=ecu::engine::Output{};latest_data=ecu::engine::RuntimeSample{};latest_data.sequence=99;
 blob.clear();write_error=commit_error=open_error=ESP_OK;writes=commits=closes=begins=finishes=finished_revision=0;
 assert(live==0);
}
std::string text(std::uint32_t revision=1,float cell=91){
 auto*j=cJSON_Parse(ecu::web::assets::engine_defaults);assert(j);
 cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"revision"),revision);
 auto*a=cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(j,"maps"),"ve"),"cells");
 cJSON_SetNumberValue(cJSON_GetArrayItem(a,0),cell);char*p=cJSON_PrintUnformatted(j);assert(p);std::string out=p;cJSON_free(p);cJSON_Delete(j);return out;
}
void retained(std::uint32_t r=1){using namespace ecu::engine_service;assert(active.revision==r&&active.ve.cells[0]==85&&!document&&stamp==123&&latest_data.sequence==99);}
}
int main(){
 using namespace ecu::engine_service;mutex=xSemaphoreCreateMutex();cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);reset();const auto input=text();assert(live==0);
 unsigned oom=0,success=0;
 for(unsigned n=0;n<3500;++n){
  reset();budget=n;const char*why="";const int code=prepare_and_save(input.c_str(),why);budget=-1;
  if(code!=200){retained();assert(writes==0&&begins==0&&finishes==0&&storage_ok&&live==0);++oom;}
  else{assert(active.revision==2&&active.ve.cells[0]==91&&document&&writes==1&&commits==1&&begins==1&&finishes==1&&finished_revision==2&&stamp==0&&latest_data.sequence==0);++success;}
 }
 assert(oom&&success);reset();
 for(int path=0;path<3;++path){
  reset();if(path==0)open_error=ESP_ERR_NVS_NOT_ENOUGH_SPACE;if(path==1)write_error=ESP_ERR_NVS_NOT_ENOUGH_SPACE;if(path==2)commit_error=ESP_ERR_NVS_NOT_ENOUGH_SPACE;
  const char*why="";assert(prepare_and_save(input.c_str(),why)==507);retained();assert(!storage_ok&&begins==1&&finishes==1&&finished_revision==1&&live==0);
  const auto old_writes=writes;assert(prepare_and_save(input.c_str(),why)==503&&writes==old_writes);retained();assert(live==0);
 }
 reset();const auto stale=text(2);const char*why="";assert(prepare_and_save(stale.c_str(),why)==409);retained();assert(!writes&&!begins&&live==0);
 reset();ecu::engine::Tune candidate=active;candidate.ve.cells[0]=92;unsigned typed_oom=0,typed_success=0;
 for(unsigned n=0;n<3500;++n){
  reset();candidate=active;candidate.ve.cells[0]=92;std::uint32_t saved=777;budget=n;auto result=tuning_commit(candidate,saved);budget=-1;
  if(result!=ecu::tuning::Result::Ok){retained();assert(saved==777&&!writes&&!begins&&!finishes&&storage_ok&&live==0);++typed_oom;}
  else{assert(active.revision==2&&active.ve.cells[0]==92&&saved==2&&document&&writes==1&&commits==1&&begins==1&&finishes==1);auto*j=cJSON_Parse(document.get());ecu::engine::Tune parsed;assert(ecu::engine::parse_tune(j,parsed)&&parsed.revision==2&&parsed.ve.cells[0]==92);cJSON_Delete(j);++typed_success;}
 }
 assert(typed_oom&&typed_success);reset();
 // Prepared text becomes stale before entering the commit fence.
 Document prepared(nullptr,&cJSON_free);auto*j=cJSON_Parse(input.c_str());cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"revision"),2);prepared.reset(cJSON_PrintUnformatted(j));cJSON_Delete(j);
 auto stale_candidate=active;stale_candidate.ve.cells[0]=91;active.revision=2;const auto prior_live=live;assert(prior_live==1);assert(persist_prepared(stale_candidate,1,std::move(prepared),why)==409);assert(active.revision==2&&!writes&&!begins&&live==0);reset();
 reset();const char nonterminated[2]={'{','}'};
 assert(ecu::engine_storage::save(nonterminated,2)==ESP_OK&&blob=="{}"&&writes==1&&closes==1);
 reset();const char embedded[3]={'{',0,'}'};
 assert(ecu::engine_storage::save(nullptr,2)==ESP_ERR_NVS_INVALID_LENGTH);
 assert(ecu::engine_storage::save(nonterminated,0)==ESP_ERR_NVS_INVALID_LENGTH);
 assert(ecu::engine_storage::save(nonterminated,ecu::engine_storage::maximum+1)==ESP_ERR_NVS_INVALID_LENGTH);
 assert(ecu::engine_storage::save(embedded,3)==ESP_ERR_NVS_INVALID_LENGTH&&writes==0&&closes==0);
 std::cout<<"{\"http_failure_positions\":"<<oom<<",\"http_success_positions\":"<<success<<",\"typed_failure_positions\":"<<typed_oom<<",\"typed_success_positions\":"<<typed_success<<",\"leaks\":0,\"nvs_open_set_commit_failures_retain_active\":true,\"repeat_save_blocked\":true,\"stale_prepared_cas_rejected\":true}\n";
 delete mutex;mutex=nullptr;cJSON_InitHooks(nullptr);
}
