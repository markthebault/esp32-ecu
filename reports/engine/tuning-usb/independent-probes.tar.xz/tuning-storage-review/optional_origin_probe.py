import asyncio,copy,hashlib,json,runpy,struct,tempfile,threading,xml.etree.ElementTree as ET
from pathlib import Path
from http.server import ThreadingHTTPServer
helpers=runpy.run_path('.cache/engine/tuning-storage-review/browser_probe.py',run_name='origin_review_helpers')
er,tr,Device,Handler,cb=(helpers[k] for k in ['er','tr','Device','Handler','cb'])
from playwright.async_api import async_playwright
from engine_msq import import_msq,tag
R=Path.cwd();out=R/'.cache/engine/tuning-storage-review';fixture=R/'.cache/engine/live-tuning/own004/application-roundtrip.msq';raw=fixture.read_bytes()
assert not any(e.get('name')=='baseRevision' for e in ET.fromstring(raw).iter(tag('constant')))
def changed(body,remove=None,origin=None,duplicate=False):
 root=ET.fromstring(body)
 for page in root.findall(tag('page')):
  for e in list(page.findall(tag('constant'))):
   if e.get('name')==remove:page.remove(e)
 if origin is not None:
  page=next(p for p in root.findall(tag('page')) if p.get('number')=='0');e=ET.SubElement(page,tag('constant'),name='baseRevision');e.text=origin
  if duplicate:ET.SubElement(page,tag('constant'),name='baseRevision').text=origin
 return ET.tostring(root)
def must_reject(body,**kw):
 try:import_msq(body,**kw)
 except ValueError:return
 raise AssertionError(('accepted invalid MSQ',kw))
results={}
tune=import_msq(raw);assert tune['revision']==1 and tune['cylinder_trims']['spark_deg'][1]==-2.5 and tune['cylinder_trims']['fuel_maps'][1]['cells']==[120]*36
assert import_msq(raw,base_revision=7)['revision']==7
provided=changed(raw,origin='99');assert import_msq(provided)['revision']==99 and import_msq(provided,base_revision=7)['revision']==7
for invalid in ['0','-1','1.5','4294967296','NaN','Infinity','1e309','','true','1 2']:
 for kw in [{},{'base_revision':7}]:must_reject(changed(raw,origin=invalid),**kw)
results['provided_origin']='Valid present99 preserved without caller base; explicit7 overrides;10 malformed present values reject with and without explicit7'
for bad in [True,False,0,-1,1.5,4294967296,float('nan'),float('inf'),'7',{}]:
 for body in [raw,provided]:must_reject(body,base_revision=bad)
results['caller_base']='10 invalid caller bases rejected with present and absent own004 origin'
missing=[]
for e in ET.fromstring(raw).iter(tag('constant')):
 name=e.get('name');must_reject(changed(raw,remove=name),base_revision=7);missing.append(name)
results['required_other_fields']=len(missing)
legacy=[]
for name in ['tunerstudio-roundtrip.msq','tunerstudio-sequential-roundtrip.msq','tunerstudio-cylinder-roundtrip.msq']:
 body=(R/'tuning/examples'/name).read_bytes();original=import_msq(body)['revision'];assert import_msq(body,base_revision=7)['revision']==original
 for kw in [{},{'base_revision':7}]:must_reject(changed(body,remove='baseRevision'),**kw)
 for bad in [True,0,1.5]:must_reject(body,base_revision=bad)
 legacy.append(name)
results['legacy_origins_required_and_not_overridden']=legacy
must_reject(changed(raw,origin='99',duplicate=True));assert hashlib.sha256(fixture.read_bytes()).digest()==hashlib.sha256(raw).digest()
results['fixture']={'sha256':hashlib.sha256(raw).hexdigest(),'missing_origin':True,'default_placeholder':1,'explicit_caller_base':7,'c2_spark_deg':tune['cylinder_trims']['spark_deg'][1],'c2_fuel_cells':[min(tune['cylinder_trims']['fuel_maps'][1]['cells']),max(tune['cylinder_trims']['fuel_maps'][1]['cells'])]}
async def browser_probe(url,device):
 errors=[];requests=[];checks=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='chrome',headless=True,args=['--no-sandbox'])
  try:
   page=await browser.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append((r.method,r.url)))
   await page.goto(url);await page.locator('[data-page="engine"]').click();await page.locator('#engine-save').wait_for()
   # Each absent field other than origin remains mandatory in the browser helper.
   for name in missing:
    rejected=await page.evaluate('text=>{try{engineFromMsq(text,engineTune);return false}catch(e){return true}}',changed(raw,remove=name).decode())
    assert rejected,name
   for name in legacy:
    body=(R/'tuning/examples'/name).read_bytes();assert await page.evaluate('text=>{try{engineFromMsq(text,engineTune);return false}catch(e){return true}}',changed(body,remove='baseRevision').decode())
   checks.append('Every non-origin own004 field and every historical origin remains required by browser parser')
   # A malformed present origin must reject through the actual import UI.
   for value in ['0','-1','1.5','4294967296','NaN','']:
    await page.evaluate("()=>document.querySelector('#toast').textContent=''")
    await page.locator('#engine-import-file').set_input_files({'name':'invalid-origin-'+value+'.msq','mimeType':'application/xml','buffer':changed(raw,origin=value)})
    await page.wait_for_function("()=>document.querySelector('#toast').textContent.length>0")
    assert await page.evaluate('()=>!engineDirty&&engineTune.revision===1'),value
   checks.append('Malformed present004 origins reject without changing the editor')
   session=tr.Session(device.engine);assert session.command(b'M'+struct.pack('<BBHH',0,1,640,4)+struct.pack('<f',92))==b'\0';assert session.command(b'b\0\1')==b'\4' and device.engine.tune['revision']==2
   gets=sum(m=='GET' and u.endswith('/api/engine/config') for m,u in requests)
   await page.locator('#engine-import-file').set_input_files({'name':'application-roundtrip.msq','mimeType':'application/xml','buffer':raw})
   await page.wait_for_function('()=>engineDirty&&engineTune.revision===1&&engineTune.cylinder_trims.spark_deg[1]===-2.5')
   await page.locator('#engine-save-state').filter(has_text='File origin unavailable, editor base 1').wait_for()
   assert sum(m=='GET' and u.endswith('/api/engine/config') for m,u in requests)==gets
   await page.locator('#engine-save').click();await page.locator('#toast').filter(has_text='revision changed').wait_for();assert device.engine.tune['revision']==2 and device.engine.tune['maps']['ve']['cells'][0]==92
   checks.append('Missing-origin application file preserves stale editor base1, displays origin unavailable, never fetches/rebases, and Save conflicts against USB revision2')
   await page.locator('#engine-reload').click();await page.wait_for_function('()=>!engineDirty&&engineTune.revision===2')
   await page.locator('#engine-import-file').set_input_files({'name':'application-roundtrip-again.msq','mimeType':'application/xml','buffer':raw})
   await page.wait_for_function('()=>engineDirty&&engineTune.revision===2&&engineTune.cylinder_trims.spark_deg[1]===-2.5')
   await page.locator('#engine-save').click();await page.wait_for_function('()=>!engineDirty&&engineTune.revision===3')
   assert device.engine.tune['cylinder_trims']['spark_deg'][1]==-2.5 and device.engine.tune['cylinder_trims']['fuel_maps'][1]['cells']==[120]*36
   checks.append('Explicit reload followed by import/save commits complete application tune once,2→3')
   session.close();assert not errors,errors
  finally:await browser.close()
 return {'checks':checks,'page_errors':errors,'passed':True}
if __name__=='__main__':
 with tempfile.TemporaryDirectory(prefix='own004-no-origin-review-') as d,ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
  server.device=Device(Path(d)/'profile.json',cb);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:results['browser']=asyncio.run(browser_probe(f'http://127.0.0.1:{server.server_address[1]}',server.device))
  finally:server.shutdown();thread.join(2)
 (out/'optional-origin-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
