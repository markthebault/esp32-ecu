import asyncio,ctypes,json,struct,sys,tempfile,textwrap,threading
from pathlib import Path
from http.server import ThreadingHTTPServer
R=Path.cwd();out=R/'.cache/engine/tuning-storage-review';sys.path.insert(0,str(R/'tools'))
import engine_runtime as er,tuning_runtime as tr
# Reuse only each module's ctypes declarations, loading isolated review binaries.
def bindings(module,start,end,lib):
 source=Path(module.__file__).read_text();body=source[source.index(start):source.index(end)+len(end)]
 context=dict(module.__dict__);context['lib']=lib
 exec('def review_bind():\n'+textwrap.indent(textwrap.dedent(body),' '),context)
 return context['review_bind']()
b=bindings(er,'  b=ctypes.CDLL(str(lib))','\n  return b',out/'libengine-review.so');er.load_engine_bridge=lambda:b
native=bindings(tr,'  b=ctypes.CDLL(str(lib))','\n  return b',out/'libtuning-review.so');tr.load_bridge=lambda:native
from web_server import Device,Handler,Reading
cb=ctypes.CDLL(str(out/'libconfig-review.so'));cb.validate_profile.argtypes=[ctypes.c_char_p];cb.validate_profile.restype=ctypes.c_int
cb.evaluate_profile.argtypes=[ctypes.c_char_p,ctypes.POINTER(ctypes.c_uint),ctypes.POINTER(ctypes.c_double),ctypes.POINTER(Reading)];cb.evaluate_profile.restype=ctypes.c_int
from playwright.async_api import async_playwright
from engine_msq import export_msq,import_msq
async def probe(url,device):
 checks=[];errors=[];requests=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='chrome',headless=True,args=['--no-sandbox'])
  try:
   page=await browser.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append((r.method,r.url)))
   await page.goto(url);await page.locator('[data-page="engine"]').click();await page.locator('#engine-import-file').wait_for(state='attached')
   initial=await page.evaluate('()=>engineTune.revision');assert initial==1
   tune=json.loads(json.dumps(device.engine.tune));tune['revision']=99;tune['maps']['ve']['cells'][0]=97
   msq=export_msq(tune);assert import_msq(msq)['revision']==99
   # Another tuning connection changes the backend while this editor stays at1.
   session=tr.Session(device.engine)
   assert session.command(b'M'+struct.pack('<BBHH',0,1,640,4)+struct.pack('<f',92))==b'\0'
   assert session.command(b'b\0\1')==b'\4' and device.engine.tune['revision']==2
   origin=session.diagnostics()['origin_revision'];assert origin==1
   gets_before=sum(m=='GET' and u.endswith('/api/engine/config') for m,u in requests)
   await page.locator('#engine-import-file').set_input_files({'name':'review-own004.msq','mimeType':'application/xml','buffer':msq.encode()})
   await page.wait_for_function('()=>engineDirty&&engineImportOrigin===99&&engineTune.maps.ve.cells[0]===97')
   assert await page.evaluate('()=>engineTune.revision')==1
   assert sum(m=='GET' and u.endswith('/api/engine/config') for m,u in requests)==gets_before
   await page.locator('#engine-save').click();await page.locator('#toast').filter(has_text='revision changed').wait_for()
   assert device.engine.tune['revision']==2 and device.engine.tune['maps']['ve']['cells'][0]==92
   assert await page.evaluate('()=>engineDirty&&engineTune.revision===1&&engineImportOrigin===99')
   checks.append('Stale004 import retains editor base1 and origin99; Save conflicts against USB revision2 without overwrite or hidden rebase')
   await page.locator('#engine-reload').click();await page.wait_for_function('()=>!engineDirty&&engineTune.revision===2&&engineImportOrigin===null')
   await page.locator('#engine-import-file').set_input_files({'name':'review-own004-again.msq','mimeType':'application/xml','buffer':msq.encode()})
   await page.wait_for_function('()=>engineDirty&&engineImportOrigin===99&&engineTune.revision===2')
   await page.locator('#engine-save').click();await page.wait_for_function('()=>!engineDirty&&engineTune.revision===3&&engineImportOrigin===null')
   assert device.engine.tune['revision']==3 and device.engine.tune['maps']['ve']['cells'][0]==97
   checks.append('After explicit reload, same004 file saves with editor base2 and increments backend exactly once to3; origin metadata clears')
   assert session.command(b'M'+struct.pack('<BBHH',0,1,640,4)+struct.pack('<f',94))==b'\x84'
   assert session.command(b'b\0\1')==b'\x84' and device.engine.tune['revision']==3
   session.close();checks.append('Original USB session conflicts after HTTP change and cannot overwrite it')
   for name in ['tunerstudio-roundtrip.msq','tunerstudio-sequential-roundtrip.msq','tunerstudio-cylinder-roundtrip.msq']:
    await page.evaluate("()=>document.querySelector('#toast').textContent=''")
    await page.locator('#engine-import-file').set_input_files(R/'tuning/examples'/name)
    await page.locator('#toast').filter(has_text='base revision differs').wait_for()
    assert await page.evaluate('()=>!engineDirty&&engineTune.revision===3')
   checks.append('Historical001/002/003 files retain exact revision guard and leave the editor unchanged on mismatch')
   # Invalid004 origin is never promoted to the current editor revision.
   invalid=msq.replace('>99<','>4294967296<')
   assert invalid!=msq
   await page.locator('#engine-import-file').set_input_files({'name':'invalid-origin.msq','mimeType':'application/xml','buffer':invalid.encode()})
   await page.locator('#toast').filter(has_text='Invalid tune origin revision').wait_for();assert await page.evaluate('()=>!engineDirty&&engineTune.revision===3')
   checks.append('Out-of-range004 origin rejects before rebasing to editor CAS')
   assert not errors,errors
  finally:await browser.close()
 report={'checks':checks,'page_errors':errors,'passed':True,'scope':'Installed Chrome against isolated native code and temporary host files; no target flash/device'}
 (out/'browser-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':
 with tempfile.TemporaryDirectory(prefix='own004-storage-review-') as d,ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
  server.device=Device(Path(d)/'profile.json',cb);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:asyncio.run(probe(f'http://127.0.0.1:{server.server_address[1]}',server.device))
  finally:server.shutdown();thread.join(2)
