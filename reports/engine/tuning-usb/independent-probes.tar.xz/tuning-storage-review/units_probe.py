import json,re,runpy,xml.etree.ElementTree as ET
from pathlib import Path
ns=runpy.run_path('.cache/engine/tuning-storage-review/browser_probe.py',run_name='review_helpers')
from engine_msq import export_msq,tag
from engine_protocol import DEFAULT
text=Path('tuning/esp32-ecu-development.ini').read_text();block=text.split('[Constants]',1)[1].split('[ConstantsExtensions]',1)[0]
units={}
for line in block.splitlines():
 m=re.match(r'\s*(\w+)\s*=\s*(scalar|array),\s*\w+,\s*\d+,\s*(?:\[[^]]+\],\s*)?"([^"]*)"',line)
 if m:units[m[1]]=m[3]
root=ET.fromstring(export_msq(DEFAULT));exported={e.get('name'):e.get('units','') for e in root.iter(tag('constant'))}
missing=set(units)-set(exported);different={name:(unit,exported.get(name)) for name,unit in units.items() if exported.get(name)!=unit}
assert not missing and not different,(missing,different)
report={'passed':True,'scalar_array_units_checked':len(units),'differences':different,'missing':sorted(missing),'timing_units':{k:exported[k] for k in ['injection_end_deg','cam_sync_deg','cam_window_deg']}}
Path('.cache/engine/tuning-storage-review/units-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
