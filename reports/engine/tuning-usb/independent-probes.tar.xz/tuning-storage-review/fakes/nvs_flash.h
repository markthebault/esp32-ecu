#pragma once
#include "nvs.h"
esp_err_t nvs_flash_init_partition(const char*);
