#pragma once
#define ESP_LOGI(...) ((void)0)
#define ESP_LOGE(...) ((void)0)
