#pragma once
#include <cassert>
#include <cstdint>
using TickType_t=unsigned;
constexpr unsigned portMAX_DELAY=~0U;
constexpr int pdTRUE=1;
#define configASSERT(x) assert(x)
