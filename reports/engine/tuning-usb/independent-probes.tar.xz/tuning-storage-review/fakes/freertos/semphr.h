#pragma once
#include "FreeRTOS.h"
#include <mutex>
using SemaphoreHandle_t=std::mutex*;
inline SemaphoreHandle_t xSemaphoreCreateMutex(){return new std::mutex;}
inline int xSemaphoreTake(SemaphoreHandle_t p,unsigned wait){if(wait==portMAX_DELAY){p->lock();return pdTRUE;}return p->try_lock()?pdTRUE:0;}
inline int xSemaphoreGive(SemaphoreHandle_t p){p->unlock();return pdTRUE;}
