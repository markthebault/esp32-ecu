"""Rebuild frozen portable harness and reproduce every original replay.

No target or circuit solver runs. All new files are private review artifacts.
Exact decompressed native JSON and native MSL bytes are compared to originals.
"""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
OUT=HERE/'independent-native-replays'
OUT.mkdir(exist_ok=False)
BUILD=OUT/'build';BUILD.mkdir()
SOURCE=HERE/'private-baseline-seed/sources'
CJSON=Path.home()/'.platformio/packages/framework-espidf/components/json/cJSON'

def sha_bytes(body):return hashlib.sha256(body).hexdigest()
def sha(path):return sha_bytes(path.read_bytes())
def write_json(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')

for name in ('cJSON.c','cJSON.h'):shutil.copyfile(CJSON/name,BUILD/name)
commands=[
 ['cc','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-c',str(BUILD/'cJSON.c'),'-o',str(BUILD/'cJSON.o')],
 ['g++','-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-pedantic','-fsanitize=address,undefined','-fno-omit-frame-pointer',
  '-I'+str(BUILD),'-I'+str(SOURCE/'firmware/include'),str(SOURCE/'tools/flex_circuit_control.cpp'),str(BUILD/'cJSON.o'),'-o',str(BUILD/'control')]
]
for index,command in enumerate(commands):
 with (BUILD/f'build-{index}.log').open('xb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
write_json(BUILD/'metadata.json',dict(commands=commands,cc_version=subprocess.check_output(['cc','--version'],text=True),
 gpp_version=subprocess.check_output(['g++','--version'],text=True),
 compiled_source_sha256={str(p.relative_to(SOURCE)):sha(p) for p in SOURCE.rglob('*') if p.is_file()},
 cjson_source_sha256={n:sha(BUILD/n) for n in ('cJSON.c','cJSON.h')},binary_sha256=sha(BUILD/'control')))

results=[];started=time.monotonic();error=None
try:
 for run_name in ('run-013','run-014'):
  matrix=ROOT/'.cache/engine/flex-nonideal'/run_name
  ledger=json.loads((matrix/'results.json').read_text())
  assert ledger['complete'] and ledger['status']=='complete' and len(ledger['cases'])==26
  assert ledger['source_sha256']==json.loads((SOURCE.parent/'results.json').read_text())['source_sha256']
  for case in ledger['cases']:
   name=case['scenario']['name'];target=OUT/run_name/name;target.mkdir(parents=True)
   for observation in case['observations']:
    r,f,strategy,basis=(observation[k] for k in ('rising_fraction','falling_fraction','strategy','calibration_basis'))
    label=f'gpio-{r}-{f}-strategy{strategy}-{basis}'
    assert observation['transcript']==f'{name}/{label}.jsonl.gz'
    stimulus=matrix/name/f'gpio-{r}-{f}.stimulus.txt';body=stimulus.read_bytes()
    expected=matrix/observation['transcript'];expected_msl=expected.with_name(label)/'engine.msl'
    stdout_path=target/(label+'.jsonl');stderr_path=target/(label+'.stderr.log')
    command=[str(BUILD/'control'),str(strategy),basis,str(target/label)]
    with stdout_path.open('xb') as stdout,stderr_path.open('xb') as stderr:
     process=subprocess.run(command,input=body,stdout=stdout,stderr=stderr,timeout=30)
    actual=stdout_path.read_bytes()
    with gzip.open(expected,'rb') as source:expected_bytes=source.read()
    msl=target/label/'engine.msl'
    row=dict(matrix=run_name,case=name,label=label,command=command,returncode=process.returncode,
      stimulus_sha256=sha_bytes(body),original_transcript_sha256=sha(expected),
      original_json_sha256=sha_bytes(expected_bytes),reproduced_json_sha256=sha_bytes(actual),
      exact_json=actual==expected_bytes,original_msl_sha256=sha(expected_msl),
      reproduced_msl_sha256=sha(msl) if msl.exists() else None,
      exact_msl=msl.exists() and msl.read_bytes()==expected_msl.read_bytes(),stderr_sha256=sha(stderr_path),
      stderr_bytes=stderr_path.stat().st_size)
    archive=stdout_path.with_suffix('.jsonl.gz');archive.write_bytes(gzip.compress(actual,compresslevel=1,mtime=0));stdout_path.unlink()
    results.append(row)
    if not (process.returncode==0 and row['exact_json'] and row['exact_msl'] and row['stderr_bytes']==0):
     raise AssertionError('Independent native replay differs: '+run_name+'/'+name+'/'+label)
   print(json.dumps(dict(matrix=run_name,case=name,reproduced=len(case['observations']),total=len(results))),flush=True)
  write_json(OUT/(run_name+'-results.json'),[r for r in results if r['matrix']==run_name])
except BaseException as exception:
 error=dict(type=type(exception).__name__,message=str(exception))
 raise
finally:
 write_json(OUT/'results.json',dict(complete=error is None and len(results)==1248,expected_replays=1248,
  completed_replays=len(results),error=error,elapsed_s=time.monotonic()-started,
  binary_sha256=sha(BUILD/'control'),entries=results,physical_qualification=False))
