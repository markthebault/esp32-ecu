"""Read-only verification of final audit identities and all retained inputs."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
SCOPE=HERE/'reviewed-sources-final'
spec=importlib.util.spec_from_file_location('review_final',SCOPE/'tools/analyze_flex_nonideal.py')
analyzer=importlib.util.module_from_spec(spec);spec.loader.exec_module(analyzer)

def sha(path):
 digest=hashlib.sha256()
 with path.open('rb') as file:
  for body in iter(lambda:file.read(1<<20),b''):digest.update(body)
 return digest.hexdigest()

reports=[];inspections={}
for name in sys.argv[1:] or ['run-013','run-014']:
 folder=ROOT/'.cache/engine/flex-nonideal'/('audit-final-'+name.removeprefix('run-')+'-001')
 path=folder/(name+'.json');report=json.loads(path.read_text());matrix=Path(report['root'])
 ledger=json.loads((matrix/'results.json').read_text());plan=json.loads((matrix/'matrix-plan.json').read_text())
 assert report['analyzer_sha256']==analyzer.AUDITOR_SHA256==sha(folder/'analyzer.py')
 assert report['complete'] and ledger['complete'] and len(report['cases'])==26 and report['replays']==624
 assert report['original_matrix_status']=='complete' and report['physical_qualification'] is False
 assert report['audited_case_names']==report['original_planned_cases']==ledger['selected_case_names']==ledger['completed_case_names']
 assert ledger['source_sha256']==plan['source_sha256']
 for source,expected in ledger['source_sha256'].items():assert sha(matrix/'sources'/source)==expected
 for evidence,expected in report['input_sha256'].items():assert sha(matrix/evidence)==expected,(name,evidence)
 for row in report['cases'].values():
  assert row['full_replay_matrix'] and row['sampling_derived_from_raw'] and row['msl_columns_checked']==229
  assert len(row['replays'])==24 and len(row['queries'])==44
  for replay in row['replays'].values():assert replay['rows']==440 and len(replay['phase0'])==44
 parent='hardware/a5-idle-interface/net_contract.json'
 assert report['recovered_bound_sources'][parent]['sha256']==ledger['binding']['carrier_sha256']==sha(SCOPE/parent)
 inspections[name]=dict(audit_file=str(path),audit_sha256=sha(path),matrix=str(matrix),analyzer_sha256=report['analyzer_sha256'],
  cases=len(report['cases']),replays=report['replays'],raw_rows=sum(r['raw_rows'] for r in report['cases'].values()),
  json_rows=sum(z['rows'] for r in report['cases'].values() for z in r['replays'].values()),
  verified_input_files=len(report['input_sha256']),verified_frozen_sources=len(ledger['source_sha256']),
  source_tree_frozen_producer_sha256=ledger['source_sha256']['tools/run_flex_nonideal.py'],recovered_bound_sources=report['recovered_bound_sources'],
  exposure_and_point_deltas={n:dict(acquisition_hits=r['ripple_acquisition_samples'],conversion_hits=r['ripple_conversion_samples'],
   max_reference_span_fullscale_lsb=r['max_reference_span_fullscale_lsb'],relative_to_matched_baseline=r.get('relative_to_matched_baseline'))
   for n,r in report['cases'].items()})
 reports.append(report)
 print(json.dumps({k:v for k,v in inspections[name].items() if k not in ('exposure_and_point_deltas','recovered_bound_sources')}),flush=True)
if len(reports)==2:
 comparison=analyzer.compare(*reports)
 assert len(comparison)==26
 inspections['independent_comparison']=comparison
 inspections['all_discrete_inputs_and_native_records_identical']=all(v['identical_discrete_inputs'] and not v['native_record_differences'] for v in comparison.values())
 authoritative=ROOT/'.cache/engine/flex-nonideal/final-comparison-001.json'
 if authoritative.exists():
  published=json.loads(authoritative.read_text())
  assert published['cases']==comparison and published['complete'] and published['physical_qualification'] is False
  assert published['analyzer_sha256']==analyzer.AUDITOR_SHA256
  assert published['coarse_report_sha256']==inspections['run-013']['audit_sha256']
  assert published['fine_report_sha256']==inspections['run-014']['audit_sha256']
  inspections['authoritative_comparison']=dict(path=str(authoritative.relative_to(ROOT)),sha256=sha(authoritative),matches_independent_comparison=True)
filename='final-evidence-inspection.json' if len(reports)==2 else sys.argv[1]+'-evidence-inspection.json'
(HERE/filename).write_text(json.dumps(inspections,indent=2,allow_nan=False)+'\n')
