"""Additional isolated identity/header controls, using only private seed files."""
import ast
from pathlib import Path

HERE=Path(__file__).resolve().parent
base=HERE/'review_probes.py'
tree=ast.parse(base.read_text(),str(base))
# Load helper definitions only; do not recreate or rerun existing fixtures.
stop=next(n for n,node in enumerate(tree.body) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Tuple) for t in node.targets))
namespace={'__file__':str(base),'__name__':'probe_helpers'}
exec(compile(ast.Module(body=tree.body[:stop],type_ignores=[]),str(base),'exec'),namespace)
clone,check,summary,alter_summary,replace_bytes,write_json=(namespace[n] for n in ('clone','check','summary','alter_summary','replace_bytes','write_json'))
seed=HERE/'private-baseline-seed'
results={}

root=clone(seed,'aliased-threshold-transcript')
def alias(case):
    source=next(o for o in case['observations'] if (o['rising_fraction'],o['falling_fraction'],o['strategy'],o['calibration_basis'])==(.25,.25,0,'absolute'))
    index=next(n for n,o in enumerate(case['observations']) if (o['rising_fraction'],o['falling_fraction'],o['strategy'],o['calibration_basis'])==(.75,.75,0,'absolute'))
    case['observations'][index]={**source,'rising_fraction':.75,'falling_fraction':.75}
alter_summary(root,alias)
results[root.name]=check(root)
results[root.name]['unique_transcript_paths']=len({o['transcript'] for o in summary(root)['cases'][0]['observations']})

root=clone(seed,'wrong-msl-retention-header')
observation=summary(root)['cases'][0]['observations'][0]
path=root/(observation['transcript'].removesuffix('.jsonl.gz')+'/engine.msl')
old=path.read_text();new=old.replace('period_ms=5 duration_s=1 / retained rows 1..44 of 44 / overwritten=0 missed_periods=0 repeated=0 invalid=0',
    'period_ms=777 duration_s=900 / retained rows 999..999 of 999 / overwritten=88 missed_periods=77 repeated=66 invalid=55')
assert old!=new;replace_bytes(path,new.encode())
results[root.name]=check(root)

write_json(HERE/'identity-header-probe-results.json',results)
