"""Recheck every privately retained negative control with the final analyzer."""
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import traceback

HERE=Path(__file__).resolve().parent
OUT=HERE/'final-recheck';OUT.mkdir(exist_ok=False)
SOURCE=HERE/'reviewed-sources-final/tools/analyze_flex_nonideal.py'
PARENT=HERE/'reviewed-sources-final/hardware/a5-idle-interface/net_contract.json'

def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
analyzer=load(SOURCE,'final_analyzer')

def check(tag,root,expected_accept=False,module=analyzer,binding_source=PARENT):
 progress=io.StringIO()
 try:
  with contextlib.redirect_stdout(progress):report=module.audit(root,binding_source=binding_source)
 except Exception as error:
  result=dict(accepted=False,error_type=type(error).__name__,error=str(error));(OUT/(tag+'-error.txt')).write_text(traceback.format_exc())
 else:
  result=dict(accepted=True,complete=report['complete'],replays=report['replays'],analyzer_sha256=report['analyzer_sha256'],
    recovered_bound_sources=report['recovered_bound_sources'])
  (OUT/(tag+'-audit.json')).write_text(json.dumps(report,indent=2)+'\n')
 result['expected_accept']=expected_accept;result['matches_expectation']=result['accepted']==expected_accept
 (OUT/(tag+'-progress.txt')).write_text(progress.getvalue());print(tag,json.dumps(result),flush=True);return result

initial=json.loads((HERE/'negative-probe-results.json').read_text())
results={}
for tag in initial:
 root=HERE/('private-baseline-seed' if tag=='unmodified_baseline' else tag)
 results[tag]=check(tag,root,expected_accept=tag=='unmodified_baseline')
for tag in json.loads((HERE/'identity-header-probe-results.json').read_text()):
 results[tag]=check(tag,HERE/tag)

root=OUT/'sampling-alias';shutil.copytree(HERE/'private-baseline-seed',root,copy_function=os.link)
os.link(root/'baseline/sampling.json',root/'baseline/alternate-sampling.json')
summary=json.loads((root/'results.json').read_text());summary['cases'][0]['sampling_file']='alternate-sampling.json'
temp=root/'results.json.owned-replacement';temp.write_text(json.dumps(summary,indent=2)+'\n');os.replace(temp,root/'results.json')
results['sampling-alias']=check('sampling-alias',root)

wrong=OUT/'wrong-parent.json';wrong.write_text('{}\n')
results['wrong-recovered-parent']=check('wrong-recovered-parent',HERE/'private-baseline-seed',binding_source=wrong)

guard_source=OUT/'source-guard-analyzer.py';shutil.copyfile(SOURCE,guard_source)
guard=load(guard_source,'guard_analyzer');guard_source.write_bytes(guard_source.read_bytes()+b'\n# Artificial source-change rejection control\n')
results['changed-analyzer-after-import']=check('changed-analyzer-after-import',HERE/'private-baseline-seed',module=guard)

(OUT/'results.json').write_text(json.dumps(dict(analyzer_sha256=analyzer.AUDITOR_SHA256,entries=results,
 all_expectations_met=all(r['matches_expectation'] for r in results.values())),indent=2)+'\n')
assert all(r['matches_expectation'] for r in results.values())
