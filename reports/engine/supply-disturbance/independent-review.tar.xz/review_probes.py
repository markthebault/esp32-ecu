"""Independent artificial rejection controls; immutable producer evidence.

The seed contains private copies of original files. Clones hardlink only that
owned seed; all mutations replace the destination inode, never write through a
hardlink. These fixtures are one-case audit controls, not produced matrices.
"""
import contextlib
import copy
import csv
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
ORIGINAL = ROOT / '.cache/engine/flex-nonideal/run-013'
spec = importlib.util.spec_from_file_location('independent_analyzer', HERE/'reviewed-sources/tools/analyze_flex_nonideal.py')
analyzer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analyzer)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_bytes(path, body):
    temporary = path.with_name(path.name+'.owned-replacement')
    temporary.write_bytes(body)
    os.replace(temporary, path)


def write_json(path, obj):
    replace_bytes(path, (json.dumps(obj, indent=2, allow_nan=False)+'\n').encode())


def summary(root):
    return json.loads((root/'results.json').read_text())


def make_seed():
    seed = HERE/'private-baseline-seed'
    seed.mkdir(exist_ok=False)
    report = summary(ORIGINAL)
    case = copy.deepcopy(next(c for c in report['cases'] if c['scenario']['name']=='baseline'))
    plan = json.loads((ORIGINAL/'matrix-plan.json').read_text())
    plan['selected_cases'] = [case['scenario']]
    report.update(status='complete', complete=True, active_case=None, active_stage='finished', failure=None,
                  selected_case_names=['baseline'], completed_case_names=['baseline'], cases=[case])
    names = ['sources/'+name for name in report['source_sha256']]
    names += ['toolchain.json', 'toolchain/ngspice-elf', 'toolchain/spice-lib/scripts/spinit',
              'baseline/values.txt.gz', 'baseline/sampling.json', 'baseline/circuit.cir', 'baseline/ngspice.log']
    names += [o['transcript'] for o in case['observations']]
    names += [o['transcript'].removesuffix('.jsonl.gz')+'/engine.msl' for o in case['observations']]
    names += [str(p.relative_to(ORIGINAL)) for p in (ORIGINAL/'baseline').glob('*.stimulus.txt')]
    original_manifest = {}
    for name in names:
        source=ORIGINAL/name;target=seed/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
        assert source.stat().st_ino != target.stat().st_ino
        original_manifest[name]=sha(source)
        assert sha(target)==original_manifest[name]
    write_json(HERE/'original-input-sha256.json',original_manifest)
    write_json(seed/'matrix-plan.json',plan);write_json(seed/'results.json',report)
    (seed/'ARTIFICIAL-AUDIT-CONTROL.txt').write_text('Privately copied baseline; artificial one-case completion declaration. Never acceptance evidence.\n')
    return seed, original_manifest


def clone(seed, name):
    root=HERE/name
    shutil.copytree(seed,root,copy_function=os.link)
    return root


def check(root):
    progress=io.StringIO()
    try:
        with contextlib.redirect_stdout(progress):
            report=analyzer.audit(root)
    except Exception as error:
        result=dict(accepted=False,error_type=type(error).__name__,error=str(error))
        (root/'audit-error.txt').write_text(traceback.format_exc())
    else:
        result=dict(accepted=True,complete=report['complete'],replays=report['replays'],
                    full_replay_matrix=report['cases']['baseline']['full_replay_matrix'],
                    analyzer_sha256=report['analyzer_sha256'])
        write_json(root/'audit.json',report)
    (root/'audit-progress.txt').write_text(progress.getvalue())
    write_json(root/'probe-result.json',result)
    print(root.name,json.dumps(result),flush=True)
    return result


def alter_summary(root, change):
    value=summary(root);change(value['cases'][0]);write_json(root/'results.json',value)


def alter_sampling(root, change):
    path=root/'baseline/sampling.json';value=json.loads(path.read_text());change(value);write_json(path,value)


def alter_frames(root, change):
    value=summary(root);observation=value['cases'][0]['observations'][0]
    path=root/observation['transcript']
    with gzip.open(path,'rt') as source:frames=[json.loads(line) for line in source]
    change(frames)
    body=''.join(json.dumps(f,separators=(',',':'),allow_nan=False)+'\n' for f in frames).encode()
    replace_bytes(path,gzip.compress(body,mtime=0))
    observation['transcript_sha256']=sha(path);observation['final']=frames[-1]
    write_json(root/'results.json',value)


seed, manifest = make_seed()
results={}
results['unmodified_baseline']=check(seed)

for tag, change in [
    ('missing-all-replays',lambda c:c.update(observations=[])),
    ('missing-one-replay',lambda c:c['observations'].pop()),
    ('extra-duplicate-replay',lambda c:c['observations'].append(copy.deepcopy(c['observations'][0]))),
    ('replace-replay-with-duplicate',lambda c:c['observations'].__setitem__(-1,copy.deepcopy(c['observations'][0]))),
]:
    root=clone(seed,tag);alter_summary(root,change);results[tag]=check(root)

for tag, change in [
    ('impossible-pin-metadata',lambda s:s['queries'][0]['samples'][0].update(pin_v=100.)),
    ('changed-reference-metadata',lambda s:s['queries'][0]['samples'][0].update(reference_v=4.)),
    ('changed-scan-timing',lambda s:s['queries'][0]['samples'][0].update(acquisition_us=[1.,2.])),
    ('changed-window-metadata',lambda s:s['queries'][0]['samples'][0].update(reference_range_v=[3.,4.])),
    ('changed-exposure-metadata',lambda s:s['queries'][0]['samples'][0].update(source_ripple_overlaps_acquisition=True)),
    ('changed-point-code',lambda s:s['queries'][0]['raw'].__setitem__(0,s['queries'][0]['raw'][0]+1)),
]:
    root=clone(seed,tag);alter_sampling(root,change);results[tag]=check(root)

root=clone(seed,'changed-msl-only')
obs=summary(root)['cases'][0]['observations'][0]
path=root/(obs['transcript'].removesuffix('.jsonl.gz')+'/engine.msl')
rows=list(csv.reader(io.StringIO(path.read_text()),delimiter='\t'))
changes={}
for name,new in [('ADC0','4095'),('MAP','777'),('Flags','0'),('Faults','0')]:
    index=rows[2].index(name);changes[name]={'before':rows[4][index],'after':new};rows[4][index]=new
stream=io.StringIO();csv.writer(stream,delimiter='\t',lineterminator='\n').writerows(rows)
replace_bytes(path,stream.getvalue().encode());results['changed-msl-only']={**check(root),'changes':changes}

for tag, change in [
    ('changed-stimulus-edge',lambda text: text.replace(' 1\n',' 0\n',1)),
    ('changed-stimulus-query-time',lambda text:text.replace('Q 1000.000000000000','Q 1001.000000000000',1)),
]:
    root=clone(seed,tag);path=root/'baseline/gpio-0.25-0.25.stimulus.txt';old=path.read_text();new=change(old)
    assert old!=new;replace_bytes(path,new.encode());results[tag]=check(root)

for tag, change in [
    ('changed-native-raw-with-new-hash',lambda rows:rows[0]['raw_adc'].__setitem__(0,rows[0]['raw_adc'][0]+1)),
    ('changed-native-basis-with-new-hash',lambda rows:rows[0].update(circuit_ratiometric=True)),
    ('changed-native-strategy-with-new-hash',lambda rows:rows[0].update(strategy_code=1)),
]:
    root=clone(seed,tag);alter_frames(root,change);results[tag]=check(root)

root=clone(seed,'swapped-threshold-identity-labels')
def swap_thresholds(case):
    a=next(o for o in case['observations'] if (o['rising_fraction'],o['falling_fraction'],o['strategy'],o['calibration_basis'])==(.25,.25,0,'absolute'))
    b=next(o for o in case['observations'] if (o['rising_fraction'],o['falling_fraction'],o['strategy'],o['calibration_basis'])==(.75,.75,0,'absolute'))
    a['rising_fraction'],b['rising_fraction']=b['rising_fraction'],a['rising_fraction']
    a['falling_fraction'],b['falling_fraction']=b['falling_fraction'],a['falling_fraction']
alter_summary(root,swap_thresholds);results[root.name]=check(root)
if results[root.name]['accepted']:
    original=json.loads((seed/'audit.json').read_text())['cases']['baseline']
    mutated=json.loads((root/'audit.json').read_text())['cases']['baseline']
    labels=['0.25-0.25:0:absolute','0.75-0.75:0:absolute']
    results[root.name]['original_native_sha256']={label:original['replays'][label]['canonical_sha256'] for label in labels}
    results[root.name]['swapped_native_sha256']={label:mutated['replays'][label]['canonical_sha256'] for label in labels}
    results[root.name]['original_quantized_edges_differ']=original['edge_inputs']['0.25-0.25']!=original['edge_inputs']['0.75-0.75']

root=clone(seed,'changed-startup')
replace_bytes(root/'toolchain/spice-lib/scripts/spinit',b'* Mutated audit control\n')
results[root.name]=check(root)

root=clone(seed,'solver-abort-log')
path=root/'baseline/ngspice.log';replace_bytes(path,path.read_bytes()+b'\nTimestep too small\n')
results[root.name]=check(root)

root=clone(seed,'changed-circuit-deck-only')
path=root/'baseline/circuit.cir';old=path.read_text();new=old.replace('Rmodel_F2 bus5 sensor5 4.5','Rmodel_F2 bus5 sensor5 7.5')
assert old!=new;replace_bytes(path,new.encode());results[root.name]=check(root)

write_json(HERE/'negative-probe-results.json',results)
after={name:sha(ORIGINAL/name) for name in manifest}
write_json(HERE/'original-input-preservation.json',dict(checked=len(manifest),unchanged=after==manifest,before=manifest,after=after))
assert after==manifest
