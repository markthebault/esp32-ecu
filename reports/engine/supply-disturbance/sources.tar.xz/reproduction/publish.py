"""Retain a compact source/audit/review checkpoint; full waveforms stay local."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[3]
CACHE=ROOT/'.cache/engine/flex-nonideal'
OUT=ROOT/'reports/engine/supply-disturbance'

def sha(body):return hashlib.sha256(body).hexdigest()
def read(path):return json.loads(path.read_text())
def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

reports=[read(CACHE/'audit-final-013-001/run-013.json'),read(CACHE/'audit-final-014-001/run-014.json')]
comparison=read(CACHE/'final-comparison-001.json')
review=CACHE/'independent-nonideal-003'
assert all(r['complete'] and r['replays']==624 and len(r['cases'])==26 for r in reports)
assert all(v['identical_discrete_inputs'] and not v['native_record_differences'] for v in comparison['cases'].values())
assert read(review/'independent-native-replays/results.json')['completed_replays']==1248
assert (review/'findings.md').is_file() and (review/'review-close.json').is_file()
analyzer=sha((ROOT/'tools/analyze_flex_nonideal.py').read_bytes())
assert {r['analyzer_sha256'] for r in reports}=={analyzer}
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'README.md').write_text((CACHE/'published-README-001.md').read_text())
archives={}

def pack(name,items):
    assert len(items)==len(set(items))
    members={}
    with tarfile.open(OUT/name,'x:xz',preset=6) as archive:
        for target,source in sorted(items.items()):
            path=Path(target)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0] not in ('AGENTS.md','secrets')
            body=source.read_bytes();info=tarfile.TarInfo(target);info.size=len(body);info.mode=0o644;info.mtime=0
            archive.addfile(info,io.BytesIO(body));members[target]=dict(bytes=len(body),sha256=sha(body))
    archive_bytes=(OUT/name).read_bytes()
    archives[name]=dict(bytes=len(archive_bytes),sha256=sha(archive_bytes),members=members)
    # Re-open every payload and verify exact member bytes, without extraction.
    with tarfile.open(OUT/name,'r:xz') as archive:
        assert set(archive.getnames())==set(members)
        for member in archive:
            body=archive.extractfile(member).read();assert members[member.name]==dict(bytes=len(body),sha256=sha(body))

originals=[read(CACHE/n/'results.json') for n in ('run-013','run-014')]
assert originals[0]['source_sha256']==originals[1]['source_sha256']
sources={}
for name,expected in originals[0]['source_sha256'].items():
    source=CACHE/'run-013/sources'/name;assert sha(source.read_bytes())==expected;sources['frozen/'+name]=source
parent='hardware/a5-idle-interface/net_contract.json'
assert sha((ROOT/parent).read_bytes())==originals[0]['binding']['carrier_sha256']==originals[1]['binding']['carrier_sha256']
sources['recovered-bound/'+parent]=ROOT/parent
current=['tools/analyze_flex_nonideal.py','tools/run_flex_nonideal.py','tools/flex_circuit_control.cpp',
    'tools/test_flex_nonideal.py','tools/fixtures/flex-nonideal-open-before-minbreak.cir',
    'tools/fixtures/flex-nonideal-msl007.json.gz','docs/engine-supply-disturbance.md']
for name in current:sources['current/'+name]=ROOT/name
sources['reproduction/publish.py']=Path(__file__)
pack('sources.tar.xz',sources)

records={}
for index,run in enumerate(('run-013','run-014')):
    audit=CACHE/('audit-final-013-001' if index==0 else 'audit-final-014-001')
    records['audits/'+run+'.json']=audit/(run+'.json')
    records['audits/'+run+'.log']=audit.with_suffix('.log')
    for name in ('results.json','matrix-plan.json','source-hashes.json','toolchain.json','build-commands.json','build-0.log','build-1.log'):
        records[run+'/'+name]=CACHE/run/name
    for case in originals[index]['cases']:
        for name in ('circuit.cir','ngspice.log','sampling.json'):
            rel=case['scenario']['name']+'/'+name;records[run+'/'+rel]=CACHE/run/rel
records['comparison.json']=CACHE/'final-comparison-001.json'
records['authored-tests.log']=CACHE/'nonideal-unit-011.log'
pack('audit-records.tar.xz',records)

review_files=read(review/'archive-whitelist.json')
assert len(review_files)==len(set(review_files))
review_items={name:review/name for name in review_files}
review_items['archive-whitelist.json']=review/'archive-whitelist.json'
# Earlier objections remain visible, separately labelled and never promoted to
# acceptance. Large intentionally mutated fixtures stay in the local cache.
for number in ('001','002'):
    for name in ('findings.md','review.json','metadata.json','review-close.json','negative-probe-results.json'):
        path=CACHE/('independent-nonideal-'+number)/name
        if path.is_file():review_items['earlier-'+number+'/'+name]=path
pack('independent-review.tar.xz',review_items)

rows=[]
for name,case in reports[0]['cases'].items():
    row=dict(name=name,scenario=case['scenario'],coarse_raw_rows=case['raw_rows'],
        fine_raw_rows=reports[1]['cases'][name]['raw_rows'],
        ripple_acquisition_samples=case['ripple_acquisition_samples'],
        max_reference_span_fullscale_lsb=case['max_reference_span_fullscale_lsb'],
        fullscale_reference_span_is_not_an_adc_error_bound=True,strategies={})
    for strategy in range(3):
        row['strategies'][str(strategy)]={}
        for basis in ('absolute','ratiometric'):
            r=case['replays'][f'0.75-0.25:{strategy}:{basis}']
            row['strategies'][str(strategy)][basis]={k:r[k] for k in ('rows','faulted','ready','acknowledgements','fault_masks','settled_map_error_kpa')}
    rows.append(row)
write('results.json',dict(complete=True,meaning='Complete conditional experiment and data-chain audit; not physical qualification',
    matrix_cases=52,scenarios=26,native_replays=1248,
    raw_rows=sum(c['raw_rows'] for r in reports for c in r['cases'].values()),
    identical_declared_discrete_inputs=True,identical_native_records=True,cases=rows,physical_qualification=False))
write('comparison.json',comparison)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
case=reports[0]['cases']['three-volt-dip']
fig,axes=plt.subplots(3,1,figsize=(9,7),sharex=True,layout='constrained')
queries=case['queries'];time=[q['control_us']/1000 for q in queries]
axes[0].plot(time,[q['adc_reference_v'] for q in queries],'.-',color='#536cb0')
axes[0].set_ylabel('ADC7 point\nreference (V)')
for basis,color in [('absolute','#c35a35'),('ratiometric','#198769')]:
    records=case['replays']['0.75-0.25:0:'+basis]['phase0']
    axes[1].plot([r['control_us']/1000 for r in records],[r['map_kpa'] for r in records],'.-',label=basis,color=color)
    axes[2].step([r['control_us']/1000 for r in records],[bool(r['faults']) for r in records],where='post',label=basis,color=color)
axes[1].axhline(50,color='#555555',linestyle=':',label='authored true MAP')
axes[1].set_ylabel('Bound MAP (kPa)');axes[1].legend(loc='upper right',ncols=3,fontsize=8)
axes[2].set_ylabel('Controller fault\n(both proposals cut)');axes[2].set_yticks([0,1],['no','yes'])
axes[2].set_xlabel('Control query time (ms); scan occurs earlier at its declared phase')
for ax in axes:ax.set_xlim(85,115);ax.grid(alpha=.2)
fig.suptitle('Conditional 3.3 V source-dip replay\nIdeal point conversion, authored supply equivalents; no physical execution',fontsize=11)
fig.savefig(OUT/'reference-dip.png',dpi=160);plt.close(fig)
write('manifest.json',dict(schema_version=1,source_base_commit='c2448c0f66c8d007ee47622f9494c6e07aebe8d6',
    current_sources={n:sha((ROOT/n).read_bytes()) for n in current},analyzer_sha256=analyzer,
    recovered_parent=dict(path=parent,sha256=originals[0]['binding']['carrier_sha256'],hash_recorded_before_run=True,bytes_recovered_after_run=True),
    solver_sha256=read(CACHE/'run-013/toolchain.json')['executable_sha256'],
    archives=archives,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(OUT.iterdir()) if p.is_file()},
    plot=dict(path='reference-dip.png',sha256=sha((OUT/'reference-dip.png').read_bytes()),matplotlib=matplotlib.__version__,data_source='audit-final-013-001/run-013.json / three-volt-dip / 0.75-0.25:0 / both calibration bases'),
    local_complete_run_directories=[str(CACHE/n) for n in ('run-013','run-014')],
    not_distributed=['full raw waveforms','all native transcripts/MSL files','solver and native executables'],
    full_rerun_required_for_raw_audit_outside_this_workspace=True,physical_qualification=False))
print(json.dumps(dict(output=str(OUT),archives={n:a['bytes'] for n,a in archives.items()},raw_rows=read(OUT/'results.json')['raw_rows'])))
