"""Independent direct-SIL current file/viewer identity and lifecycle addendum."""
import csv,hashlib,io,json,math,os,sys
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu')
WORK=ROOT/'.cache/engine/tuning-apps-011-001'
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from engine_log import export_msl
from boost_config import log_fields
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
log=WORK/'direct-sil008.msl';session=WORK/'mlv-direct-sil/session.json';closed=WORK/'mlv-direct-sil/closed.json'
inputs=[log,session,closed,WORK/'direct-sil-state.json',WORK/'direct-sil-summary.json',WORK/'direct-sil-file-check.json',WORK/'mlv-direct-sil/actions.jsonl',WORK/'mlv-direct-sil/direct-sil-boost-reason.png',ROOT/'tools/engine_log.py',ROOT/'tools/boost_config.py']
before={str(p.relative_to(ROOT)):sha(p) for p in inputs}
metadata=json.loads(session.read_text());closure=json.loads(closed.read_text());summary=json.loads((WORK/'direct-sil-summary.json').read_text())
lines=log.read_text().splitlines();expected=export_msl([],summary['scenario'],summary['strategy']).splitlines()
assert lines[:4]==expected
headers=lines[2].split('\t');units=lines[3].split('\t');assert len(headers)==len(set(headers))==len(units)==202
raw=list(csv.reader(io.StringIO('\n'.join(lines[4:])),delimiter='\t'));assert len(raw)==300 and all(len(row)==202 for row in raw)
rows=[dict(zip(headers,row)) for row in raw]
assert all(math.isfinite(float(r['Time'])) for r in rows)
times=[float(r['Time']) for r in rows]
assert times[0]==0 and times[-1]==5.98 and all(math.isclose(b-a,.02,abs_tol=1e-12) for a,b in zip(times,times[1:]))
boost=log_fields();assert len(boost)==16 and headers[-16:]==[x[0] for x in boost] and units[-16:]==[x[1] for x in boost]
field_stats={}
for name,unit,key in boost:
 tokens=[row[name] for row in rows]
 values=[float(value) for value in tokens if value!='NaN']
 assert all(math.isfinite(value) for value in values)
 field_stats[name]=dict(unit=unit,known=len(values),unknown=len(tokens)-len(values),minimum=min(values) if values else None,maximum=max(values) if values else None)
 if name in ('BoostAvailable','BoostPressureEnabled','BoostInhibitEngine'):assert all(value in ('0','1') for value in tokens)
 if name in ('BoostFlags','BoostReason','BoostMode','BoostPidUpdates','BoostOverboostEvents'):
  assert all(value.isdigit() and 0<=int(value)<=4294967295 for value in tokens)
assert set(row['BoostReason'] for row in rows)=={'6','8'}
assert rows[-1]['BoostReason']=='6'
assert metadata['input']==str(log) and metadata['input_sha256']==sha(log)
assert metadata['physical_connection'] is False and metadata['online'] is False
factory=Path('/home/mark/.local/opt/efi-analytics/MegaLogViewerHD-4.6.14/MegaLogViewerHD')
copy=WORK/'mlv-direct-sil/app';binaries=[]
for original in sorted(factory.rglob('*')):
 if original.is_file() and original.suffix.lower() in ('.jar','.class','.so','.dll','.dylib'):
  relative=original.relative_to(factory);target=copy/relative
  assert target.is_file() and sha(original)==sha(target),str(relative)
  binaries.append(dict(path=relative.as_posix(),bytes=original.stat().st_size,sha256=sha(original)))
assert metadata['jar_sha256']==sha(copy/'HogLogViewer.jar')=='18205c30686de499d722a3244d4e8dab01a64dce868c986bfc54a05d0f2afc4c'
processes=[]
for key in ('java_pid','xvfb_pid'):
 pid=metadata[key]
 try:os.kill(pid,0)
 except ProcessLookupError:present=False
 else:present=True
 processes.append(dict(role=key,pid=pid,present_now=present))
 assert not present,(key,pid)
assert closure==dict(java_returncode=143,xvfb_returncode=0,endpoint_failure=None,all_owned_processes_terminal=True)
assert summary['physical_outputs_enabled'] is False and summary['model']=='unvalidated reduced-order SI plant v1'
assert before=={str(p.relative_to(ROOT)):sha(p) for p in inputs}
report=dict(passed=True,scope='Current202-column direct-SIL MSL008 file shape/header/current sixteen boost fields and actual selected BoostReason plot; no new simulator/engine/physical acceptance',rows=len(rows),columns=len(headers),boost_fields=field_stats,plot=dict(selected='BoostReason',minimum=6,maximum=8,current_last_value=6,visual_evidence='direct-sil-boost-reason.png',visual_confirmation='Independently viewed screenshot shows unmodified MLVHD Lite4.6.14, direct-sil008.msl, max8.000/min6.000/current6.000'),input_sha256=before,unmodified_vendor_binaries=binaries,processes=processes,physical_connection=False,physics_accepted=False,online_accepted=False,full_goal_complete=False)
(OUT/'probe-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(passed=True,rows=len(rows),columns=len(headers),boost_fields=len(boost),unchanged_vendor_binaries=len(binaries),all_owned_processes_absent=True)))
