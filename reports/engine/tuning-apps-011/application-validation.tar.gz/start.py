"""Run unmodified vendor apps on an owned Xvfb, copied app and fresh profile."""
import argparse,hashlib,json,os,select,shutil,subprocess,sys,threading
from pathlib import Path
from PIL import ImageGrab
ROOT=Path('/home/mark/persospace/esp32-ecu');sys.path.insert(0,str(ROOT/'tools'))
p=argparse.ArgumentParser();p.add_argument('app',choices=('ts','mlv'));p.add_argument('--output',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--online',action='store_true');a=p.parse_args()
task=a.output.resolve();task.mkdir(parents=True,exist_ok=False);home=task/'user';home.mkdir()
original=Path('/home/mark/.local/opt/efi-analytics')/('TunerStudioMS-3.3.01/TunerStudioMS' if a.app=='ts' else 'MegaLogViewerHD-4.6.14/MegaLogViewerHD')
app=task/'app';shutil.copytree(original,app)
jar='TunerStudioMS.jar' if a.app=='ts' else 'HogLogViewer.jar'
target=a.input.resolve();endpoint=None;store=None;wire=None;display=None;java=None
if a.app=='ts':
 project=task/'ESP32ECU-BOOST-011'
 shutil.copytree(ROOT/'.cache/engine/flex-integration/applications/ts/ESP32ECU-FLEX-010',project)
 shutil.copyfile(ROOT/'tuning/esp32-ecu-boost.ini',project/'projectCfg/mainController.ini')
 shutil.copyfile(target,project/'CurrentTune.msq')
 link=task/'tuner-serial';props=project/'projectCfg/project.properties';lines=[]
 for line in props.read_text().splitlines():
  if 'Com\\ Port=' in line or line.startswith('commPort='):line=line.split('=',1)[0]+'='+str(link)
  if line.startswith('projectName='):line='projectName=ESP32ECU-BOOST-011'
  if line.startswith('lastDisplayedTuneFile='):line='lastDisplayedTuneFile=CurrentTune.msq'
  if line.startswith('tuneFileDir='):line='tuneFileDir='+str(task)
  lines.append(line)
 props.write_text('\n'.join(lines)+'\n');target=project
 if a.online:
  from engine_runtime import EngineStore
  from engine_msq import import_msq
  from tuning_server import PtyEndpoint
  state=task/'engine.json';state.write_text(json.dumps(import_msq(a.input.read_bytes(),base_revision=1)))
  store=EngineStore(state);wire=(task/'wire.log').open('x');wire_lock=threading.Lock();used=0
  def capture(direction,body):
   global used
   line=f'{direction} {len(body)} {body.hex()}\n'
   with wire_lock:
    if used+len(line)>2*1024**2:raise OSError('Owned capture bound reached; capture incomplete')
    wire.write(line);wire.flush();used+=len(line)
  endpoint=PtyEndpoint(store,link,on_wire=capture)
try:
 read,write=os.pipe()
 try:
  display=subprocess.Popen(['Xvfb','-displayfd',str(write),'-screen','0','1440x1000x24','-nolisten','tcp'],pass_fds=[write],stdout=subprocess.DEVNULL,stderr=(task/'xvfb.log').open('x'))
  os.close(write);write=None
  if not select.select([read],[],[],5)[0]:raise RuntimeError('Owned Xvfb did not report a display')
  number=os.read(read,64).decode().strip()
 finally:
  os.close(read)
  if write is not None:os.close(write)
 env=dict(os.environ,DISPLAY=':'+number)
 command=['java','-Duser.home='+str(home),'-Djava.awt.headless=false']
 if a.app=='ts':command+=['-Djava.library.path=lib/alternateLinuxDrivers/x86_64-linux:lib']
 command+=['-jar',jar,str(target)]
 java=subprocess.Popen(command,cwd=app,env=env,stdout=(task/'application.log').open('x'),stderr=subprocess.STDOUT)
 metadata=dict(command=command,display=env['DISPLAY'],java_pid=java.pid,xvfb_pid=display.pid,
  input=str(a.input.resolve()),input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),
  jar_sha256=hashlib.sha256((app/jar).read_bytes()).hexdigest(),online=a.online,physical_connection=False)
 (task/'session.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata),flush=True)
 for line in sys.stdin:
  item=json.loads(line);action=item['action']
  if action=='quit':break
  if action=='snap':
   assert java.poll() is None,java.returncode
   name=item['name'];assert Path(name).name==name
   ImageGrab.grab(xdisplay=env['DISPLAY']).save(task/name);print('saved '+name,flush=True)
  elif action=='keys':
   args=item['args'];assert all(isinstance(v,str) for v in args)
   r=subprocess.run(['xdotool',*args],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   print(json.dumps(dict(returncode=r.returncode,output=r.stdout)),flush=True)
  elif action=='windows':
   ids=subprocess.run(['xdotool','search','--onlyvisible','--name','.'],env=env,text=True,capture_output=True)
   for window in ids.stdout.split():print(window,subprocess.run(['xdotool','getwindowname',window],env=env,text=True,capture_output=True).stdout.strip(),flush=True)
  (task/'actions.jsonl').open('a').write(json.dumps(item)+'\n')
finally:
 for process in (java,display):
  if process and process.poll() is None:
   process.terminate()
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
 if endpoint:endpoint.close()
 if store:store.runtime.close();store.data_recorder.close()
 if wire:wire.close()
 (task/'closed.json').write_text(json.dumps(dict(java_returncode=java.returncode if java else None,xvfb_returncode=display.returncode if display else None,endpoint_failure=endpoint.failure if endpoint else None,all_owned_processes_terminal=True),indent=2)+'\n')
