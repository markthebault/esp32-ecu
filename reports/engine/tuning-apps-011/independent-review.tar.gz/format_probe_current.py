import copy,csv,ctypes,hashlib,io,json,re,struct,sys,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from engine_runtime import EngineStore
from engine_protocol import Session,pages,decode_pages,envelope,SIGNATURE,LIVE_BYTES
from engine_msq import export_msq,import_msq,tag
import tuning_runtime
library=ctypes.CDLL(str(OUT/'libtuning-review.so'));P=ctypes.c_void_p;Z=ctypes.c_size_t;B=ctypes.POINTER(ctypes.c_uint8)
signatures={'tuning_create':([P,tuning_runtime.LOAD,tuning_runtime.CURRENT,tuning_runtime.COMMIT,tuning_runtime.SAMPLE],P),'tuning_destroy':([P],None),'tuning_command':([P,P,Z,ctypes.POINTER(Z)],B),'tuning_feed':([P,P,Z,ctypes.c_uint64,ctypes.POINTER(Z)],B),'tuning_page':([P],B),'tuning_status':([P],ctypes.c_char_p),'tuning_buffered':([P],Z),'tuning_disconnect':([P],None)}
for name,(args,result) in signatures.items():
 fn=getattr(library,name);fn.argtypes=args;fn.restype=result
tuning_runtime.load_bridge=lambda:library
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['tuning/editor-limits.json','tuning/esp32-ecu-boost.ini','tuning/protocol-layout.json','tools/engine_msq.py','tools/engine_protocol.py','firmware/include/ecu/tuning_layout.hpp','firmware/include/ecu/tuning_live.hpp','firmware/include/ecu/engine_log_msl.hpp','tools/engine_log.py']
before={p:sha(ROOT/p) for p in names};checks=[]
with tempfile.TemporaryDirectory() as folder:
 store=EngineStore(Path(folder)/'tune.json');t=copy.deepcopy(store.tune)
 t['boost_control'].update(pressure_enabled=True,mode='closed_loop',kp=.625,ki=.125,kd=.25)
 for kind in ('open_duty','target','feedforward'):
  t['boost_control'][kind]['rpm']=[600,1100,1700,2300,3100,4300,6100,8100]
  t['boost_control'][kind]['cells']=[140+i*.125 if kind=='target' else i+.125 if kind=='open_duty' else 90-i*.5 for i in range(64)]
 assert store.save(json.dumps(t).encode())[0]==200
 tune=store.tune;xml=export_msq(tune);(OUT/'probe-current-input.msq').write_text(xml)
 (OUT/'probe-current-input.json').write_text(json.dumps(tune,indent=2)+'\n')
 constants={e.get('name'):e for e in ET.fromstring(xml).iter(tag('constant'))}
 with_session=Session(store)
 try:
  native=bytes(with_session.buffers[1]);(OUT/'native-current-page.bin').write_bytes(native)
  assert len(native)==12288 and pages(import_msq(xml,base_revision=tune['revision']))[1]==native
  section='';expected=bytearray(12288);mapped=set();field_count=0
  for line in (ROOT/'tuning/esp32-ecu-boost.ini').read_text().splitlines():
   if line.startswith('['):section=line.strip();continue
   if section!='[Constants]':continue
   m=re.match(r'\s*(\w+)\s*=\s*(scalar|array|bits),\s*(U08|U32|F32),\s*(\d+),\s*(.*)',line)
   if not m:continue
   name,kind,typ,offset,tail=m.groups();offset=int(offset);field_count+=1
   element=constants[name];text=element.text.strip();width={'U08':1,'U32':4,'F32':4}[typ];code={'U08':'B','U32':'I','F32':'f'}[typ]
   if kind=='bits':
    parts=next(csv.reader([tail],skipinitialspace=True));span=re.fullmatch(r'\[(\d+):(\d+)\]',parts[0]);lo,hi=map(int,span.groups())
    labels=parts[1:];value=labels.index(text.strip('"'));mask=((1<<(hi-lo+1))-1)<<lo
    old=struct.unpack_from('<I',expected,offset)[0];struct.pack_into('<I',expected,offset,old|(value<<lo))
    assert struct.unpack_from('<I',native,offset)[0]&mask==value<<lo,name
   else:
    values=[float(v) for v in text.split()]
    if kind=='array':
     shape=re.match(r'\[(\d+)(?:x(\d+))?\]',tail);count=int(shape[1])*int(shape[2] or 1)
    else:count=1
    assert len(values)==count,name
    encoded=struct.pack('<'+str(count)+code,*values) if typ=='F32' else struct.pack('<'+str(count)+code,*map(int,values))
    assert native[offset:offset+len(encoded)]==encoded,name
    expected[offset:offset+len(encoded)]=encoded
   mapped.add(name)
  assert mapped==set(constants) and expected==native
  checks.append(dict(name='Every INI constant independently maps to the complete native calibration page',constants=field_count,page_bytes=len(native)))
  assert with_session.command(b'Q')==b'\0'+SIGNATURE
  live=with_session.command(b'r\0\x30'+struct.pack('<HH',0,1152));assert len(live)==1153 and live[0]==0
  checks.append(dict(name='Current identity and complete runtime read',identity=SIGNATURE.decode(),live_bytes=1152,framed_bytes=len(envelope(live))))
  changed=copy.deepcopy(tune);changed['boost_control']['open_duty']['cells'][17]=18.375;body=pages(changed)[1]
  for offset in range(0,12288,256):
   chunk=body[offset:offset+256];assert with_session.command(b'M\0\1'+struct.pack('<HH',offset,len(chunk))+chunk)==b'\0'
  assert with_session.command(b'b\0\1')==b'\4';active=copy.deepcopy(store.tune);assert active['revision']==tune['revision']+1
  assert active['boost_control']['open_duty']['cells'][17]==18.375 and with_session.buffers[1]==body
  checks.append(dict(name='48 chunks stage/commit atomically and retain session origin',chunks=48,active_revision=active['revision'],origin_revision=tune['revision']))
  invalid=struct.pack('<f',150);assert with_session.command(b'M\0\1'+struct.pack('<HH',8208,4)+invalid)==b'\0'
  assert with_session.command(b'b\0\1')==b'\x84' and store.tune==active
  checks.append(dict(name='Cross-table invalid cut rejected without partial calibration activation',burn_status=132))
 finally:with_session.close()
 root=ET.fromstring(xml);page=root.find(tag('page'))
 controls=[]
 def reject(label,body):
  try:import_msq(body)
  except ValueError:controls.append(label)
  else:raise AssertionError('Malformed MSQ accepted: '+label)
 reject('wrong own identity',xml.replace(SIGNATURE.decode(),'speeduino 202504-dev'))
 altered=copy.deepcopy(root);p=altered.find(tag('page'));p.append(copy.deepcopy(next(e for e in p if e.get('name')=='boost_mode')));reject('duplicate boost selection',ET.tostring(altered))
 altered=copy.deepcopy(root);next(e for e in altered.iter(tag('constant')) if e.get('name')=='boost_kp').text='NaN';reject('nonfinite gain',ET.tostring(altered))
 altered=copy.deepcopy(root);p=altered.find(tag('page'));p.remove(next(e for e in p if e.get('name')=='boost_feedforward_cells'));reject('missing latest table',ET.tostring(altered))
 altered=copy.deepcopy(root);altered.find(tag('page')).set('number','1');reject('wrong page',ET.tostring(altered))
 checks.append(dict(name='Malformed current MSQ controls rejected',controls=controls))

for kind in range(3):
 b=(OUT/f'live-{kind}.bin').read_bytes();assert len(b)==1152
 if kind==0:assert b[832:]==bytes(320)
 elif kind==1:assert all(__import__('math').isnan(v) for v in struct.unpack_from('<8f',b,832)) and struct.unpack_from('<I',b,864)[0]==0
 else:
  assert struct.unpack_from('<8f',b,832)==(42.125,63.25,175.5,27.75,5.875,-2.25,3.5,-.125)
  assert struct.unpack_from('<II',b,880)==(123,2097152) and struct.unpack_from('<II',b,888)==(71,2147483648)
 rows=list(csv.reader(io.StringIO((OUT/f'log-{kind}.msl').read_text()),delimiter='\t'))
 assert len(rows[2])==len(rows[3])==len(rows[4])==245
 values=dict(zip(rows[2],rows[4]))
 assert values['BoostAvailable']==('1' if kind==2 else '0')
 if kind==2:assert values['BoostPidUpdates']==str((1<<53)+123) and values['BoostOverboostEvents']==str((1<<63)+71)
 else:assert all(values[key]=='NaN' for key in ('BoostDuty','BoostTarget','BoostP','BoostD'))
checks.append(dict(name='Native live and245-column MSL preserve unavailable values and full U64 counter halves/text',states=3,large_counters=[str((1<<53)+123),str((1<<63)+71)]))
assert before=={p:sha(ROOT/p) for p in names}
assert sha(OUT/'libtuning-review.so')==json.loads((OUT/'fresh-build-manifest.json').read_text())['library_sha256']
(OUT/'format-probe-current-results.json').write_text(json.dumps(dict(passed=True,checks=checks,source_sha256=before,qualification='Native and own-definition consistency only; actual proprietary application acceptance remains separate.'),indent=2)+'\n')
print(json.dumps(dict(passed=True,checks=len(checks))))
