#include "ecu/tuning_live.hpp"
#include "ecu/engine_log_msl.hpp"
#include <cstdio>
#include <fstream>
#include <string>

int main(int argc,char**argv){
 if(argc!=2)return 2;
 const std::string directory=argv[1];
 for(unsigned kind=0;kind<3;++kind){
  ecu::engine::RuntimeSample sample;
  if(kind){sample.flags=ecu::engine::Present;sample.sequence=1;sample.source=ecu::engine::DataSource::Synthetic;sample.control_us=1000000;sample.sampled_us=1000000;sample.tune_revision=7;sample.sensor_revision=3;}
  if(kind==2){
   auto&boost=sample.boost_control;boost.available=true;boost.pressure_enabled=true;boost.mode=2;boost.reason=1;boost.flags=1;
   boost.values={42.125F,63.25F,175.5F,27.75F,5.875F,-2.25F,3.5F,-.125F};boost.counters={(std::uint64_t{1}<<53)+123,(std::uint64_t{1}<<63)+71};
  }
  std::array<std::uint8_t,ecu::tuning::live_bytes>live;
  ecu::tuning::live_block(sample,1001000,live);
  std::ofstream binary(directory+"/live-"+std::to_string(kind)+".bin",std::ios::binary);binary.write(reinterpret_cast<const char*>(live.data()),live.size());
  char header[18000],row[12000];ecu::engine_log::Header h;h.source=sample.source;h.log_id=9;h.started_us=1000000;
  ecu::engine_log::Row item;item.sample=sample;item.recorded_us=1001000;item.log_id=9;item.sequence=1;
  if(!ecu::engine_log::msl_header(h,header,sizeof header)||!ecu::engine_log::msl_row(h,item,row,sizeof row))return 3;
  std::ofstream msl(directory+"/log-"+std::to_string(kind)+".msl");msl<<header<<row;
 }
}
