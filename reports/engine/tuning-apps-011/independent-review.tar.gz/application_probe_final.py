"""Audit actual application artifacts, without trusting the author's summaries."""
import copy,csv,hashlib,io,json,math,re,struct,sys,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');OUT=Path(__file__).resolve().parent;APP=ROOT/'.cache/engine/tuning-apps-011-001'
sys.path.insert(0,str(ROOT/'tools'))
from engine_msq import import_msq,tag
from engine_protocol import pages
from analyze_tuning_wire import analyze
from units_probe import definitions,split,compare
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
base=json.loads((APP/'application-tune.json').read_text());base['revision']=7
changed=copy.deepcopy(base)
for kind,index,value in [('open_duty',0,13.25),('target',9,149.75),('feedforward',18,31.125)]:changed['boost_control'][kind]['cells'][index]=value
for file,tune in [('application-saved011.msq',base),('application-edited011.msq',changed),('application-latest-definition011.msq',changed)]:
 path=APP/file;before=path.read_bytes();parsed=import_msq(before,base_revision=7);expected=bytes(pages(tune)[1]);actual=bytes(pages(parsed)[1]);assert actual==expected,file
 tree=ET.fromstring(before);constants={e.get('name'):e for e in tree.iter(tag('constant'))}
 assert len(constants)==202 and 'baseRevision' not in constants
 assert not compare(before,allow_origin_omission=True)
 for name in ('boost_pressure_enabled','boost_mode','boost_activation'):assert constants[name].get('units','')==''
 assert path.read_bytes()==before
 records.append(dict(file=file,page_bytes=len(actual),constants=202,origin_omitted=True,explicit_base=7,whole_page_equal=True,sha256=sha(path)))

published=json.loads((ROOT/'tuning/editor-limits.json').read_text());independent=json.loads((OUT/'native-editor-limits.json').read_text())
for section in ('scalar_limits','curve_limits','timing_limits'):
 assert published[section]==independent[section]
 for name,(low,high) in independent[section].items():
  args=definitions[name];index=6 if args[0]=='scalar' else 7
  assert float(args[index])==low,name
  if isinstance(high,str):assert re.sub(r'\s+','',args[index+1])=='{'+high+'}',name
  else:assert float(args[index+1])==high,name
records.append(dict(editor_ranges_match=True,scalars=33,curves=6,timing=3,dynamic_dwell_ceiling=True,ini_sha256=sha(ROOT/'tuning/esp32-ecu-boost.ini')))

wire=APP/'ts-online/wire.log';capture=analyze(wire)
assert capture['capture_complete'] and not capture['invalid_frames'] and not capture['unanswered_requests']
assert capture['command_counts']=={'F':337,'I':337,'f':674,'Q':337} and capture['complete_transactions']==1685
assert capture['signatures']==['ESP32ECU DEV 011 INHIBITED']
assert all(cap==dict(protocol=2,read_chunk_bytes=256,write_chunk_bytes=256) for cap in capture['capabilities'])
debug=APP/'ts-online/user/TunerStudioProjects/TunerStudioAppDebug.txt';log=debug.read_text(errors='replace')
assert log.count('Unsupported Controller Firmware: ESP32ECU DEV 011 INHIBITED')==337
closed=json.loads((APP/'ts-online/closed.json').read_text());assert closed['all_owned_processes_terminal'] and not closed['endpoint_failure']
assert sha(APP/'ts-online/ESP32ECU-BOOST-011/projectCfg/mainController.ini')==sha(ROOT/'tuning/esp32-ecu-boost.ini')
records.append(dict(own011_online_supported=False,explicit_unsupported_cycles=337,complete_valid_exchanges=1685,no_calibration_runtime_write_burn_requests=True,all_owned_processes_terminal=True,wire_sha256=sha(wire),debug_sha256=sha(debug)))

path=APP/'boost-control008.msl';lines=list(csv.reader(io.StringIO(path.read_text()),delimiter='\t'));headers=lines[2];units=lines[3];rows=lines[4:]
assert len(headers)==len(units)==245 and len(set(headers))==245 and len(rows)==120
source=json.loads((APP/'boost-control-samples.json').read_text());assert 'no engine plant' in source['scope'].lower() or 'authored' in source['scope'].lower(),source['scope']
samples={str(row['sequence']):row for row in source['samples']};assert len(samples)==121
values={'BoostDuty':'duty_pct','BoostDemand':'demand_pct','BoostTarget':'target_kpa','BoostFeedforward':'feedforward_pct','BoostError':'error_kpa','BoostP':'p_term','BoostI':'i_term','BoostD':'d_term'}
integer={'BoostFlags':'flags','BoostReason':'reason_code','BoostMode':'mode_code','BoostAvailable':'available','BoostPressureEnabled':'pressure_enabled','BoostInhibitEngine':'inhibit_engine','BoostPidUpdates':'pid_updates','BoostOverboostEvents':'overboost_events'}
unknown_lambda=0;peak=0
for row in rows:
 assert len(row)==245
 raw=dict(zip(headers,row));sample=samples[raw['SnapshotSequence']];boost=sample['boost_control']
 assert int(raw['InputValidMask'])==sample['input_valid_mask'] and int(raw['Source'])==2
 for name,key in values.items():
  value=boost[key]
  if value is None:assert raw[name]=='NaN',(name,value,raw[name])
  else:assert struct.pack('<f',float(raw[name]))==struct.pack('<f',value),(name,value,raw[name])
 for name,key in integer.items():assert int(raw[name])==int(boost[key]),name
 measured=sample['inputs']['lambda']
 if measured is None:assert raw['Lambda']=='NaN' and not sample['input_valid_mask']&32;unknown_lambda+=1
 else:assert float(raw['Lambda'])==measured and sample['input_valid_mask']&32
 peak=max(peak,float(raw['BoostDuty']))
records.append(dict(msl_columns=245,msl_rows=120,all16_boost_columns_match_source=True,unknown_lambda_rows=unknown_lambda,peak_boost_duty=peak,msl_sha256=sha(path),source_sha256=sha(APP/'boost-control-samples.json'),scope=source['scope'],vendor_calculated_afr_not_accepted=True))

(OUT/'application-artifact-final-results.json').write_text(json.dumps(dict(passed=True,checks=records,qualification='Actual offline MSQ byte preservation plus current MSL/capture artifact integrity. Third-party online support is rejected, not accepted; no physical/engine/target throughput qualification.'),indent=2)+'\n')
print(json.dumps(dict(passed=True,checks=len(records))))
