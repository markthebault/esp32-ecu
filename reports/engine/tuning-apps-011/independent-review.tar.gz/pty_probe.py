"""Independent coalesced-request and observer-I/O-failure PTY controls."""
import hashlib,json,os,select,struct,sys,tempfile,time,zlib
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'tools'))
from engine_runtime import EngineStore
from engine_protocol import envelope,SIGNATURE
from tuning_server import PtyEndpoint
records=[]
for failure in (False,True):
 with tempfile.TemporaryDirectory() as folder:
  store=EngineStore(Path(folder)/'tune.json');events=[]
  def observer(direction,body):
   events.append((direction,bytes(body)))
   if failure and direction=='TX':raise OSError('Independent observer I/O failure control')
  endpoint=PtyEndpoint(store,Path(folder)/'serial',on_wire=observer)
  try:
   fd=os.open(endpoint.link,os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK)
   try:
    request=envelope(b'Q')+(b'' if failure else envelope(b'r\0\x30'+struct.pack('<HH',0,1152)))
    os.write(fd,request);reply=bytearray();end=time.monotonic()+3
    while time.monotonic()<end:
     if select.select([fd],[],[],.01)[0]:
      try:reply.extend(os.read(fd,79))
      except OSError:break
     if failure and not endpoint.thread.is_alive():break
     if not failure and len(reply)>=len(SIGNATURE)+7+1159:break
   finally:os.close(fd)
  finally:
   endpoint.close();store.runtime.close();store.data_recorder.close()
  assert not endpoint.thread.is_alive() and not endpoint.link.exists()
  assert b''.join(data for direction,data in events if direction=='RX')==request
  assert endpoint.failure==('Independent observer I/O failure control' if failure else '')
  if not failure:
   assert b''.join(data for direction,data in events if direction=='TX')==reply
   frames=[];raw=reply
   while raw:
    size=int.from_bytes(raw[:2],'big');frame=raw[:size+6];assert zlib.crc32(frame[2:-4])==int.from_bytes(frame[-4:],'big');frames.append(bytes(frame[2:-4]));raw=raw[size+6:]
   assert frames[0]==b'\0'+SIGNATURE and len(frames[1])==1153 and frames[1][0]==0
  records.append(dict(observer_failure=failure,request_bytes=len(request),reply_bytes=len(reply),failure=endpoint.failure,owned_thread_and_link_closed=True))
source=ROOT/'tools/tuning_server.py'
(OUT/'pty-controls.json').write_text(json.dumps(dict(passed=True,cases=records,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),qualification='Owned Linux PTY only; observer records successful host reads/writes, not physical USB delivery or application consumption.'),indent=2)+'\n')
print(json.dumps(records))
