"""Compare MSQ units only with real Constants, using helper enums for expressions."""
import hashlib,json,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from engine_msq import export_msq,tag

def split(text):
    result=[];start=0;quote=False;depth=0
    for i,char in enumerate(text):
        if char=='"':quote=not quote
        if quote:continue
        if char in '{[(':depth+=1
        elif char in '}])':depth-=1
        elif char==',' and not depth:result.append(text[start:i].strip().strip('"'));start=i+1
    result.append(text[start:].strip().strip('"'));return result

ini=(ROOT/'tuning/esp32-ecu-boost.ini').read_text();section='';definitions={};helpers={}
for line in ini.splitlines():
    if line.startswith('['):section=line.strip();continue
    m=re.match(r'\s*(\w+)\s*=\s*(.*)',line)
    if not m:continue
    args=split(m[2])
    if section=='[Constants]' and args[0] in ('scalar','array','bits'):definitions[m[1]]=args
    elif section=='[PcVariables]' and args[0]=='bits':helpers[m[1]]=args[3:]

def compare(body,allow_origin_omission=False):
    elements={e.get('name'):e for e in ET.fromstring(body).iter(tag('constant'))}
    expected=set(definitions)-({'baseRevision'} if allow_origin_omission and 'baseRevision' not in elements else set())
    assert set(elements)==expected
    mismatches=[]
    for name,args in definitions.items():
        if name not in elements:continue
        if args[0]=='bits':expected=''
        else:
            expected=args[3 if args[0]=='scalar' else 4]
            if expected.startswith('{'):
                match=re.fullmatch(r'\{\s*bitStringValue\((\w+),\s*(\w+)\)\s*\}',expected)
                assert match,expected
                helper,selection=match.groups();labels=definitions[selection][4:];value=elements[selection].text.strip().strip('"')
                index=labels.index(value) if value in labels else int(value);expected=helpers[helper][index]
        if elements[name].get('units','')!=expected:mismatches.append(dict(name=name,expected=expected,actual=elements[name].get('units','')))
    return mismatches

old=(OUT/'probe-input.msq').read_text();new=export_msq(json.loads((OUT/'probe-input.json').read_text()))
old_mismatch=compare(old);new_mismatch=compare(new)
assert {r['name'] for r in old_mismatch}=={'boost_pressure_enabled','boost_mode','boost_activation'}
assert not new_mismatch,new_mismatch
(OUT/'probe-unit-fixed.msq').write_text(new)
report=dict(passed=True,constants_compared=len(definitions),pc_helpers_excluded_from_expected_tune=sorted(helpers),original_mismatches=old_mismatch,current_mismatches=new_mismatch,
            ini_sha256=hashlib.sha256(ini.encode()).hexdigest(),exporter_sha256=hashlib.sha256((ROOT/'tools/engine_msq.py').read_bytes()).hexdigest())
(OUT/'unit-metadata-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
