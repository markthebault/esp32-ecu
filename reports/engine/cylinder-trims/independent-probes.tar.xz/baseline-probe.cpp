#include "ecu/engine_json.hpp"
#include "ecu/timing_executor.hpp"
#include "ecu/engine_data.hpp"
#include "ecu/engine_log.hpp"
#include <cstdlib>
extern "C" int validate_length(const char*text){auto*j=cJSON_ParseWithOpts(text,nullptr,true);ecu::engine::Tune t;bool valid=j&&ecu::engine::parse_tune(j,t);char*encoded=valid?cJSON_PrintUnformatted(j):nullptr;int n=encoded?std::strlen(encoded):0;cJSON_Delete(j);cJSON_free(encoded);return n;}
extern "C" int current_canonical(const char*text){ecu::engine::Tune t;std::string s;return ecu::engine::canonical_tune(text,t,s)?s.size():0;}
extern "C" unsigned current_size(unsigned which){switch(which){case 0:return sizeof(ecu::engine::Tune);case 1:return sizeof(ecu::engine::Output);case 2:return sizeof(ecu::timing::Command);case 3:return sizeof(ecu::timing::Executor::Candidate);case 4:return sizeof(ecu::timing::Executor);case 5:return sizeof(ecu::engine::RuntimeSample);case 6:return sizeof(ecu::engine_log::Recorder);default:return sizeof(ecu::engine_log::Page);}}
