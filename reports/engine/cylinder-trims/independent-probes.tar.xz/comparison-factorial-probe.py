#!/usr/bin/env python3
"""Independent fixtures and calculations; imports controllers/coupler, not test metrics."""
from pathlib import Path
import sys,copy,hashlib,json,statistics,time
R=Path('/home/mark/persospace/esp32-ecu');sys.path.insert(0,str(R/'tools'))
import compare_engine_controllers as bench
from engine_research_plant import ResearchPlant
from run_target_scenarios import TargetController
from speeduino_runtime import SpeeduinoRuntime
OUT=R/'.cache/engine/cylinder-review'
FLOW=[1.,.9,1.08,.95];OFFSETS=[-3,2,5,-4]
BASE=R/'.cache/engine/cylinder-scenarios-final'
original=bench.OurController,bench.SpeeduinoRuntime,bench.ResearchPlant
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((R/'.cache/engine/cylinder-transients/summary.json').read_text())['source_hashes']
for n,h in source.items():assert sha(R/n)==h,n
report={'scope':'Independent final-window combustion recapture and isolated fuel/spark controls on same declared uncalibrated fixture. No production edits, physical engine or real-time IRQ claim. Uses supplied coupler but independent fixture generation and metrics.', 'source_hashes':source,'cases':[],'failures':[]}
started=time.monotonic()
try:
 for who in ['ours','speeduino']:
  pw=json.loads((BASE/'speeduino-disabled.json').read_text())['trace'][-1]['ecu']['pulse_us']
  for kind,step in [('both_fine',125),('fuel_only',250),('spark_only',250)]:
   tune=copy.deepcopy(bench.benchmark_tune());trim=tune['cylinder_trims'];trim['enabled']=True
   for i in range(4):
    factor=100/FLOW[i] if who=='ours' else 100*(900+(pw-900)/FLOW[i])/pw
    trim['fuel_maps'][i]['cells']=[100 if kind=='spark_only' else factor]*36
   trim['spark_deg']=[0]*4 if kind=='fuel_only' else OFFSETS
   instances=[];att=[]
   class FixedPlant(ResearchPlant):
    def __init__(self):super().__init__(injector_flow_factors=FLOW,optimum_spark_offsets=OFFSETS);instances.append(self)
   class Project(TargetController):
    def __init__(self,tune=None):
     t=copy.deepcopy(tune);t['cylinder_trims']=copy.deepcopy(trim);super().__init__(t)
   class Reference(SpeeduinoRuntime):
    def __init__(self,**kw):
     super().__init__(**kw);self.cylinder_trims(trim);att.append(sha(Path('/proc')/str(self.process.pid)/'exe'))
   bench.ResearchPlant=FixedPlant;bench.OurController=Project;bench.SpeeduinoRuntime=Reference
   print('Independent',who,kind,step,flush=True)
   result=bench.run(who,'warm_start',10,step,tune=tune if who=='ours' else None,control_period_us=5000,sequential=True,reference_timer_bits=16)
   plant=instances[0];cyl=[]
   for i in range(4):
    rows=[b for b in plant.cylinder_combustions if b['cylinder']==i+1 and b['time_s']>=8 and b['lambda_value']is not None]
    cyl.append({'cylinder':i+1,'attempts':len(rows),'successes':sum(b['scheduled_work_j']>0 for b in rows),'mean_lambda':statistics.mean(b['lambda_value'] for b in rows),'mean_work_j':statistics.mean(b['scheduled_work_j'] for b in rows),'mean_advance_deg':statistics.mean(b['advance_deg'] for b in rows)})
   values=[c['mean_lambda'] for c in cyl];works=[c['mean_work_j'] for c in cyl]
   row={'controller':who,'fixture':kind,'step_us':step,'lambda_spread':max(values)-min(values),'work_cv':statistics.pstdev(works)/statistics.mean(works),'cylinders':cyl,'mean_final_rpm':result['summary']['mean_final_second_rpm'],'live_reference_binary_sha256':att,'summary':result['summary']}
   raw=OUT/(f'independent-{who}-{kind}.json');raw.write_text(json.dumps({'review_metrics':row,'physical_flow_factors':FLOW,'physical_optimum_offsets':OFFSETS,'trim_tune':trim,'combustions':plant.cylinder_combustions,**result},separators=(',',':'),allow_nan=False)+'\n')
   row['raw_sha256']=sha(raw);report['cases'].append(row);print('Result',who,kind,'spread',row['lambda_spread'],'workCV',row['work_cv'],flush=True)
 for n,h in source.items():assert sha(R/n)==h,n+' changed during probe'
 for who in ['ours','speeduino']:
  rows={v['fixture']:v for v in report['cases'] if v['controller']==who}
  baseline=json.loads((BASE/(who+'-disabled.json')).read_text())['metrics'];corrected=json.loads((BASE/(who+'-'+('corrected' if who=='ours' else 'total_pw_adjusted')+'.json')).read_text())['metrics']
  fine=rows['both_fine'];fuel=rows['fuel_only'];spark=rows['spark_only']
  checks={
   'fine_balanced':fine['lambda_spread']<baseline['lambda_spread']*.1,
   'fuel_only_balanced':fuel['lambda_spread']<baseline['lambda_spread']*.1,
   'spark_only_still_unbalanced':spark['lambda_spread']>baseline['lambda_spread']*.75,
   'full_work_more_balanced_than_fuel_only':fine['work_cv']<fuel['work_cv']*.25,
   'each_final_attempt_successful':all(c['attempts']==c['successes']>10 for r in rows.values() for c in r['cylinders'])}
  if not all(checks.values()):report['failures'].append({'controller':who,'checks':checks})
  report.setdefault('checks',{})[who]={'checks':checks,'coarse_lambda_spread':corrected['lambda_spread'],'fine_lambda_spread':fine['lambda_spread'],'coarse_work_cv':corrected['work_cv'],'fine_work_cv':fine['work_cv']}
 report['runtime_seconds']=time.monotonic()-started;report['passed']=not report['failures'];(OUT/'comparison-factorial-probe.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'passed':report['passed'],'failures':report['failures'],'checks':report['checks'],'runtime_seconds':report['runtime_seconds']},indent=2),flush=True)
finally:bench.OurController,bench.SpeeduinoRuntime,bench.ResearchPlant=original
