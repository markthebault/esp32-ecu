#include "ecu/engine_json.hpp"
#include "ecu/engine_data_json.hpp"
#include "ecu/engine_log_json.hpp"
#include "ecu/engine_radio.hpp"
#include <cassert>
#include <fstream>
#include <sstream>
#include <iostream>
#include <unordered_map>
#include <functional>
static std::unordered_map<void*,std::size_t> allocations;static unsigned position=0,fail_at=UINT32_MAX;
void* allocate(std::size_t n){if(position++==fail_at)return nullptr;auto*p=std::malloc(n);if(p)allocations[p]=n;return p;}
void release(void*p){if(p){assert(allocations.erase(p)==1);std::free(p);}}
using namespace ecu;
void dirty(engine::Tune&t){t.cylinder_trims_enabled=true;t.cylinder_spark_deg.fill(9);for(auto&m:t.cylinder_fuel){m.rpm[0]=99;m.load[0]=9;m.cells.fill(149);}}
void neutral(const engine::Tune&t){assert(!t.cylinder_trims_enabled);engine::TrimMap n;for(unsigned i=0;i<4;++i){assert(t.cylinder_spark_deg[i]==0);assert(t.cylinder_fuel[i].rpm==n.rpm&&t.cylinder_fuel[i].load==n.load&&t.cylinder_fuel[i].cells==n.cells);}}
unsigned allocation_test(const std::function<cJSON*()>&fn){unsigned failed=0,passed=0;for(unsigned n=0;n<700;++n){position=0;fail_at=n;auto*j=fn();if(j)++passed;else ++failed;cJSON_Delete(j);assert(allocations.empty());}assert(failed&&passed);return failed;}
int main(int argc,char**argv){assert(argc==2);std::ifstream in(argv[1]);std::ostringstream buf;buf<<in.rdbuf();auto text=buf.str();auto*j=cJSON_ParseWithOpts(text.c_str(),nullptr,true);assert(j);engine::Tune tune;dirty(tune);assert(engine::parse_tune(j,tune));neutral(tune);const auto original=tune;
std::string canonical;assert(engine::canonical_tune(text.c_str(),tune,canonical));assert(canonical.size()>16384&&canonical.size()<engine::tune_maximum);auto*k=cJSON_Parse(canonical.c_str());assert(cJSON_GetObjectItemCaseSensitive(k,"schema_version")->valueint==3);engine::Tune check;dirty(check);assert(engine::parse_tune(k,check));neutral(check);assert(check.ve.cells==original.ve.cells);cJSON_Delete(k);
cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"schema_version"),1);cJSON_DeleteItemFromObjectCaseSensitive(j,"timing");dirty(tune);assert(engine::parse_tune(j,tune));neutral(tune);auto*encoded=cJSON_PrintUnformatted(j);std::string schema1=encoded;cJSON_free(encoded);cJSON_Delete(j);
engine::Tune active;active.strategy=engine::Strategy::Sequential;active.cylinder_trims_enabled=true;active.afterstart_pct=0;active.cylinder_fuel[2].cells.fill(125);active.cylinder_spark_deg[2]=-4;engine::Inputs input;input.rpm=1200;input.map_kpa=45;input.tps_pct=10;input.clt_c=85;input.iat_c=25;input.lambda=1;input.battery_v=14;input.sensor_v=5;input.sampled_us=1000;input.synced=input.phase_synced=input.sensors_valid=input.lambda_ready=true;engine::Controller control;auto out=control.step(active,input,1000);assert(!out.faults);engine::RuntimeSample sample;engine::data_values(sample,input,out);sample.sequence=UINT64_C(9007199254740993);sample.control_us=sample.sampled_us=1000;sample.source=engine::DataSource::Target;
std::uint8_t frame1[radio::wire::engine_size],frame2[radio::wire::engine_size];assert(radio::wire::engine_body(frame1,sample,1,1,0,0,0,1000));auto other=sample;other.cylinder_pulse_ms.fill(123);other.cylinder_advance_deg.fill(-4);other.cylinder_valid=0;other.cylinder_enabled=0;other.cylinder_capacity_mask=other.cylinder_spark_clamp_mask=other.cylinder_retard_floor_mask=15;assert(radio::wire::engine_body(frame2,other,1,1,0,0,0,1000));assert(!std::memcmp(frame1,frame2,sizeof frame1));
cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);unsigned upgrade_fail=0,upgrade_pass=0;for(unsigned n=0;n<700;++n){fail_at=UINT32_MAX;position=0;auto*tree=cJSON_Parse(schema1.c_str());assert(tree);position=0;fail_at=n;bool ok=engine::upgrade_tune_document(tree);if(ok)++upgrade_pass;else ++upgrade_fail;cJSON_Delete(tree);assert(allocations.empty());}assert(upgrade_fail&&upgrade_pass);
const auto output_fail=allocation_test([&]{return engine::output_json(out);});const auto data_fail=allocation_test([&]{return engine::data_json(sample,1000);});engine_log::Row row{sample,1000,1,1};const auto row_fail=allocation_test([&]{return engine_log::row_json(row);});cJSON_InitHooks(nullptr);
std::cout<<"{\"reuse_schema1_neutral\":true,\"reuse_schema2_neutral\":true,\"legacy_upgrade_bytes\":"<<canonical.size()<<",\"same_legacy_base_float_cells\":true,\"radio_frame_unchanged_by_cylinder_fields\":true,\"allocation_positions_per_builder\":700,\"upgrade_failure_positions\":"<<upgrade_fail<<",\"output_failure_positions\":"<<output_fail<<",\"data_failure_positions\":"<<data_fail<<",\"row_failure_positions\":"<<row_fail<<",\"no_cjson_leaks\":true,\"runtime_sample_bytes\":"<<sizeof(engine::RuntimeSample)<<",\"row_bytes\":"<<sizeof(engine_log::Row)<<",\"page_bytes\":"<<sizeof(engine_log::Page)<<",\"recorder_bytes\":"<<sizeof(engine_log::Recorder)<<"}\n";}
