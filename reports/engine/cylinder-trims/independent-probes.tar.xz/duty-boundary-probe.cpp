#include "ecu/engine_scheduler.hpp"
#include <iostream>
int main(){using namespace ecu::engine;Tune t;t.strategy=Strategy::Sequential;t.max_duty=.85f;Output o;o.state=State::Running;o.rpm=1000;o.pulse_ms=2;o.dwell_ms=1;o.advance_deg=15;const auto a=angle_config(t);auto beyond=a;beyond.max_duty=std::nextafter(double(.85f),INFINITY);if(demand_valid(beyond,o,o.rpm))return 2;std::cout.precision(17);std::cout<<"{\"valid_tune_at_max_duty_0_85\":"<<(!validate(t)?"true":"false")<<",\"converted_max_duty\":"<<a.max_duty<<",\"demand_valid\":"<<(demand_valid(a,o,o.rpm)?"true":"false")<<"}\n";}
