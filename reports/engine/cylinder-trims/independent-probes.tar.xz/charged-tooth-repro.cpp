// Independent public-API reproduction of a charged coil/tooth coincidence.
// Build: c++ -std=c++17 -O2 -Ifirmware/include charged-tooth-repro.cpp -o probe
#include "ecu/engine_scheduler.hpp"
#include <cassert>
#include <iostream>
#include <iomanip>
using namespace ecu::engine;
struct Case {const char* name;double advance;std::uint64_t final_tooth;bool lower_max;};
int main(){
 for(const auto c:{Case{"exact",6,1862190,false},Case{"rounded_ahead",5.999999,1862190,false},Case{"slightly_behind",6.001,1862190,false},Case{"time_over25",6,1862160,false},Case{"time_exact25",6,1862171,false},Case{"combined_angle_over",6.19,1862134,false},Case{"expired_end",6,1862196,false},Case{"max_dwell_reduced",6,1862190,true}}){
  Tune t;t.strategy=Strategy::Sequential;t.cylinder_trims_enabled=true;
  Output o;o.state=State::Running;o.rpm=60000000./(260.5*360);o.fuel_cut=true;o.dwell_ms=2.8;o.advance_deg=10;
  o.cylinder_data=o.cylinder_trims_enabled=true;o.cylinder_advance_deg={7,12,15,c.advance};AngleScheduler s;
  assert(s.tooth(t,o,1857523,71,60,1857523,1857523));
  assert(s.tooth(t,o,1859086,72,60,1859086,1859086));
  Edge edge;assert(s.pop(edge)&&edge.channel==7&&edge.high);const auto rise=edge.time_us;
  assert(s.tooth(t,o,1860641,73,60,1860641,1860641));const auto end=s.next_time();
  if(c.lower_max){t.max_dwell_ms=2.78f;o.dwell_ms=2.7;}
  const bool ok=s.tooth(t,o,c.final_tooth,74,60,c.final_tooth,c.final_tooth);
  const auto remaining=static_cast<std::int64_t>(end)-static_cast<std::int64_t>(c.final_tooth);
  const double late_angle=c.advance-6+remaining/(double(c.final_tooth-1860641)/6);
  if(ok){assert(s.next_time()==end);assert(s.pop(edge)&&edge.channel==7&&!edge.high&&edge.time_us==end);}
  std::cout<<std::setprecision(15)<<"{\"case\":\""<<c.name<<"\",\"advance\":"<<c.advance<<",\"rise_us\":"<<rise<<",\"committed_end_us\":"<<end<<",\"old_dwell_us\":"<<end-rise<<",\"remaining_us\":"<<remaining<<",\"combined_late_angle_deg\":"<<late_angle<<",\"retained\":"<<(ok?"true":"false")<<",\"reason\":\""<<AngleScheduler::reason_name(s.stop_reason())<<"\"}\n";
 }
}
