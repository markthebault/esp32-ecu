#include "ecu/engine_log.hpp"
#include "ecu/timing_executor.hpp"
extern "C" { char review_sample[sizeof(ecu::engine::RuntimeSample)]; char review_row[sizeof(ecu::engine_log::Row)]; char review_page[sizeof(ecu::engine_log::Page)]; char review_ring[sizeof(ecu::engine_log::Recorder)]; char review_command[sizeof(ecu::timing::Command)]; char review_candidate[sizeof(ecu::timing::Executor::Candidate)]; }
