#!/usr/bin/env python3
"""Read-only arithmetic replay independent of benchmark/audit helper code."""
from pathlib import Path
import collections, hashlib, json, math, statistics, subprocess
ROOT=Path('/home/mark/persospace/esp32-ecu')
BASE=ROOT/'.cache/engine/cylinder-scenarios-final'
OUT=ROOT/'.cache/engine/cylinder-review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((BASE/'summary.json').read_text())
report={'scope':'Independent replay of saved actuator edges and physical-angle/combustion records; no production code imports, physical qualification or claimed real-time CPU/IRQ behavior.', 'failures':[], 'cases':[], 'raw_sha256':{}, 'baseline_summary_sha256':sha(BASE/'summary.json'), 'source_hash_checks':{}, 'transients':{}}
def check(test,msg):
 if not test:report['failures'].append(msg)
def finite_tree(x):
 if isinstance(x,float):return math.isfinite(x)
 if isinstance(x,list):return all(finite_tree(v) for v in x)
 if isinstance(x,dict):return all(finite_tree(v) for v in x.values())
 return True
for name,digest in summary['source_hashes'].items():
 actual=sha(ROOT/name);report['source_hash_checks'][name]={'recorded':digest,'actual':actual,'matches':actual==digest};check(actual==digest,'baseline source changed: '+name)
raw={}
for row in summary['rows']:
 name=row['controller']+'-'+row['mode'];p=BASE/(name+'.json');report['raw_sha256'][str(p.relative_to(ROOT))]=sha(p);d=json.loads(p.read_text());raw[name]=d
 check(finite_tree(d),name+' nonfinite JSON')
 check({k:v for k,v in d.items() if k not in ('combustions','edges','trace','spark_timing')}==row,name+' summary row differs from raw')
 high={};maxwidth=[0]*8;counts=[0]*8;fuel=[0.]*4;scheduled_falls=collections.Counter();previous=-1;pulses=[[] for _ in range(8)]
 for us,ch,value,cause in d['edges']:
  check(type(us)is int and previous<=us<=10_000_000,name+' invalid timestamp/order');previous=us
  check(type(ch)is int and ch in range(8) and type(value)is bool,name+' invalid channel/value')
  if value:
   check(ch not in high,name+' duplicate rise');high[ch]=us
  else:
   check(ch in high,name+' fall without rise')
   if ch not in high:continue
   start=high.pop(ch);width=us-start;maxwidth[ch]=max(maxwidth[ch],width);counts[ch]+=1;pulses[ch].append((start,us,width,cause))
   if ch<4:fuel[ch]+=3725*d['physics']['injector_flow_factors'][ch]*max(0,width-900)/1e6
   elif cause=='scheduled':scheduled_falls[(us,ch)]+=1
 check(not high,name+' final high from replay');check(all(counts),name+' missing physical channel')
 check(len(d['edges'])==d['summary']['edges'],name+' edge count')
 check(max(maxwidth[:4])==d['summary']['max_injector_high_us'] and max(maxwidth[4:])==d['summary']['max_dwell_high_us'],name+' high-time summary')
 check(max(maxwidth[:4])<=15000 and max(maxwidth[4:])<=3504,name+' pulse bound')
 sparkkeys=collections.Counter((round(s['time_s']*1e6),s['channel']) for s in d['spark_timing'])
 check(sparkkeys==scheduled_falls,name+' scheduled coil falls differ from spark records')
 check(len(d['spark_timing'])==d['summary']['sparks'],name+' spark count summary')
 fueldeltas=[fuel[i]-d['metrics']['cylinders'][i]['total_delivered_fuel_mg'] for i in range(4)]
 check(max(map(abs,fueldeltas))<1e-6,name+' fuel pulses differ from cylinder mass ledger')
 check(abs(sum(fuel)-d['summary']['ledger']['fuel_in_mg'])<1e-6,name+' global fuel input ledger')
 late=[];cylinders=[];expected_adv=[];command_deltas=[]
 for i in range(4):
  burns=[b for b in d['combustions'] if b['cylinder']==i+1 and b['time_s']>=8 and b['lambda_value']is not None]
  m=d['metrics']['cylinders'][i]
  check(len(burns)==m['burns'],name+' late burn count')
  recomputed={a:statistics.mean(b[k] for b in burns) for a,k in [('mean_lambda','lambda_value'),('mean_charge_fuel_mg','fuel_mg'),('mean_air_mg','air_mg'),('mean_advance_deg','advance_deg'),('mean_scheduled_work_j','scheduled_work_j')]}
  check(all(abs(v-m[k])<1e-12 for k,v in recomputed.items()),name+' cylinder means')
  check(all(b['scheduled_work_j']>0 for b in burns),name+' zero-work late attempt counted as burn')
  check(all(abs(b['lambda_value']-b['air_mg']/(14.7*b['fuel_mg']))<1e-12 for b in burns),name+' lambda record mismatch')
  trim=d['trim_tune']['spark_deg'][i] if d['trim_tune']['enabled'] else 0
  expected=10+trim;expected_adv.append(expected)
  angles=[]
  for s in d['spark_timing']:
   if s['channel']!=i+4 or s['time_s']<8:continue
   angle=((90,630,270,450)[i]-s['shaft_angle_deg']+360)%720-360
   # This independent oracle deliberately ignores requested_deg and stored error.
   angles.append(angle-expected)
   check(abs(((angle-s['requested_deg']+360)%720-360)-s['phase_error_deg'])<1e-8,name+' stored720 error wrong')
   command_deltas.append(s['requested_deg']-expected)
  cylinders.append({'cylinder':i+1,'attempts_late':len(burns),'positive_work_late':sum(b['scheduled_work_j']>0 for b in burns),'lambda':recomputed['mean_lambda'],'advance_expected':expected,'actual_advance_mean':recomputed['mean_advance_deg'],'peak720_error_vs_fixed_late_demand':max(map(abs,angles)),'fuel_pulses_mg':fuel[i], 'fuel_ledger_difference_mg':fueldeltas[i]})
  late+=angles
 lam=[c['lambda'] for c in cylinders];work=[d['metrics']['cylinders'][i]['mean_scheduled_work_j'] for i in range(4)]
 spread=max(lam)-min(lam);cv=statistics.pstdev(lam)/statistics.mean(lam);workcv=statistics.pstdev(work)/statistics.mean(work)
 check(abs(spread-d['metrics']['lambda_spread'])<1e-12 and abs(cv-d['metrics']['lambda_cv'])<1e-12 and abs(workcv-d['metrics']['work_cv'])<1e-12,name+' spread/CV summary')
 check(all(abs(x)<1e-12 for x in command_deltas),name+' late per-cylinder requested command mapping')
 l=d['summary']['ledger']
 check(abs((l['fuel_in_mg']-l['burned_mg']-l['unburned_mg']-l['stored_mg'])-l['fuel_residual_mg'])<1e-8,name+' fuel residual arithmetic')
 check(abs((l['burned_chemical_j']-l['combustion_shaft_j']-l['heat_j']-l['pending_work_j'])-l['chemical_residual_j'])<1e-8,name+' chemical residual arithmetic')
 check(abs((l['starter_j']+l['combustion_shaft_j']-l['friction_j']-l['load_j']-l['kinetic_j'])-l['shaft_residual_j'])<1e-8,name+' shaft residual arithmetic')
 for key,tol in [('fuel_residual_mg',1e-6),('chemical_residual_j',1e-4),('shaft_residual_j',1e-4),('air_residual_kg',1e-7),('air_energy_residual_j',.05)]:check(abs(l[key])<tol,name+' residual tolerance '+key)
 check(abs(sum(c['total_shaft_j'] for c in d['metrics']['cylinders'])-l['combustion_shaft_j'])<1e-6,name+' shaft per-cylinder sum')
 # Reconstruct all known burning chemical work from combustion attempts.
 burned=sum(min(b['fuel_mg'],b['air_mg']/14.7) for b in d['combustions'] if b['scheduled_work_j']>0)
 check(abs(burned-l['burned_mg'])<1e-6,name+' burned mass vs combustion records')
 check(abs(burned*44-l['burned_chemical_j'])<1e-4,name+' burned chemical energy vs records')
 check(abs(sum(b['scheduled_work_j'] for b in d['combustions'])-l['combustion_shaft_j']-l['pending_work_j'])<1e-6,name+' combustion work vs released+pending (warm speed above shaft loss threshold)')
 report['cases'].append({'name':name,'edge_count':len(d['edges']),'pulse_counts':counts,'max_high_us':maxwidth,'fuel_pulse_ledger_differences_mg':fueldeltas,'lambda_spread':spread,'work_cv':workcv,'cylinders':cylinders,'peak720_error_vs_fixed_late_demand':max(map(abs,late)),'late_min_positive_work_j':min(b['scheduled_work_j'] for b in d['combustions'] if b['time_s']>=8 and b['lambda_value']is not None),'final_rpm':d['summary']['final_rpm']})
report['disabled_neutral']={}
for who in ['ours','speeduino']:
 a,b=raw[who+'-disabled'],raw[who+'-neutral'];same={k:a[k]==b[k] for k in ('edges','combustions','spark_timing','metrics','summary')};report['disabled_neutral'][who]=same;check(all(same.values()),who+' disabled vs neutral differs')
ref=raw['speeduino-total_pw_adjusted'];neutral=raw['speeduino-disabled'];pw=neutral['trace'][-1]['ecu']['pulse_us'];expected=[100*(900+(pw-900)/v)/pw for v in ref['physics']['injector_flow_factors']]
report['reference_calibration']={'neutral_base_pw_us':pw,'expected_full_pw_percent':expected,'recorded_percent':[m['cells'][0] for m in ref['trim_tune']['fuel_maps']], 'integer_percent_after_quantization':[round(v) for v in expected]}
check(pw==ref['calibration']['neutral_pw_us'],'adjusted calibration baseline')
check(all(abs(expected[i]-ref['trim_tune']['fuel_maps'][i]['cells'][0])<1e-10 for i in range(4)),'adjusted calibration formula')
transpath=ROOT/'.cache/engine/cylinder-transients/summary.json';trans=json.loads(transpath.read_text())
report['transients']['summary_sha256']=sha(transpath);report['transients']['recorded_passed']=trans['passed'];report['transients']['source_hash_checks']={}
check(trans['baseline_summary_sha256']==sha(BASE/'summary.json'),'transient baseline digest')
for n,h in trans['source_hashes'].items():
 matches=sha(ROOT/n)==h;report['transients']['source_hash_checks'][n]=matches;check(matches,'transient source changed: '+n)
report['binary_fingerprints']={}
for bits,cache in [(16,'speeduino-sim16'),(32,'speeduino-sim')]:
 p=ROOT/'.cache/engine'/cache;man=json.loads((p/'build-manifest.json').read_text());actual=sha(p/'speeduino-sim');mh=sha(p/'build-manifest.json')
 report['binary_fingerprints'][str(bits)]={'manifest_sha256':mh,'actual_executable_sha256':actual,'manifest_matches':actual==man['binary_sha256'],'speeduino_commit':man['speeduino_sha'],'unit_test':man['unit_test']}
 check(actual==man['binary_sha256'],'actual binary digest differs from manifest')
 for att in trans['live_reference_binaries']:
  if att['timer_bits']==bits:check(att['live_executable_sha256']==actual and att['manifest_sha256']==mh,'live binary attestation differs from current build')
fmu=ROOT/'.cache/engine/modelica-mvem/airpath';manifest=json.loads((fmu/'manifest.json').read_text());report['fmu_fingerprints']={'fmu_sha256':sha(fmu/'EngineAirPath.fmu'),'manifest_sha256':sha(fmu/'manifest.json'),'wrapper_sha256':sha(ROOT/'simulation/modelica/EngineAirPath.mo')}
check(report['fmu_fingerprints']['fmu_sha256']==manifest['fmu_sha256'],'FMU hash');check(report['fmu_fingerprints']['wrapper_sha256']==manifest['adapter_sha256'],'FMU adapter hash')
report['target_library_sha256']=sha(ROOT/'.cache/engine/target-native/libtarget_engine.so')
report['speeduino_git_status']=subprocess.check_output(['git','-C',str(ROOT.parent/'speeduino'),'status','--porcelain'],text=True)
report['passed']=not report['failures'];(OUT/'comparison-independent-replay.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ['passed','failures','disabled_neutral','reference_calibration','binary_fingerprints','fmu_fingerprints','target_library_sha256']},indent=2))
for c in report['cases']:print(c['name'],'spread',c['lambda_spread'],'late720',c['peak720_error_vs_fixed_late_demand'],'pulses',c['pulse_counts'],'maxfuel_delta',max(map(abs,c['fuel_pulse_ledger_differences_mg'])))
