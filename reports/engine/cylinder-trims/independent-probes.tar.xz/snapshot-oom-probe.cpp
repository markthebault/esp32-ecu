#include "ecu/engine_json.hpp"
#include "ecu/engine_target.hpp"
#include <unordered_map>
#include <cstdlib>
#include <cassert>
#include <iostream>
static std::unordered_map<void*,std::size_t> allocations;static unsigned position=0,fail_at=UINT32_MAX;
void* allocate(std::size_t n){if(position++==fail_at)return nullptr;auto*p=std::malloc(n);if(p)allocations[p]=n;return p;}
void release(void*p){if(p){assert(allocations.erase(p)==1);std::free(p);}}
static int mutex=0;static constexpr int portMAX_DELAY=0;void xSemaphoreTake(int,int){}void xSemaphoreGive(int){}
namespace ecu::engine_target {std::uint64_t clock_us(){return 4000;}Measurement measurement(){return Measurement{};}cJSON* snapshot(){auto*j=cJSON_CreateObject();if(j)cJSON_AddNumberToObject(j,"marker",123);return j;}}
namespace ecu::engine_service {engine::Output latest;engine::Tune active;bool storage_ok=true;std::uint64_t stamp=1000;const char*binding="bound";
cJSON* snapshot(){
 xSemaphoreTake(mutex,portMAX_DELAY);const auto output=latest;const auto revision=active.revision;const bool stored=storage_ok;const auto sample_stamp=stamp;const auto* reason=binding;xSemaphoreGive(mutex);
 auto*j=engine::output_json(output);if(!j)return nullptr;const auto now=engine_target::clock_us();cJSON_AddNumberToObject(j,"revision",revision);cJSON_AddBoolToObject(j,"storage_ok",stored);cJSON_AddStringToObject(j,"binding",reason);cJSON_AddNumberToObject(j,"sample_age_ms",sample_stamp&&now>=sample_stamp?(now-sample_stamp)/1000.0:-1);cJSON_AddBoolToObject(j,"simulator",false);cJSON_AddBoolToObject(j,"fresh",sample_stamp&&now>=sample_stamp&&now-sample_stamp<50000);auto*timing=engine_target::snapshot();if(!timing||!cJSON_AddItemToObject(j,"timing",timing)){cJSON_Delete(timing);cJSON_Delete(j);return nullptr;}
 const auto phase=engine_target::measurement();cJSON_AddBoolToObject(j,"crank_synced",phase.synced);cJSON_AddBoolToObject(j,"phase_synced",phase.phase_synced);cJSON_AddBoolToObject(j,"phase_required",phase.phase_required);
 cJSON_AddStringToObject(j,"phase_reason",engine::PhaseDecoder::reason_name(phase.phase_reason));cJSON_AddNumberToObject(j,"phase_losses",phase.phase_losses);cJSON_AddNumberToObject(j,"cam_rejected",phase.cam_rejected);cJSON_AddNumberToObject(j,"cam_error_deg",phase.cam_error_deg);return j;
}
}
int main(){cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);unsigned leaks=0,null_parent_leaks=0,max_leaked=0;
for(unsigned n=0;n<400;++n){position=0;fail_at=n;auto*j=ecu::engine_service::snapshot();const bool null=!j;cJSON_Delete(j);if(!allocations.empty()){++leaks;if(null)++null_parent_leaks;max_leaked=std::max<unsigned>(max_leaked,allocations.size());for(const auto&entry:allocations)std::free(entry.first);allocations.clear();}}
cJSON_InitHooks(nullptr);std::cout<<"{\"single_failed_allocation_positions\":400,\"positions_leaking_children\":"<<leaks<<",\"null_parent_leak_positions\":"<<null_parent_leaks<<",\"maximum_leaked_allocations\":"<<max_leaked<<"}\n";}
