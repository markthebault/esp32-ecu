import copy,gzip,hashlib,json,math,random,subprocess,sys
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');sys.path.insert(0,str(ROOT/'tools'))
OUT=Path(__file__).resolve().parent
from engine_geometry import EngineGeometry
from engine_sil import Plant,Simulation
from engine_research_plant import AirPath,ResearchPlant
from compare_engine_controllers import run,benchmark_tune
from engine_runtime import EngineRuntime
from engine_log import export_msl,cylinder_log_values

checks=[];observations={};findings=[]
def check(name,value,detail=None):
 if not value:raise AssertionError((name,detail))
 checks.append(name)
def profile(n,mode='sequential'):
 t=benchmark_tune();t['engine']['cylinders']=n;t['engine']['displacement_cc']=500*n;t['timing']['firing_order']=[1]+list(range(n,1,-1))+[0]*(8-n);t['strategy']=mode;return t
def saved(name,result):
 (OUT/(name+'.json.gz')).write_bytes(gzip.compress(json.dumps(result,allow_nan=False,separators=(',',':')).encode(),mtime=0));observations[name]=result['summary']

# Pumping component parameters are checked in the FMU itself, rather than
# accepting only the public Python metadata. The total displacement is held
# fixed across counts, so a hidden fixed nCyl4 or missing4/N factor is exposed.
for n in range(1,9):
 g=EngineGeometry(n,tuple(range(1,n+1)),2400);a=AirPath(geometry=g)
 try:
  pvd,pnc=a.model.getReal([a.vr['pumping.Vd'],a.vr['pumping.nCyl']])
  check(f'FMU actual count{n}',pnc==n,(pvd,pnc))
  check(f'FMU actual cylinder volume{n}',math.isclose(pvd,.0024/n,rel_tol=1e-12),(pvd,n))
  a.step(0,.00025,100,12);observations[f'fixed-total-air-{n}']=a.read()
 finally:a.close()
reference=observations['fixed-total-air-1']
for n in range(2,9):
 for k,v in reference.items():check(f'fixed-total airflow invariance{n}:{k}',math.isclose(v,observations[f'fixed-total-air-{n}'][k],rel_tol=1e-8,abs_tol=1e-12))

# A closed-cylinder charge should scale as1/N at the same total air flow,
# omega and fixed physical displacement. Force a short crossing of intake
# close with no controller or fuel input to isolate this conversion.
charges=[]
for n in (1,2,3,5,7,8):
 g=EngineGeometry(n,tuple(range(1,n+1)),2400);p=ResearchPlant(geometry=g)
 try:
  p.rpm=600;p.angle=629.9;p.integrate(0,.0001)
  charges.append((n,p.air_charge_mg[0],p.air_state['cylinder_air_kg_s']))
  expected=p.air_state['cylinder_air_kg_s']*(4*math.pi/(600*math.pi/30))/n*1e6
  check(f'trapped charge independent4pi/N conversion{n}',math.isclose(p.air_charge_mg[0],expected,rel_tol=1e-12))
 finally:p.close()
observations['isolated_charges']=charges

# Read the historical Plant class from HEAD without changing it or project
# files; drive it with identical external actuator events and integration.
text=subprocess.check_output(['git','show','HEAD:tools/engine_sil.py'],cwd=ROOT,text=True)
old_source=text[text.index('class Plant:'):text.index('class Simulation:')]
ns=dict(math=math,random=random);exec(old_source,ns);old=ns['Plant']();new=Plant()
for k in range(4000):
 t=k*.00025
 for p in (old,new):
  if k%400==0:
   for ch in range(4):p.edge(ch,True,t)
  if k%400==16:
   for ch in range(4):p.edge(ch,False,t)
  p.integrate(t,.00025,starter=True)
 for name in ('rpm','angle','map_kpa','fuel_mg','lambda_sensor','wall_mg','charge_mg'):
  check('historical four-cylinder quick model exact:'+name,getattr(old,name)==getattr(new,name))

# Valid native integral JSON counts currently fail in the comparison harness
# before canonicalization. Record the actual repro, not an inferred issue.
t=profile(4);t['engine']['cylinders']=4.0;r=EngineRuntime(t);r.close()
try:run('ours','warm_start',1,250,tune=t)
except TypeError as e:findings.append(dict(id='P1',severity='medium',topic='Canonicalize declared tune before geometry',reproduction='Native EngineRuntime accepts integral JSON cylinders4.0, but run(...tune=that_tune) raises before creating the controller',error=str(e)))
else:check('integral JSON count canonicalization fixed',True)

# An explicitly provided8-cylinder FMU is silently combined with the default
# four-cylinder ResearchPlant when geometry is omitted.
a=AirPath(geometry=EngineGeometry(8,tuple(range(1,9)),4000))
try:
 try:p=ResearchPlant(air_path=a)
 except ValueError:check('provided air path mismatch rejected',True)
 else:
  findings.append(dict(id='P2',severity='medium',topic='Provided air path geometry must agree even if argument omitted',reproduction='ResearchPlant(air_path=AirPath(geometry=8cyl4L)) uses four-cylinder2L combustion geometry with the8-cylinder4L FMU',plant_geometry=p.geometry.summary(),air_geometry=a.geometry.summary()))
finally:a.close()

# Execute a less trivial non4 profile using actual controller/dispatcher,
# then refine its integration step. The shaft is never prescribed.
for n in (1,7,8):
 coarse=run('ours','warm_start',5,250,tune=profile(n),target_dispatcher=True);saved(f'coupled-{n}-250',coarse)
 fine=run('ours','warm_start',5,125,tune=profile(n),target_dispatcher=True);saved(f'coupled-{n}-125',fine)
 for key in ('final_rpm',):check(f'coupling refinement{n}:{key}',abs(coarse['summary'][key]-fine['summary'][key])/max(1,abs(fine['summary'][key]))<.02)
 for result in (coarse,fine):
  s=result['summary'];check(f'coupled{n} actual all-cylinder fuel',len(s['cylinder_fuel_mg'])==n and all(v>0 for v in s['cylinder_fuel_mg']));check(f'coupled{n} actual all-cylinder work',all(v>0 for v in s['cylinder_shaft_j']))
  for key,limit in (('fuel_residual_mg',1e-7),('chemical_residual_j',1e-5),('shaft_residual_j',1e-5),('air_residual_kg',1e-8),('air_energy_residual_j',.02)):
   check(f'coupled{n} ledger:'+key,abs(s['ledger'][key])<limit,s['ledger'][key])

# New cylinder IDs must coexist with reserved logical idle8 rather than
# turning that auxiliary output into an injector or coil.
t=profile(8);idle=run('ours','warm_start',4,250,tune=t,idle_options={'tune':t},target_dispatcher=True);saved('coupled-eight-idle',idle)
check('idle8 and expanded engine IDs coexist',any(e[1]==8 for e in idle['edges']) and any(e[1]==17 for e in idle['edges']))

# Sparse full-width worker mask and all8 typed proposals remain visible in
# the direct log; inactive/absent rows remain unknown, not numeric zero.
r=EngineRuntime(profile(8));r.step(dict(rpm=1000,synced=True,phase_synced=True),1000,use_decoder=False);sample=r.data();r.close()
sample['worker_observation'].update(cylinder_count=8,virtual_high_mask=(1<<17)|(1<<10),physical_command_mask=0)
lines=export_msl([dict(time=0,engine_sample=sample)],'review','sequential').splitlines();names=lines[2].split('\t');values=lines[4].split('\t');data=dict(zip(names,values))
check('direct log245 unique names',len(names)==len(set(names))==len(values)==245)
check('full32 worker mask lossless',int(data['VirtualMask'])==(1<<17)|(1<<10))
check('all8 cylinder proposals logged',all(data[f'C{i}PW']!='NaN' for i in range(1,9)))
empty=cylinder_log_values({});check('empty cylinder export unknown',all(v is None for v in empty))

sources=['tools/engine_geometry.py','tools/engine_sil.py','tools/engine_research_plant.py','tools/compare_engine_controllers.py','tools/engine_log.py','tools/test_engine_profile_plants.py','simulation/modelica/EngineProfileAirPath.mo','simulation/modelica/EngineAirPath.mo','scripts/build_engine_airpath.py']
report=dict(checks=len(checks),passed_checks=checks,findings=findings,observations=observations,source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources},scope='Independent native/coupled/model/log probes; no target/RF/physical or expanded genuineSpeeduino comparison')
(OUT/'probes.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(checks=len(checks),findings=findings),indent=2))
