import hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'tools'))
from engine_geometry import EngineGeometry
from engine_research_plant import AirPath,ResearchPlant
from boost_research_plant import BoostResearchPlant

checks=[]
def check(name,value):
 assert value,name;checks.append(name)
g=EngineGeometry(8,tuple(range(1,9)),4000);air=AirPath(geometry=g)
try:
 p=ResearchPlant(air_path=air)
 check('Known provided geometry inferred in full',p.geometry==g and len(p.injector_on)==len(p.coil_on)==8)
 check('Known provided pumping matches inferred geometry',air.parameters['cylinders']==8 and air.parameters['displacement_m3']==.004)
 p=ResearchPlant(air_path=air,geometry=g);check('Explicit matching provided geometry accepted',p.geometry==g)
 try:ResearchPlant(air_path=air,geometry=EngineGeometry())
 except ValueError:check('Explicit known mismatch rejected',True)
 else:raise AssertionError('Known mismatch accepted')
finally:air.close()
try:BoostResearchPlant(geometry=g)
except ValueError as e:check('Unknown turbo geometry with explicit8 profile rejected','geometry' in str(e))
else:raise AssertionError('Unspecified turbo pumping accepted as8-cylinder4L')
legacy=BoostResearchPlant()
try:
 check('Historical default turbo fixture still constructs',legacy.geometry==EngineGeometry() and len(legacy.injector_on)==4)
 check('Historical turbo pumping unchanged',legacy.air.components.model.parameters['TC_ENGINE.geometry.V_d']==.0018)
finally:legacy.close()
sources=['tools/engine_geometry.py','tools/engine_sil.py','tools/engine_research_plant.py','tools/compare_engine_controllers.py','tools/engine_log.py','tools/test_engine_profile_plants.py','simulation/modelica/EngineProfileAirPath.mo','simulation/modelica/EngineAirPath.mo','scripts/build_engine_airpath.py']
report=dict(passed=True,checks=checks,source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources})
(OUT/'geometry-recheck.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
