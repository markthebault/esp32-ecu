import hashlib,json,math,subprocess,sys
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'tools'))
from engine_geometry import EngineGeometry
from engine_research_plant import AirPath,ResearchPlant
from compare_engine_controllers import run

text=subprocess.check_output(['git','show','HEAD:tools/engine_research_plant.py'],cwd=ROOT,text=True)
source=text[text.index('class ResearchPlant:'):];namespace=dict(AirPath=AirPath,math=math);exec(source,namespace)
old=namespace['ResearchPlant']();new=ResearchPlant();checks=0
try:
 for k in range(6000):
  t=k*.00025
  for p in (old,new):
   if k%400==0:
    for ch in range(4):p.edge(ch,True,t)
   if k%400==16:
    for ch in range(4):p.edge(ch,False,t)
   if k%400==100:
    for ch in range(4,8):p.edge(ch,True,t)
   if k%400==112:
    for ch in range(4,8):p.edge(ch,False,t)
   p.integrate(t,.00025,starter=True)
  for key in ('rpm','angle','map_kpa','fuel_mg','burned_mg','unburned_mg','combustion_shaft_j','port_mg','charge_mg','wall_mg','air_charge_mg','cylinder_fuel_mg','cylinder_shaft_j'):
   assert getattr(old,key)==getattr(new,key),(k,key,getattr(old,key),getattr(new,key));checks+=1
 assert old.ledger()==new.ledger();checks+=1
 result=dict(passed=True,exact_checks=checks,legacy_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),legacy_class_sha256=hashlib.sha256(source.encode()).hexdigest(),ledger=new.ledger())
finally:old.close();new.close()
try:run('speeduino',duration=1,plant_geometry=EngineGeometry(8,tuple(range(1,9)),4000))
except ValueError as e:
 assert 'expanded fixture required' in str(e);result['expanded_reference_rejected_explicitly']=str(e)
else:raise AssertionError('Expanded reference silently used legacy fixture')
(OUT/'legacy-probes.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
