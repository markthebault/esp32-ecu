#include "ecu/control.hpp"
#include "ecu/pins.hpp"
#include "ecu/web_config.hpp"
#include "ecu/espnow.hpp"
#include "ecu/engine_service.hpp"
#include "ecu/engine_target.hpp"
#include "ecu/engine_log_service.hpp"
#include "ecu/engine_tuning.hpp"
#include "ecu/switch_service.hpp"
#include "driver/gpio.h"
#include "driver/gptimer.h"
#include "driver/mcpwm_cap.h"
#include "driver/spi_master.h"
#include "driver/twai.h"
#include "esp_log.h"
#include "esp_attr.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "sdkconfig.h"
#include <array>
#include <cstdint>

#ifndef ECU_ENGINE_DUMMY_LOADS
#define ECU_ENGINE_DUMMY_LOADS 0
#endif

#ifndef ECU_BENCH_PULSES
#define ECU_BENCH_PULSES 0
#endif
#if defined(ECU_SELECTED_N16R8) && ECU_ENGINE_DUMMY_LOADS
#error Selected supplier module remains output-inhibited pending its hardware pin/fit checks
#endif

namespace {
constexpr const char* tag = "ecu_a0";
// ISR lookup data must remain readable while the flash cache is disabled.
DRAM_ATTR std::array<int,8> outputs{ecu::pins::inj1_cmd,ecu::pins::inj2_cmd,
    ecu::pins::inj3_cmd,ecu::pins::inj4_cmd,ecu::pins::ign1_cmd,ecu::pins::ign2_cmd,
    ecu::pins::ign3_cmd,ecu::pins::ign4_cmd};
spi_device_handle_t adc;
gptimer_handle_t pulse_timer;
volatile int bench_channel = -1;
portMUX_TYPE pulse_lock = portMUX_INITIALIZER_UNLOCKED;

void all_off() {
    // Inhibit first. Clearing dwell can create a spark on an actual coil;
    // this firmware is a dummy-load bench monitor, not an engine controller.
    gpio_set_level(static_cast<gpio_num_t>(ecu::pins::arm),0);
    for (int pin : outputs) gpio_set_level(static_cast<gpio_num_t>(pin),0);
    gpio_set_level(static_cast<gpio_num_t>(ecu::pins::pump_cmd),0);
    gpio_set_level(static_cast<gpio_num_t>(ecu::pins::fan_cmd),0);
}

bool IRAM_ATTR pulse_done(gptimer_handle_t, const gptimer_alarm_event_data_t*, void*) {
    portENTER_CRITICAL_ISR(&pulse_lock);
    // One-shot compare ends a dummy-load pulse without depending on task timing.
    gpio_set_level(static_cast<gpio_num_t>(ecu::pins::arm),0);
    const int channel = bench_channel;
    if (channel >= 0 && channel < static_cast<int>(outputs.size()))
        gpio_set_level(static_cast<gpio_num_t>(outputs[static_cast<std::size_t>(channel)]),0);
    bench_channel = -1;
    portEXIT_CRITICAL_ISR(&pulse_lock);
    return false;
}

void init_gpio() {
    gpio_config_t config{};
    config.mode = GPIO_MODE_OUTPUT;
    for (int pin : outputs) config.pin_bit_mask |= 1ULL << pin;
    config.pin_bit_mask |= (1ULL << ecu::pins::arm)|(1ULL << ecu::pins::wdi)|
                           (1ULL << ecu::pins::pump_cmd)|(1ULL << ecu::pins::fan_cmd);
    ESP_ERROR_CHECK(gpio_config(&config));
    all_off();
    gpio_set_level(static_cast<gpio_num_t>(ecu::pins::wdi),0);
    config = {};
    config.mode = GPIO_MODE_INPUT;
    config.pin_bit_mask = (1ULL << ecu::pins::interlock)|(1ULL << ecu::pins::safe_n_mon);
    // Both inputs already have board-level bias. Do not load open-drain SAFE_N
    // with an internal pulldown and reduce its high-level margin.
    config.pull_down_en = GPIO_PULLDOWN_DISABLE;
    ESP_ERROR_CHECK(gpio_config(&config));
}

void init_adc() {
    spi_bus_config_t bus{};
    bus.mosi_io_num = ecu::pins::spi_mosi;
    bus.miso_io_num = ecu::pins::spi_miso;
    bus.sclk_io_num = ecu::pins::spi_clk;
    bus.quadwp_io_num = -1;
    bus.quadhd_io_num = -1;
    bus.max_transfer_sz = 3;
    ESP_ERROR_CHECK(spi_bus_initialize(SPI2_HOST,&bus,SPI_DMA_DISABLED));
    spi_device_interface_config_t device{};
    // MCP3208 at 3.3V: conservative 500 kHz, 3 bytes/sample, SPI mode 0.
    device.clock_speed_hz = 500000;
    device.mode = 0;
    device.spics_io_num = ecu::pins::adc_cs;
    device.queue_size = 1;
    ESP_ERROR_CHECK(spi_bus_add_device(SPI2_HOST,&device,&adc));
}

bool sample(std::array<unsigned,8>& values) {
    for (unsigned ch=0; ch<8; ++ch) {
        spi_transaction_t t{};
        t.flags = SPI_TRANS_USE_TXDATA|SPI_TRANS_USE_RXDATA;
        t.length = 24;
        t.tx_data[0] = static_cast<std::uint8_t>(0x06|((ch&4)>>2));
        t.tx_data[1] = static_cast<std::uint8_t>((ch&3)<<6);
        if (spi_device_polling_transmit(adc,&t) != ESP_OK) return false;
        values[ch] = ((t.rx_data[1]&0x0fU)<<8)|t.rx_data[2];
    }
    return true;
}

void init_bench_timer() {
    gptimer_config_t cfg{};
    cfg.clk_src = GPTIMER_CLK_SRC_DEFAULT;
    cfg.direction = GPTIMER_COUNT_UP;
    cfg.resolution_hz = 1000000;
    ESP_ERROR_CHECK(gptimer_new_timer(&cfg,&pulse_timer));
    gptimer_event_callbacks_t callbacks{};
    callbacks.on_alarm = pulse_done;
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(pulse_timer,&callbacks,nullptr));
    ESP_ERROR_CHECK(gptimer_enable(pulse_timer));
}

void init_can() {
    // This mode does not transmit frames or ACKs, even if JP1 is fitted.
    const twai_general_config_t general = TWAI_GENERAL_CONFIG_DEFAULT(static_cast<gpio_num_t>(ecu::pins::can_tx),
        static_cast<gpio_num_t>(ecu::pins::can_rx),TWAI_MODE_LISTEN_ONLY);
    const twai_timing_config_t timing = TWAI_TIMING_CONFIG_500KBITS();
    const twai_filter_config_t filter = TWAI_FILTER_CONFIG_ACCEPT_ALL();
    ESP_ERROR_CHECK(twai_driver_install(&general,&timing,&filter));
    ESP_ERROR_CHECK(twai_start());
}

} // namespace

extern "C" void app_main() {
    init_gpio();
    const bool interlock_at_boot=gpio_get_level(static_cast<gpio_num_t>(ecu::pins::interlock)) != 0;
#if ECU_BENCH_PULSES
    ecu::BenchGate bench_gate(interlock_at_boot);
#endif
    ecu::web::init();
    ecu::engine_service::init();
    ecu::engine_log_service::init();
    init_adc();
    init_can();
    init_bench_timer();
    ESP_LOGW(tag,"Target timing enabled; physical policy=%s. No vehicle calibration.",ECU_ENGINE_DUMMY_LOADS?"DUMMY LOADS ONLY":"INHIBITED");
    ecu::config::Config profile;
    (void)ecu::web::try_config(profile);
    ecu::engine_target::init({profile.slots,profile.missing,profile.max_rpm},interlock_at_boot);
    ecu::switch_service::init();
    ecu::engine_tuning::start(interlock_at_boot);
    ecu::web::start_service();
    ecu::radio::start();
    ESP_LOGI(tag,"Bench trigger profile: %u-%u, capture ceiling %u RPM",
             profile.slots,profile.missing,profile.max_rpm);
    bool watchdog_high = false;
    std::uint64_t can_frames = 0;
    std::int64_t last_print = 0, last_heartbeat = 0, last_publish = 0;
    ecu::engine::RuntimeSample last_engine;
    std::uint8_t switch_mask=0;
#if ECU_BENCH_PULSES
    std::int64_t last_pulse = 0;
    unsigned next_channel = 0;
#endif
    TickType_t wake = xTaskGetTickCount();
    while (true) {
        const auto now = esp_timer_get_time();
        ecu::config::Config next;
        if (ecu::web::try_config(next) && next.revision != profile.revision) {
            profile = next;
        }
        // A skipped tune-lock read retains ownership until a later successful
        // read. Never turn a contention event into an Off rule or clear faults.
        (void)ecu::engine_service::switch_requirements(switch_mask);
        const auto switch_observation=ecu::switch_service::tick(switch_mask);
        std::array<unsigned,8> raw{};
        const auto sampled_us=ecu::engine_target::clock_us();
        const bool adc_ok = sample(raw);
        const auto edge_state=ecu::engine_target::measurement();
        const bool safe = gpio_get_level(static_cast<gpio_num_t>(ecu::pins::safe_n_mon)) != 0;
        const bool interlock = gpio_get_level(static_cast<gpio_num_t>(ecu::pins::interlock)) != 0;
        twai_message_t message{};
        // Bound background work so a busy bus cannot starve supervision.
        for (unsigned i=0; i<16 && twai_receive(&message,0) == ESP_OK; ++i) ++can_frames;
    ecu::web::Sample live;
    live.raw=raw; live.adc_ok=adc_ok; live.safe=safe; live.interlock=interlock;
    live.table_switches=switch_observation.samples;
    live.overflow=edge_state.overflow; live.synced=edge_state.synced; live.rpm=edge_state.rpm; live.timing_fault=edge_state.timing_fault;
    live.phase_synced=edge_state.phase_synced;
    live.phase_tune_revision=edge_state.tune_revision;live.phase_sensor_revision=edge_state.sensor_revision;
    live.phase_epoch=edge_state.phase_epoch;
    live.phase_losses=static_cast<std::uint32_t>(std::min<std::uint64_t>(edge_state.phase_losses,UINT32_MAX));
    live.cam_rejected=static_cast<std::uint32_t>(std::min<std::uint64_t>(edge_state.cam_rejected,UINT32_MAX));
    live.phase_reason=static_cast<std::uint8_t>(edge_state.phase_reason);live.cam_error_deg=edge_state.cam_error_deg;
    live.timing_cause=edge_state.timing_cause;live.last_timing_cause=edge_state.last_timing_cause;
    live.worker_sequence=edge_state.worker_sequence;live.worker_observed_us=edge_state.worker_observed_us;live.worker_epoch=edge_state.worker_epoch;
    live.worker_tune_revision=edge_state.worker_tune_revision;live.worker_sensor_revision=edge_state.worker_sensor_revision;
    live.worker_cylinder_count=edge_state.worker_cylinder_count;live.virtual_high_mask=edge_state.virtual_high_mask;live.physical_command_mask=edge_state.physical_command_mask;
    live.can_frames=can_frames; live.cam_edges=edge_state.cam_edges; live.crank_edges=edge_state.crank_edges;
    live.crank_level=gpio_get_level(static_cast<gpio_num_t>(ecu::pins::crank));
    live.cam_level=gpio_get_level(static_cast<gpio_num_t>(ecu::pins::cam));
        const bool control_completed=ecu::engine_service::observe(live,profile,ecu::engine_target::clock_us(),sampled_us,last_engine);
        ecu::switch_service::control_observed(switch_observation,control_completed);
        live.engine=last_engine;
        ecu::engine_log_service::observe(last_engine);
        const bool monitor_healthy = adc_ok && !edge_state.overflow && esp_timer_get_time()-now < 10000;
        [[maybe_unused]] const bool healthy = edge_state.synced && monitor_healthy;
#if !ECU_ENGINE_DUMMY_LOADS
        if (!healthy || !safe || !interlock) all_off();
#endif
        // The watchdog is fed by the supervised loop, not a free-running ISR.
        // An inhibited monitor must stay available without a crank source.
        // Pulse builds still require valid trigger decoding to feed supervision.
#if ECU_BENCH_PULSES
        const bool feed_watchdog = bench_gate.state()==ecu::BenchGate::State::Waiting ? monitor_healthy : healthy && bench_gate.state()==ecu::BenchGate::State::Armed;
#elif ECU_ENGINE_DUMMY_LOADS
        const bool feed_watchdog = monitor_healthy && !edge_state.timing_fault;
#else
        const bool feed_watchdog = monitor_healthy;
#endif
        if (feed_watchdog && now-last_heartbeat >= 10000) {
            watchdog_high = !watchdog_high;
            gpio_set_level(static_cast<gpio_num_t>(ecu::pins::wdi),watchdog_high ? 1 : 0);
            last_heartbeat = now;
        }
#if ECU_BENCH_PULSES
        const bool bench_armed = bench_gate.update(healthy,safe,interlock);
        // J3 must be closed at MCU boot; any inhibit after arming latches until reset.
        // MAIN_LS follows ARM, so NEVER connect actuator power in this mode.
        if (bench_armed && healthy && safe && interlock && now-last_pulse >= 1000000 && bench_channel < 0) {
            all_off();
            ESP_ERROR_CHECK(gptimer_set_raw_count(pulse_timer,0));
            gptimer_alarm_config_t alarm{};
            alarm.alarm_count = 1000;
            ESP_ERROR_CHECK(gptimer_set_alarm_action(pulse_timer,&alarm));
            bench_channel = static_cast<int>(next_channel);
            // Start the cutoff clock first: an interrupted start cannot leave
            // an unbounded pulse. Actual pulse width can be less than 1 ms.
            portENTER_CRITICAL(&pulse_lock);
            ESP_ERROR_CHECK(gptimer_start(pulse_timer));
            gpio_set_level(static_cast<gpio_num_t>(ecu::pins::arm),1);
            gpio_set_level(static_cast<gpio_num_t>(outputs[next_channel]),1);
            portEXIT_CRITICAL(&pulse_lock);
            next_channel = (next_channel+1)%outputs.size();
            last_pulse = now;
        }
        // GPTimer one-shot alarms do not stop the counter themselves.
        if (bench_channel < 0) (void)gptimer_stop(pulse_timer);
#elif !ECU_ENGINE_DUMMY_LOADS
        all_off();
        (void)interlock;
#endif
        if (now-last_publish >= 50000) {
            ecu::web::publish(live); last_publish=now;
        }
        if (now-last_print >= 1000000) {
            ESP_LOGI(tag,"sync=%d rpm=%.0f ADC=[%u,%u,%u,%u,%u,%u,%u,%u] safe=%d lock=%d CAN=%llu cam=%llu overflow=%d ARM=%d",
                edge_state.synced,edge_state.rpm,raw[0],raw[1],raw[2],raw[3],raw[4],raw[5],raw[6],raw[7],
                safe,interlock,static_cast<unsigned long long>(can_frames),
                static_cast<unsigned long long>(edge_state.cam_edges),edge_state.overflow,
                gpio_get_level(static_cast<gpio_num_t>(ecu::pins::arm)));
            last_print = now;
        }
        vTaskDelayUntil(&wake,pdMS_TO_TICKS(5));
    }
}
