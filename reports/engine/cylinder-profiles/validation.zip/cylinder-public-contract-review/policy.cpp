#include "ecu/timing_executor.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
using namespace ecu;
struct IO {
 std::uint32_t mask=0;unsigned writes=0,cuts=0;
 bool write(unsigned ch,bool high){++writes;assert(ch<18);if(high)mask|=1U<<ch;else mask&=~(1U<<ch);return true;}
 void all_low(){mask=0;++cuts;}
};
int main(){
 unsigned admitted=0,rejected=0;
 for(unsigned capacity:{4U,8U})for(unsigned cylinders=1;cylinders<=8;++cylinders){
  timing::Executor core(capacity);IO io;timing::Command cmd;
  cmd.sequence=1;cmd.command_us=cmd.sampled_us=1000;cmd.tune_revision=cmd.sensor_revision=1;
  cmd.angle.cylinders=cmd.output.cylinder_count=cylinders;cmd.angle.firing_order.fill(0);
  for(unsigned i=0;i<cylinders;++i)cmd.angle.firing_order[i]=i+1;
  cmd.output.state=engine::State::Running;cmd.output.rpm=1000;cmd.output.pulse_ms=3;cmd.output.dwell_ms=2.8;cmd.output.advance_deg=15;
  assert(engine::demand_valid(cmd.angle,cmd.output,1000));core.progress(1000,io);core.command(cmd,1000,io);
  if(cylinders>capacity){++rejected;assert(core.stats().fault==timing::Cause::Plan&&io.mask==0&&core.current_command().sequence==0&&io.writes==0);}
  else{++admitted;assert(core.stats().fault==timing::Cause::None&&core.current_command().angle.cylinders==cylinders&&core.current_command().sequence==1);}
 }
 std::cout<<"{\"passed\":true,\"admitted\":"<<admitted<<",\"rejected\":"<<rejected<<"}\n";
}
