#include "ecu/engine_json.hpp"
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
static std::size_t calls=0,fail_at=0;
static void* checked_alloc(std::size_t n){++calls;return fail_at&&calls==fail_at?nullptr:std::malloc(n);}
int main(int argc,char**argv){
 assert(argc==2);std::ifstream file(argv[1]);assert(file);std::stringstream input;input<<file.rdbuf();const auto text=input.str();
 cJSON_Hooks hooks{checked_alloc,std::free};cJSON_InitHooks(&hooks);
 ecu::engine::Tune tune;std::string document="unchanged";
 assert(ecu::engine::canonical_tune(text.c_str(),tune,document));const auto total=calls;assert(total>100);
 for(std::size_t failure=1;failure<=total;++failure){
  calls=0;fail_at=failure;document="unchanged";ecu::engine::Tune scratch;
  const bool ok=ecu::engine::canonical_tune(text.c_str(),scratch,document);
  assert(!ok);assert(document=="unchanged");
 }
 fail_at=0;calls=0;assert(ecu::engine::canonical_tune(text.c_str(),tune,document));
 auto*j=cJSON_Parse(document.c_str());assert(j);assert(cJSON_GetObjectItemCaseSensitive(j,"schema_version")->valueint==11);
 assert(cJSON_GetArraySize(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(j,"cylinder_trims"),"fuel_maps"))==8);cJSON_Delete(j);
 cJSON_InitHooks(nullptr);
 std::cout<<"{\"passed\":true,\"injected_cjson_allocation_failures\":"<<total<<",\"published_document_unchanged_on_every_failure\":true}\n";
}
