import copy
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import sys
import tempfile
from unittest import mock
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
from engine_runtime import EngineRuntime,EngineStore
from engine_protocol import DEFAULT,pages,decode_pages,SIGNATURE
from tuning_runtime import Session,status
from engine_msq import export_msq,import_msq,tag
from profile_config import fuel_offset,spark_offset,order_offset

OUT=Path(__file__).resolve().parent
checks=[]
failures=[]
def check(name,predicate,detail=None):
    item=dict(name=name,passed=bool(predicate))
    if detail is not None:item['detail']=detail
    checks.append(item)
    if not predicate:failures.append(name)
def rejects(tune):
    try:
        runtime=EngineRuntime(tune)
    except (ValueError,OverflowError):return True
    runtime.close();return False
def request(offset,data):return b'M'+struct.pack('<BBHH',0,1,offset,len(data))+data
def profile(n,strategy='sequential'):
    tune=copy.deepcopy(DEFAULT);tune['engine']['cylinders']=n
    order=[1]+list(reversed(range(2,n+1)))
    tune['timing']['firing_order']=order+[0]*(8-n)
    tune['strategy']=strategy;tune['cylinder_trims']['enabled']=strategy=='sequential'
    for i,m in enumerate(tune['cylinder_trims']['fuel_maps']):
        m['cells']=[100+((i*17+j)%33)/4 for j in range(36)]
        tune['cylinder_trims']['spark_deg'][i]=(i-3)/2
    return tune

def main():
    for n in range(1,9):
        for strategy in ('batch_wasted','sequential','semi_sequential'):
            tune=profile(n,strategy);before=copy.deepcopy(tune)
            runtime=EngineRuntime(tune);canonical=runtime.tune;runtime.close()
            encoded=pages(canonical)[1]
            check(f'profile-{n}-{strategy}-canonical',canonical==tune)
            check(f'profile-{n}-{strategy}-python-codec-roundtrip',pages(decode_pages({1:encoded},tune))[1]==encoded)
            check(f'profile-{n}-{strategy}-encoder-source-unchanged',tune==before)
            restored=import_msq(export_msq(tune))
            check(f'profile-{n}-{strategy}-msq-binary-roundtrip',pages(restored)[1]==encoded)
            with tempfile.TemporaryDirectory(dir=OUT) as directory:
                store=EngineStore(Path(directory)/'tune.json')
                try:
                    code,saved=store.save(json.dumps(tune).encode());check(f'profile-{n}-{strategy}-store-save',code==200)
                    session=Session(store)
                    try:
                        check(f'profile-{n}-{strategy}-native-page-exact',session.buffers[1]==pages(saved)[1])
                        check(f'profile-{n}-{strategy}-native-signature',session.command(b'Q')==b'\0'+SIGNATURE)
                        check(f'profile-{n}-{strategy}-native-status-signature',session.diagnostics()['identity']==SIGNATURE.decode())
                        host=status(store)
                        check(f'profile-{n}-{strategy}-host-status-signature',host['identity']==SIGNATURE.decode(),host['identity'])
                    finally:session.close()
                finally:store.runtime.close();store.data_recorder.close()
    for file in sorted((ROOT/'config/engine').glob('defaults-v*.json')):
        old=json.loads(file.read_text());schema=old['schema_version'];runtime=EngineRuntime(old);migrated=runtime.tune;runtime.close()
        check(f'legacy-schema{schema}-canonical-shape',migrated['schema_version']==11 and migrated['engine']['cylinders']==4 and len(migrated['timing']['firing_order'])==8 and len(migrated['cylinder_trims']['fuel_maps'])==8)
        check(f'legacy-schema{schema}-neutral-extra-maps',all(m['cells']==[100]*36 and m['rpm']==migrated['cylinder_trims']['fuel_maps'][0]['rpm'] and m['load']==migrated['cylinder_trims']['fuel_maps'][0]['load'] for m in migrated['cylinder_trims']['fuel_maps'][4:]))
        check(f'legacy-schema{schema}-neutral-extra-order-and-spark',migrated['timing']['firing_order'][4:]==[0]*4 and migrated['cylinder_trims']['spark_deg'][4:]==[0]*4)
        for n in (0,1,2,3,5,6,7,8,4.5,True):
            candidate=copy.deepcopy(old);candidate['engine']['cylinders']=n
            check(f'legacy-schema{schema}-reject-count-{n}',rejects(candidate))
        for key,values in (('displacement_cc',(499,4001)),('injector_cc_min',(99,1501))):
            for value in values:
                candidate=copy.deepcopy(old);candidate['engine'][key]=value
                check(f'legacy-schema{schema}-reject-{key}-{value}',rejects(candidate))
    old=json.loads((ROOT/'config/engine/defaults-v2.json').read_text());old['schema_version']=1;old.pop('timing')
    runtime=EngineRuntime(old);check('legacy-schema1-implicit-order',runtime.tune['timing']['firing_order']==[1,3,4,2,0,0,0,0]);runtime.close()
    for key,value in [('cylinders',8),('displacement_cc',5000),('injector_cc_min',99)]:
        candidate=copy.deepcopy(old);candidate['engine'][key]=value;check(f'legacy-schema1-reject-{key}-{value}',rejects(candidate))
    base=profile(8)
    for n in (0,9,-1,4.5,True):
        candidate=copy.deepcopy(base);candidate['engine']['cylinders']=n;check(f'schema11-reject-count-{n}',rejects(candidate))
    for n in range(1,9):
        candidate=profile(n);candidate['timing']['firing_order']=[1,3,4,2]
        check(f'schema11-reject-order-length4-for-{n}',rejects(candidate))
    for order in ([2,1,3,4,5,6,7,8],[1,2,3,4,5,6,7,7],[1,2,3,4,5,6,7,0],[1,2,3,4,5,6,7,9]):
        candidate=copy.deepcopy(base);candidate['timing']['firing_order']=order;check('schema11-reject-bad-order-'+str(order),rejects(candidate))
    candidate=profile(4);candidate['timing']['firing_order'][7]=8;check('schema11-reject-nonzero-inactive-order',rejects(candidate))
    for key,value in [('displacement_cc',25),('displacement_cc',12000),('injector_cc_min',25),('injector_cc_min',5000)]:
        candidate=copy.deepcopy(base);candidate['engine'][key]=value;check(f'schema11-accept-bound-{key}-{value}',not rejects(candidate))
    for key,value in [('displacement_cc',24),('displacement_cc',12001),('injector_cc_min',24),('injector_cc_min',5001)]:
        candidate=copy.deepcopy(base);candidate['engine'][key]=value;check(f'schema11-reject-bound-{key}-{value}',rejects(candidate))
    for key in ('fuel_maps','spark_deg'):
        candidate=copy.deepcopy(base);candidate['cylinder_trims'][key]=candidate['cylinder_trims'][key][:4];check('schema11-reject-trim-length4-'+key,rejects(candidate))
    for bad in (49,151,float('nan'),float('inf')):
        candidate=profile(1);candidate['cylinder_trims']['fuel_maps'][7]['cells'][35]=bad
        check('schema11-validates-inactive-c8-map-'+str(bad),rejects(candidate))
    for file in sorted((ROOT/'tuning/examples').glob('*.msq')):
        body=file.read_bytes();migrated=import_msq(body);signature=ET.fromstring(body).find(tag('versionInfo')).get('signature')
        check(file.name+'-import-current',migrated['schema_version']==11 and migrated['engine']['cylinders']==4 and migrated['timing']['firing_order'][4:]==[0]*4,signature)
        check(file.name+'-neutral-extras',all(m['cells']==[100]*36 and m['load']==migrated['cylinder_trims']['fuel_maps'][0]['load'] for m in migrated['cylinder_trims']['fuel_maps'][4:]))
        if file.name=='tunerstudio-boost-roundtrip.msq':check('actual-own011-boost-retained',migrated['boost_control']['mode']=='closed_loop')
        for key,value in [('cylinders','8'),('displacement_cc','5000'),('injector_cc_min','99')]:
            root=ET.fromstring(body)
            for element in root.iter(tag('constant')):
                if element.get('name')==key:element.text=value
            try:import_msq(ET.tostring(root));accepted=True
            except ValueError:accepted=False
            check(file.name+'-historical-reject-'+key,not accepted)
    with tempfile.TemporaryDirectory(dir=OUT) as directory:
        path=Path(directory)/'tune.json';store=EngineStore(path)
        try:
            code,saved=store.save(json.dumps(base).encode());assert code==200
            for bad in (float('nan'),float('inf'),-float('inf'),0,9,4.5,-1):
                session=Session(store)
                try:
                    before_tune=copy.deepcopy(store.tune);before_file=path.read_bytes();initial=session.buffers[1]
                    data=struct.pack('<f',bad);check('native-stage-invalid-count-'+str(bad),session.command(request(4,data))==b'\0')
                    check('native-burn-reject-count-'+str(bad),session.command(b'b\0\1')==b'\x84')
                    check('native-invalid-count-no-active-or-disk-change-'+str(bad),store.tune==before_tune and path.read_bytes()==before_file and session.dirty)
                    buf=bytearray(initial);buf[4:8]=data
                    try:decode_pages({1:buf},base);accepted=True
                    except ValueError:accepted=False
                    check('python-decode-reject-count-'+str(bad),not accepted)
                finally:session.close()
            session=Session(store)
            try:
                before=copy.deepcopy(store.tune);before_file=path.read_bytes()
                check('stage-c8-spark',session.command(request(spark_offset(7),struct.pack('<f',3.75)))==b'\0')
                check('stage-c8-map-last-cell',session.command(request(fuel_offset(7)+48+35*4,struct.pack('<f',125.25)))==b'\0')
                check('staged-isolation-before-burn',store.tune==before and path.read_bytes()==before_file)
                with mock.patch('engine_runtime.EngineRuntime',side_effect=MemoryError):reply=session.command(b'b\0\1')
                check('allocation-failure-retryable',reply==b'\x85' and session.dirty and store.tune==before and path.read_bytes()==before_file)
                check('c8-commit-success',session.command(b'b\0\1')==b'\4' and store.tune['cylinder_trims']['spark_deg'][7]==3.75 and store.tune['cylinder_trims']['fuel_maps'][7]['cells'][35]==125.25)
                check('c8-commit-updated-only-selected',store.tune['cylinder_trims']['spark_deg'][:7]==before['cylinder_trims']['spark_deg'][:7] and store.tune['revision']==before['revision']+1)
                rev=store.tune['revision'];page=session.buffers[1]
                check('duplicate-burn-idempotent',session.command(b'b\0\1')==b'\4' and store.tune['revision']==rev and session.buffers[1]==page)
                shrink=copy.deepcopy(store.tune);shrink['engine']['cylinders']=1;shrink['timing']['firing_order']=[1]+[0]*7
                check('shrink-persist-retains-inactive-c8',store.save(json.dumps(shrink).encode())[0]==200 and store.tune['cylinder_trims']['spark_deg'][7]==3.75 and store.tune['cylinder_trims']['fuel_maps'][7]['cells'][35]==125.25)
                check('stale-session-write-rejected',session.command(request(spark_offset(7),struct.pack('<f',4.25)))==b'\x84')
            finally:session.close()
            a,b=Session(store),Session(store)
            try:
                assert a.command(request(spark_offset(7),struct.pack('<f',5)))==b'\0'
                assert b.command(request(spark_offset(7),struct.pack('<f',6)))==b'\0'
                assert a.command(b'b\0\1')==b'\4'
                before=copy.deepcopy(store.tune);before_file=path.read_bytes();staged=b.buffers[1]
                check('two-editor-CAS-conflict',b.command(b'b\0\1')==b'\x84' and b.diagnostics()['state']=='revision_conflict')
                check('CAS-conflict-preserves-staged-active-disk',b.dirty and b.buffers[1]==staged and store.tune==before and path.read_bytes()==before_file)
            finally:a.close();b.close()
            s=Session(store)
            try:
                before=copy.deepcopy(store.tune);before_file=path.read_bytes();assert s.command(request(spark_offset(7),struct.pack('<f',7)))==b'\0'
                with mock.patch('engine_runtime.os.replace',side_effect=OSError('independent injected storage failure')):reply=s.command(b'b\0\1')
                check('storage-failure-retains-active-disk',reply==b'\x84' and store.tune==before and path.read_bytes()==before_file and not store.storage_ok and s.dirty)
                check('storage-failure-blocks-retry',s.command(b'b\0\1')==b'\x84' and s.diagnostics()['state']=='storage_blocked')
            finally:s.close()
        finally:store.runtime.close();store.data_recorder.close()
    current_xml=export_msq(base);root=ET.fromstring(current_xml)
    # A dimension mismatch currently exercises actual parser policy, not a presumed gate.
    for element in root.iter(tag('constant')):
        if element.get('name')=='c8FuelTable':element.set('rows','1');element.set('cols','36')
    try:result=import_msq(ET.tostring(root));shape_accepted=True
    except ValueError:shape_accepted=False
    checks.append(dict(name='current-msq-shape-attribute-observation',passed=True,detail=dict(mismatching_rows_cols_accepted=shape_accepted)))
    (OUT/'probe-results.json').write_text(json.dumps(dict(checks=checks,failed=failures,total=len(checks)),indent=2)+'\n')
    print(json.dumps(dict(total=len(checks),failed=failures)))

if __name__=='__main__':main()
