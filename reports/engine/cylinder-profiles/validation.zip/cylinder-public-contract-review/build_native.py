from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
flags=['-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie','-I'+str(ROOT/'firmware/include')]
def run(command,name):
 p=subprocess.run(command,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (OUT/(name+'.log')).write_text(p.stdout)
 if p.returncode:raise RuntimeError(name+' failed: '+p.stdout)
 return p.stdout
run(['g++',*flags,str(OUT/'policy.cpp'),'-o',str(OUT/'policy')],'policy-build')
print(run([str(OUT/'policy')],'policy-run').strip())
cjson=Path.home()/'.platformio/packages/framework-espidf/components/json/cJSON'
run(['gcc','-O1','-g','-fno-pie','-fsanitize=address,undefined','-I'+str(cjson),'-c',str(cjson/'cJSON.c'),'-o',str(OUT/'cJSON.o')],'cjson-build')
run(['g++',*flags,'-I'+str(cjson),str(OUT/'migration_allocation.cpp'),str(OUT/'cJSON.o'),'-o',str(OUT/'migration_allocation')],'migration-allocation-build')
print(run([str(OUT/'migration_allocation'),str(ROOT/'config/engine/defaults-v10.json')],'migration-allocation-run').strip())
# Compile the actual target's OutputIO body with GPIO/auxiliary stubs under
# both policies. This verifies guards without claiming a whole-target build.
target=(ROOT/'firmware/main/engine_target.cpp').read_text()
body=target[target.index('struct OutputIO {'):target.index('DRAM_ATTR OutputIO output;')]
stubs='''#include "ecu/cylinder_channels.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
namespace engine=ecu::engine;
struct Port{};Port GPIO;static unsigned writes=0,reads=0;
void gpio_ll_set_level(Port*,unsigned pin,unsigned){assert(pin<20);++writes;}
unsigned gpio_ll_get_level(Port*,unsigned pin){assert(pin<20);++reads;return 1;}
void idle_engine_stop(){} void boost_engine_stop(){}
namespace pins {constexpr unsigned arm=8,pump_cmd=9,fan_cmd=10,safe_n_mon=11,interlock=12;}
constexpr unsigned output_pins[8]={0,1,2,3,4,5,6,7};
'''
main='''
int main(){OutputIO io;io.armed=true;io.boot_allowed=true;unsigned accepted=0,rejected=0;
 for(unsigned ch=0;ch<20;++ch){const auto before=io.physical_mask;const auto nwrite=writes,nread=reads;const auto kind=engine::channels::kind(ch);
 const bool engine_channel=kind==engine::channels::Kind::Injector||kind==engine::channels::Kind::Coil;
 const bool expected=engine_channel&&(!ECU_ENGINE_DUMMY_LOADS||ch<8);
 const bool high=io.write(ch,true);assert(high==expected);
 if(high){++accepted;
  if(ECU_ENGINE_DUMMY_LOADS)assert(io.physical_mask==(1U<<ch));else assert(io.physical_mask==0);
  assert(io.write(ch,false));assert(io.physical_mask==0);
 }else{++rejected;assert(io.physical_mask==before&&writes==nwrite&&reads==nread);assert(!io.write(ch,false));}
 }
 std::cout<<"{\\\"passed\\\":true,\\\"physical_policy\\\":"<<ECU_ENGINE_DUMMY_LOADS<<",\\\"accepted_channels\\\":"<<accepted<<",\\\"rejected_channels\\\":"<<rejected<<"}\\n";
}
'''
(OUT/'output_io_extracted.cpp').write_text(stubs+body+main)
for policy in (0,1):
 exe=OUT/('output_io_'+str(policy))
 run(['g++',*flags,'-DECU_ENGINE_DUMMY_LOADS='+str(policy),str(OUT/'output_io_extracted.cpp'),'-o',str(exe)],'output-io-build-'+str(policy))
 print(run([str(exe)],'output-io-run-'+str(policy)).strip())
