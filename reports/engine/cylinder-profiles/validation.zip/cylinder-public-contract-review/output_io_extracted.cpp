#include "ecu/cylinder_channels.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
namespace engine=ecu::engine;
struct Port{};Port GPIO;static unsigned writes=0,reads=0;
void gpio_ll_set_level(Port*,unsigned pin,unsigned){assert(pin<20);++writes;}
unsigned gpio_ll_get_level(Port*,unsigned pin){assert(pin<20);++reads;return 1;}
void idle_engine_stop(){} void boost_engine_stop(){}
namespace pins {constexpr unsigned arm=8,pump_cmd=9,fan_cmd=10,safe_n_mon=11,interlock=12;}
constexpr unsigned output_pins[8]={0,1,2,3,4,5,6,7};
struct OutputIO {
 bool boot_allowed=false,armed=false,failed=false;
 std::uint32_t physical_mask=0;
 ECU_ISR_CODE void all_low(){
#if ECU_ENGINE_DUMMY_LOADS
  gpio_ll_set_level(&GPIO,pins::arm,0);
  for(auto pin:output_pins)gpio_ll_set_level(&GPIO,pin,0);
  gpio_ll_set_level(&GPIO,pins::pump_cmd,0);gpio_ll_set_level(&GPIO,pins::fan_cmd,0);
#endif
  physical_mask=0;
  idle_engine_stop();
  boost_engine_stop();
 }
 ECU_ISR_CODE bool write(unsigned ch,bool high){
  const auto kind=engine::channels::kind(ch);if(kind!=engine::channels::Kind::Injector&&kind!=engine::channels::Kind::Coil)return false;
#if ECU_ENGINE_DUMMY_LOADS
  if(ch>=8)return false;
  if(high&&(!armed||failed||!gpio_ll_get_level(&GPIO,pins::safe_n_mon)||!gpio_ll_get_level(&GPIO,pins::interlock)))return false;
  if(high){gpio_ll_set_level(&GPIO,pins::arm,1);gpio_ll_set_level(&GPIO,output_pins[ch],1);physical_mask|=1U<<ch;}
  else{gpio_ll_set_level(&GPIO,output_pins[ch],0);physical_mask&=~(1U<<ch);}
#else
  (void)ch;(void)high;
#endif
  return true;
 }
 void supervise(bool healthy){
#if ECU_ENGINE_DUMMY_LOADS
  const bool power= gpio_ll_get_level(&GPIO,pins::safe_n_mon)&&gpio_ll_get_level(&GPIO,pins::interlock);
  if(!boot_allowed||(armed&&(!healthy||!power))){failed=true;armed=false;all_low();}
  else if(!failed&&healthy&&power)armed=true;
#else
  (void)healthy;
#endif
 }
};

int main(){OutputIO io;io.armed=true;io.boot_allowed=true;unsigned accepted=0,rejected=0;
 for(unsigned ch=0;ch<20;++ch){const auto before=io.physical_mask;const auto nwrite=writes,nread=reads;const auto kind=engine::channels::kind(ch);
 const bool engine_channel=kind==engine::channels::Kind::Injector||kind==engine::channels::Kind::Coil;
 const bool expected=engine_channel&&(!ECU_ENGINE_DUMMY_LOADS||ch<8);
 const bool high=io.write(ch,true);assert(high==expected);
 if(high){++accepted;
  if(ECU_ENGINE_DUMMY_LOADS)assert(io.physical_mask==(1U<<ch));else assert(io.physical_mask==0);
  assert(io.write(ch,false));assert(io.physical_mask==0);
 }else{++rejected;assert(io.physical_mask==before&&writes==nwrite&&reads==nread);assert(!io.write(ch,false));}
 }
 std::cout<<"{\"passed\":true,\"physical_policy\":"<<ECU_ENGINE_DUMMY_LOADS<<",\"accepted_channels\":"<<accepted<<",\"rejected_channels\":"<<rejected<<"}\n";
}
