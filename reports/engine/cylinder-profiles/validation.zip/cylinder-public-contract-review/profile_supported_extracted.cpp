#include "ecu/engine.hpp"
#include <cassert>
#include <iostream>
namespace engine=ecu::engine;
bool profile_supported(const engine::Tune&t){
#if defined(ECU_ENGINE_DUMMY_LOADS) && ECU_ENGINE_DUMMY_LOADS
 return t.cylinders<=4;
#else
 (void)t;return true;
#endif
}

int main(){engine::Tune t;unsigned accepted=0;for(unsigned n=1;n<=8;++n){t.cylinders=n;const bool expected=!ECU_ENGINE_DUMMY_LOADS||n<=4;assert(profile_supported(t)==expected);accepted+=expected;}std::cout<<"{\"passed\":true,\"physical_policy\":"<<ECU_ENGINE_DUMMY_LOADS<<",\"accepted_valid_profile_counts\":"<<accepted<<"}\n";}
