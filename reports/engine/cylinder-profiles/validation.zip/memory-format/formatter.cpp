#include "ecu/engine_log_msl.hpp"
#include <cfloat>
#include <cstring>
#include <iostream>
int main(){
 ecu::engine_log::Header h;h.source=ecu::engine::DataSource::Target;
 h.log_id=h.period_ms=h.duration_s=h.total=h.retained=h.overwritten=h.missed_periods=h.repeated=h.invalid=UINT32_MAX;
 h.started_us=0;
 char buffer[ecu::engine_log::text_capacity];
 const bool header=ecu::engine_log::msl_header(h,buffer,sizeof(buffer),"0123456789abcdef0123456789abcdef");
 const auto header_size=std::strlen(buffer);
 ecu::engine_log::Row row;row.recorded_us=UINT64_MAX;row.sequence=row.log_id=UINT32_MAX;
 auto&r=row.sample;r.flags=UINT16_MAX;r.source=ecu::engine::DataSource::Target;
 r.sequence=r.worker_sequence=UINT64_MAX;r.tune_revision=r.sensor_revision=r.phase_epoch=r.worker_epoch=r.worker_tune_revision=r.worker_sensor_revision=r.controller_faults=r.phase_losses=r.cam_rejected=UINT32_MAX;
 r.inputs.fill(-FLT_MAX);r.proposals.fill(-FLT_MAX);r.idle_proposals.fill(-FLT_MAX);r.idle_available=true;
 r.raw_adc.fill(UINT16_MAX);r.input_valid=r.cylinder_valid=r.cylinder_enabled=r.cylinder_capacity_mask=r.cylinder_spark_clamp_mask=r.cylinder_retard_floor_mask=255;
 r.cylinder_pulse_ms.fill(-FLT_MAX);r.cylinder_advance_deg.fill(-FLT_MAX);r.cylinder_fuel_pct.fill(-FLT_MAX);r.cylinder_duty_pct.fill(-FLT_MAX);
 r.cylinder_count=r.worker_cylinder_count=8;r.virtual_high_mask=r.physical_command_mask=UINT32_MAX;r.cam_error_deg=-FLT_MAX;r.idle_pid_updates=UINT64_MAX;r.idle_flags=UINT32_MAX;r.board_flags=255;
 r.transient_enrichment.available=true;r.transient_enrichment.values.fill(-FLT_MAX);
 r.load_model.available=true;r.load_model.values.fill(-FLT_MAX);
 for(auto*o:{&r.secondary_fuel,&r.secondary_spark}){o->available=true;for(auto member:ecu::secondary::value_members)o->*member=-FLT_MAX;o->input_observed_us=UINT64_MAX;}
 r.flex_fuel.flags=UINT32_MAX;r.flex_fuel.values.fill(-FLT_MAX);r.flex_fuel.times.fill(UINT64_MAX);
 r.boost_control.available=true;r.boost_control.values.fill(-FLT_MAX);r.boost_control.counters.fill(UINT64_MAX);
 const bool line=ecu::engine_log::msl_row(h,row,buffer,sizeof(buffer));
 std::cout<<"{\"runtime_sample_bytes\":"<<sizeof(ecu::engine::RuntimeSample)<<",\"recorder_bytes\":"<<sizeof(ecu::engine_log::Recorder)<<",\"row_bytes\":"<<sizeof(ecu::engine_log::Row)<<",\"capacity\":"<<sizeof(buffer)<<",\"header_ok\":"<<(header?"true":"false")<<",\"header_bytes\":"<<header_size<<",\"row_ok\":"<<(line?"true":"false")<<",\"stress_row_bytes\":"<<std::strlen(buffer)<<",\"scope\":\"current schema3 native formatter type-extrema stress; not a valid control observation\"}\n";
}
