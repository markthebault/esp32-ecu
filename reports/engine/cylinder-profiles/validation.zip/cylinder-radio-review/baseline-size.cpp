#include "ecu/engine_radio_flex.hpp"
#include "ecu/engine_log.hpp"
#include <iostream>
int main(){std::cout<<"{\"pair_bytes\":"<<sizeof(ecu::radio::wire::EnginePair)<<",\"runtime_sample_bytes\":"<<sizeof(ecu::engine::RuntimeSample)<<",\"recorder_bytes\":"<<sizeof(ecu::engine_log::Recorder)<<"}\n";}
