import copy,ctypes,hashlib,hmac,itertools,json,math,struct,sys
from pathlib import Path
ROOT=Path('/home/mark/persospace/esp32-ecu');sys.path.insert(0,str(ROOT/'tools'))
from engine_runtime import EngineRuntime
from engine_observability import EngineRecorder,encoded
from engine_receiver import EngineReceiver,derive_engine_key,engine_acknowledgement
from cylinder_radio import engine_cylinder_fragment
from profile_config import LAYOUT
OUT=ROOT/'.cache/engine/cylinder-radio-review-001'
LMK=bytes(range(16));BOOT=bytes(range(16,32));MAC='02:EC:00:00:00:01';SESSION=0x12345678;FLOOR=2**53+91
KEY=derive_engine_key(LMK,BOOT,SESSION)
results=[]
def check(condition,label,detail=None):
 results.append(dict(label=label,passed=bool(condition),detail=detail))
 if not condition:raise AssertionError((label,detail))
def rejects(fn,label):
 try:fn()
 except (ValueError,TypeError):check(True,label);return
 check(False,label)
def signed(part):
 p=bytearray(part);p[-32:]=hmac.digest(KEY,p[:-32],'sha256');return bytes(p)
def config(n,mode='sequential'):
 t=json.loads((ROOT/'config/engine/defaults.json').read_text());t['strategy']=mode;t['engine']['cylinders']=n;t['engine']['displacement_cc']=500*n
 order=[1]+list(range(n,1,-1));t['timing']['firing_order']=order+[0]*(8-n)
 if mode=='sequential':
  t['cylinder_trims']['enabled']=True
  for i,m in enumerate(t['cylinder_trims']['fuel_maps']):m['cells']=[100+i]*36
  t['cylinder_trims']['spark_deg']=[.25*i for i in range(8)]
 return t
def sample(n=8,mode='sequential',flex=False):
 t=config(n,mode)
 if flex:t['flex_fuel']['input_confirmed']=True;t['flex_fuel']['correction']['enabled']=True;t['flex_fuel']['capture']['cycles']=2
 r=EngineRuntime(t)
 try:
  if flex:
   r.flex_edge(980000,True)
   for k in (1,2):r.flex_edge(980000+k*10000-3000,False);r.flex_edge(980000+k*10000,True)
  r.step(dict(rpm=2000,synced=True,phase_synced=True),1000000,use_decoder=False)
  return r.data()
 finally:r.close()
native=EngineRecorder()
def parts(s=None,seq=FLOOR+1,sent=5030000,age=0):
 return native.frame_profile(s or sample(),LMK,BOOT,SESSION,seq,sent=sent,sample_age=12+age,control_age=8+age)
def receiver():
 native.reset_capabilities();r=EngineReceiver(MAC,LMK,schema=7);q=r.query(100,b'a'*16)
 r.receive_reply(native.capability_reply(q,LMK,SESSION,BOOT,FLOOR,5000000),MAC,110);q=r.update(True,120,b'b'*16)
 r.receive_reply(native.capability_reply(q,LMK,SESSION,BOOT,FLOOR,5010000),MAC,125);return r
def complete(r,packets,when=140,order=(0,1,2,3)):
 d=None
 for k,index in enumerate(order):d=r.receive(packets[index],MAC,when+k*10)
 return d
try:
 for n in range(1,9):
  for mode in ('batch_wasted','sequential','semi_sequential'):
   s=sample(n,mode);p=parts(s);d=complete(receiver(),p)
   check(d['cylinders']['count']==n,f'profile-{n}-{mode}-count')
   check(d['strategy']==mode,f'profile-{n}-{mode}-strategy')
   check(d['board_capacity']==dict(injector_commands=4,coil_commands=4,additional_outputs_allocated=False),f'profile-{n}-{mode}-fitted')
   for index,row in enumerate(d['cylinders']['proposals']):
    check(row['active']==(index<n),f'profile-{n}-{mode}-active-{index}')
    check(row['injector_logical_channel']==LAYOUT['injector_channels'][index] and row['coil_logical_channel']==LAYOUT['coil_channels'][index],f'profile-{n}-{mode}-logical-{index}')
    for key in ('pulse_ms','advance_deg','fuel_pct','duty_pct'):
     source=s['cylinders']['proposals'][index][key]
     value=struct.unpack('<f',struct.pack('<f',source))[0] if source is not None else None
     check(row[key]==value,f'profile-{n}-{mode}-{index}-{key}')
   if n!=4:
    rejects(lambda:native.frame_triple(s,LMK,BOOT,SESSION,FLOOR+1),f'legacy6-excludes-{n}-{mode}')
 for proposal in range(1,9):
  for worker in range(9):
   s=sample(proposal);mask=sum(1<<ch for ch in LAYOUT['injector_channels'][:worker]+LAYOUT['coil_channels'][:worker]);physical=sum(1<<ch for ch in LAYOUT['injector_channels'][:min(worker,4)]+LAYOUT['coil_channels'][:min(worker,4)])
   s['worker_observation'].update(cylinder_count=worker,virtual_high_mask=mask,physical_command_mask=physical)
   p=parts(s);d=complete(receiver(),p)
   check(d['cylinders']['count']==proposal and d['worker_observation']['cylinder_count']==worker,f'independent-counts-{proposal}-{worker}')
   check(d['worker_observation']['virtual_high_mask']==mask and d['worker_observation']['physical_command_mask']==physical,f'full-masks-{proposal}-{worker}')
 # Every fragment binds all32 bytes of BASE MAC, with a valid own HMAC.
 s=sample();p=parts(s)
 for index in (1,2,3):
  for byte in range(32):
   q=list(p);b=bytearray(q[index]);b[24+byte]^=1;q[index]=signed(b)
   r=receiver();rejects(lambda:complete(r,q),f'base-bind-{index}-{byte}');check(r.latest is None and r.last_packet==FLOOR,f'base-bind-no-publish-{index}-{byte}')
 # All schema combinations and all session/sequence mismatches are rejected.
 for index in range(4):
  for schema in range(0,9):
   if schema==7:continue
   q=list(p);b=bytearray(q[index]);struct.pack_into('<H',b,20,schema);q[index]=signed(b)
   r=receiver();rejects(lambda:complete(r,q),f'part-schema-{index}-{schema}');check(r.latest is None,f'part-schema-no-publish-{index}-{schema}')
  for offset,fmt,value in ((8,'I',0),(8,'I',SESSION+1),(12,'Q',0),(12,'Q',FLOOR),(12,'Q',FLOOR+2)):
   q=list(p);b=bytearray(q[index]);struct.pack_into('<'+fmt,b,offset,value);q[index]=signed(b)
   r=receiver()
   try:d=complete(r,q)
   except ValueError:d=None
   check(d is None and r.latest is None,f'part-session-sequence-{index}-{offset}-{value}')
 # Assembly start is first part, independent of which part arrives first.
 for order in itertools.permutations(range(4)):
  r=receiver()
  for k,index in enumerate(order[:-1]):check(r.receive(p[index],MAC,140+k) is None,'expiry-prefix')
  rejects(lambda:r.receive(p[order[-1]],MAC,391),'expiry-original-first-part')
  check(r.latest is None and r.last_packet==FLOOR,'expiry-no-ack-window')
 # A first valid completion followed by malformed partials must not change its liveness.
 r=receiver();d=complete(r,p);receipt=r.received_ms;latest=copy.deepcopy(r.latest)
 q=parts(s,FLOOR+2,5070000,40);b=bytearray(q[3]);b[65]=1
 for index in (0,1,2):check(r.receive(q[index],MAC,190+index) is None,'later-prefix')
 rejects(lambda:r.receive(signed(b),MAC,200),'later-invalid-cylinder')
 check(r.received_ms==receipt and r.latest==latest and r.last_packet==FLOOR+1,'invalid-preserves-last-complete')
 # Re-query retains immutable cylinder payload and conservative age history.
 r=receiver();complete(r,p);old=r.status(170)['control_age_ms']
 q=r.query(200,b'c'*16);r.receive_reply(native.capability_reply(q,LMK,SESSION,BOOT,FLOOR+10,5090000),MAC,210)
 d=complete(r,parts(s,FLOOR+11,5100000,0),220)
 check(d['bounded_control_age_ms']>=old+80,'requery-repeated-age-does-not-young')
 changed=copy.deepcopy(s);changed['cylinders']['proposals'][7]['fuel_pct']+=1
 rejects(lambda:complete(r,parts(changed,FLOOR+12,5140000,110),270),'requery-c8-immutable')
 # Wrong MAC, clock reversal and changed boot cannot reuse old parts.
 r=receiver();rejects(lambda:r.receive(p[3],'02:EC:00:00:00:02',140),'saved-mac-only')
 r=receiver();r.receive(p[3],MAC,150);rejects(lambda:r.receive(p[0],MAC,149),'clock-reversal');check(r.status(151)['query_required'],'clock-reversal-query-required')
 # Current metadata never authorizes additional physical commands.
 for count in (1,4,8):
  s=sample(count);s['worker_observation'].update(cylinder_count=8,physical_command_mask=1<<17)
  rejects(lambda:parts(s),f'unmapped-physical-mask-{count}')
 # Compare all legacy native bytes to HEAD's actual frozen C++ serializer.
 baseline=ctypes.CDLL(str(OUT/'baseline.so'));P=ctypes.c_void_p;S=ctypes.c_char_p;U=ctypes.c_uint32;T=ctypes.c_uint64;I=ctypes.c_int
 baseline.data_validate.argtypes=[S];baseline.data_validate.restype=I
 baseline.data_radio_frame.argtypes=[S,S,S,U,T,U,U,U,T,U,P];baseline.data_radio_frame.restype=I
 for name in ('data_radio_pair','data_radio_triple'):
  getattr(baseline,name).argtypes=[S,S,S,U,T,U,U,U,U,T,P];getattr(baseline,name).restype=I
 for mode in ('batch_wasted','sequential','semi_sequential'):
  s=sample(4,mode);old=copy.deepcopy(s);old['schema_version']=2;old['cylinders']['proposals']=old['cylinders']['proposals'][:4]
  check(baseline.data_validate(encoded(old))==1,f'baseline-observation-{mode}')
  for schema in range(1,7):
   if schema==1 and mode=='semi_sequential':continue
   if schema<5:
    out=ctypes.create_string_buffer(250)
    ok=baseline.data_radio_frame(encoded(old),LMK,BOOT,SESSION,FLOOR+1,12,8,2**32-1,5030000,schema,out)
    actual=native.frame(s,LMK,BOOT,SESSION,FLOOR+1,sample_age=12,control_age=8,sent=5030000,schema=schema)
    expected=out.raw[:232 if schema<3 else 250]
   else:
    size=482 if schema==5 else 626;out=ctypes.create_string_buffer(size);name='data_radio_pair' if schema==5 else 'data_radio_triple'
    ok=getattr(baseline,name)(encoded(old),LMK,BOOT,SESSION,FLOOR+1,12,8,2**32-1,2**32-1,5030000,out)
    actual=b''.join((native.frame_pair if schema==5 else native.frame_triple)(s,LMK,BOOT,SESSION,FLOOR+1,sample_age=12,control_age=8,sent=5030000))
    expected=out.raw
   check(ok==1 and actual==expected,f'legacy-byte-exact-{schema}-{mode}',dict(bytes=len(expected),sha256=hashlib.sha256(actual).hexdigest()))
finally:
 native.close()
 (OUT/'probe-results.json').write_text(json.dumps(dict(passed=all(r['passed'] for r in results),checks=len(results),results=results),indent=2)+'\n')
print(json.dumps(dict(passed=True,checks=len(results))))
