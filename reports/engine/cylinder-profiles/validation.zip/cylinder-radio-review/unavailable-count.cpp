#include "ecu/engine_radio_flex.hpp"
#include <cstdlib>
#include <iostream>
int main(int argc,char**argv){ecu::engine::RuntimeSample r;r.cylinder_count=argc>1?std::strtoul(argv[1],nullptr,10):32;std::cout<<ecu::radio::wire::engine_schema_supports(7,r)<<"\n";}
