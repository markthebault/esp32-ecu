#include "ecu/engine_radio_flex.hpp"
#include "ecu/engine_log.hpp"
#include <iostream>
#include <cstdlib>
#include <limits>
using namespace ecu;
using namespace ecu::radio::wire;
unsigned checks=0;
void check(bool value){++checks;if(!value){std::cerr<<"check failed "<<checks<<'\n';std::abort();}}
engine::RuntimeSample observation(unsigned count){
 engine::Tune tune;tune.cylinders=count;tune.displacement_cc=500*count;tune.firing_order.fill(0);for(unsigned i=0;i<count;++i)tune.firing_order[i]=i+1;
 tune.strategy=engine::Strategy::Sequential;
 engine::Inputs in;in.rpm=2000;in.map_kpa=50;in.tps_pct=10;in.clt_c=85;in.iat_c=25;in.lambda=1;in.battery_v=14;in.sensor_v=5;in.synced=in.phase_synced=in.sensors_valid=in.lambda_ready=true;in.sampled_us=1000000;
 engine::Controller controller;const auto output=controller.step(tune,in,1000000);return engine::synthetic_data(tune,in,output,1,1000000);
}
int main(){
 for(unsigned present=0;present<2;++present)for(unsigned count=0;count<256;++count){engine::RuntimeSample r;r.cylinder_count=count;if(present)r.flags|=engine::Present;const auto ok=engine_schema_supports(7,r);if(count>8||(present&&!count))check(!ok);else check(ok);}
 for(unsigned worker=9;worker<256;++worker){auto r=observation(8);r.worker_cylinder_count=worker;check(!engine_schema_supports(7,r));}
 for(unsigned value=2;value<256;++value){auto r=observation(8);r.cylinder_enabled=value;check(!engine_schema_supports(7,r));}
 for(unsigned count=1;count<=8;++count)for(unsigned worker=0;worker<=8;++worker){
  auto r=observation(count);r.worker_cylinder_count=worker;r.virtual_high_mask=engine::channels::mask(worker);r.physical_command_mask=engine::channels::mask(worker<4?worker:4);
  check(engine_schema_supports(7,r));
  for(unsigned bit=0;bit<32;++bit){auto bad=r;bad.virtual_high_mask=std::uint32_t(1)<<bit;check(engine_schema_supports(7,bad)==bool(engine::channels::mask(worker)&bad.virtual_high_mask));}
  for(unsigned bit=0;bit<32;++bit){auto bad=r;bad.physical_command_mask=std::uint32_t(1)<<bit;check(engine_schema_supports(7,bad)==bool(engine::channels::mask(worker<4?worker:4)&bad.physical_command_mask));}
  for(unsigned schema=1;schema<=6;++schema)if(count!=4||worker>4)check(!engine_schema_supports(schema,r));
 }
 auto r=observation(8);EnginePair pending;
 for(unsigned fail=1;fail<=4;++fail){unsigned calls=0;check(!pending.prepare(r,7,9,0,0,UINT32_MAX,UINT32_MAX,1000,[&](const auto*,unsigned,auto*proof){std::memset(proof,++calls,32);return calls!=fail;},7));check(calls==fail&&!pending.pending()&&!pending.data()&&!pending.size()&&!pending.base_submitted());}
 for(unsigned stage=0;stage<4;++stage){
  auto original=r;unsigned calls=0;check(pending.prepare(r,7,10+stage,0,0,UINT32_MAX,UINT32_MAX,2000,[&](const auto*,unsigned,auto*proof){std::memset(proof,++calls,32);return true;},7));check(calls==4);
  std::array<std::uint8_t,250> base{};std::memcpy(base.data(),pending.data(),250);
  // Caller-side data changes cannot mutate the pending last cylinder part.
  r.cylinder_pulse_ms[7]=99;r.cylinder_count=1;r.virtual_high_mask=UINT32_MAX;
  for(unsigned part=0;part<stage;++part)check(!pending.submitted());
  check(!pending.expired(252000)&&pending.expired(252001)&&pending.expired(1999));
  if(stage==3){check(pending.data()[56]==8);float value;const auto bits=read32(pending.data()+76+16*7);std::memcpy(&value,&bits,4);check(value==original.cylinder_pulse_ms[7]);check(same(pending.data()+24,base.data()+218,32));}
  pending.cancel();check(!pending.pending()&&!pending.data()&&!pending.size()&&!pending.base_submitted()&&pending.part_index()==0);r=original;
 }
 std::cout<<"{\"passed\":true,\"checks\":"<<checks<<",\"pair_bytes\":"<<sizeof(EnginePair)<<",\"runtime_sample_bytes\":"<<sizeof(engine::RuntimeSample)<<",\"recorder_bytes\":"<<sizeof(engine_log::Recorder)<<"}\n";
}
