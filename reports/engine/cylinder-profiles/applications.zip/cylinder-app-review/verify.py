"""Recheck saved vendor output and source logs; never launches an application."""
from pathlib import Path
import copy
import hashlib
import json
import math
import sys
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from engine_msq import import_msq,tag
from engine_protocol import pages

base=json.loads((OUT/'fixtures/input.json').read_text())
body=(OUT/'ts/application-edited012.msq').read_bytes()
xml=ET.fromstring(body)
constants={e.get('name'):(e.text or '').strip() for e in xml.iter(tag('constant'))}
actual=import_msq(body,base_revision=base['revision'])
expected=copy.deepcopy(base)
expected['cylinder_trims']['spark_deg'][7]=3.75
expected['cylinder_trims']['fuel_maps'][7]['cells'][31]=123.25
expected_page=pages(expected)[1];actual_page=pages(actual)[1]
assert len(expected_page)==len(actual_page)==12288
assert actual_page==expected_page
assert xml.find(tag('versionInfo')).get('signature')=='ESP32ECU DEV 012 INHIBITED'
assert len(constants)==222 and 'baseRevision'not in constants
assert import_msq(body,base_revision=17)['revision']==17
assert import_msq(body)['revision']==1
original=pages(base)[1]
result=dict(passed=True,signature=xml.find(tag('versionInfo')).get('signature'),
 saved_constants=len(constants),materialized_constants=223,base_revision_constant_omitted=True,
 explicit_caller_origin_revision=base['revision'],caller_origin17_preserved=True,
 import_without_origin_placeholder=1,page_bytes=len(actual_page),
 expected_page_sha256=hashlib.sha256(expected_page).hexdigest(),
 actual_page_sha256=hashlib.sha256(actual_page).hexdigest(),unedited_bytes_preserved=True,
 intended_edits=dict(c8_spark_deg=3.75,c8_fuel_cell_index=31,c8_fuel_cell_value=123.25),
 changed_bytes_from_original=[i for i in range(12288) if actual_page[i]!=original[i]],
 output_sha256=hashlib.sha256(body).hexdigest())
(OUT/'ts-validation.json').write_text(json.dumps(result,indent=2)+'\n')

logs=[]
for name,columns,expected_rows in [('coherent.msl',265,128),('direct.msl',245,200)]:
 lines=(OUT/'fixtures'/name).read_text().splitlines();names=lines[2].split('\t');units=lines[3].split('\t')
 assert len(names)==len(set(names))==len(units)==columns
 rows=[]
 for line in lines[4:]:
  values=line.split('\t');assert len(values)==columns
  rows.append(dict(zip(names,values)))
 assert len(rows)==expected_rows
 stats={}
 for key in ['C8PW','C8FuelTrim','CylinderCount','WorkerCylinderCount','VirtualMask','PhysicalCommandMask','FittedInjectorCommands','FittedCoilCommands','Lambda']:
  values=[float(row[key]) for row in rows]
  finite=[v for v in values if math.isfinite(v)]
  stats[key]=dict(finite_count=len(finite),unavailable_count=len(values)-len(finite),min=min(finite),max=max(finite),last=finite[-1])
 assert stats['CylinderCount']['min']==stats['CylinderCount']['max']==8
 assert stats['WorkerCylinderCount']['min']==0 and stats['WorkerCylinderCount']['max']==8
 assert stats['PhysicalCommandMask']['min']==stats['PhysicalCommandMask']['max']==0
 assert stats['VirtualMask']['max']==131072
 for key in ('FittedInjectorCommands','FittedCoilCommands'):assert stats[key]['min']==stats[key]['max']==4
 # Manually read from actual application screenshots, not synthesized from a log.
 gui=dict(C8PW=dict(min=1.958,max=6.383,last=1.958),C8FuelTrim=dict(min=100.399,max=102.534,last=100.453),
  CylinderCount=dict(min=8,max=8,last=8),WorkerCylinderCount=dict(min=0,max=8,last=8),
  VirtualMask=dict(min=0,max=131072,last=0),PhysicalCommandMask=dict(min=0,max=0,last=0),
  FittedInjectorCommands=dict(min=4,max=4,last=4),FittedCoilCommands=dict(min=4,max=4,last=4))
 for key,displayed in gui.items():
  for part,value in displayed.items():assert abs(stats[key][part]-value)<=.00051,(name,key,part,stats[key][part],value)
 logs.append(dict(file=name,format=lines[0],columns=columns,rows=len(rows),raw_stats=stats,
  actual_gui_displayed=gui,gui_matches_raw_to_three_decimals=True,
  screenshot='mlv-coherent-final/03-final-painted.png' if name=='coherent.msl' else 'mlv-direct/02-eight-cylinder-channels.png'))
(OUT/'log-validation.json').write_text(json.dumps(dict(passed=True,logs=logs),indent=2)+'\n')
print(json.dumps(dict(passed=True,ts_page_bytes=12288,ts_materialized_constants=223,log_formats=[(item['columns'],item['rows']) for item in logs])))
