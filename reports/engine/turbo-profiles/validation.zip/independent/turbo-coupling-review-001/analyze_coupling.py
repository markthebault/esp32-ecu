"""Independent saved-artifact checks for the scoped turbo controller coupling review."""
from pathlib import Path
import collections,hashlib,json,os,sys
ROOT=Path.cwd();sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools'))
from engine_geometry import EngineGeometry
OUT=ROOT/'.cache/engine/turbo-coupling-review-001'

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def lines(path):return [json.loads(line) for line in Path(path).read_text().splitlines()]
def check_run(path):
 path=Path(path).resolve();r=json.loads((path/'result.json').read_text());p=json.loads((path/'progress.json').read_text());m=json.loads((path/'provenance/manifest.json').read_text());t=json.loads((path/'tune.json').read_text());edges=lines(path/'edges.jsonl');captures=lines(path/'trigger-stimuli.jsonl');traces=lines(path/'trace.jsonl')
 assert r['completed'] and p['status']=='complete' and p['complete']
 assert r['provenance_manifest_sha256']==digest(path/'provenance/manifest.json')
 assert m['requested_tune_sha256']==digest(path/'tune.json')
 for name,value in m['source_hashes'].items():assert digest(path/'provenance/sources'/name)==value,(path,name)
 assert m['own_runtime']['binary_sha256']==m['own_runtime']['freshly_rebuilt_sha256']==digest(path/'provenance/libtarget_engine.so')
 g=EngineGeometry.from_tune(t);summary=r['plant_geometry'];assert summary==g.summary()
 assert r['strategy']==t['strategy']
 air=r['plant_air_parameters'];assert air['cylinders']==g.cylinders and air['displacement_m3']==air['graph_displacement_m3']==g.displacement_m3
 layout_present='config/engine-profile.json'in m['source_hashes']
 if layout_present:
  layout=json.loads((path/'provenance/sources/config/engine-profile.json').read_text())
  assert m['loaded_engine_profile_layout']==layout
  assert tuple(layout['injector_channels'][:g.cylinders])==g.injector_channels
  assert tuple(layout['coil_channels'][:g.cylinders])==g.coil_channels
 allowed=set(g.injector_channels+g.coil_channels+(9,));high=[False]*len(r['before_halt']['high']);hist=collections.Counter();cuts=[];last_time=0
 assert len(high)==18
 for sequence,row in enumerate(edges,1):
  when,ch,value=row['time_us'],row['ch'],row['high'];assert row['sequence']==sequence and when>=last_time;last_time=when
  assert ch in allowed and type(value)is bool and high[ch]!=value
  high[ch]=value;hist[ch]+=1
  if row['cause']=='cut:simulation_end':cuts.append(row)
 assert all(hist[ch]>0 for ch in g.injector_channels+g.coil_channels)
 assert not any(high) and len(edges)==r['edges']==p['edges']
 crank=[row for row in captures if row.get('kind')!='cam'];cams=[row for row in captures if row.get('kind')=='cam']
 assert len([row for row in crank if row['delivered']])==r['trigger_edges']
 assert len([row for row in cams if row['delivered']])==r['cam_edges']
 assert all(crank[i]['time_us']<crank[i+1]['time_us'] and crank[i]['tooth_angle_deg']<crank[i+1]['tooth_angle_deg'] for i in range(len(crank)-1))
 for row in crank:
  assert row['slot']==round(row['tooth_angle_deg']/6)%60 and row['slot']not in (58,59)
 assert all(captures[i]['time_us']<=captures[i+1]['time_us'] for i in range(len(captures)-1))
 for index,row in enumerate(captures):
  if row.get('kind')=='cam':
   prior=captures[index-1];assert row['cam_angle_deg']==540.+720.*sum(s.get('kind')=='cam'for s in captures[:index])
   assert prior.get('kind')!='cam' and prior['time_us']==row['time_us'] and prior['tooth_angle_deg']==row['cam_angle_deg']
 for row in traces:
  consumed=row['edges_consumed'];assert 0<=consumed<=len(edges)
  if consumed:assert edges[consumed-1]['time_us']<=row['time_us']
  if consumed<len(edges):assert edges[consumed]['time_us']>=row['time_us']
 before=[i for i,value in enumerate(r['before_halt']['high'])if value]
 assert {row['ch']for row in cuts}==set(before)
 after=r.get('after_halt')
 if after:
  assert not any(after['high']) and not after['boost_command_high']
  assert after['edges_consumed']==len(edges)
  for name in ('injector_on','coil_on'):
   assert len(after[name])==g.cylinders and all(value is None for value in after[name])
  for field,limit in (('coupled_energy_residual_j',1e-6),('coupled_mass_residual_kg',1e-12),('heat_partition_residual_j',1e-8),('fuel_residual_mg',1e-8)):
   assert abs(after['ledger'][field])<limit
  old=r['before_halt']['cut_discharges'];new=after['cut_discharges'][len(old):]
  assert after['cut_discharges'][:len(old)]==old
  assert {row['channel']for row in new}==set(before)&set(g.coil_channels)
  chemical=after['ledger']['burned_chemical_j']-r['before_halt']['ledger']['burned_chemical_j']
  assert abs(chemical-sum(row['chemical_delta_j']for row in new))<1e-8
  for row in new:
   rise=next(e for e in reversed(edges)if e['ch']==row['channel']and e['high'])
   expected=(round(r['duration_s']*1e6)-rise['time_us'])
   assert row['energy_j']>0 and abs(row['dwell_us']-expected)<1e-6
 return dict(path=str(path.relative_to(ROOT)),completed=True,duration_s=r['duration_s'],strategy=r['strategy'],geometry=summary,output_edges=len(edges),edge_histogram=dict(hist),trigger_edges=r['trigger_edges'],cam_edges=r['cam_edges'],same_time_crank_before_cam_verified=bool(cams),simulation_end_cut_channels=before,replayed_final_high_channels=[i for i,v in enumerate(high)if v],layout_dependency_attested=layout_present,after_halt_snapshot_present=after is not None,post_halt_snapshot=after,native_binary_sha256=m['own_runtime']['binary_sha256'],run_boost_engine_sha256=m['source_hashes']['tools/run_boost_engine.py'],provenance_module_sha256=m['source_hashes']['tools/boost_engine_provenance.py'],manifest_sha256=digest(path/'provenance/manifest.json'),maximum_tooth_quantization_deg=r['maximum_tooth_quantization_deg'],before_halt_ledger_residuals={k:v for k,v in r['before_halt']['ledger'].items()if 'residual'in k},artifacts_sha256={name:digest(path/name)for name in ('tune.json','result.json','progress.json','edges.jsonl','trigger-stimuli.jsonl','trace.jsonl','provenance/manifest.json')})

paths=[OUT/'n7-semi',OUT/'n7-semi-charged-cut',ROOT/'.cache/engine/turbo-profiles-controller-001']
paths.extend(Path(arg)for arg in sys.argv[1:])
results=[check_run(path)for path in paths]
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit()or int(p.name)==os.getpid():continue
 try:args=(p/'cmdline').read_bytes().split(b'\0')
 except(OSError,PermissionError):continue
 if not any(arg.endswith(b'run_boost_engine.py')for arg in args):continue
 if any(b'turbo-coupling-review-001/'in arg and not arg.startswith(b'cat ')for arg in args):active.append(int(p.name))
assert not active,active
report=dict(scope=__doc__,runs=results,active_reviewer_run_processes=active,process_cleanup='All three independent native runner processes returned exit0; no matching reviewer run process remains.',parent_run_is_observed_artifact_not_reviewer_execution=True)
(OUT/'analysis.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(checked_runs=len(results),output_edges=sum(r['output_edges']for r in results),active_reviewer_run_processes=active,cut_channels=[r['simulation_end_cut_channels']for r in results]),indent=2))
