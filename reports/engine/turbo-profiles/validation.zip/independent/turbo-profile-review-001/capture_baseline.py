from pathlib import Path
import sys,json,math,hashlib,subprocess
ROOT=Path.cwd();sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools'))
from turbo_components import TurboComponents
from turbo_gas_path import TurboGasPath
from boost_research_plant import BoostResearchPlant
from tcsi_mdl import verify_archive
OUT=ROOT/'.cache/engine/turbo-profile-review-001'
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source':verify_archive(),'sha256':{},'components':[],'gas':[],'boost':[]}
for p in (OUT/'baseline').glob('*.py'):report['sha256'][p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
for profile in ('source','conservative'):
 c=TurboComponents(profile)
 for omega in (2000,5000,20000):
  for p in (100000,160000,250000):
   report['components'].append({'profile':profile,'omega':omega,'pressure':p,'compressor':c.compressor(100000,298.15,omega,p),'turbine':c.turbine(p,900,omega,100000),'engine_flow':c.engine_flow(p,310,100,170000,1)})
for dt,omega,heat,initial in ((.00025,0,0,0),(.00025,30,2000,0),(.000125,30,2000,0),(.00025,0,0,20000)):
 p=TurboGasPath(initial_turbo_rad_s=initial);p.sources(.3,heat_w=heat)
 for n in range(round(.01/dt)):p.step(n*dt,dt,omega,10)
 report['gas'].append({'dt':dt,'omega':omega,'heat':heat,'initial':initial,'state':p.state,'read':p.read(),'ledger':p.ledger()})
for fixture in ('starter','charged_cut','charged_fall'):
 p=BoostResearchPlant();p.rpm=1000 if fixture!='starter' else 0;p.angle=62 if fixture!='starter' else 0
 if fixture!='starter':p.charge_mg[0]=10;p.air_charge_mg[0]=147;p.edge(4,True,0)
 for n in range(12):p.integrate(n*.00025,.00025,starter=fixture=='starter')
 if fixture=='charged_cut':p.cut()
 elif fixture=='charged_fall':p.edge(4,False,.003)
 for n in range(20):p.integrate(.003+n*.00025,.00025,starter=fixture=='starter')
 report['boost'].append({'fixture':fixture,'state':p.air.state,'rpm':p.rpm,'angle':p.angle,'heat_pulses':p.heat_pulses,'combustions':p.combustions,'ledger':p.ledger()})
 p.close()
(OUT/'baseline.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'captured':str(OUT/'baseline.json'),'source_sha256':report['source']['files'],'historical_boost_physical_displacement':.0018,'baseline_case_counts':{k:len(report[k]) for k in ('components','gas','boost')}},indent=2))
