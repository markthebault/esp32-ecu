"""Independent review probes; synthetic fixtures, no engine/vehicle qualification."""
from pathlib import Path
import copy, hashlib, json, math, subprocess, sys, traceback
ROOT=Path.cwd();sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools'))
OUT=ROOT/'.cache/engine/turbo-profile-review-001'
from engine_geometry import EngineGeometry, INJECTOR_CHANNELS, COIL_CHANNELS
from turbo_components import TurboComponents
from turbo_gas_path import TurboGasPath
from boost_research_plant import BoostResearchPlant
from tcsi_graph import Model, Unsupported
from tcsi_mdl import verify_archive
rows=[]

def case(name,fn):
 try:
  details=fn();rows.append(dict(name=name,status='pass',details=details))
 except Exception as exc:
  rows.append(dict(name=name,status='fail',error=repr(exc),traceback=traceback.format_exc()))

def close(a,b,rel=2e-12,abs_tol=2e-14):
 assert math.isclose(a,b,rel_tol=rel,abs_tol=abs_tol),(a,b)

def geometry(n,cc=None):return EngineGeometry(n,tuple([1]+list(range(n,1,-1))),250.*n if cc is None else cc)

def numeric_leaves(obj,path=()):
 if isinstance(obj,dict):
  for key,value in obj.items():
   if key!='source':yield from numeric_leaves(value,path+(key,))
 elif isinstance(obj,(list,tuple)):
  for index,value in enumerate(obj):yield from numeric_leaves(value,path+(index,))
 elif type(obj) in (int,float,bool):yield path,obj

def value_at(obj,path):
 for key in path:obj=obj[key]
 return obj

def identical_baseline_numeric(actual,baseline):
 differences=[];count=0
 for path,old in numeric_leaves(baseline):
  count+=1
  try:new=value_at(actual,path)
  except Exception:differences.append(dict(path=path,missing=True));continue
  if new!=old:differences.append(dict(path=path,baseline=old,current=new))
 assert not differences,differences[:20]
 return count

def physical(p):
 names=('rpm','angle','tps','clt','iat','battery','map_kpa','lambda_sensor','exhaust_lambda','lambda_valid','last_exhaust_t','injector_on','coil_on','charge_mg','port_mg','wall_mg','air_charge_mg','fuel_mg','burned_mg','unburned_mg','combustions','sparks','dwell_events','spark_errors','burned_chemical_j','combustion_shaft_j','heat_j','starter_j','friction_j','load_j','cylinder_fuel_mg','cylinder_burned_mg','cylinder_scheduled_work_j','cylinder_shaft_j','cylinder_combustions','heat_pulses','heat_seen','wall_heat_j','fuel_seen_mg','pending_fuel_kg','pending_pumping_j','pumping_work_j','heat_delivered_j','maximum_exchange_delay_s','cut_discharges')
 return copy.deepcopy(dict(attributes={name:getattr(p,name) for name in names},ledger=p.ledger(),air_state=p.air.state,air_time=p.air.time,air_read=p.air.read(),idle=p.idle_valve.snapshot() if p.idle_valve is not None else None))

def rejected_unchanged(p,fn):
 before=physical(p)
 try:fn()
 except (ValueError,TypeError,RuntimeError):pass
 else:raise AssertionError('Invalid request accepted')
 assert physical(p)==before,'Rejected request partially mutated physical state'

def source_attestation():
 source=verify_archive();before=json.loads((OUT/'baseline.json').read_text())['source']
 assert source==before,(source,before)
 return source
case('attested_upstream_inputs_unchanged',source_attestation)

def total_flow():
 checks=[]
 for n in range(1,9):
  for displacement in (250.*n,2000.):
   g=geometry(n,displacement);c=TurboComponents(geometry=g)
   assert c.geometry==g
   close(c.model.parameters['TC_ENGINE.geometry.V_d'],g.displacement_m3)
   assert c.model.parameters['TC_ENGINE.geometry.n_cyl']==n
   close(c.engine_graph.env['V_d'],g.displacement_m3)
   for pim,tim,omega,pem in ((100000.,298.15,100.,100000.),(160000.,330.,200.,190000.),(90000.,300.,35.,140000.)):
    expected=.8/(9.5-1)*(9.5-(pem/pim)**(1/1.3))*omega*g.displacement_m3*pim/(4*math.pi*287.2*tim)
    actual=c.engine_flow(pim,tim,omega,pem,1.)
    close(actual,expected)
    checks.append(dict(cylinders=n,displacement_cc=displacement,flow_kg_s=actual,relative_error=(actual-expected)/expected))
 return checks
case('counts1_to8_total_displacement_flow_identity',total_flow)

def clone_isolation():
 model=Model(parameter_inputs={'toggle_vol':1});params=copy.deepcopy(model.parameters);provenance=copy.deepcopy(model.provenance)
 path=next(p for p in model.systems if p[-1]=='Engine flow');oldgraph=model.graph(path);args=(150000.,310.,200.,180000.)
 original=oldgraph.run(args,time_s=31.)[1]
 a=TurboComponents(model=model,geometry=geometry(8,4000.));first=a.engine_flow(*args,31.)
 b=TurboComponents(model=model,geometry=geometry(3,1500.));second=b.engine_flow(*args,31.)
 assert a.model is not model and b.model is not model and a.model is not b.model
 assert model.parameters==params and model.provenance==provenance
 assert oldgraph.run(args,time_s=31.)[1]==original
 assert a.engine_flow(*args,31.)==first
 close(first/original,4000/1800);close(second/original,1500/1800)
 for bad in ({'TC_ENGINE.geometry.V_d':.004},{'TC_ENGINE.geometry.n_cyl':8}):
  try:Model(parameter_inputs=bad)
  except Unsupported:pass
  else:raise AssertionError('Source external-toggle boundary broadened')
 assert any('research' in key.lower() or 'geometry' in key.lower() for key in a.provenance),a.provenance.keys()
 return dict(original_fault_flow=original,geometry8_flow=first,geometry3_flow=second,shared_model_unchanged=True)
case('explicit_geometry_clones_shared_model_and_retains_source_fault',clone_isolation)

def fixed_volumes():
 expected=dict(filter=.010,charge=.005,cooler=.005,intake=.0018,exhaust=.0025,tail=.020);checks=[]
 for n in range(1,9):
  p=TurboGasPath(geometry=geometry(n));assert p.geometry==geometry(n)
  actual={name:p.graphs[name].env['V'] for name in expected};assert actual==expected
  for name,vol in expected.items():
   mass,temp,pressure=p.thermo(p.state,name);close(pressure,100000.);close(mass,100000.*vol/(p.graphs[name].env['R']*298.15))
  p.sources(.3,heat_w=2000.)
  for step in range(40):p.step(step*.00025,.00025,30.,10.)
  ledger=p.ledger();assert abs(ledger['mass_residual_kg'])<1e-12;assert abs(ledger['energy_residual_j'])<1e-8
  checks.append(dict(cylinders=n,volumes_m3=actual,mass_residual_kg=ledger['mass_residual_kg'],energy_residual_j=ledger['energy_residual_j']))
 return checks
case('fixed_six_volume_assumption_and_profiled_gas_conservation',fixed_volumes)

def trapped_air():
 checks=[]
 for n in range(1,9):
  g=geometry(n);p=BoostResearchPlant(geometry=g);p.rpm=1000.
  target=n-1;tdc=g.compression_tdc_deg[target];p.angle=tdc-180.-.3
  omega=p.rpm*math.pi/30;p.integrate(0.,.00025)
  expected=p.air_state['cylinder_air_kg_s']*(4*math.pi/omega)/n*1e6
  actual=p.air_charge_mg[target];assert actual>0;close(actual,expected)
  frozen=list(p.air_charge_mg);p.tps=80.;p.integrate(.00025,.00025)
  assert p.air_charge_mg==frozen
  assert p.geometry==p.air.geometry==p.air.components.geometry==g
  checks.append(dict(cylinders=n,target=target+1,trapped_air_mg=actual,expected_mg=expected))
 return checks
case('trapped_air_uses_total_flow_times_four_stroke_period_divided_by_count',trapped_air)

def charged_pair(n,target=None):
 g=geometry(n);plants=[]
 for _ in range(2):
  p=BoostResearchPlant(geometry=g,idle_valve='normal');p.rpm=1000.
  # Account for the independently seeded initial shaft kinetic energy.
  p.starter_j=.5*p.rotor_inertia*(p.rpm*math.pi/30)**2
  p.angle=62. if target is None else g.compression_tdc_deg[target]-28.
  indices=list(range(n)) if target is None else [target]
  for index in indices:
   p.charge_mg[index]=10.;p.air_charge_mg[index]=147.;p.fuel_mg+=10.;p.cylinder_fuel_mg[index]+=10.
   p.edge(g.injector_channels[index],True,0.);p.edge(g.coil_channels[index],True,0.)
  p.edge(8,True,0.);p.edge(9,True,0.)
  for step in range(12):p.integrate(step*.00025,.00025)
  plants.append(p)
 cut,falls=plants;cut.cut()
 for channel in g.injector_channels+g.coil_channels:
  kind,index=g.actuator(channel);active=falls.injector_on if kind=='injector' else falls.coil_on
  if active[index] is not None:falls.edge(channel,False,falls.air.time)
 falls.edge(8,False,falls.air.time);falls.edge(9,False,falls.air.time)
 expected=n if target is None else 1
 assert len(cut.cut_discharges)==expected and cut.sparks==expected
 assert all(value is None for value in cut.injector_on+cut.coil_on)
 assert not cut.idle_valve.high and not cut.boost_valve.coil.high
 assert {event['channel'] for event in cut.cut_discharges}=={g.coil_channels[i] for i in (range(n) if target is None else [target])}
 assert all(event['energy_j']>.002 and event['dwell_us']==3000. for event in cut.cut_discharges)
 if target is not None:assert cut.burned_chemical_j==440.,cut.burned_chemical_j
 before=cut.sparks;cut.cut();assert cut.sparks==before
 for step in range(20):
  for p in plants:p.integrate(.003+step*.00025,.00025)
 a=physical(cut);b=physical(falls)
 a['attributes'].pop('cut_discharges');b['attributes'].pop('cut_discharges');a['ledger'].pop('global_cut_discharges');b['ledger'].pop('global_cut_discharges')
 assert a==b,'Global low differs from individual falling edges'
 ledger=cut.ledger()
 assert abs(ledger['coupled_energy_residual_j'])<1e-7,ledger['coupled_energy_residual_j']
 assert abs(ledger['coupled_mass_residual_kg'])<1e-12,ledger['coupled_mass_residual_kg']
 assert abs(ledger['heat_partition_residual_j'])<1e-9
 assert abs(ledger['fuel_residual_mg'])<1e-10
 return dict(cylinders=n,target=target,discharge_channels=sorted(event['channel'] for event in cut.cut_discharges),burned_chemical_j=cut.burned_chemical_j,coupled_energy_residual_j=ledger['coupled_energy_residual_j'],coupled_mass_residual_kg=ledger['coupled_mass_residual_kg'])
case('all_declared_channels_global_low_equals_individual_falls',lambda:[charged_pair(n) for n in range(1,9)])
case('extended_coils14_to17_each_discharge_and_schedule_heat',lambda:[charged_pair(8,index) for index in range(4,8)])

def invalid_integrations():
 p=BoostResearchPlant(geometry=geometry(8),idle_valve='normal');p.edge(8,True,0.);p.edge(9,True,0.);p.edge(17,True,0.)
 bad=[dict(t=1.,dt=.00025),dict(t=float('nan'),dt=.00025),dict(t=float('inf'),dt=.00025),dict(t=False,dt=.00025),dict(t=0.,dt=-.1),dict(t=0.,dt=.002),dict(t=0.,dt=float('nan')),dict(t=0.,dt=float('inf')),dict(t=0.,dt=True),dict(t=0.,dt=.00025,starter=1),dict(t=0.,dt=.00025,load=float('nan')),dict(t=0.,dt=.00025,load=True),dict(t=0.,dt=.00025,idle_pct=float('nan')),dict(t=0.,dt=.00025,idle_pct=101.),dict(t=0.,dt=.00025,idle_pct=True)]
 for kw in bad:rejected_unchanged(p,lambda kw=kw:p.integrate(**kw))
 # A failure after the actuator and pending inventories are touched must roll back.
 p.heat_j=p.heat_seen=1/p.EXHAUST_HEAT_FRACTION;p.wall_heat_j=p.heat_j-1;p.heat_pulses=[dict(start=0.,end=1.,rate=1.,remaining=1.)];p.pending_fuel_kg=1e-6;p.pending_pumping_j=.01
 original=p.air.rates;calls=0
 def failure(*args):
  nonlocal calls
  calls+=1
  if calls==3:raise ValueError('Independent injected third-RK-stage failure')
  return original(*args)
 p.air.rates=failure;rejected_unchanged(p,lambda:p.integrate(0.,.00025));del p.air.__dict__['rates']
 return dict(invalid_request_count=len(bad),third_rk_stage_rollback=True)
case('invalid_complete_plant_requests_and_late_RK_failure_are_atomic',invalid_integrations)

def invalid_edges():
 p=BoostResearchPlant(geometry=geometry(8),idle_valve='normal')
 calls=[]
 for channel in (4.,8.,9.,True,-1,18):calls.append(lambda channel=channel:p.edge(channel,True,0.))
 for high in (1,0,None,'true',float('nan')):calls.append(lambda high=high:p.edge(17,high,0.))
 for time in (-.001,float('nan'),float('inf'),False,1.):calls.append(lambda time=time:p.edge(17,True,time))
 calls.append(lambda:p.edge(17,True,0.,commanded_advance=float('nan')))
 for fn in calls:rejected_unchanged(p,fn)
 p.edge(17,True,0.)
 rejected_unchanged(p,lambda:p.edge(17,True,0.))
 rejected_unchanged(p,lambda:p.edge(17,False,-.001))
 return dict(invalid_edge_count=len(calls)+2)
case('invalid_edge_types_times_and_duplicate_rises_are_atomic',invalid_edges)

def invalid_gas_steps():
 p=TurboGasPath(geometry=geometry(8));before=(copy.deepcopy(p.state),p.time,copy.deepcopy(p.latest))
 bad=((float('nan'),.00025,0.,0.,0.),(float('inf'),.00025,0.,0.,0.),(False,.00025,0.,0.,0.),(0.,True,0.,0.,0.),(0.,.00025,True,0.,0.),(0.,.00025,0.,True,0.),(0.,.00025,0.,0.,True),(1.,.00025,0.,0.,0.),(0.,.002,0.,0.,0.),(0.,.00025,-1.,0.,0.))
 for args in bad:
  try:p.step(*args)
  except (ValueError,TypeError):pass
  else:raise AssertionError(('Invalid gas request accepted',args))
  assert (p.state,p.time,p.latest)==before
 return dict(invalid_request_count=len(bad))
case('invalid_gas_path_requests_are_atomic',invalid_gas_steps)

def historical():
 old=json.loads((OUT/'baseline.json').read_text());count=0
 for row in old['components']:
  c=TurboComponents(row['profile']);actual=dict(profile=row['profile'],omega=row['omega'],pressure=row['pressure'],compressor=c.compressor(100000,298.15,row['omega'],row['pressure']),turbine=c.turbine(row['pressure'],900,row['omega'],100000),engine_flow=c.engine_flow(row['pressure'],310,100,170000,1))
  count+=identical_baseline_numeric(actual,row)
 for row in old['gas']:
  p=TurboGasPath(initial_turbo_rad_s=row['initial']);p.sources(.3,heat_w=row['heat'])
  for n in range(round(.01/row['dt'])):p.step(n*row['dt'],row['dt'],row['omega'],10)
  actual=dict(row,state=p.state,read=p.read(),ledger=p.ledger());count+=identical_baseline_numeric(actual,row)
 for row in old['boost']:
  fixture=row['fixture'];p=BoostResearchPlant();p.rpm=1000 if fixture!='starter' else 0;p.angle=62 if fixture!='starter' else 0
  if fixture!='starter':p.charge_mg[0]=10;p.air_charge_mg[0]=147;p.edge(4,True,0)
  for n in range(12):p.integrate(n*.00025,.00025,starter=fixture=='starter')
  if fixture=='charged_cut':p.cut()
  elif fixture=='charged_fall':p.edge(4,False,.003)
  for n in range(20):p.integrate(.003+n*.00025,.00025,starter=fixture=='starter')
  actual=dict(fixture=fixture,state=p.air.state,rpm=p.rpm,angle=p.angle,heat_pulses=p.heat_pulses,combustions=p.combustions,ledger=p.ledger());count+=identical_baseline_numeric(actual,row)
 return dict(exact_numeric_leaves_compared=count,baseline_component_cases=len(old['components']),baseline_gas_cases=len(old['gas']),baseline_complete_cases=len(old['boost']))
case('historical_four_cylinder_numerical_preservation',historical)

def geometry_and_inactive_channels():
 count=0
 for cls in (TurboComponents,TurboGasPath,BoostResearchPlant):
  for invalid in (False,{},4,'eight'):
   try:cls(geometry=invalid)
   except (ValueError,TypeError):count+=1
   else:raise AssertionError(('Invalid geometry accepted',cls,invalid))
 for n in range(1,8):
  p=BoostResearchPlant(geometry=geometry(n))
  for channel in (p.geometry.injector_channels[-1]+100,17,13):
   rejected_unchanged(p,lambda channel=channel:p.edge(channel,True,0.))
 return dict(invalid_geometry_rejections=count,inactive_channel_rejections=21)
case('invalid_geometry_and_inactive_sparse_channels_rejected',geometry_and_inactive_channels)

def tolerated_clock_cut():
 checks=[]
 for delta in (-5e-9,5e-9):
  p=BoostResearchPlant(geometry=geometry(8));p.integrate(0.,.00025,starter=True)
  p.edge(4,True,p.air.time);accepted=True
  try:p.edge(17,True,p.air.time+delta)
  except ValueError:accepted=False
  p.cut()
  assert all(value is None for value in p.injector_on+p.coil_on)
  assert p.sparks==1+accepted
  checks.append(dict(relative_timestamp_s=delta,near_timestamp_rise_accepted=accepted,all_channels_low=True))
 return checks
case('tolerated_clock_edges_cannot_break_or_partially_apply_global_cut',tolerated_clock_cut)

result=dict(scope=__doc__,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),results=rows,passed=sum(r['status']=='pass' for r in rows),failed=sum(r['status']=='fail' for r in rows),source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in map(Path,('tools/turbo_components.py','tools/turbo_gas_path.py','tools/boost_research_plant.py','tools/engine_research_plant.py','tools/engine_geometry.py','tools/tcsi_graph.py'))})
(OUT/'probe_results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
for row in rows:print(row['status'].upper(),row['name'],row.get('error',''))
print(json.dumps(dict(passed=result['passed'],failed=result['failed'])))
sys.exit(bool(result['failed']))
