import gzip,json,sys
from pathlib import Path
sys.path.insert(0,str(Path('/home/mark/persospace/esp32-ecu/tools')))
from boost_research_plant import BoostResearchPlant

def capture():
 out={}
 for name in ('starter','charged_cut'):
  p=BoostResearchPlant();history=[]
  try:
   if name=='charged_cut':
    p.rpm=1000;p.angle=62;p.charge_mg[0]=10;p.air_charge_mg[0]=147;p.edge(4,True,0)
   for n in range(100):
    if name=='charged_cut'and n==12:p.cut()
    p.integrate(n*.00025,.00025,starter=name=='starter')
    history.append(dict(rpm=p.rpm,angle=p.angle,air=list(p.air.state),ledger=p.ledger(),
                        fuel=list(p.cylinder_fuel_mg),work=list(p.cylinder_shaft_j),sparks=p.spark_errors))
   out[name]=history
  finally:p.close()
 return out

if __name__=='__main__':
 out=Path(sys.argv[1]);data=capture()
 with out.open('xb')as f:f.write(gzip.compress(json.dumps(data,sort_keys=True,separators=(',',':'),allow_nan=False).encode(),mtime=0))
 print('captured',sum(len(v)for v in data.values()),'states')
