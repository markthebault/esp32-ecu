#include "source-final-001/tools/engine_observability_bridge.cpp"
#include <iostream>
#include <fstream>
using namespace ecu;
static unsigned checks=0;
static void check(bool good,const char*why){++checks;if(!good){std::cerr<<"FAIL "<<why<<"\n";std::exit(1);}}
static std::string print(cJSON*j){char*text=cJSON_PrintUnformatted(j);check(text,"JSON print");std::string out=text;cJSON_free(text);return out;}
static engine::RuntimeSample fixture(double map,boost::Mode mode){
 engine::Tune t;t.injector_cc_min=1500;t.afterstart_pct=0;t.dfco_enabled=false;t.boost_control.pressure_enabled=true;t.boost_control.mode=mode;t.boost_control.kp=10;t.boost_control.ki=t.boost_control.kd=0;t.boost_control.open_duty.cells.fill(40);
 engine::Inputs in;in.rpm=2000;in.map_kpa=map;in.tps_pct=50;in.clt_c=85;in.iat_c=25;in.battery_v=14;in.sensor_v=5;in.synced=in.phase_synced=in.sensors_valid=true;
 engine::Controller c;auto out=c.step(t,in,0);return engine::synthetic_data(t,in,out,1,0);
}
int main(){
 for(auto mode:{boost::Mode::Off,boost::Mode::OpenLoop,boost::Mode::ClosedLoop})for(double map:{100.,150.,220.,230.,401.}){
  auto original=fixture(map,mode);check(boost::valid_record(original.boost_control),"actual controller record valid");auto*j=engine::data_json(original,0);check(j,"coherent JSON serializes");check(cJSON_GetObjectItemCaseSensitive(j,"schema_version")->valueint==2,"coherent schema2");engine::RuntimeSample parsed;check(sample(print(j).c_str(),parsed),"actual coherent schema2 parses");check(parsed.boost_control.available&&parsed.boost_control.mode==unsigned(mode),"typed boost record retained");check(parsed.boost_control.counters==original.boost_control.counters&&parsed.boost_control.flags==original.boost_control.flags,"record flags/counters retained");check(parsed.boost_control.values[0]==original.boost_control.values[0]&&parsed.boost_control.values[1]==original.boost_control.values[1],"duty/raw demand retained");
  const bool known=map<=300;check(bool(original.input_valid&(1<<engine::MapKpa))==known,"MAP display follows confirmed pressure ceiling");
  cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"schema_version"),1);cJSON_DeleteItemFromObjectCaseSensitive(j,"boost_control");check(sample(print(j).c_str(),parsed),"legacy coherent schema1 parses");check(!parsed.boost_control.available&&!parsed.boost_control.pressure_enabled&&!parsed.boost_control.mode,"legacy boost stays unavailable");cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"schema_version"),2);check(!sample(print(j).c_str(),parsed),"schema2 missing boost rejected");cJSON_Delete(j);
 }
 auto base=fixture(100,boost::Mode::ClosedLoop);auto*j=boost::record_json(base.boost_control);boost::Record parsed;check(boost::parse_record(j,parsed,true),"boost record fixture");
 auto*pid=cJSON_GetObjectItemCaseSensitive(j,"pid_updates");cJSON_SetValuestring(pid,"18446744073709551615");check(boost::parse_record(j,parsed,true)&&parsed.counters[0]==UINT64_MAX,"full-width counter preserves decimal precision");cJSON_SetValuestring(pid,"18446744073709551616");check(!boost::parse_record(j,parsed,true),"counter overflow rejected");cJSON_SetValuestring(pid,"-1");check(!boost::parse_record(j,parsed,true),"negative counter rejected");cJSON_SetValuestring(pid,"0");
 auto*reason=cJSON_GetObjectItemCaseSensitive(j,"reason");cJSON_SetValuestring(reason,"disabled");check(!boost::parse_record(j,parsed,true),"reason code/text mismatch rejected");cJSON_SetValuestring(reason,"ready");
 auto*duty=cJSON_GetObjectItemCaseSensitive(j,"duty_pct");cJSON_SetNumberValue(duty,101);check(!boost::parse_record(j,parsed,true),"actual duty stays bounded");cJSON_SetNumberValue(duty,0);
 auto*demand=cJSON_GetObjectItemCaseSensitive(j,"demand_pct");for(double value:{-700.,500.,double(FLT_MAX),-double(FLT_MAX)}){cJSON_SetNumberValue(demand,value);check(boost::parse_record(j,parsed,true),"all finite representable raw demand values accepted");}cJSON_SetNumberValue(demand,INFINITY);check(!boost::parse_record(j,parsed,true),"infinite raw demand rejected");cJSON_Delete(j);
 // Fixed ring wraps without dropping the boost record or its counter bits.
 engine_log::Recorder recorder;check(recorder.start(20,30,engine::DataSource::Synthetic,0),"recorder starts");
 for(unsigned n=1;n<=300;++n){auto r=base;r.sequence=n;r.control_us=r.sampled_us=(n-1)*20000ULL;r.boost_control.counters={UINT64_MAX-n,n};check(recorder.append(r,r.control_us),"append unique coherent row");}
 auto h=recorder.header();check(h.total==300&&h.retained==128&&h.overwritten==172,"128-row bounded retention");for(unsigned n=h.first_sequence();n<=h.total;++n){engine_log::Row row;check(recorder.read(h.log_id,n,row),"retained row readable");check(row.sample.boost_control.counters[0]==UINT64_MAX-n&&row.sample.boost_control.counters[1]==n,"counter bits survive ring");}
 engine_log::Page page;recorder.page(h.log_id,0,page);check(page.count==16&&page.gap_first==1&&page.gap_last==172,"bounded page discloses overwritten gap");
 char header[engine_log::text_capacity];check(engine_log::msl_header(h,header,sizeof(header),"01234567890123456789012345678901"),"MSL header fits bounded buffer");std::ofstream hf("observation-audit-header.msl");hf<<header;hf.close();engine_log::Row row;check(recorder.read(h.log_id,300,row),"last row");char line[engine_log::text_capacity];check(engine_log::msl_row(h,row,line,sizeof(line)),"MSL boost row fits bounded buffer");std::ofstream rf("observation-audit-row.msl");rf<<line;rf.close();
 std::cout<<"{\"assertions\":"<<checks<<",\"RuntimeSample_bytes\":"<<sizeof(engine::RuntimeSample)<<",\"BoostRecord_bytes\":"<<sizeof(boost::Record)<<",\"Row_bytes\":"<<sizeof(engine_log::Row)<<",\"Page_bytes\":"<<sizeof(engine_log::Page)<<",\"Recorder_bytes\":"<<sizeof(engine_log::Recorder)<<",\"Recorder_budget_bytes\":"<<100*1024<<",\"MSL_header_bytes\":"<<std::strlen(header)<<",\"MSL_row_bytes\":"<<std::strlen(line)<<",\"text_capacity\":"<<engine_log::text_capacity<<"}\n";
}
