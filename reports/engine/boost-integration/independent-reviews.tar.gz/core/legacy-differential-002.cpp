#include "ecu/engine_json.hpp"
#include <cstdio>
#include <iostream>
using namespace ecu;
static unsigned rng=0x1df7d9b3U;
static unsigned next(){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
int main(){
 unsigned total=0;
 for(unsigned profile=0;profile<96;++profile){
  engine::Tune t;t.strategy=engine::Strategy(profile%3);t.injector_cc_min=400+profile*4;t.afterstart_pct=profile%4?0:10;t.ego_enabled=profile%3==0;t.dfco_enabled=profile%2;t.idle_enabled=profile%3==1;
  t.idle_control.algorithm=idle::Algorithm(profile%3);t.cylinder_trims_enabled=t.strategy==engine::Strategy::Sequential&&profile%2;
  if(profile%4==1){t.load_model.fuel_source=load::Source::Tps;t.load_model.ve_axis=t.load_model.lambda_axis=t.load_model.trim_axis=load::Axis::TpsPercent;for(unsigned i=0;i<16;++i)t.ve.load[i]=t.lambda.load[i]=float(i)*100/15;for(auto& grid:t.cylinder_fuel)for(unsigned i=0;i<6;++i)grid.load[i]=float(i)*100/5;}
  if(profile%4==2){t.load_model.pressure=load::Pressure::MapBaro;t.load_model.fixed_baro_kpa=85;}
  if(profile%5==0){t.transient_enrichment.mode=transient::Mode::MapRate;}
  if(engine::validate(t)){std::cerr<<"invalid profile "<<profile<<": "<<engine::validate(t)<<"\n";return 2;}
  engine::Controller controller;engine::Inputs in;
  for(unsigned i=0;i<500;++i){
   in.rpm=i<10?0:i<25?250:1400+(next()%1200);in.map_kpa=25+next()%75;in.tps_pct=15+next()%40;in.clt_c=profile%2?80:40;in.iat_c=25;in.battery_v=14;in.sensor_v=5;in.lambda=1+(int(next()%31)-15)/100.;
   in.synced=in.phase_synced=true;in.sensors_valid=true;in.lambda_ready=profile%2;in.map_qualified=true;in.sampled_us=(profile*10000000ULL+i*5000ULL);
   switch(i%101){case 31:in.map_kpa=200;break;case 32:in.map_qualified=false;break;case 33:in.synced=false;break;case 34:in.phase_synced=false;break;case 35:in.sensors_valid=false;break;case 36:in.sensor_v=4;break;case 37:in.rpm=8000;break;case 38:in.clt_c=120;break;case 39:in.tps_pct=0;in.rpm=3500;break;case 40:in.sampled_us-=25000;break;}
   const auto out=controller.step(t,in,profile*10000000ULL+i*5000ULL);auto*j=engine::output_json(out);if(!j)return 3;cJSON_DeleteItemFromObjectCaseSensitive(j,"boost_control");char*text=cJSON_PrintUnformatted(j);if(!text)return 4;std::puts(text);cJSON_free(text);cJSON_Delete(j);++total;
  }
 }
 std::cerr<<total<<" legacy observations\n";
}
