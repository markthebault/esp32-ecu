#include "ecu/engine_json.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
using namespace ecu;
int main(){unsigned checks=0;auto check=[&](bool good){++checks;if(!good)std::exit(1);};std::ifstream f("source-current/config/engine/defaults-v2.json");std::ostringstream text;text<<f.rdbuf();auto*j=cJSON_Parse(text.str().c_str());check(j);cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"schema_version"),1);cJSON_SetValuestring(cJSON_GetObjectItemCaseSensitive(j,"strategy"),"batch_wasted_4cyl");cJSON_DeleteItemFromObjectCaseSensitive(j,"timing");auto*body=cJSON_PrintUnformatted(j);check(body);engine::Tune t;std::string canonical;check(engine::canonical_tune(body,t,canonical));check(t.strategy==engine::Strategy::BatchWasted&&!t.boost_control.pressure_enabled&&t.boost_control.mode==boost::Mode::Off);auto*upgraded=cJSON_Parse(canonical.c_str());check(upgraded&&cJSON_GetObjectItemCaseSensitive(upgraded,"schema_version")->valueint==10);cJSON_Delete(upgraded);cJSON_free(body);cJSON_Delete(j);std::cout<<"{\"assertions\":"<<checks<<",\"fixture\":\"authored schema1 from retained schema2 default, batch strategy and timing removed\"}\n";}
