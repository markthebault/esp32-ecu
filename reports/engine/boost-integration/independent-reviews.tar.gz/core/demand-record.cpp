#include "ecu/engine_data_json.hpp"
#include <iostream>
using namespace ecu;
int main(){
 unsigned invalid=0;
 for(double map:{100.,150.,220.}){
  engine::Tune t;t.injector_cc_min=1500;t.afterstart_pct=0;t.dfco_enabled=false;t.boost_control.pressure_enabled=true;t.boost_control.mode=boost::Mode::ClosedLoop;t.boost_control.kp=10;t.boost_control.ki=t.boost_control.kd=0;
  engine::Inputs in;in.rpm=2000;in.map_kpa=map;in.tps_pct=50;in.clt_c=85;in.iat_c=25;in.battery_v=14;in.sensor_v=5;in.synced=in.phase_synced=in.sensors_valid=true;
  engine::Controller c;auto out=c.step(t,in,0);auto sample=engine::synthetic_data(t,in,out,1,0);auto& r=sample.boost_control;
  auto*j=boost::record_json(r);boost::Record parsed;const bool valid=boost::valid_record(r),round_trip=j&&boost::parse_record(j,parsed,true);
  std::cout<<"{\"map_kpa\":"<<map<<",\"faults\":"<<out.faults<<",\"duty\":"<<out.boost_control.duty_pct<<",\"demand\":"<<out.boost_control.demand_pct<<",\"flags\":"<<out.boost_control.flags<<",\"record_valid\":"<<(valid?"true":"false")<<",\"round_trip\":"<<(round_trip?"true":"false")<<"}\n";
  if(!valid||!round_trip)++invalid;cJSON_Delete(j);
 }
 return invalid?1:0;
}
