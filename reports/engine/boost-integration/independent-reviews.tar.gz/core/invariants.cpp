#include "ecu/engine_json.hpp"
#include "ecu/engine_data.hpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
using namespace ecu;
unsigned checks=0;
void check(bool value,const char*message){++checks;if(!value){std::cerr<<"FAIL "<<message<<"\n";std::exit(1);}}
engine::Inputs fresh(){engine::Inputs in;in.rpm=2000;in.map_kpa=150;in.tps_pct=50;in.clt_c=85;in.iat_c=25;in.battery_v=14;in.sensor_v=5;in.synced=in.phase_synced=in.sensors_valid=true;return in;}
engine::Tune tune(){engine::Tune t;t.injector_cc_min=1500;t.afterstart_pct=0;t.dfco_enabled=false;t.boost_control.pressure_enabled=true;t.boost_control.mode=boost::Mode::OpenLoop;t.boost_control.open_duty.cells.fill(40);return t;}
std::string read(const std::string&path){std::ifstream file(path);std::ostringstream out;out<<file.rdbuf();return out.str();}
int main(){
 for(auto strategy:{engine::Strategy::BatchWasted,engine::Strategy::Sequential,engine::Strategy::SemiSequential}){
  for(unsigned fault=0;fault<7;++fault){
   auto t=tune();t.strategy=strategy;auto in=fresh();engine::Controller c;std::uint64_t now=0;
   auto step=[&](){in.sampled_us=now;auto out=c.step(t,in,now);now+=5000;return out;};
   for(unsigned n=0;n<10;++n){auto out=step();check(!out.faults,"boosted operating baseline");check(!out.fuel_cut&&!out.spark_cut,"boosted proposal baseline");}
   in.map_kpa=401;
   switch(fault){case 1:in.synced=false;break;case 2:in.phase_synced=false;break;case 3:in.sensors_valid=false;break;case 4:in.battery_v=6;break;case 5:in.clt_c=120;break;case 6:in.rpm=9000;break;}
   auto out=step();check(out.faults&engine::Overboost,"above envelope pressure witness preserves latch despite concurrent fault");check(out.boost_control.overboost_events==1,"one overboost event per latch");check(out.fuel_cut&&out.spark_cut&&out.pulse_ms==0&&out.dwell_ms==0&&!out.pump&&!out.cylinder_data,"all scheduling proposals inhibited");check(out.boost_control.duty_pct==0,"fault closes boost proposal");
   in=fresh();in.map_kpa=215;
   for(unsigned n=0;n<80;++n){out=step();check(out.faults&engine::Overboost,"hysteresis dead band must retain latch");}
   in.map_kpa=200;
   for(unsigned n=0;n<49;++n){out=step();check(out.faults&engine::Overboost,"insufficient recovery observations");}
   // A stale interval during recovery invalidates that release history.
   in.sampled_us=now-25000;out=c.step(t,in,now);now+=5000;check(out.faults&engine::Overboost,"stale recovery retains latch");
   for(unsigned n=0;n<50;++n){out=step();check(out.faults&engine::Overboost,"stale interruption restarts recovery");}
   out=step();check(!out.faults&&!out.fuel_cut&&!out.spark_cut,"qualified continuous recovery releases latch");check(out.boost_control.overboost_events==1,"event counter retained on recovery");
   in.map_kpa=220;out=step();check(!out.faults,"cut boundary is greater-than, not greater-or-equal");in.map_kpa=220.00001;out=step();check(out.faults&engine::Overboost,"strictly above cut triggers");check(out.boost_control.overboost_events==2,"new excursion increments count");
  }
 }
 // Same limits apply to every physical MAP table and its declared source.
 auto t=tune();for(auto*grid:{&t.ve,&t.spark,&t.lambda,&t.secondary_ve,&t.secondary_spark})for(unsigned i=0;i<16;++i)grid->load[i]=10+i*290.f/15;
 for(auto&grid:t.cylinder_fuel)for(unsigned i=0;i<6;++i)grid.load[i]=10+i*290.f/5;
 check(!engine::validate(t),"boost axes up to configured ceiling supported");t.boost_control.pressure_enabled=false;t.boost_control.mode=boost::Mode::Off;check(engine::validate(t),"same axes rejected in NA context");
 // New defaults and every retained JSON identity must migrate to a disabled actuator.
 for(unsigned schema=1;schema<=9;++schema){const auto path=std::string("source-current/config/engine/defaults-v")+std::to_string(schema)+".json";auto text=read(path);if(text.empty())continue;engine::Tune parsed;std::string canonical;check(engine::canonical_tune(text.c_str(),parsed,canonical),"legacy canonical parse");check(!parsed.boost_control.pressure_enabled&&parsed.boost_control.mode==boost::Mode::Off,"legacy does not authorize boost");auto*j=cJSON_Parse(canonical.c_str());check(j&&cJSON_GetObjectItemCaseSensitive(j,"schema_version")->valueint==10,"legacy canonical schema10");cJSON_Delete(j);}
 auto body=read("source-current/config/engine/defaults.json");auto*j=cJSON_Parse(body.c_str());check(j,"current fixture exists");engine::Tune parsed;check(engine::parse_tune(j,parsed),"new schema round trip");auto*b=cJSON_GetObjectItemCaseSensitive(j,"boost_control");cJSON_AddNumberToObject(b,"unexpected",1);check(!engine::parse_tune(j,parsed),"boost unknown key rejected");cJSON_DeleteItemFromObject(b,"unexpected");auto*p=cJSON_GetObjectItemCaseSensitive(b,"pressure_enabled");p->type=cJSON_Number;p->valuedouble=1;check(!engine::parse_tune(j,parsed),"numeric boolean rejected");p->type=cJSON_False;auto*m=cJSON_GetObjectItemCaseSensitive(b,"mode");cJSON_SetValuestring(m,"future_mode");check(!engine::parse_tune(j,parsed),"unknown boost mode rejected");cJSON_SetValuestring(m,"off");auto*schema=cJSON_GetObjectItemCaseSensitive(j,"schema_version");cJSON_SetNumberValue(schema,9);check(!engine::parse_tune(j,parsed),"boost cannot hide in legacy root");cJSON_SetNumberValue(schema,10);cJSON_DeleteItemFromObject(j,"boost_control");check(!engine::parse_tune(j,parsed),"schema10 boost is mandatory");cJSON_Delete(j);
 // Identify any remaining observation ceiling gap without treating it as a controller failure.
 t=tune();auto in=fresh();engine::Controller c;auto out=c.step(t,in,0);auto sample=engine::synthetic_data(t,in,out,1,0);std::cout<<"{\"assertions\":"<<checks<<",\"boost_map_in_observation\":"<<((sample.input_valid&(1<<engine::MapKpa))?"true":"false")<<",\"physical_outputs\":\"inhibited\"}\n";
}
