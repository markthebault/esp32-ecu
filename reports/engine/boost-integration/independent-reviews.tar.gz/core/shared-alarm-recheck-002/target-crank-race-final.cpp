#include "source/firmware/main/engine_target.cpp"
#include <iostream>
namespace target=ecu::engine_target;using namespace ecu;
static unsigned checks=0;static void check(bool ok,const char*why){++checks;if(!ok){std::cerr<<"FAIL "<<why<<"\n";std::exit(1);}}
struct Finished{};
static engine::Tune tune;static engine::Controller controller;static std::uint64_t sequence=0,last_command=0;static timing::Command held;static bool injected=false,requeued=false;
static timing::Command evaluate(){auto m=target::measurement();engine::Inputs in;in.rpm=m.rpm;in.map_kpa=150;in.tps_pct=50;in.clt_c=85;in.iat_c=25;in.battery_v=14;in.sensor_v=5;in.synced=m.synced;in.phase_synced=m.phase_synced;in.sensors_valid=true;in.sampled_us=fake_now;timing::Command c;c.output=controller.step(tune,in,fake_now);c.angle=engine::angle_config(tune);c.sequence=++sequence;c.command_us=c.sampled_us=fake_now;c.tune_revision=c.sensor_revision=1;c.max_injector_high_us=15000;c.max_coil_high_us=3500;boost::prepare_pwm(c,tune);return c;}
static void advance(std::uint64_t to){unsigned alarms=0;while(target::installed_alarm!=UINT64_MAX&&target::installed_alarm<=to){check(++alarms<64,"bounded number of scheduled alarms between teeth");fake_now=target::installed_alarm;fake_gpt_callbacks.on_alarm(&fake_timer,nullptr,nullptr);}fake_now=to;}
static void scenario(){static unsigned tooth=0,ticks=0;
 check(++ticks<2500,"genuine decoder must reach running state");
 if(injected){
  if(!requeued){check(!target::measurement().synced,"authored wrong interval removes actual decoder synchronization");check(target::executor.stats().fault==timing::Cause::None,"synchronization loss itself is an immediate stop without a latched timing fault");check(!target::boost_executor.stats().active&&!target::boost_executor.stats().high,"sync loss stops active boost");check(fake_now-held.command_us<20000,"held pre-loss running command is still fresh");check(target::submit(held),"fresh pre-loss running command requeued after decoder loss");requeued=true;return;}
  check(target::executor.stats().fault==timing::Cause::None,"timing fault is not masking the independent sync gate");check(!target::boost_executor.stats().active&&!target::boost_executor.stats().high,"pre-loss running command cannot restart boost with unsynced worker");check(fake_gpio_output_writes==0,"no physical pin was allocated or driven");std::cout<<"{\"assertions\":"<<checks<<",\"decoded_rpm_before_loss\":2000,\"boost_rises_before_loss\":"<<target::boost_executor.stats().rises<<",\"held_command_age_us\":"<<(fake_now-held.command_us)<<",\"physical_pin_writes\":"<<fake_gpio_output_writes<<"}\n";throw Finished{};
 }
 if(target::measurement().synced&&target::boost_executor.stats().rises>=3&&tooth==10){
  held=evaluate();check(!held.output.faults&&held.output.state==engine::State::Running&&held.output.boost_control.flags&boost::ValveAllowed,"held command genuinely comes from healthy main controller");advance(fake_now+1000);target::Capture edge{fake_now,target::external_epoch,false};target::executor.raw_capture(fake_now);check(xQueueSendFromISR(target::captures,&edge,nullptr)==pdTRUE,"unexpected interval queued");injected=true;return;
 }
 const auto delta=tooth==0&&ticks>1?1500:500;advance(fake_now+delta);tooth=(tooth+1)%58;
 if(!last_command||fake_now-last_command>=5000){auto c=evaluate();check(target::submit(c),"actual controller heartbeat queued");last_command=fake_now;}
 target::Capture edge{fake_now,target::external_epoch,false};target::executor.raw_capture(fake_now);check(xQueueSendFromISR(target::captures,&edge,nullptr)==pdTRUE,"60-2 raw capture time queued");
 if(target::measurement().synced)check(target::executor.stats().fault==timing::Cause::None,"genuine 60-2 stream has no scheduling fault");
}
int main(){tune.injector_cc_min=1500;tune.afterstart_pct=0;tune.dfco_enabled=false;tune.boost_control.pressure_enabled=true;tune.boost_control.mode=boost::Mode::OpenLoop;tune.boost_control.open_duty.cells.fill(40);check(!engine::validate(tune),"boosted development tune valid");target::captures=xQueueCreate(64,sizeof(target::Capture));target::commands=xQueueCreate(1,sizeof(target::TaggedCommand));target::started=xSemaphoreCreateBinary();target::configuration_mutex=xSemaphoreCreateMutex();target::trigger_mutex=xSemaphoreCreateMutex();fake_tick=scenario;try{target::run(nullptr);}catch(const Finished&){} }
