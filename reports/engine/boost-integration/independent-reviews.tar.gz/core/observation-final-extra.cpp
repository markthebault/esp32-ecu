#include "source-final-001/tools/engine_observability_bridge.cpp"
#include "ecu/boost_pwm_json.hpp"
#include <iostream>
using namespace ecu;
static unsigned checks=0;static void check(bool ok,const char*why){++checks;if(!ok){std::cerr<<"FAIL "<<why<<"\n";std::exit(1);}}
static int budget=-1;static unsigned live=0;static void*allocate(std::size_t bytes){if(!budget)return nullptr;if(budget>0)--budget;auto*p=std::malloc(bytes);if(p)++live;return p;}static void release(void*p){if(p){check(live>0,"owned allocation");--live;std::free(p);}}
int main(){
 engine::Tune t;t.injector_cc_min=1500;t.afterstart_pct=0;t.dfco_enabled=false;t.boost_control.pressure_enabled=true;t.boost_control.mode=boost::Mode::OpenLoop;t.secondary_tables.fuel.mode=secondary::Mode::Input;t.secondary_tables.fuel.condition=secondary::Condition::Map;t.secondary_tables.fuel.threshold=180;t.secondary_tables.fuel.debounce_ms=0;
 engine::Inputs in;in.rpm=2000;in.map_kpa=150;in.tps_pct=50;in.clt_c=85;in.iat_c=25;in.battery_v=14;in.sensor_v=5;in.synced=in.phase_synced=in.sensors_valid=true;in.table_switches[0].valid=true;in.table_switches[0].level=true;in.table_switches[0].source=secondary::InputSource::Synthetic;
 check(!engine::validate(t),"boosted Input tune valid");engine::Controller controller;auto out=controller.step(t,in,0);check(!out.faults&&out.secondary_fuel.active,"boosted Input selection healthy");auto record=engine::synthetic_data(t,in,out,1,0);auto*j=engine::data_json(record,0);check(j,"coherent JSON");auto*text=cJSON_PrintUnformatted(j);check(text,"coherent print");engine::RuntimeSample parsed;check(sample(text,parsed),"180kPa secondary threshold survives typed observation boundary");check(parsed.secondary_fuel.threshold==180,"secondary threshold retained");cJSON_free(text);
 auto*threshold=cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(cJSON_GetObjectItemCaseSensitive(j,"secondary_tables"),"fuel"),"threshold");cJSON_SetNumberValue(threshold,401);text=cJSON_PrintUnformatted(j);check(text&&!sample(text,parsed),"typed secondary threshold remains bounded at400kPa");cJSON_free(text);cJSON_Delete(j);
 boost::PwmStats stats;stats.high=true;stats.active=true;j=boost::pwm_json(stats);check(j,"boost qualification serializes");check(cJSON_IsFalse(cJSON_GetObjectItemCaseSensitive(j,"physical_policy_enabled"))&&cJSON_IsFalse(cJSON_GetObjectItemCaseSensitive(j,"physical_command_high")),"boost qualification cannot claim physical output policy");auto*q=cJSON_GetObjectItemCaseSensitive(j,"qualification");check(cJSON_IsString(q)&&std::strstr(q->valuestring,"No boost GPIO or physical valve driver"),"boost-specific virtual qualification present");cJSON_Delete(j);
 cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);bool completed=false;unsigned attempts=0;
 for(int n=0;n<512&&!completed;++n){budget=n;++attempts;auto*result=boost::pwm_json(stats);completed=result!=nullptr;cJSON_Delete(result);check(live==0,"every allocation-failure path frees complete PWM JSON tree");}
 cJSON_InitHooks(nullptr);check(completed,"allocation-failure sweep reaches success");
 std::cout<<"{\"assertions\":"<<checks<<",\"allocation_failure_positions\":"<<(attempts-1)<<",\"typed_threshold_limit_kpa\":400,\"physical_policy_enabled\":false}\n";
}
