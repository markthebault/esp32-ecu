from fractions import Fraction
from collections import Counter
import json
rows=[]
for n in range(1,9):
    phase=[Fraction(720*i,n) for i in range(n)]
    cyclic=sorted(phase)
    gaps=[(cyclic[(i+1)%n]-cyclic[i])%720 if n>1 else Fraction(720) for i in range(n)]
    assert all(x==Fraction(720,n) for x in gaps)
    modulo=Counter(x%360 for x in phase)
    expected_multiplicity=2 if n%2==0 else 1
    assert set(modulo.values())=={expected_multiplicity}
    assert len(modulo)==n//expected_multiplicity
    assert all((x+360)%720 in phase for x in phase) if n%2==0 else all((x+360)%720 not in phase for x in phase)
    inj=list(range(min(n,4)))+list(range(10,10+max(0,n-4)))
    coil=list(range(4,4+min(n,4)))+list(range(14,14+max(0,n-4)))
    assert len(set(inj+coil))==2*n and not ({8,9}&set(inj+coil))
    assert max(inj+coil)<18
    rows.append(dict(cylinders=n,exact_compression_phases=[str(x) for x in phase],sequential_spacing_deg=str(Fraction(720,n)),nonsequential_distinct_crank_phases=len(modulo),cylinders_per_crank_phase=expected_multiplicity,opposing_pairs_exist=n%2==0,injector_channel_ids=inj,coil_channel_ids=coil,engine_mask=sum(1<<x for x in inj+coil),mask_bits_required=max(inj+coil)+1))
print(json.dumps(dict(passed=True,scope="Independent rational geometry and proposed ID-namespace calculation only; no implementation or physical acceptance",rows=rows),indent=2))
