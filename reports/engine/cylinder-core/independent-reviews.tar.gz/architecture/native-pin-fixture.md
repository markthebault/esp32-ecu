# Feasible native 16-output probe

The pinned source is clean at9ff5aae44de51fdc00d3fb1c7c2bfc1f0d0b3e20. Existing build flags already include INJ_CHANNELS=8 and IGN_CHANNELS=8. The existing adapter uses4+4 observations and v0.4 pin mapping, which aliases injector6/coil4 at pin50 and leaves other extra pins unassigned. It cannot establish16 independent output edges.

A precise adapter-only injection point is immediately after unmodified setup() returns in tools/speeduino_sim.cpp, before record_edges=true, observer bindings and any benchmark clock advance. The adapter can stopFuelSchedulers()/stopIgnitionSchedulers(), closeAllInjectors()/stopAllCoilsCharging() using the previous bindings, assign all8 injector and8 coil pins through pinNumbers.setInjectorPin/CoilPin, then call real public production initializers:

```cpp
initialiseIgnitionSchedules(currentStatus, configPage2, configPage4,
                           configPage10, configPage13, pinNumbers);
initialiseFuelSchedules(currentStatus, configPage2, configPage4,
                       configPage6, configPage10, pinNumbers);
```

Restart the real scheduler timers and bind all16 observers to the new pin/port/mask identities. Both initializers rebind production IO, close outputs, reset schedules, validate configuration and compute actual angles/callbacks. Disclose this as **unmodified setup followed by explicit native-pin fixture reinitialization**, not as a physical v0.4 shield or an original before-setup mapping. Restore the requested count/layout/mode before reinitialization if the first setup fell back; then expose effective configuration and reject unannounced fallback.

Relevant production locations: init.cpp158..171 performs original mapping and initialization; init.cpp230..231 starts timers; scheduler_fuel_controller.cpp833..847 rebinds and configures fuel; scheduler_ignition_controller.cpp451..469 rebinds and configures ignition. Public declarations are in scheduler_fuel_controller.h and scheduler_ignition_controller.h. These are not UNIT_TEST entry points.

Validate unique16 pin/port/mask identities against all trigger, ADC and auxiliary uses before the first event. Retain the standard4-channel profile path exactly. Keep configPage2.injAng[4] as its RPM curve; do not extend it by cylinder count. A geometry-only probe can inspect schedules without claiming GPIO evidence. A subsequent bounded event probe should run real decoder/loop/timer paths with prescribed crank/cam timestamps and inspect every channel, phase/fallback and high-time behavior. Neither probe establishes engine-plant accuracy or physical target timing.
