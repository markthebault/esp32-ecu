#include "ecu/engine_phase.hpp"
#include <cassert>
#include <iostream>
#include <stdexcept>
using namespace ecu::engine;
unsigned checks=0;
void check(bool ok){++checks;if(!ok)throw std::runtime_error("independent core probe failed at check "+std::to_string(checks));}
ExpandedTune tune(unsigned count,Strategy strategy){
 ExpandedTune t;t.cylinders=count;t.strategy=strategy;t.firing_order.fill(0);
 for(unsigned i=0;i<count;++i)t.firing_order[i]=i+1;
 t.displacement_cc=2000;t.afterstart_pct=0;t.warmup_pct.fill(100);t.crank_pct.fill(100);
 t.deadtime_ms.fill(.9f);t.dwell_ms.fill(1);t.spark.cells.fill(10);return t;
}
Inputs sample(){Inputs in;in.rpm=1200;in.map_kpa=20;in.tps_pct=10;in.clt_c=85;in.iat_c=25;in.lambda=1;in.battery_v=14;in.sensor_v=5;in.sampled_us=1000000;in.synced=in.phase_synced=in.sensors_valid=true;return in;}
ExpandedOutput step(const ExpandedTune&t,Inputs in){Controller c;return c.step(t,in,1000000);}
void geometry(){
 unsigned permutations=0;std::uint32_t bits=0;
 for(unsigned c=0;c<8;++c){
  const auto inj=channels::injector(c),coil=channels::coil(c);
  check(inj<18&&coil<18&&inj!=channels::idle&&inj!=channels::boost&&coil!=channels::idle&&coil!=channels::boost);
  check(channels::kind(inj)==channels::Kind::Injector&&channels::kind(coil)==channels::Kind::Coil);
  check(channels::cylinder(inj)==c&&channels::cylinder(coil)==c);
  check(!(bits&(1U<<inj))&&!(bits&(1U<<coil)));bits|=(1U<<inj)|(1U<<coil);
 }
 check(bits==0x3fcffU);check(channels::injector(8)==255&&channels::coil(8)==255);
 for(unsigned n=1;n<=8;++n){auto t=tune(n,Strategy::Sequential);
  do{
   check(channels::order_valid(t.firing_order,n));auto phases=channels::compression_phases(t.firing_order,n);
   for(unsigned slot=0;slot<n;++slot)check(std::abs(phases[t.firing_order[slot]-1]*n-720.0*slot)<1e-9);
   ++permutations;
  }while(std::next_permutation(t.firing_order.begin()+1,t.firing_order.begin()+n));
 }
 check(permutations==5914);std::cout<<"geometry_permutations "<<permutations<<'\n';
}
void conservation(){
 double total_reference=0;
 for(unsigned n=1;n<=8;++n)for(auto strategy:{Strategy::BatchWasted,Strategy::SemiSequential,Strategy::Sequential}){
  auto t=tune(n,strategy);auto in=sample();const auto out=step(t,in);check(!out.faults&&out.cylinder_count==n);
  const unsigned openings=strategy==Strategy::Sequential?1:2;
  double dose=0;
  for(unsigned c=0;c<n;++c){
   const double effective=(out.pulse_for(c)-out.deadtime_ms)*openings;
   check(effective>0);dose+=effective;
  }
  if(n==1&&strategy==Strategy::BatchWasted)total_reference=dose;
  check(std::abs(dose-total_reference)<1e-10);
  if(strategy==Strategy::Sequential){
   t.cylinder_trims_enabled=true;t.cylinder_fuel[n-1].cells.fill(150);t.cylinder_spark_deg[n-1]=-3;
   auto trimmed=step(t,in);check(!trimmed.faults);
   check(std::abs((trimmed.pulse_for(n-1)-trimmed.deadtime_ms)/(out.pulse_for(n-1)-out.deadtime_ms)-1.5)<1e-12);
   check(trimmed.advance_for(n-1)==out.advance_for(n-1)-3);
   for(unsigned c=0;c+1<n;++c)check(trimmed.pulse_for(c)==out.pulse_for(c)&&trimmed.advance_for(c)==out.advance_for(c));
  }
  in=sample();in.sampled_us=979999;auto stale=step(t,in);check(stale.faults&Stale);check(stale.fuel_cut&&stale.spark_cut&&stale.pulse_ms==0);
  in=sample();in.phase_synced=false;auto phase=step(t,in);
  if(strategy==Strategy::Sequential)check((phase.faults&CamPhase)&&phase.fuel_cut&&phase.spark_cut);
  else check(!phase.faults);
 }
 std::cout<<"dose_total_effective_ms "<<total_reference<<'\n';
}
void cam_loss(){
 for(unsigned n=1;n<=8;++n){auto t=tune(n,Strategy::Sequential);ExpandedPhaseDecoder decoder({60,2,8000},angle_config(t));check(decoder.valid());
  for(unsigned tooth=0;tooth<480;++tooth){const auto us=1000000+tooth*500U;if(tooth%60<58)decoder.edge(us);if(tooth%120==90)decoder.cam(us);decoder.tick(us);}
  check(decoder.crank_synced()&&decoder.phase_synced()&&decoder.synced()&&decoder.accepted()>=2);
  const auto losses=decoder.losses();
  for(unsigned tooth=480;tooth<720;++tooth){const auto us=1000000+tooth*500U;if(tooth%60<58)decoder.edge(us);decoder.tick(us);}
  check(decoder.crank_synced()&&!decoder.phase_synced()&&!decoder.synced()&&decoder.faulted());
  check(decoder.losses()==losses+1&&decoder.reason()==ExpandedPhaseDecoder::Reason::Timeout);
 }
}
void selective_cut(){
 auto t=tune(8,Strategy::Sequential);ExpandedOutput o;o.cylinder_count=8;o.state=State::Running;o.rpm=2000;o.pulse_ms=2;o.dwell_ms=1;o.advance_deg=10;
 ExpandedAngleScheduler scheduler;std::array<bool,18> high{};std::array<std::uint64_t,18> rise{};
 bool cutting=false,expanded_was_high=false;unsigned injector_falls=0,coils_after=0;
 for(unsigned tooth=0;tooth<480;++tooth){const auto us=1000000+tooth*500U;
  while(scheduler.next_time()<=us){Edge e;check(scheduler.pop(e)&&!scheduler.event_forced_cut());check(high[e.channel]!=e.high);high[e.channel]=e.high;
   if(e.high)rise[e.channel]=e.time_us;
   const auto kind=channels::kind(e.channel);
   if(kind==channels::Kind::Injector){
    if(cutting)check(!e.high);
    if(!e.high){check(e.time_us-rise[e.channel]==2000);if(cutting)++injector_falls;}
   }
   if(cutting&&kind==channels::Kind::Coil)++coils_after;
  }
  if(!cutting&&high[channels::injector(4)]){cutting=true;expanded_was_high=true;o.fuel_cut=true;}
  if(tooth%60<58)check(scheduler.tooth(t,o,us,tooth%120,60,us,us));
 }
 check(expanded_was_high&&injector_falls>0&&coils_after>0);for(unsigned c=0;c<8;++c)check(!high[channels::injector(c)]);
}
void plans(){
 for(unsigned n=1;n<=8;++n)for(auto strategy:{Strategy::BatchWasted,Strategy::SemiSequential}){
  auto t=tune(n,strategy);auto o=step(t,sample());auto p=plan_revolution(t,o,1000000);check(p.valid&&p.count==4*n);
  o.cylinder_count=n==1?2:1;check(!plan_revolution(t,o,1000000).valid);
  o=step(t,sample());o.pulse_ms=20;check(!plan_revolution(t,o,1000000).valid);
  o=step(t,sample());o.advance_deg=NAN;check(!plan_revolution(t,o,1000000).valid);
 }
 auto t=tune(8,Strategy::SemiSequential);auto o=step(t,sample());ExpandedAngleScheduler scheduler;
 check(scheduler.tooth(t,o,1000000,0,60,1000000,1000000));
 check(!scheduler.tooth(t,o,1000500,1,36,1000500,1000500));check(scheduler.failed()&&scheduler.next_time()==UINT64_MAX);
 scheduler.reset();check(scheduler.tooth(t,o,1001000,0,36,1001000,1001000));
}
int main(){try{geometry();conservation();cam_loss();selective_cut();plans();std::cout<<"{\"passed\":true,\"checks\":"<<checks<<"}\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
