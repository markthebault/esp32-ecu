#include "ecu/engine_scheduler.hpp"
int main(){ecu::engine::AngleScheduler s;ecu::engine::ExpandedTune t;ecu::engine::ExpandedOutput o;return s.tooth(t,o,1,0,60,1,1);}
