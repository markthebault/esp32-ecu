#include "ecu/timing_executor.hpp"
int main(){ecu::timing::Command c;c.output=ecu::engine::ExpandedOutput{};}
