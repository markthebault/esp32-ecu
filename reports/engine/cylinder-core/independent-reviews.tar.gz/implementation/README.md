# Independent cylinder core review

Accepted for the internal1..8 shared-core and existing public4 boundary scope. There are no remaining findings within that scope. This is not public1..8 engine, generalized-plant, target timing, physical hardware or full-goal acceptance.

The review independently ran8 ASan/UBSan executables,53179 deep checks including5914 firing-order permutations,1296 motored cases,3 negative compile tests,3 new Python boundary tests and46 checks against an existing persisted tune. It replayed24 genuine production setup profiles after checking565 locked reference inputs and4 fixture sources. The parent's1296 output rows match the independently compiled rows exactly;7776 old/current F64 controller rows compare equal.

An unfenced8-to1 change emitted26 removed-cylinder edges before correction. The final identical sanitized reproducer rejects the change and emits zero ghost edges. The original log is retained; the later first full source snapshot already contains the first fence patch and must not be used as its pre-fix source. The first fence test also retained enabled trims in a semi-sequential fixture; that test fixture is corrected. A reviewer-only overly strict F64 dose equality was replaced with the float arithmetic's justified relative gate; the failed initial source/log are retained.

The final82-file core snapshot and separate boundary/document snapshots bind acceptance to exact sources. Final docs distinguish internal8 from public4, disclose measured0.07degree spark and2.115degree injector errors, describe reference fallback/geometry without asserting physical bugs, and retain future plant/UI/config/telemetry/target/hardware/wider-goal work. Three current target ELF hashes match author build/static-audit receipts, which are not physical tests.

The whitelist contains only source, probes, logs, receipts and assessments. Compiled executables, shared libraries, framework caches and reference vendor/dependency binaries are excluded. All reviewer child processes are terminal. No physical target, service restart, proprietary application or external message was used.
