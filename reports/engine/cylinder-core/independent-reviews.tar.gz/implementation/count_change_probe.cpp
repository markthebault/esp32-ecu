#include "ecu/engine_scheduler.hpp"
#include <iostream>
using namespace ecu::engine;
int main(){
 ExpandedTune t;t.cylinders=8;t.firing_order={1,2,3,4,5,6,7,8};
 ExpandedOutput o;o.cylinder_count=8;o.state=State::Running;o.rpm=2000;o.pulse_ms=2;o.dwell_ms=1;o.advance_deg=10;
 ExpandedAngleScheduler s;bool first=s.tooth(t,o,1000000,0,60,1000000,1000000);
 t.cylinders=1;t.firing_order={1,0,0,0,0,0,0,0};o.cylinder_count=1;
 bool change=s.tooth(t,o,1000500,1,60,1000500,1000500);
 std::cout<<"first="<<first<<" change="<<change<<" failed="<<s.failed()<<"\n";
 unsigned ghost=0;
 for(unsigned tooth=2;tooth<59;++tooth){
  const auto now=1000000+tooth*500;
  while(s.next_time()<=now){Edge e;if(!s.pop(e)||s.event_forced_cut())break;
   const auto c=channels::cylinder(e.channel);
   if(c>=1){++ghost;std::cout<<"removed_cylinder_edge "<<e.time_us<<" channel="<<e.channel<<" cylinder="<<c+1<<" high="<<e.high<<"\n";}
  }
  if(!s.tooth(t,o,now,tooth,60,now,now))break;
 }
 std::cout<<"ghost_edges="<<ghost<<"\n";
 return ghost?5:0;
}