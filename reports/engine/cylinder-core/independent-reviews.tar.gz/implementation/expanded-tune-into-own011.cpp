#include "ecu/tuning_layout.hpp"
int main(){ecu::tuning::Page p;ecu::engine::ExpandedTune t;ecu::tuning::encode_page(t,1,p);}
