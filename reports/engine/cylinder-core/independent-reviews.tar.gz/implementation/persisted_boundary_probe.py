import copy,json,tempfile
from pathlib import Path
from engine_runtime import EngineStore,EngineRuntime
from engine_protocol import pages
from engine_msq import export_msq
checks=0
with tempfile.TemporaryDirectory() as directory:
 path=Path(directory)/'tune.json';store=EngineStore(path)
 try:
  good=copy.deepcopy(store.tune);good['maps']['ve']['cells'][0]=88.25
  code,_=store.save(json.dumps(good).encode());assert code==200 and path.is_file();checks+=1
  original=copy.deepcopy(store.tune);body=path.read_bytes();page=bytes(pages(original)[1]);assert original['revision']==2
  for count in (0,1,2,3,5,6,7,8,9):
   candidate=copy.deepcopy(original);candidate['engine']['cylinders']=count;candidate['timing']['firing_order']=list(range(1,count+1))+[0]*max(0,4-count)
   code,_=store.save(json.dumps(candidate).encode());assert code==422;checks+=1
   assert store.tune==original and path.read_bytes()==body and bytes(pages(store.tune)[1])==page;checks+=1
   for operation in (EngineRuntime,export_msq,pages):
    try:operation(candidate)
    except ValueError:checks+=1
    else:raise AssertionError('nonfour profile escaped current public boundary')
 finally:store.runtime.close();store.data_recorder.close()
print(json.dumps(dict(passed=True,checks=checks,persisted_file_unchanged=True,cylinder_counts=[0,1,2,3,5,6,7,8,9])))
