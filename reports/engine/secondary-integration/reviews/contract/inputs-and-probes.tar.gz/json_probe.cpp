#include "ecu/engine_json.hpp"
#include <cassert>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
struct alignas(std::max_align_t) Allocation {std::size_t size;};
static std::size_t live=0,peak=0,count=0;
static void*tracked_malloc(std::size_t size){auto*p=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+size));if(!p)return nullptr;p->size=size;live+=size;peak=std::max(peak,live);++count;return p+1;}
static void tracked_free(void*ptr){if(!ptr)return;auto*p=static_cast<Allocation*>(ptr)-1;assert(live>=p->size);live-=p->size;std::free(p);}
int main(int argc,char**argv){
 cJSON_Hooks hooks{tracked_malloc,tracked_free};cJSON_InitHooks(&hooks);
 std::cout<<"[";
 for(int a=1;a<argc;++a){
  std::ifstream file(argv[a]);std::string body{std::istreambuf_iterator<char>(file),std::istreambuf_iterator<char>()};
  assert(ecu::web::safe_json(body.data(),body.size(),48*1024));assert(live==0);peak=count=0;
  auto*root=cJSON_ParseWithOpts(body.c_str(),nullptr,true);assert(root);
  auto*secondary=cJSON_DetachItemFromObjectCaseSensitive(root,"secondary_tables");assert(cJSON_IsObject(secondary));
  auto*schema=cJSON_GetObjectItemCaseSensitive(root,"schema_version");assert(cJSON_GetNumberValue(schema)==8);cJSON_SetNumberValue(schema,7);
  ecu::engine::Tune tune;assert(ecu::engine::parse_tune(root,tune));
  auto*fuel=cJSON_GetObjectItemCaseSensitive(secondary,"fuel"),*spark=cJSON_GetObjectItemCaseSensitive(secondary,"spark");
  assert(ecu::engine::map_parse(cJSON_GetObjectItemCaseSensitive(fuel,"map"),tune.secondary_ve));
  assert(ecu::engine::map_parse(cJSON_GetObjectItemCaseSensitive(spark,"map"),tune.secondary_spark));
  // Fixtures deliberately retain default Off/absolute Rules. This is a legal
  // C++ Tune/cell-range check, not acceptance of the future schema8 parser.
  assert(!ecu::engine::validate(tune));
  cJSON_SetNumberValue(schema,8);assert(cJSON_AddItemToObject(root,"secondary_tables",secondary));
  const auto parse_live=live;char*encoded=cJSON_PrintUnformatted(root);assert(encoded);const auto bytes=std::strlen(encoded);
  std::string path=std::string(argv[a])+".canonical";std::ofstream out(path,std::ios::binary);out.write(encoded,bytes);out.close();
  cJSON_free(encoded);cJSON_Delete(root);assert(live==0);
  if(a>1)std::cout<<",";
  std::cout<<"{\"path\":\""<<argv[a]<<"\",\"legal_cpp_tune\":true,\"input_bytes\":"<<body.size()<<",\"canonical_bytes\":"<<bytes<<",\"over_24k\":"<<(bytes>24*1024?"true":"false")<<",\"fits_48k\":"<<(bytes<=48*1024?"true":"false")<<",\"cjson_live_after_parse\":"<<parse_live<<",\"cjson_peak_parse_print\":"<<peak<<",\"allocations\":"<<count<<"}";
 }
 std::cout<<"]\n";
}
