#!/usr/bin/env python3
"""Rebuild independent contract probes from the frozen baseline, without root edits."""
import json,shutil,subprocess,uuid
from pathlib import Path
D=Path(__file__).resolve().parent
W=D/'replays'/str(uuid.uuid4());W.mkdir(parents=True)
inc=D/'baseline-source/firmware/include';cjson=D/'external-source/components/json/cJSON'
commands=[]
def run(argv,output=None):
 commands.append(argv)
 p=subprocess.run([str(v) for v in argv],check=True,capture_output=True,text=True)
 if output:(W/output).write_text(p.stdout)
 return p.stdout
run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I'+str(inc),D/'size_probe.cpp','-o',W/'size_probe'])
sizes=json.loads(run([W/'size_probe'],'native-sizes.json'))
run(['cc','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-c',cjson/'cJSON.c','-o',W/'cJSON.o'])
run(['g++','-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-pedantic','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(inc),'-I'+str(cjson),D/'json_probe.cpp',W/'cJSON.o','-o',W/'json_probe'])
fixtures=[]
for name in ('defaults.json','dense-f32.json','dense-subnormal-f32.json'):
 shutil.copyfile(D/name,W/name);fixtures.append(W/name)
json_sizes=json.loads(run([W/'json_probe',*fixtures],'json-sizes.json'))
expected=json.loads((D/'json-sizes.json').read_text())
for item,wanted in zip(json_sizes,expected):
 for k in ('legal_cpp_tune','input_bytes','canonical_bytes','over_24k','fits_48k','cjson_live_after_parse','cjson_peak_parse_print','allocations'):assert item[k]==wanted[k],(k,item[k],wanted[k])
assert sizes==json.loads((D/'native-sizes.json').read_text())
tool=Path('/home/mark/.platformio/packages/toolchain-xtensa-esp-elf/bin/xtensa-esp32s3-elf-g++');nm=tool.with_name('xtensa-esp32s3-elf-nm')
run([tool,'-std=c++17','-Os','-fno-rtti','-fno-exceptions','-I'+str(inc),'-I'+str(cjson),'-c',D/'target_size_probe.cpp','-o',W/'target_size_probe.o'])
symbols=run([nm,'-S','--size-sort',W/'target_size_probe.o'],'target-symbol-sizes.txt')
values={line.split()[-1]:int(line.split()[1],16) for line in symbols.splitlines() if len(line.split())==4 and line.split()[-1].startswith('bytes_')}
assert values['bytes_cjson']==40 and values['bytes_planned_observation']==64 and values['bytes_planned_sample']==528 and values['bytes_planned_recorder']==139352 and values['bytes_planned_session']==8272 and values['bytes_planned_reply']==648
receipt={'passed':True,'scope':'proposed_contract_against_frozen_f3b049e_not_implementation_acceptance','commands':[[str(v) for v in cmd] for cmd in commands],'native_sizes':sizes,'target_symbol_sizes':values,'json_cases':json_sizes,'compiler':run(['g++','--version']).splitlines()[0],'target_compiler':run([tool,'--version']).splitlines()[0]}
(W/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':True,'receipt':str(W/'execution.json'),'json_cases':len(json_sizes),'target_sizes_verified':True},indent=2))
