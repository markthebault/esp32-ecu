#include "ecu/engine_log.hpp"
#include "ecu/tuning_stream.hpp"
#include <iostream>
using namespace ecu;
struct PlannedObservation {
 secondary::Mode mode;secondary::Cells cells;load::Source source;secondary::Condition condition;secondary::Reason reason;secondary::InputSource input_source;
 bool available,evaluated,active,clamped,pending,input_qualified,input_level,pending_level,input_valid,input_raw,active_high;
 std::uint8_t input_channel;
 float primary,primary_corrected,secondary_value,combined,coordinate,condition_value,input_age_ms,threshold,debounce_ms;
 std::uint64_t observed_us;
};
struct PlannedSample {engine::RuntimeSample base;PlannedObservation fuel,spark;};
struct PlannedRow {PlannedSample sample;std::uint64_t recorded_us;std::uint32_t log_id,sequence;};
struct PlannedRecorder {engine_log::Header header;std::array<PlannedRow,256> rows;std::uint64_t next_due,last_observed,last_snapshot;};
struct PlannedSession {void*backend;std::array<std::uint8_t,8192>page;tuning::Stats stats;};
struct PlannedReply {std::array<std::uint8_t,641> bytes;std::size_t size;};

#include "cJSON.h"
extern "C" {
char bytes_cjson[sizeof(cJSON)];
char bytes_tune[sizeof(engine::Tune)];
char bytes_sample[sizeof(engine::RuntimeSample)];
char bytes_recorder[sizeof(engine_log::Recorder)];
char bytes_session[sizeof(tuning::Session)];
char bytes_planned_observation[sizeof(PlannedObservation)];
char bytes_planned_sample[sizeof(PlannedSample)];
char bytes_planned_row[sizeof(PlannedRow)];
char bytes_planned_recorder[sizeof(PlannedRecorder)];
char bytes_planned_session[sizeof(PlannedSession)];
char bytes_planned_reply[sizeof(PlannedReply)];
}
