import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];S=R/'.cache/engine/secondary-software-review'
load=lambda name:json.loads((D/name).read_text())
b=load('source-bindings.json');receipt=load('receipt-probe.json');assert receipt['passed']
for name,record in b['files'].items():
 data=(R/name).read_bytes();assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'],name
 assert (D/record['snapshot']).read_bytes()==data,name
old_manifest=(S/'artifact-manifest.json').read_bytes();old=json.loads(old_manifest)
assert hashlib.sha256(old_manifest).hexdigest()==b['software_review_packet']['sha256']
for name,item in old['files'].items():
 data=(S/name).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],name
software_bindings=json.loads((S/'final-source-bindings.json').read_text());deltas=[]
for name,item in software_bindings['files'].items():
 if hashlib.sha256((R/name).read_bytes()).hexdigest()!=item['sha256']:deltas.append(name)
assert deltas==['tuning/README.md'],deltas
delta=b['software_source_delta'];assert delta['old_sha256']==software_bindings['files']['tuning/README.md']['sha256']
assert delta['new_sha256']==hashlib.sha256((R/'tuning/README.md').read_bytes()).hexdigest()
unchanged=dict(verified=True,files=len(old['files']),manifest_sha256=hashlib.sha256(old_manifest).hexdigest(),software_bound_paths=len(software_bindings['files']),only_live_delta=deltas)
(D/'software-packet-after.json').write_text(json.dumps(unchanged,indent=2)+'\n')
findings=[
 dict(id='DOC-1',severity='medium',title='Load-model guide instructed current operators to use historical own008 INI',status='closed',initial='initial-sources/docs/engine-load-model.md',final='sources/docs/engine-load-model.md',resolution='The tuning section now labels the own008 layouts/application checks historical and directs current operators to the own009 INI and secondary guide before the old offsets.'),
 dict(id='DOC-2',severity='low',title='Current and historical layout/log descriptions conflicted',status='closed',initial=['initial-sources/docs/engine-observability.md','initial-sources/docs/engine-development.md','initial-sources/docs/engine-usb-tuning.md'],final=['sources/docs/engine-observability.md','sources/docs/engine-development.md','sources/docs/engine-usb-tuning.md','sources/docs/engine-feature-coverage.md'],resolution='The main observability section leads with MSL006 188/145, own009 offline acceptance and unresolved online acceptance. Own003/005/006/007 facts are explicitly historical or introduced by their increments. Development now includes the current schema8/own009 summary.'),
 dict(id='DOC-3',severity='low',title='Ethanol dependency description applied to unused condition metadata',status='closed',initial='initial-sources/docs/engine-secondary-tables.md',final='sources/docs/engine-secondary-tables.md',resolution='The guide now requires qualified ethanol for enabled Conditional ethanol rules. Other modes may retain unused condition metadata without adding that dependency, matching the reviewed requirements contract.'),
]
checks=[
 dict(name='Current operator identity/layout/log contract',result='pass',detail='Current entry points identify schema8/own009, 8192-byte page, 640-byte runtime/647-byte framed response, MSL006 188-field engine and145-field direct SIL, and schema4 compact250-byte screens. Retained prior layouts are explicitly historical.'),
 dict(name='Offline vendor claims and online limitation',result='pass',evidence='receipt-probe.json',detail='Receipt-bound TunerStudio MS Lite3.3.01 has zero recorded definition parser errors/unit warnings. Independent packing of the actual saved MSQ reproduces all8192 bytes/hash with known base revision37 supplied after the application omitted origin. Own009 online acceptance remains unverified. Three MegaLogViewer files match their recorded hashes, field counts188/145/188 and row counts120/120/2. These are synthetic native fixtures, not coupled plant acceptance.'),
 dict(name='Migrations and revision semantics',result='pass',detail='JSON1..7/own001..008 add default Off secondary data. Schema7/own008 preserve load/AFR and0..255 coefficients; older20..120 F32 bounds remain. Imports do not publish or silently rebase. Browser Save uses its loaded revision and CAS; explicit base revision and read-only origin behavior agree with the software review and actual receipt.'),
 dict(name='48KiB/128KiB capacity and startup guard',result='pass',detail='The docs describe a48KiB tune document envelope and128KiB engine_nvs at0x210000, with other offsets unchanged and a2MiB factory app. Startup blocks saves on an older layout before opening storage. Flashing, raw flash recovery, fragmentation and power-loss behavior remain unqualified; no automatic erase instruction is introduced.'),
 dict(name='Diagnostics and radio meanings',result='pass',detail='Unknown numbers remain null/NaN; raw future switch timestamps remain diagnostic strings, not a control clock. Source, validity, selection/evaluation, approximate F32 values and vendor integer/calculated-channel limits remain explicit. Every non-Off mode gates schemas1..3; schema4 carries compact mode/source/status rather than full switch health or per-cylinder execution.'),
 dict(name='Protected input and physical/plant holds',result='pass',detail='Target protected switch/ethanol producers and the J4 accessory remain missing/proposed. PAIR/RESET/cam/J16/SAFE_N roles remain reserved. The accessory has no current PCB/BOM/Gerber/case/manual implementation. New enabled-table coupled plant/Speeduino comparisons and physical target storage/heap/stack/USB/RF/timing/electrical/environment/fit qualification remain required. Outputs remain inhibited; no full feature-parity or perfectly running engine claim is introduced.'),
 dict(name='Sole post-freeze software-bound file delta',result='pass',evidence='software-readme-delta.json',detail='Exactly tuning/README.md differs from the299 frozen software input paths. Its explicit old/new SHA binding accompanies the current operator-documentation snapshot.'),
 dict(name='Original software evidence immutability',result='pass',evidence=['software-packet-before.json','software-packet-after.json'],detail='All503 portable software-review artifacts and their original manifest hash verify unchanged before/after this supplemental review.'),
]
result=dict(review='Supplemental operator-documentation review',created_utc=datetime.now(timezone.utc).isoformat(),status='complete_with_three_documentation_findings_closed',scope='Documentation and recorded application receipt consistency only; no production edits, subagents, application restarts or new engineering implementation.',remaining_medium_high_findings=[],findings=findings,checks=checks,source_bindings='source-bindings.json',receipt_probe='receipt-probe.json',software_readme_delta=delta,software_packet_unchanged=unchanged,limits=['The prior software packet is preserved. This supplement does not broaden its software/physical acceptance scope.','Vendor apps were not driven again by this reviewer; recorded files/receipts were independently checked. The receipt claims are limited to the actual offline files, not online integration.','Documentation links to the current integration report/verifier are publication entry points; this review does not certify the final evidence publication tree.','MCP23008 electrical design, target protected input producer, enabled coupled plant acceptance and all physical qualification remain separate work.'])
(D/'review.json').write_text(json.dumps(result,indent=2)+'\n')
text='''**Supplemental documentation review completed.** Three documentation findings were corrected by the owner and checked in the final bound bytes. No remaining medium or high documentation finding was found in this scope.

Eight operator documents consistently identify current schema 8/own009, the 8,192-byte page, 640-byte runtime, MSL006 188/145-field logs and compact radio schema 4. Historical definitions/counts are labelled as such. The load guide directs current operators to own009; ethanol is required only for enabled Conditional ethanol rules.

The actual TunerStudio INI/MSQ hashes match the application receipt. Independently packing its 157 constants reproduces the recorded 8,192-byte page hash with explicit base revision 37. All three MegaLogViewer files match receipt hashes, field counts and row counts. Own009 online acceptance remains unverified, and these synthetic native fixtures do not establish coupled plant acceptance.

Off migrations, preserved schema7/own008 load/AFR choices, legacy coefficient bounds, CAS/origin behavior and the 48 KiB/128 KiB storage limits agree with the reviewed software. Protected switch/ethanol acquisition, accessory hardware, enabled coupled plant comparisons and physical qualification remain explicit holds. Outputs remain inhibited.

The original 503-artifact software packet and its manifest remain unchanged. Exactly tuning/README.md differs among its 299 live bound input paths; software-readme-delta.json binds that sole post-freeze documentation change explicitly. Initial and final documentation snapshots are retained. No project files were edited by this reviewer, and no subagents or applications were started.
'''
(D/'review.md').write_text(text)
files={}
for p in sorted(D.rglob('*')):
 if p.is_file() and p.name!='artifact-manifest.json':
  data=p.read_bytes();files[str(p.relative_to(D))]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
manifest=D/'artifact-manifest.json';manifest.write_text(json.dumps(dict(review='Supplemental operator-documentation review',files=files),indent=2)+'\n')
for name,item in files.items():
 data=(D/name).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],name
print(json.dumps(dict(status=result['status'],bound_inputs=len(b['files']),findings_closed=len(findings),software_packet_unchanged=True,old_readme_sha256=delta['old_sha256'],new_readme_sha256=delta['new_sha256'],manifest_files=len(files),manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest())))
