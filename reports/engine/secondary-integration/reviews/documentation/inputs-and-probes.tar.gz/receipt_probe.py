"""Read-only receipt checks for the supplemental operator-documentation review."""
import csv,hashlib,io,json,struct,xml.etree.ElementTree as ET
from pathlib import Path
D=Path(__file__).resolve().parent;S=D/'sources/receipts'
x=json.loads((S/'application-checks.json').read_text())
assert x['passed'] and x['tunerstudio']['passed'] and x['owned_applications_closed']
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(S/'esp32-ecu-secondary.ini')==x['tunerstudio']['definition_sha256']
assert digest(S/'tunerstudio-secondary-roundtrip.msq')==x['tunerstudio']['file_sha256']
def split(value):
 result=[];start=0;depth=0;quoted=False;escape=False
 for n,c in enumerate(value):
  if c=='"' and not escape:quoted=not quoted
  if not quoted:
   if c in '[{(':depth+=1
   elif c in ']})':depth-=1
   elif c==',' and depth==0:result.append(value[start:n].strip());start=n+1
  escape=c=='\\' and not escape
 result.append(value[start:].strip());return result
constants={};section=None
for raw in (S/'esp32-ecu-secondary.ini').read_text().splitlines():
 line=raw.strip()
 if line.startswith('['):section=line
 elif section=='[Constants]' and '=' in line:
  name,value=map(str.strip,line.split('=',1));parts=split(value)
  if parts[0] in ('scalar','array','bits'):assert name not in constants;constants[name]=parts
ns={'m':'http://www.msefi.com/:msq'};root=ET.parse(S/'tunerstudio-secondary-roundtrip.msq').getroot();info=root.find('m:versionInfo',ns)
assert info.get('signature')==x['tunerstudio']['identity']=='ESP32ECU DEV 009 INHIBITED'
values={e.get('name'):(e.text or '').strip() for e in root.findall('.//m:constant',ns)}
assert 'baseRevision' not in values and x['tunerstudio']['origin_omitted_by_application']
values['baseRevision']=str(x['tunerstudio']['base_revision_supplied']);assert set(values)==set(constants)
page=bytearray(8192);used=set()
for name,parts in constants.items():
 kind,typ,offset=parts[:3];offset=int(offset);raw=values[name]
 if kind=='bits':
  lo,hi=map(int,parts[3].strip('[]').split(':'));labels=[v.strip('"') for v in parts[4:]]
  value=labels.index(raw.strip('"')) if raw.startswith('"') else int(raw)
  assert 0<=value<2**(hi-lo+1)
  for bit in range(offset*8+lo,offset*8+hi+1):assert bit not in used;used.add(bit)
  word=int.from_bytes(page[offset:offset+4],'little')|(value<<lo);page[offset:offset+4]=word.to_bytes(4,'little')
 else:
  count=1
  if kind=='array':
   for n in parts[3].strip('[]').split('x'):count*=int(n)
  numbers=list(map(float,raw.split()));assert len(numbers)==count
  fmt={'F32':'f','U32':'I','U08':'B'}[typ];body=struct.pack('<'+str(count)+fmt,*numbers) if fmt=='f' else struct.pack('<'+str(count)+fmt,*map(int,numbers))
  for bit in range(offset*8,(offset+len(body))*8):assert bit not in used;used.add(bit)
  page[offset:offset+len(body)]=body
page_sha=hashlib.sha256(page).hexdigest();assert page_sha==x['tunerstudio']['sha256']
assert x['tunerstudio']['page_bytes']==8192 and x['tunerstudio']['definition_parser_errors']==0 and x['tunerstudio']['unit_warnings']==0
rows=[]
for name,expected in x['megalogviewer']['files'].items():
 path=S/name;assert digest(path)==expected['sha256'];records=list(csv.reader(io.StringIO(path.read_text()),delimiter='\t'))
 assert len(records)-4==expected['rows'] and all(len(row)==expected['fields'] for row in records[2:]),name
 assert all(key in records[2] for key in x['megalogviewer']['plotted_fields'])
 rows.append(dict(path=name,fields=len(records[2]),rows=len(records)-4,sha256=digest(path)))
assert 'No online ECU acceptance' in x['tunerstudio']['limits']
assert 'not a coupled engine trajectory' in x['megalogviewer']['limits']
result=dict(passed=True,scope='Receipt/file/layout consistency only; vendor applications were not restarted by this reviewer.',tunerstudio=dict(identity=info.get('signature'),base_revision=int(values['baseRevision']),page_bytes=len(page),page_sha256=page_sha,constant_fields=len(constants),parser_errors=0,unit_warnings=0,online_acceptance=False),megalogviewer=rows)
(D/'receipt-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
