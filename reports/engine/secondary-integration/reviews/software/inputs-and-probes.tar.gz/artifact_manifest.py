"""Hash portable review evidence; native helpers and generated caches stay local."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
excluded=[];files={}
for p in sorted(D.rglob('*')):
 if not p.is_file():continue
 relative=p.relative_to(D)
 if str(relative)=='artifact-manifest.json':continue
 if any(part in ('.cache','__pycache__') for part in relative.parts) or p.suffix in ('.pyc','.so','.o','.dylib'):
  excluded.append(str(relative));continue
 data=p.read_bytes()
 if data.startswith(b'\x7fELF'):
  excluded.append(str(relative));continue
 files[str(relative)]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
result=dict(review='Independent secondary software integration review',files=files,excluded_local_build_artifacts=excluded,scope='Portable source, probes, results, findings and screenshots. Generated native binaries/caches are excluded; their build commands and helper hashes are in helper-builds.json.')
p=D/'artifact-manifest.json';p.write_text(json.dumps(result,indent=2)+'\n')
for name,value in files.items():
 data=(D/name).read_bytes();assert len(data)==value['bytes'] and hashlib.sha256(data).hexdigest()==value['sha256'],name
print(json.dumps(dict(files=len(files),bytes=sum(v['bytes'] for v in files.values()),manifest_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),portable_files_verified=True)))
