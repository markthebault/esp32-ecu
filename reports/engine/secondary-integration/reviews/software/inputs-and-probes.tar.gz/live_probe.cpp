#include "tools/engine_observability_bridge.cpp"
#include "ecu/tuning_live.hpp"
#include <iostream>
#include <iterator>
int main(){std::string text((std::istreambuf_iterator<char>(std::cin)),{});ecu::engine::RuntimeSample r;if(!sample(text.c_str(),r))return 2;std::array<std::uint8_t,ecu::tuning::live_bytes> block;ecu::tuning::live_block(r,r.control_us,block);std::cout.write(reinterpret_cast<const char*>(block.data()),block.size());}
