import os
import copy,json,sys,tempfile
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_runtime import EngineRuntime,EngineStore
D=Path(__file__).resolve().parent
cases=[]
def add(label,path,value):
 t=copy.deepcopy(default);v=t
 for key in path[:-1]:v=v[key]
 v[path[-1]]=value;cases.append((label,json.dumps(t,separators=(',',':'),allow_nan=False).encode(),422))
default=json.loads((R/'config/engine/defaults.json').read_text())
for kind in ('fuel','spark'):
 prefix=['secondary_tables',kind]
 for key in ('mode','source','axis','cells','condition'):
  for value in (None,0,True,'','future_selection'):add(f'{kind}-{key}-{value!r}',prefix+[key],value)
 for key in ('threshold','debounce_ms'):
  for value in (None,'20',True,-1e-50,-1,10001 if key=='threshold' else 501):add(f'{kind}-{key}-{value!r}',prefix+[key],value)
 for value in (None,True,'1',-1,.5,2,256,65536,4294967295,4294967296):add(f'{kind}-channel-{value!r}',prefix+['input_channel'],value)
 for value in (None,0,1,'true'):add(f'{kind}-polarity-{value!r}',prefix+['active_high'],value)
 for key in ('rpm','load','cells'):
  values=default['secondary_tables'][kind]['map'][key]
  for value in (None,{},values[:-1],values+[values[-1]]):add(f'{kind}-{key}-shape-{value!r}'[:120],prefix+['map',key],value)
  for value in (None,'85',True):add(f'{kind}-{key}-element-{value!r}',prefix+['map',key,0],value)
 add(f'{kind}-axis-rounds-duplicate',prefix+['map','rpm',1],80+1e-8)
 add(f'{kind}-axis-decreases',prefix+['map','load',1],9)
 add(f'{kind}-map-unknown',prefix+['map'],{**default['secondary_tables'][kind]['map'],'future':0})
 add(f'{kind}-unknown',prefix,{**default['secondary_tables'][kind],'future':0})
 add(f'{kind}-multiply-cell-meaning',prefix+['mode'],'multiply')
 add(f'{kind}-input-channel-overflow',prefix+['input_channel'],2**64)
for key,value in [('schema_version',9),('revision',0),('physical_outputs','enabled')]:add(key,[key],value)
body=json.dumps(default,separators=(',',':')).encode()
cases.append(('duplicate-secondary-mode',body.replace(b'"mode":"off"',b'"mode":"off","mode":"multiply"',1),422))
cases.append(('json-trailing',body+b'{}',422));cases.append(('json-nul',body+b'\0',422))
cases.append(('over48KiB',body+b' '*(49153-len(body)),413))
rows=[]
with tempfile.TemporaryDirectory() as directory:
 file=Path(directory)/'engine.json';file.write_bytes(body);store=EngineStore(file);before=copy.deepcopy(store.tune);raw=file.read_bytes();stamp=file.stat().st_mtime_ns
 for label,b,expected in cases:
  code,_=store.save(b);assert code==expected,(label,code)
  assert store.tune==before and store.runtime.tune==before and file.read_bytes()==raw and file.stat().st_mtime_ns==stamp,label
  rows.append(dict(label=label,status=code,bytes=len(b)))
 # The documented byte bound includes input whitespace and preserves revision.
 code,value=store.save(body+b' '*(49152-len(body)));assert code==200 and value['revision']==2
 store.runtime.close();store.data_recorder.close()
runtime=EngineRuntime(default);runtime.step(dict(rpm=2000,synced=True),1000000,use_decoder=False);before=runtime.data();input_rows=[]
valid=[dict(valid=True,level=True,observed_us='1000000'),dict(valid=False,level=False,observed_us='0')]
invalid=[('forged-target-provenance',[{**valid[0],'source':'target_protected_input'},valid[1]]),('numeric-time',[{**valid[0],'observed_us':1000000},valid[1]]),('leading-zero-time',[{**valid[0],'observed_us':'01000000'},valid[1]]),('negative-time',[{**valid[0],'observed_us':'-1'},valid[1]]),('overflow-time',[{**valid[0],'observed_us':'18446744073709551616'},valid[1]]),('float-time',[{**valid[0],'observed_us':'1.0'},valid[1]]),('boolean-valid',[{**valid[0],'valid':1},valid[1]]),('boolean-level',[{**valid[0],'level':1},valid[1]]),('missing-switch',[valid[0]]),('extra-switch',valid+[valid[0]])]
for label,switches in invalid:
 try:runtime.step(dict(rpm=2000,synced=True,table_switches=switches),1010000,use_decoder=False)
 except ValueError:pass
 else:raise AssertionError(label)
 assert runtime.data()==before,label;input_rows.append(label)
runtime.close()
result=dict(passed=True,rejected_tunes=len(rows),accepted_exactly49152_bytes=True,host_input_rejections=input_rows,rows=rows)
(D/'rejection-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
