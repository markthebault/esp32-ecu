import os
import copy, hashlib, itertools, json, subprocess
from pathlib import Path

R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve()
D=Path(__file__).resolve().parent
default=json.loads((R/'config/engine/defaults.json').read_text())
rows=[]
for strategy,source,pressure,afr,transient in itertools.product(
 ('batch_wasted_4cyl','sequential_4cyl','semi_sequential_4cyl'),
 ('map','tps','imap_emap'),('none','map_100kpa','map_baro'),
 ('off','target','measured'),('legacy_tps','off','tps_rate','map_rate')):
 t=copy.deepcopy(default);t['revision']=73;t['strategy']=strategy
 t['transient_enrichment']['mode']=transient
 c=t['load_model'];c.update(fuel_source=source,spark_source=source,pressure=pressure,afr=afr,fixed_baro_kpa=83.25,afr_delay_s=2.5)
 if source=='imap_emap':c['aux_role']='emap'
 axis={'map':'map_kpa','tps':'tps_pct','imap_emap':'imap_emap_pct'}[source]
 for key in ('ve_axis','spark_axis','lambda_axis','trim_axis'):c[key]=axis
 for name in ('ve','spark','lambda'):t['maps'][name]['load']=[10+100*i/15 if source=='map' else (100 if source=='tps' else 600)*i/15 for i in range(16)]
 for m in t['cylinder_trims']['fuel_maps']:m['load']=[10+100*i/5 if source=='map' else (100 if source=='tps' else 600)*i/5 for i in range(6)]
 # Include wider own008 coefficient endpoints, not merely the neutral default.
 t['maps']['ve']['cells'][0]=0;t['maps']['ve']['cells'][-1]=255
 body=json.dumps(t,separators=(',',':')).encode()
 outputs=[]
 for name in ('page_encoder_old','page_encoder'):
  p=subprocess.run([str(D/name)],input=body,capture_output=True)
  assert p.returncode==0,(name,p.returncode,p.stderr.decode())
  outputs.append(p.stdout)
 old,new=outputs
 assert len(old)==5376 and len(new)==8192
 assert old==new[:5376],(strategy,source,pressure,afr,transient)
 rows.append(dict(strategy=strategy,source=source,pressure=pressure,afr=afr,transient=transient,sha256=hashlib.sha256(old).hexdigest()))
 result=dict(passed=True,profiles=len(rows),prefix_bytes=5376,rows=rows)
(D/'prefix-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
