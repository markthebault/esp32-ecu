import os
import copy,hashlib,json,random,struct,subprocess,sys,tempfile,zlib
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_runtime import EngineRuntime,EngineStore
from engine_protocol import pages,decode_pages,Session
from engine_msq import export_msq,import_msq,tag
import xml.etree.ElementTree as ET
D=Path(__file__).resolve().parent;checks=0;rows=[]
def check(v):
 global checks;checks+=1;assert v
f32=lambda v:struct.unpack('<f',struct.pack('<f',v))[0]
def base():return json.loads((R/'config/engine/defaults.json').read_text())
def configure(t,kind,mode,source,cells=None):
 r=t['secondary_tables'][kind];r['mode']=mode;r['source']=source;r['axis']={'map':'map_kpa','tps':'tps_pct','imap_emap':'imap_emap_pct'}[source];r['cells']=cells or ('multiplier' if mode=='multiply' else 'adder' if mode=='add' else 'absolute')
 r.update(condition='tps_pct',threshold=f32(25.123456),debounce_ms=f32(20.123456),input_channel=0 if kind=='fuel' else 1,active_high=kind=='fuel')
 r['map']['load']=[f32((10+i*100/15) if source=='map' else (i*(100 if source=='tps' else 600)/15)) for i in range(16)]
 value=110.333333 if r['cells']=='multiplier' else 3.333333 if r['cells']=='adder' else 80.333333 if kind=='fuel' else 25.333333
 r['map']['cells']=[f32(value+((n*13)%17)/100) for n in range(256)]
 if mode!='off' and source=='imap_emap':t['load_model']['aux_role']='emap'
 return t
profiles=[]
for kind in ('fuel','spark'):
 for mode in ('off','multiply','add','conditional','input'):
  for source in ('map','tps','imap_emap'):profiles.append((kind+'-'+mode+'-'+source,configure(base(),kind,mode,source)))
for a in ('map','tps','imap_emap'):
 for b in ('map','tps','imap_emap'):profiles.append(('both-'+a+'-'+b,configure(configure(base(),'fuel','multiply',a),'spark','conditional',b)))
for kind in ('fuel','spark'):
 for cells in ('absolute','multiplier','adder'):profiles.append(('off-stored-'+kind+'-'+cells,configure(base(),kind,'off','tps',cells)))
for name,t in profiles:
 r=EngineRuntime(t);canonical=r.tune;r.close();p=pages(canonical);check(len(p[1])==8192);check(pages(decode_pages(p,canonical))==p)
 xml=export_msq(canonical);check(pages(import_msq(xml))==p);check('DEV 009' in xml)
 path=D/'fixtures'/(name+'.json');path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(canonical,separators=(',',':'))+'\n')
 result=subprocess.run([str(D/'native_probe')],input=json.dumps(canonical,separators=(',',':')),text=True,capture_output=True);check(result.returncode==0)
 native=json.loads(result.stdout);check(native['passed']);rows.append(dict(name=name,bytes=len(json.dumps(canonical,separators=(',',':'))),native=native,msq_bytes=len(xml)))
# Independent dense and subnormal F32 profiles, all five maps and all trims populated.
for label in ('dense','subnormal'):
 rng=random.Random(738);t=base()
 t['secondary_tables']['fuel'].update(mode='multiply',cells='multiplier')
 t['secondary_tables']['spark'].update(mode='add',cells='adder')
 for group,kind in [(t['maps']['ve'],'fuel'),(t['maps']['spark'],'spark'),(t['maps']['lambda'],'lambda'),(t['secondary_tables']['fuel']['map'],'fuel'),(t['secondary_tables']['spark']['map'],'spark')]:
  lo,hi=(0,255) if kind=='fuel' else (-5,40) if kind=='spark' else (.75,1.2)
  group['cells']=[f32((n+1)*2**-149) if label=='subnormal' and kind=='fuel' else f32(rng.uniform(lo,hi)) for n in range(256)]
 for m in t['cylinder_trims']['fuel_maps']:m['cells']=[f32(rng.uniform(50,150)) for _ in range(36)]
 body=json.dumps(t,separators=(',',':'));check(len(body)>24576);check(len(body)<49152)
 r=EngineRuntime(t);canonical=r.tune;r.close();xml=export_msq(canonical);check(len(xml.encode())<65536);check(pages(import_msq(xml))==pages(canonical))
 path=D/'fixtures'/(label+'.json');path.write_text(body+'\n');result=subprocess.run([str(D/'native_probe')],input=body,text=True,capture_output=True);check(result.returncode==0);rows.append(dict(name=label,bytes=len(body),native=json.loads(result.stdout),msq_bytes=len(xml)))
# Preserve each legacy file byte-for-byte during read-only migration, then save schema8 explicitly.
for schema in range(1,8):
 path=R/'config/engine'/('defaults-v2.json' if schema==1 else f'defaults-v{schema}.json');old=json.loads(path.read_text());old['schema_version']=schema;old['revision']=83
 if schema==1:old.pop('timing');old['strategy']='batch_wasted_4cyl'
 if schema==7:
  old['maps']['ve']['cells'][0]=0;old['maps']['ve']['cells'][1]=255;old['load_model'].update(afr='measured',fixed_baro_kpa=83.25,afr_delay_s=2.5)
 body=json.dumps(old,separators=(',',':')).encode()
 with tempfile.TemporaryDirectory() as directory:
  file=Path(directory)/'tune.json';file.write_bytes(body);store=EngineStore(file);check(store.storage_ok);check(file.read_bytes()==body);check(store.tune['schema_version']==8 and store.tune['revision']==83)
  check(store.tune['maps']==old['maps']);check(all(store.tune['secondary_tables'][kind]['mode']=='off' for kind in ('fuel','spark')))
  if schema==7:check(store.tune['load_model']==old['load_model'])
  code,saved=store.save(body);check(code==200 and saved['revision']==84 and json.loads(file.read_bytes())['schema_version']==8);store.runtime.close();store.data_recorder.close()
# Historical own008 supports0..255 and retains its load mode; older MSQs retain20..120.
for file in sorted((R/'tuning/examples').glob('*.msq')):
 text=file.read_bytes();t=import_msq(text);check(t['schema_version']==8)
 root=ET.fromstring(text);info=root.find(tag('versionInfo'));identity=info.get('signature')
 if '009' not in identity:check(all(t['secondary_tables'][kind]['mode']=='off' for kind in ('fuel','spark')))
 else:check(pages(import_msq(export_msq(t)))==pages(t))
 for c in root.findall('.//'+tag('constant')):
  if c.get('name')=='veTable':values=c.text.split();values[0]='0';values[1]='255';c.text=' '.join(values)
 altered=ET.tostring(root,encoding='utf-8')
 if '008' in identity or '009' in identity:check(import_msq(altered)['maps']['ve']['cells'][:2]==[0,255])
 else:
  try:import_msq(altered)
  except ValueError:check(True)
  else:check(False)
# Staging atomicity, complete rule+map update and stale-editor conflict on actual native Session.
with tempfile.TemporaryDirectory() as directory:
 store=EngineStore(Path(directory)/'tune.json');s=Session(store);original=copy.deepcopy(store.tune);oldpage=bytes(s.buffers[1])
 candidate=configure(configure(copy.deepcopy(original),'fuel','multiply','tps'),'spark','add','map');p=pages(candidate)[1]
 for start in range(0,len(p),256):chunk=p[start:start+256];check(s.command(b'M'+struct.pack('<BBHH',0,1,start,len(chunk))+chunk)==b'\0')
 check(store.tune==original);check(s.command(b'b\0\1')==b'\4');check(store.tune['revision']==2);check(pages(store.tune)[1][:268]==p[:268]);check(bytes(s.buffers[1])==bytes(p));check(s.diagnostics()['origin_revision']==1 and s.diagnostics()['base_revision']==2)
 # Whole reserved-crossing chunk is rejected, including the preceding legal byte.
 before=bytes(s.buffers[1]);check(s.command(b'M'+struct.pack('<BBHH',0,1,5447,2)+b'\x63\x01')==b'\x84');check(bytes(s.buffers[1])==before)
 # Failed late combined mode/cell-meaning validation does not activate any part.
 bad=bytearray(p);struct.pack_into('<I',bad,5388,0)
 check(s.command(b'M'+struct.pack('<BBHH',0,1,5388,4)+bad[5388:5392])==b'\0');active=copy.deepcopy(store.tune);check(s.command(b'b\0\1')==b'\x84');check(store.tune==active)
 # External editor update makes the existing staged session conflict.
 external=copy.deepcopy(active);external['settings']['pump_prime_s']=3;check(store.save(json.dumps(external).encode())[0]==200);check(s.command(b'b\0\1')==b'\x84');check(s.diagnostics()['state']=='revision_conflict')
 # Actual native framed runtime transport fits the declared640-byte block.
 payload=b'r'+struct.pack('<BBHH',0,0x30,0,640);request=struct.pack('>H',len(payload))+payload+struct.pack('>I',zlib.crc32(payload));frames=s.feed(request,2000000);check(len(frames)==1 and len(frames[0])==647);frame=frames[0];check(struct.unpack('>H',frame[:2])[0]==641);check(zlib.crc32(frame[2:-4])==struct.unpack('>I',frame[-4:])[0])
 s.close();store.runtime.close();store.data_recorder.close()
(D/'integration-probe.json').write_text(json.dumps(dict(passed=True,checks=checks,profiles=rows),indent=2)+'\n');print(json.dumps(dict(passed=True,checks=checks,profiles=len(rows),dense=[row for row in rows if row['name'] in ('dense','subnormal')])))
