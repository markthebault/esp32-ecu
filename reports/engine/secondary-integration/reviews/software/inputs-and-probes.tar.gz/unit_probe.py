import os
import asyncio, copy, hashlib, itertools, json, sys, tempfile, threading
import xml.etree.ElementTree as ET
from http.server import ThreadingHTTPServer
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from web_server import Device,Handler,load_bridge
from engine_msq import export_msq,tag
from playwright.async_api import async_playwright
D=Path(__file__).resolve().parent
AXIS={'map':('map_kpa','kPa',10,110),'tps':('tps_pct','% TPS',0,100),'imap_emap':('imap_emap_pct','% IMAP/EMAP',0,600)}
CELL={'fuel':{'absolute':'% coefficient','multiplier':'% multiplier','adder':'percentage_points'},'spark':{'absolute':'deg BTDC','multiplier':'% multiplier','adder':'deg delta'}}
COND={'rpm':'RPM','map_kpa':'kPa','tps_pct':'% TPS','ethanol_pct':'% ethanol'}
async def run(url):
 rows=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='chrome',headless=True,args=['--no-sandbox'])
  try:
   page=await browser.new_page();await page.goto(url);await page.wait_for_function("typeof engineToMsq==='function' && window.EcuSecondaryTables")
   for kind,source,cells,condition in itertools.product(('fuel','spark'),AXIS,('absolute','multiplier','adder'),COND):
    t=json.loads((R/'config/engine/defaults.json').read_text());r=t['secondary_tables'][kind]
    axis,axis_unit,lo,hi=AXIS[source];r.update(source=source,axis=axis,cells=cells,condition=condition,threshold=50)
    r['map']['load']=[lo+(hi-lo)*i/15 for i in range(16)];r['map']['cells']=[42 if kind=='fuel' or cells=='multiplier' else -2]*256
    py=export_msq(t);js=await page.evaluate('t=>engineToMsq(t)',t)
    expected={f'secondary_{kind}_mapRpm':'RPM',f'secondary_{kind}_mapLoad':axis_unit,f'secondary_{kind}_mapTable':CELL[kind][cells],f'secondary_{kind}_threshold':COND[condition],f'secondary_{kind}_debounce_ms':'ms',f'secondary_{kind}_input_channel':''}
    for text in (py,js):
     values={e.get('name'):e.get('units') for e in ET.fromstring(text).findall('.//'+tag('constant'))}
     for key,value in expected.items():assert values[key]==value,(kind,source,cells,condition,key,values[key],value)
    rows.append(dict(kind=kind,source=source,cells=cells,condition=condition,expected_units=expected,python_sha256=hashlib.sha256(py.encode()).hexdigest(),browser_sha256=hashlib.sha256(js.encode()).hexdigest()))
   ini=(R/'tuning/esp32-ecu-secondary.ini').read_text()
   for key,labels in [('secondaryAxisUnits',['kPa','% TPS','% IMAP/EMAP','INVALID']),('secondaryFuelCellUnits',list(CELL['fuel'].values())+['INVALID']),('secondarySparkCellUnits',list(CELL['spark'].values())+['INVALID']),('secondaryConditionUnits',list(COND.values()))]:
    line=next(line for line in ini.splitlines() if line.strip().startswith(key+' ='))
    for label in labels:assert '"'+label+'"' in line
   assert 'secondary_spark_mapTable = array' in ini
   line=next(line for line in ini.splitlines() if line.strip().startswith('secondary_spark_mapTable ='))
   assert '{ 0 - 5 * (secondary_spark_cells == 0) - 40 * (secondary_spark_cells == 2) }' in line
   assert '{ 40 * (secondary_spark_cells == 0) + 255 * (secondary_spark_cells == 1) + 70 * (secondary_spark_cells == 2) }' in line
  finally:await browser.close()
 report=dict(passed=True,profiles=len(rows),unit_assertions=12*len(rows),ini_unit_sets=4,rows=rows)
 (D/'unit-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
if __name__=='__main__':
 with tempfile.TemporaryDirectory() as directory,ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
  server.device=Device(Path(directory)/'profile.json',load_bridge());thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:asyncio.run(run(f'http://127.0.0.1:{server.server_address[1]}'))
  finally:server.shutdown();thread.join(2)
