#include "ecu/engine_json.hpp"
#include "tuning/archive/own008_tuning_layout.hpp"
#include <iostream>
#include <iterator>
int main(){std::string text((std::istreambuf_iterator<char>(std::cin)),{});ecu::engine::Tune t;std::string canonical;if(!ecu::engine::canonical_tune(text.c_str(),t,canonical)||!ecu::tuning::representable(t))return 2;ecu::tuning::Page p;ecu::tuning::encode_page(t,t.revision,p);std::cout.write(reinterpret_cast<const char*>(p.data()),p.size());}
