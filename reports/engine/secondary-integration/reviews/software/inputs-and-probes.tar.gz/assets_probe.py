import csv,hashlib,io,json,os,re
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();D=Path(__file__).resolve().parent
mapping={'engine_defaults':'config/engine/defaults.json','defaults':'config/defaults.json','guide':'config/interface-guide.json','index':'web/index.html','trigger_js':'web/trigger_logger.js','engine_log_js':'web/engine_logger.js','cylinder_js':'web/cylinder_tuning.js','idle_js':'web/idle_control.js','transient_js':'web/transient_enrichment.js','load_js':'web/load_model.js','secondary_js':'web/secondary_tables.js','tuning_js':'web/tuning_diagnostics.js','manual':'config/manual.json'}
text=(R/'firmware/main/web_assets.hpp').read_text();items=dict(re.findall(r'inline constexpr char (\w+)\[\]=R"ECU_ASSET\((.*?)\)ECU_ASSET";',text,re.S))
assert set(items)==set(mapping)
rows=[]
for key,name in mapping.items():
 value=(R/name).read_text();assert items[key]==value,name
 rows.append(dict(name=key,path=name,bytes=len(value.encode()),sha256=hashlib.sha256(value.encode()).hexdigest()))
partitions=[]
for row in csv.reader(io.StringIO((R/'firmware/partitions.csv').read_text())):
 if not row or row[0].startswith('#'):continue
 name,typ,sub,offset,size,*_=row;partitions.append(dict(name=name,type=typ,subtype=sub,start=int(offset,0),size=int(size,0)))
ordered=sorted(partitions,key=lambda p:p['start'])
for a,b in zip(ordered,ordered[1:]):assert a['start']+a['size']<=b['start']
p=next(p for p in partitions if p['name']=='engine_nvs');assert p==dict(name='engine_nvs',type='data',subtype='nvs',start=0x210000,size=0x20000)
result=dict(passed=True,matching_embedded_assets=len(rows),assets=rows,partitions=partitions,scope='Byte equality and static address/extent check only; the ESP HTTP/NVS/flash path is inspected but not exercised on hardware.')
(D/'assets-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('assets','partitions')}))
