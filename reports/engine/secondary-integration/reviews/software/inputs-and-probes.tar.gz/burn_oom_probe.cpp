#include "tools/tuning_bridge.cpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <iterator>
#include <vector>
static std::size_t calls=0,fail_at=0,live=0,peak=0;
struct alignas(std::max_align_t) Allocation{std::size_t n;};
static void* allocate(std::size_t n){++calls;if(fail_at&&calls==fail_at)return nullptr;auto*p=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+n));if(!p)return nullptr;p->n=n;live+=n;peak=std::max(peak,live);return p+1;}
static void release(void*v){if(!v)return;auto*p=static_cast<Allocation*>(v)-1;assert(live>=p->n);live-=p->n;std::free(p);}
struct Active{std::string body;std::uint32_t revision=1;unsigned commits=0;};
static int load_callback(void*opaque,char*out,std::size_t n){auto&a=*static_cast<Active*>(opaque);if(a.body.size()+1>n)return 5;std::memcpy(out,a.body.c_str(),a.body.size()+1);return 0;}
static int current_callback(void*opaque,std::uint32_t*out){*out=static_cast<Active*>(opaque)->revision;return 0;}
static int commit_callback(void*opaque,const char*body,std::size_t n,std::uint32_t*out){
 auto&a=*static_cast<Active*>(opaque);auto*j=cJSON_ParseWithOpts(body,nullptr,true);if(!j)return 4;ecu::engine::Tune candidate;
 if(!ecu::engine::parse_tune(j,candidate)||n>ecu::engine::tune_maximum){cJSON_Delete(j);return 5;}
 if(candidate.revision!=a.revision){cJSON_Delete(j);return 1;}
 cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(j,"revision"),a.revision+1);char*encoded=cJSON_PrintUnformatted(j);cJSON_Delete(j);if(!encoded)return 4;
 std::string next(encoded);cJSON_free(encoded);a.body.swap(next);*out=++a.revision;++a.commits;return 0;
}
static int sample_callback(void*,std::uint8_t*out,std::size_t n){std::memset(out,0,n);return 0;}
static std::size_t trial(const std::string&body,std::size_t failure,bool expect_success){
 fail_at=0;calls=0;Active a{body};Context context(&a,load_callback,current_callback,commit_callback,sample_callback);assert(context.session.stats().initialized);
 ecu::engine::Tune t;std::string canonical;assert(ecu::engine::canonical_tune(body.c_str(),t,canonical));t.secondary_tables.fuel.mode=ecu::secondary::Mode::Multiply;t.secondary_tables.fuel.cells=ecu::secondary::Cells::Multiplier;t.secondary_ve.cells.fill(110.25f);t.secondary_tables.spark.mode=ecu::secondary::Mode::Add;t.secondary_tables.spark.cells=ecu::secondary::Cells::Adder;t.secondary_spark.cells.fill(-2.125f);
 ecu::tuning::Page page;ecu::tuning::encode_page(t,1,page);
 for(unsigned start=0;start<page.size();start+=256){const unsigned count=std::min<unsigned>(256,page.size()-start);std::vector<std::uint8_t>command={'M',0,1,std::uint8_t(start),std::uint8_t(start>>8),std::uint8_t(count),std::uint8_t(count>>8)};command.insert(command.end(),page.begin()+start,page.begin()+start+count);assert(context.session.command(command.data(),command.size()).bytes[0]==0);}
 assert(context.session.staged_page()==page&&a.body==body&&a.revision==1);
 calls=0;fail_at=failure;const std::uint8_t burn[]={'b',0,1};const auto result=context.session.command(burn,3);const auto count=calls;fail_at=0;
 if(expect_success){assert(result.bytes[0]==4&&a.commits==1&&a.revision==2&&!context.session.stats().dirty&&context.session.staged_page()==page);}
 else{assert(result.bytes[0]==0x85&&a.commits==0&&a.revision==1&&a.body==body&&context.session.stats().dirty&&context.session.stats().base_revision==1&&context.session.staged_page()==page);const auto retry=context.session.command(burn,3);assert(retry.bytes[0]==4&&a.commits==1&&a.revision==2);}
 assert(live==0);return count;
}
int main(int argc,char**argv){assert(argc==2);std::ifstream input(argv[1]);std::string body((std::istreambuf_iterator<char>(input)),{});cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);
 const auto positions=trial(body,0,true);for(std::size_t n=1;n<=positions;++n)trial(body,n,false);assert(live==0);cJSON_InitHooks(nullptr);
 std::cout<<"{\"passed\":true,\"burn_allocation_failures\":"<<positions<<",\"retry_commits_once\":true,\"cjson_peak_bytes\":"<<peak<<"}\n";
}
