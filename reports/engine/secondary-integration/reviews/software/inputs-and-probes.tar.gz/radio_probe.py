import os
import copy,hmac,json,math,struct,sys
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_runtime import EngineRuntime
from engine_observability import EngineRecorder
from engine_receiver import EngineReceiver,engine_telemetry,capability_request
D=Path(__file__).resolve().parent
LMK=bytes(range(16));BOOT=bytes(range(16,32));MAC='02:EC:00:00:00:01';SESSION=0x12345678
KEY=hmac.digest(LMK,b'ECU-NOW-ENGINE-v1'+BOOT+struct.pack('<I',SESSION),'sha256');checks=0;rows=[]
def check(v):
 global checks;checks+=1;assert v
def header(kind,size):return b'ECN1'+bytes((1,kind))+struct.pack('<H',size)
def oracle(s,schema=4,seq=1,sent=5030000):
 size=232 if schema<3 else 250;b=bytearray(size);b[:8]=header(9,size)
 flags=(s['flags']&~32768)|32768;struct.pack_into('<IQHHIIII',b,8,SESSION,seq,schema,flags,12,8,s['tune_revision'],s['sensor_revision'])
 w=s['worker_observation'];struct.pack_into('<QQIIIIIf',b,40,int(s['sequence']),int(w['command_sequence']),s['phase_epoch'],w['epoch'],s['controller_faults'],s['phase_losses'],s['cam_rejected'],s['cam_error_deg'] if s['cam_error_deg'] is not None else math.nan)
 struct.pack_into('<10B',b,80,s['state_code'],s['strategy_code'],s['source_code'],s['phase_reason_code'],s['input_valid_mask'],w['timing_fault_code'],w['last_timing_fault_code'],w['virtual_high_mask'],w['physical_command_mask'],s['board_flags'])
 if schema>=4:
  for index,kind in enumerate(('fuel','spark')):
   o=s['secondary_tables'][kind]
   if o['available']:
    b[90]|=o['mode_code']<<(index*3)|int(o['active'])<<(6+index)
    b[91]|=o['source_code']<<(index*2)|1<<(4+index)|int(o['evaluated'])<<(6+index)
 struct.pack_into('<QIII',b,92,sent,w['tune_revision'],w['sensor_revision'],4294967295)
 inputs=('rpm','map_kpa','tps_pct','clt_c','iat_c','lambda','battery_v','sensor_v');proposals=('rpm','ve_pct','target_lambda','advance_deg','pulse_ms','dwell_ms','deadtime_ms','air_mg','warmup','afterstart','accel','ego','duty_pct','idle_pct')
 struct.pack_into('<8f',b,112,*[s['inputs'][key] if s['input_valid_mask']&(1<<i) else math.nan for i,key in enumerate(inputs)])
 struct.pack_into('<14f',b,144,*[s['proposals'][key] if s['proposals'][key] is not None else math.nan for key in proposals])
 if schema>=3:
  o=s['load_model'];b[200]=sum(o[key+'_source_code']<<(2*i) for i,key in enumerate(('fuel','spark','lambda','trim')))
  b[201]=o['pressure_code']|(o['baro_source_code']<<2)|(int(o['available'])<<3)|(int(o['available'] and bool(o['flags']&1))<<4)|(o['afr_code']<<5)|(int(o['available'] and bool(o['flags']&256))<<7)
  struct.pack_into('<4f',b,202,*[o[key] if o['available'] and o[key] is not None else math.nan for key in ('fuel_load','afr_factor','baro_kpa','emap_kpa')])
 end=size-32;b[end:]=hmac.digest(KEY,b[:end],'sha256');return bytes(b)
def profile(fuel,spark,fs,ss):
 t=json.loads((R/'config/engine/defaults.json').read_text())
 for kind,mode,source in (('fuel',fuel,fs),('spark',spark,ss)):
  o=t['secondary_tables'][kind];o['mode']=mode;o['cells']='multiplier' if mode=='multiply' else 'adder' if mode=='add' else 'absolute';o['source']=source;o['axis']={'map':'map_kpa','tps':'tps_pct','imap_emap':'imap_emap_pct'}[source]
  o['condition']='rpm';o['threshold']=3000;o['debounce_ms']=0
  o['map']['load']=[10+i*100/15 if source=='map' else i*(100 if source=='tps' else 600)/15 for i in range(16)];o['map']['cells']=[110 if mode=='multiply' else 3 if mode=='add' else 85 if kind=='fuel' else 25]*256
  if mode!='off' and source=='imap_emap':t['load_model']['aux_role']='emap'
 return t
def observe(t):
 r=EngineRuntime(t)
 try:r.step(dict(rpm=2000,synced=True,phase_synced=True,aux_pressure_kpa=125,aux_pressure_qualified=True,table_switches=[dict(observed_us='1000000',level=True,valid=True),dict(observed_us='1000000',level=False,valid=True)]),1000000,use_decoder=False);return r.data()
 finally:r.close()
def frame(s,schema=4,seq=1,sent=5030000):return native.frame(s,LMK,BOOT,SESSION,seq,sample_age=12,control_age=8,sent=sent,schema=schema)
def resign(b):b=bytearray(b);b[-32:]=hmac.digest(KEY,b[:-32],'sha256');return bytes(b)
def raises(fn):
 try:fn()
 except ValueError:check(True)
 else:check(False)
native=EngineRecorder()
try:
 modes=('off','multiply','add','conditional','input');sources=('map','tps','imap_emap')
 for f in modes:
  for s in modes:
   for fs in sources:
    for ss in sources:
     sample=observe(profile(f,s,fs,ss));packet=frame(sample);check(packet==oracle(sample));d=engine_telemetry(packet,KEY,4)
     for kind in ('fuel','spark'):
      o=sample['secondary_tables'][kind];got=d['secondary_tables'][kind];check(all(got[key]==o[key] for key in ('mode_code','source_code','active','available','evaluated')))
     if f!='off' or s!='off':
      for schema in (1,2,3):raises(lambda schema=schema:frame(sample,schema=schema))
     else:
      for schema in (1,2,3):check(frame(sample,schema=schema)==oracle(sample,schema))
     rows.append(dict(fuel=f,spark=s,fuel_source=fs,spark_source=ss,byte90=packet[90],byte91=packet[91]))
 # Negotiation through authenticated query and explicit4 update.
 sample=observe(profile('multiply','conditional','tps','map'));packet=frame(sample);receiver=EngineReceiver(MAC,LMK,schema=4)
 request=receiver.query(100,bytes([1])*16);reply=native.capability_reply(request,LMK,SESSION,BOOT,0,5000000);receiver.receive_reply(reply,MAC,110)
 request=receiver.update(True,120,bytes([2])*16);reply=native.capability_reply(request,LMK,SESSION,BOOT,0,5010000);check(reply==native.capability_reply(request,LMK,SESSION,BOOT,0,5010000));receiver.receive_reply(reply,MAC,125)
 for n in range(250):
  altered=bytearray(packet);altered[n]^=1;raises(lambda altered=altered:receiver.receive(bytes(altered),MAC,150));check(receiver.last_packet==0)
 receiver.receive(packet,MAC,150);check(receiver.last_packet==1);check(len(receiver.acknowledgement())==56)
 # Re-signed invalid enums and availability cannot bypass structural guards.
 mutations=[]
 for mode in (5,6,7):
  for shift in (0,3):b=bytearray(packet);b[90]=(b[90]&~(7<<shift))|(mode<<shift);mutations.append(b)
 for shift in (0,2):b=bytearray(packet);b[91]=(b[91]&~(3<<shift))|(3<<shift);mutations.append(b)
 for bit in (4,5):b=bytearray(packet);b[91]&=~(1<<bit);mutations.append(b)
 b=bytearray(packet);b[90]=(b[90]&~7)|64;mutations.append(b)
 for b in mutations:raises(lambda b=b:engine_telemetry(resign(b),KEY,4))
 # Authenticated secondary changes on a repeated source sequence are rejected.
 for changed in (90,91):
  b=bytearray(frame(sample,seq=2,sent=5040000));b[changed]^=64 if changed==90 else 1;raises(lambda b=b:receiver.receive(resign(b),MAC,160));check(receiver.last_packet==1)
 raises(lambda:receiver.receive(packet,MAC,160));check(receiver.last_packet==1)
 # Matching repeated source payload with later age/time is accepted.
 receiver.receive(frame(sample,seq=2,sent=5040000),MAC,160);check(receiver.last_packet==2)
 ack=receiver.acknowledgement();check(ack[24:]==hmac.digest(KEY,ack[:24],'sha256'))
 # Same counter cannot change nonce or schema; newer counter can upgrade/downgrade explicitly.
 raises(lambda:native.capability_reply(capability_request(LMK,SESSION,1,1,bytes([9])*16,schema=4),LMK,SESSION,BOOT,0,0))
 raises(lambda:native.capability_reply(capability_request(LMK,SESSION,1,1,bytes([2])*16,schema=3),LMK,SESSION,BOOT,0,0))
 newer=capability_request(LMK,SESSION,2,1,bytes([3])*16,schema=3);check(native.capability_reply(newer,LMK,SESSION,BOOT,0,0)==native.capability_reply(newer,LMK,SESSION,BOOT,0,0))
 raises(lambda:engine_telemetry(frame(sample),KEY,3))
 # Canonical unavailable observations zero only the two new bytes.
 unavailable=copy.deepcopy(sample);unavailable['secondary_tables']={}
 empty=EngineRuntime().data()['secondary_tables'];unavailable['secondary_tables']=empty
 p=frame(unavailable);check(p[90:92]==b'\0\0');check(engine_telemetry(p,KEY,4)['secondary_tables']['fuel']['available'] is False)
finally:native.close()
report=dict(passed=True,checks=checks,matrix_cases=len(rows),rows=rows);(D/'radio-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
