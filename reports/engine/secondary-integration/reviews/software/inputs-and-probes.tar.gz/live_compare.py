import os
import json,subprocess,sys,threading
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_protocol import live_block
D=Path(__file__).resolve().parent
class Fake:
 def __init__(self,sample):self.lock=threading.RLock();self.tune=json.loads((R/'config/engine/defaults.json').read_text());self.last_run=None;self.sample=sample
 def coherent_sample(self):return self.sample
cases=json.loads((D/'observation-fixtures.json').read_text());results=json.loads((D/'observation-differential.json').read_text())['rows'];rows=[]
for item,result in zip(cases,results):
 if not result['native']:continue
 body=json.dumps(item['sample'],allow_nan=False).encode();proc=subprocess.run([str(D/'live_probe')],input=body,capture_output=True);assert proc.returncode==0,proc.stderr.decode()
 native=proc.stdout;host=live_block(Fake(item['sample']));assert len(native)==len(host)==640
 matches=native[416:]==host[416:];rows.append(dict(label=item['label'],matched=matches))
 if not matches:
  (D/'live-mismatch-native.bin').write_bytes(native);(D/'live-mismatch-host.bin').write_bytes(host);raise AssertionError((item['label'],[(n,native[n],host[n]) for n in range(416,640) if native[n]!=host[n]]))
(D/'live-comparison.json').write_text(json.dumps(dict(passed=True,cases=len(rows),rows=rows),indent=2)+'\n');print(json.dumps(dict(passed=True,cases=len(rows))))
