import os
import copy,json,struct,subprocess,sys
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_runtime import EngineRuntime
from engine_observability import EngineRecorder
D=Path(__file__).resolve().parent
cases=[]
def add(label,runtime):
 d=runtime.data()
 for kind in ('fuel','spark'):cases.append(dict(label=label+'-'+kind,kind=kind,sample=copy.deepcopy(d)))
def profile(mode='off',kind='fuel'):
 t=json.loads((R/'config/engine/defaults.json').read_text());r=t['secondary_tables'][kind];r['mode']=mode;r['cells']='multiplier' if mode=='multiply' else 'adder' if mode=='add' else 'absolute'
 r['map']['cells']=[150 if mode=='multiply' else 10 if mode=='add' else 90 if kind=='fuel' else 25]*256
 return t
def switches(time,level=True,valid=True):return [dict(observed_us=str(time),level=level,valid=valid),dict(observed_us=str(time),level=not level,valid=valid)]
for kind in ('fuel','spark'):
 for mode in ('off','multiply','add','conditional','input'):
  t=profile(mode,kind);r=EngineRuntime(t)
  r.step({'rpm':2000,'synced':True,'table_switches':switches(1000000)},1000000,use_decoder=False);add(mode+'-first-'+kind,r)
  r.step({'rpm':2000,'synced':True,'table_switches':switches(1020000)},1020000,use_decoder=False);add(mode+'-qualified-'+kind,r)
  if mode=='input':
   for label,now,observed,level,valid in [('pending',1025000,1025000,False,True),('invalid',1030000,1030000,True,False),('future',1035000,1035001,True,True),('stale',1040000,1019999,True,True),('recovery',1045000,1045000,True,True),('qualified-again',1065000,1065000,True,True),('reversed',1070000,1064999,True,True)]:
    r.step({'rpm':2000,'synced':True,'table_switches':switches(observed,level,valid)},now,use_decoder=False);add(label+'-'+kind,r)
  r.step({'rpm':0,'synced':False},1080000,use_decoder=False);add('stopped-'+mode+'-'+kind,r)
  r.close()
# F64 comparison just above threshold rounds the logged condition value to F32 equality.
for kind in ('fuel','spark'):
 t=profile('conditional',kind);t['secondary_tables'][kind].update(condition='tps_pct',threshold=25)
 r=EngineRuntime(t);r.step({'rpm':2000,'synced':True,'tps_pct':25+1e-8},1000000,use_decoder=False);add('f32-equality-'+kind,r);r.close()
for kind in ('fuel','spark'):
 for raw_time in (9007199254740993,18446744073709551615):
  r=EngineRuntime(profile('input',kind));r.step({'rpm':2000,'synced':True,'table_switches':switches(raw_time)},1000000,use_decoder=False);add('wide-u64-'+kind+'-'+str(raw_time),r);r.close()
r=EngineRuntime();add('no-control',r);r.close()
base=copy.deepcopy(next(x for x in cases if x['label']=='off-qualified-fuel-fuel'))
mutations=[None,False,True,'1',-1e-50,-1e-5,0,20,500,10000,10000.00001,1e30,1e39]
for field in ('threshold','debounce_ms','primary','primary_corrected','secondary','combined','coordinate','condition_value','input_age_ms'):
 for value in mutations:
  item=copy.deepcopy(base);item['label']='mutate-'+field+'-'+str(value);item['sample']['secondary_tables']['fuel'][field]=value;cases.append(item)
for field in ['flags','input_channel']:
 for value in [None,False,'0',-1,0,1,2,257,4294967295]:
  item=copy.deepcopy(base);item['label']='mutate-'+field+'-'+str(value);item['sample']['secondary_tables']['fuel'][field]=value;cases.append(item)
for field in ('available','evaluated','active','clamped','pending','input_qualified','input_level','pending_level','input_valid','input_raw','active_high','valid'):
 for value in [None,False,True,0,'0']:
  item=copy.deepcopy(base);item['label']='bool-'+field+'-'+str(value);o=item['sample']['secondary_tables']['fuel'];o[field]=value
  if isinstance(value,bool):
   names=('available','evaluated','active','clamped','pending','input_qualified','input_level','pending_level','input_valid','input_raw','active_high','valid');o['flags']=sum(int(o[k])<<n for n,k in enumerate(names))+(o['input_channel']<<16)+(o['axis_code']<<20)
  cases.append(item)
(D/'observation-fixtures.json').write_text(json.dumps(cases,indent=2)+'\n')
recorder=EngineRecorder();native=[bool(recorder.bridge.data_validate(json.dumps(item['sample'],allow_nan=False).encode())) for item in cases];recorder.close()
browser=json.loads(subprocess.check_output(['node',str(D/'validator.js'),str(D/'observation-fixtures.json')],cwd=R,text=True));assert len(native)==len(browser)
rows=[dict(label=item['label'],native=a,browser=b) for item,a,b in zip(cases,native,browser)]
(D/'observation-differential.json').write_text(json.dumps(dict(total=len(rows),mismatches=[r for r in rows if r['native']!=r['browser']],rows=rows),indent=2)+'\n')
print(json.dumps(dict(total=len(rows),mismatches=[r for r in rows if r['native']!=r['browser']])))
assert native==browser
