import os
import hashlib,json,re,struct,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_msq import export_msq,tag
D=Path(__file__).resolve().parent
text=(R/'tuning/esp32-ecu-secondary.ini').read_text();sections={};section=None
for raw in text.splitlines():
 line=raw.strip()
 if line.startswith('[') and line.endswith(']'):section=line;sections[section]=[]
 elif section:sections[section].append(line)
def split(value):
 values=[];start=0;depth=0;quoted=False;escape=False
 for n,c in enumerate(value):
  if c=='"' and not escape:quoted=not quoted
  if not quoted:
   if c in '[{(':depth+=1
   elif c in ']})':depth-=1
   elif c==',' and depth==0:values.append(value[start:n].strip());start=n+1
  escape=c=='\\' and not escape
 values.append(value[start:].strip());return values
constants={}
for line in sections['[Constants]']:
 if '=' not in line:continue
 name,value=map(str.strip,line.split('=',1));parts=split(value)
 if parts[0] in ('scalar','array','bits'):
  assert name not in constants;constants[name]=parts
assert 'pageSize = 8192' in sections['[Constants]'];assert 'ochBlockSize = 640' in sections['[OutputChannels]']
rows=[]
for path in sorted((D/'fixtures').glob('*.json')):
 tune=json.loads(path.read_text());msq=export_msq(tune);root=ET.fromstring(msq);values={c.get('name'):(c.text or '').strip() for c in root.findall('.//'+tag('constant'))}
 assert set(values)==set(constants),(path.name,set(values)^set(constants))
 encoded=bytearray(8192);written=set()
 for name,parts in constants.items():
  kind,typ,offset=parts[:3];offset=int(offset);raw=values[name]
  if kind=='bits':
   low,high=map(int,parts[3].strip('[]').split(':'));labels=[v.strip('"') for v in parts[4:]];v=labels.index(raw.strip('"')) if raw.startswith('"') else int(raw)
   assert 0<=v<2**(high-low+1)
   for bit in range(offset*8+low,offset*8+high+1):assert bit not in written;written.add(bit)
   word=int.from_bytes(encoded[offset:offset+4],'little')|(v<<low);encoded[offset:offset+4]=word.to_bytes(4,'little')
  else:
   count=1
   if kind=='array':
    for n in parts[3].strip('[]').split('x'):count*=int(n)
   numbers=list(map(float,raw.split()));assert len(numbers)==count
   fmt={'F32':'f','U32':'I','U08':'B'}[typ];body=struct.pack('<'+str(count)+fmt,*numbers) if fmt=='f' else struct.pack('<'+str(count)+fmt,*map(int,numbers))
   for bit in range(offset*8,(offset+len(body))*8):assert bit not in written;written.add(bit)
   encoded[offset:offset+len(body)]=body
 native=subprocess.check_output([str(D/'page_encoder')],input=json.dumps(tune,separators=(',',':')).encode());assert bytes(encoded)==native,path.name
 rows.append(dict(profile=path.stem,constants=len(constants),sha256=hashlib.sha256(native).hexdigest(),msq_bytes=len(msq)))
# Runtime advertised field extents must fit exactly within the640-byte block.
outputs={}
for line in sections['[OutputChannels]']:
 if '=' not in line:continue
 name,value=map(str.strip,line.split('=',1));parts=split(value)
 if parts[0] in ('scalar','bits'):
  assert name not in outputs;outputs[name]=parts
  assert int(parts[2])+4<=640
for kind,base in (('Fuel',416),('Spark',496)):
 for index,name in enumerate(('Primary','PrimaryCorrected','Secondary','Combined','Coordinate','ConditionValue','InputAgeMs','Threshold','DebounceMs')):assert int(outputs['Sec'+kind+name][2])==base+index*4
 for index,name in enumerate(('Mode','Cells','Source','Reason','InputSource','Condition')):assert int(outputs['Sec'+kind+name][2])==base+40+index*4
 assert int(outputs['Sec'+kind+'Flags'][2])==base+36
 assert int(outputs['Sec'+kind+'ObservedLow'][2])==base+64 and int(outputs['Sec'+kind+'ObservedHigh'][2])==base+68
report=dict(passed=True,profiles=len(rows),constant_fields=len(constants),runtime_fields=len(outputs),rows=rows);(D/'ini-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
