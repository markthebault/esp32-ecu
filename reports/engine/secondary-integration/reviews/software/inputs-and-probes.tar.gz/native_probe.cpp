#include "ecu/engine_json.hpp"
#include "ecu/tuning_document.hpp"
#include "ecu/tuning_live.hpp"
#include "ecu/engine_log_msl.hpp"
#include <iostream>
#include <iterator>
#include <string>
#include <cassert>
static unsigned checks=0;
static void check(bool v){++checks;assert(v);}
static bool reject(const ecu::tuning::Page&p){ecu::engine::Tune t;return !ecu::tuning::decode_page(p,7,t);}
int main(){
 using namespace ecu;
 std::string text((std::istreambuf_iterator<char>(std::cin)),{});engine::Tune t;std::string canonical;
 check(engine::canonical_tune(text.c_str(),t,canonical));check(!engine::validate(t));
 tuning::Page page;tuning::encode_page(t,7,page);engine::Tune decoded;check(tuning::decode_page(page,7,decoded));
 tuning::Page same;tuning::encode_page(decoded,7,same);check(same==page);
 auto*j=cJSON_Parse(canonical.c_str());check(j!=nullptr);tuning::Document document(j);decoded.revision=9;check(tuning::update_document(document,decoded));
 engine::Tune reread;check(engine::parse_tune(j,reread));tuning::Page written;tuning::encode_page(reread,7,written);check(written==page);cJSON_Delete(j);
 for(unsigned n=0;n<page.size();++n)if(tuning::reserved_offset(n)){auto corrupt=page;corrupt[n]=1;check(reject(corrupt));}
 for(unsigned offset:{5376U,5412U}){
  for(unsigned n=0;n<5;++n){auto corrupt=page;tuning::put_u32(corrupt.data()+offset+n*4,UINT32_MAX);check(reject(corrupt));}
  for(unsigned value:{2U,257U,65537U,UINT32_MAX})for(unsigned at:{28U,32U}){auto corrupt=page;tuning::put_u32(corrupt.data()+offset+at,value);check(reject(corrupt));}
  for(unsigned at:{20U,24U})for(unsigned value:{0x7f800000U,0xff800000U,0x7fc00000U}){auto corrupt=page;tuning::put_u32(corrupt.data()+offset+at,value);check(reject(corrupt));}
 }
 for(unsigned map:{5504U,6656U}){
  for(unsigned at:{0U,64U,128U}){auto corrupt=page;tuning::put_u32(corrupt.data()+map+at,0x7fc00000U);check(reject(corrupt));}
  auto corrupt=page;tuning::put_float(corrupt.data()+map+4,tuning::get_float(corrupt.data()+map));check(reject(corrupt));
 }
 engine::Inputs in;in.rpm=2000;in.map_kpa=45;in.tps_pct=25;in.clt_c=85;in.iat_c=25;in.lambda=1;in.battery_v=14;in.sensor_v=5;in.synced=in.phase_synced=in.sensors_valid=true;in.sampled_us=1000000;
 engine::Controller controller;auto output=controller.step(t,in,1000000);auto sample=engine::synthetic_data(t,in,output,1,1000000);
 std::array<std::uint8_t,tuning::live_bytes>live;tuning::live_block(sample,1000000,live);check(live.size()==640);
 for(unsigned n=576;n<640;++n)check(live[n]==0);for(unsigned n=0;n<2;++n)for(unsigned at=72;at<80;++at)check(live[416+n*80+at]==0);
 engine_log::Header header;header.source=engine::DataSource::Synthetic;header.total=header.retained=1;engine_log::Row row{sample,1000000,1,1};char buffer[engine_log::text_capacity];check(engine_log::msl_header(header,buffer,sizeof(buffer)));check(engine_log::msl_row(header,row,buffer,sizeof(buffer)));
 std::cout<<"{\"passed\":true,\"checks\":"<<checks<<",\"canonical_bytes\":"<<canonical.size()<<",\"sample_bytes\":"<<sizeof(engine::RuntimeSample)<<",\"recorder_bytes\":"<<sizeof(engine_log::Recorder)<<",\"page_bytes\":"<<page.size()<<",\"live_bytes\":"<<live.size()<<"}\n";
}
