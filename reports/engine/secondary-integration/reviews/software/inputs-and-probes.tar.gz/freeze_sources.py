"""Freeze independent review inputs once the integration owner says ready."""
import hashlib,json,shutil,subprocess
from datetime import datetime,timezone
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];F=D/'final-sources'
assert not F.exists(),'Preserve the existing frozen candidate; use a new directory for another pass.'
paths=[]
for directory in ('firmware/include','firmware/main','tools','scripts','web','config','tuning'):
 paths.extend(p for p in (R/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.so','.dylib','.o'))
for name in ('platformio.ini','firmware/partitions.csv','firmware/CMakeLists.txt'):
 p=R/name
 if p.is_file():paths.append(p)
bindings={}
for p in sorted(set(paths)):
 relative=p.relative_to(R);data=p.read_bytes();dest=F/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 bindings[str(relative)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
external={};cjson=Path.home()/'.platformio/packages/framework-espidf/components/json/cJSON'
for name in ('cJSON.c','cJSON.h'):
 p=cjson/name;data=p.read_bytes();dest=D/'external-sources'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
 external[str(p)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
assert all((R/p).read_bytes()==(F/p).read_bytes() for p in bindings),'Source changed during snapshot'
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),files=bindings,external_files=external)
(D/'final-source-bindings.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(files=len(bindings),external_files=len(external),bytes=sum(v['bytes'] for v in bindings.values()))))
