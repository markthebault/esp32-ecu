import hashlib,json,os,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
R=Path(os.environ.get('ECU_REVIEW_ROOT',D.parents[2])).resolve()
C=D/'external-sources'
if not C.is_dir():C=Path.home()/'.platformio/packages/framework-espidf/components/json/cJSON'
flags=['-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-pedantic','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(R),'-I'+str(R/'firmware/include'),'-I'+str(C)]
results=[]
for name in ('native_probe','live_probe','page_encoder','page_encoder_old','burn_oom_probe','migration_oom_probe'):
 command=['g++',*flags,str(D/(name+'.cpp')),str(C/'cJSON.c'),*(['-lcrypto'] if name=='live_probe' else []),'-o',str(D/name)]
 p=subprocess.run(command,cwd=R,text=True,capture_output=True)
 (D/(name+'-build.log')).write_text(p.stdout+p.stderr)
 assert p.returncode==0,(name,p.returncode,p.stderr)
 results.append(dict(name=name,command=command,exit_code=p.returncode,sha256=hashlib.sha256((D/name).read_bytes()).hexdigest()))
 print(name+' built',flush=True)
(D/'helper-builds.json').write_text(json.dumps(dict(passed=True,root=str(R),builds=results),indent=2)+'\n')
