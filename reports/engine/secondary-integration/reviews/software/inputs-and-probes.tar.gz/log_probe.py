import csv,io,json,os,sys
from pathlib import Path
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from engine_observability import EngineRecorder
from engine_log import export_msl
D=Path(__file__).resolve().parent
cases=json.loads((D/'observation-fixtures.json').read_text());rows=[]
for item in cases:
 if item['label'].startswith(('mutate-','bool-','no-control')):continue
 sample=item['sample'];recorder=EngineRecorder();recorded=max(int(sample['control_us']),int(sample['sampled_us']),1000000)
 try:
  assert recorder.command(dict(action='start',period_ms=20,duration_s=2),recorded)==200
  assert recorder.append(sample,recorded),item['label'];recorder.command(dict(action='stop',log_id=1),recorded+1)
  native=recorder.msl(1,'0'*32);sil=export_msl([{'engine_sample':sample}],item['label'])
 finally:recorder.close()
 a=list(csv.reader(io.StringIO(native),delimiter='\t'));b=list(csv.reader(io.StringIO(sil),delimiter='\t'))
 assert len(a[2])==188 and len(b[2])==145
 assert a[2][-62:]==b[2][-62:] and a[3][-62:]==b[3][-62:] and a[4][-62:]==b[4][-62:],item['label']
 fields=dict(zip(a[2],a[4]));assert all(fields['Sec'+kind.title()+'ObservedUs']==(sample['secondary_tables'][kind]['input_observed_us'] or 'NaN') for kind in ('fuel','spark'))
 rows.append(dict(label=item['label'],native_fields=len(a[2]),sil_fields=len(b[2]),fuel_observed_us=fields['SecFuelObservedUs'],spark_observed_us=fields['SecSparkObservedUs']))
 if item['label'].startswith('wide-u64-fuel-18446744073709551615'):
  (D/'native-u64.msl').write_text(native);(D/'sil-u64.msl').write_text(sil)
legacy=export_msl([{}],'legacy row without secondary observations');parts=list(csv.reader(io.StringIO(legacy),delimiter='\t'));record=dict(zip(parts[2],parts[4]))
for kind in ('Fuel','Spark'):
 assert record['Sec'+kind+'Available']=='0' and record['Sec'+kind+'Flags']=='1024' and record['Sec'+kind+'ActiveHigh']=='1' and record['Sec'+kind+'Threshold']=='NaN' and record['Sec'+kind+'ObservedUs']=='NaN'
report=dict(passed=True,actual_observation_cases=len(rows),secondary_columns=62,preserved_u64_over53bits=True,legacy_unknowns=True,rows=rows)
(D/'log-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
