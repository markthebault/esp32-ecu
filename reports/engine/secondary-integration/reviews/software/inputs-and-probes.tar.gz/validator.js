const fs=require('fs');global.window={};eval(fs.readFileSync('web/secondary_tables.js','utf8'));
const items=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const result=items.map(item=>{try{window.EcuSecondaryTables.checkObservation(item.sample.secondary_tables[item.kind],item.kind,item.sample.available);return true;}catch(error){return false;}});
process.stdout.write(JSON.stringify(result));
