import os
import asyncio,copy,csv,io,json,sys,tempfile,threading
from pathlib import Path
from http.server import ThreadingHTTPServer
R=Path(os.environ.get('ECU_REVIEW_ROOT',Path(__file__).resolve().parents[3])).resolve();sys.path.insert(0,str(R/'tools'))
from playwright.async_api import async_playwright
from web_server import Device,Handler,load_bridge
from engine_runtime import EngineRuntime
from engine_msq import import_msq
from engine_protocol import pages
D=Path(__file__).resolve().parent
async def run(url,device):
 checks=[];errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='chrome',headless=True,args=['--no-sandbox'])
  try:
   page=await browser.new_page(viewport={'width':1440,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)));await page.goto(url);await page.locator('[data-page="engine"]').click();await page.locator('#sec-fuel-mode').wait_for()
   original=copy.deepcopy(device.engine.tune);assert original['schema_version']==8
   await page.locator('#sec-fuel-mode').select_option('multiply');await page.locator('#engine-save').click();await page.locator('#toast').filter(has_text='cell meaning').wait_for();assert device.engine.tune==original
   await page.locator('[data-sec-review="fuel"][data-action="cells"]').click();assert 'Acknowledge' in await page.locator('#sec-fuel-error').inner_text();assert await page.evaluate('engineTune.secondary_tables.fuel.map.cells')==original['secondary_tables']['fuel']['map']['cells']
   await page.locator('#sec-fuel-ack').check();await page.locator('[data-sec-review="fuel"][data-action="cells"]').click();assert await page.evaluate('engineTune.secondary_tables.fuel.cells')=='multiplier';assert await page.evaluate('engineTune.secondary_tables.fuel.map.cells')==original['secondary_tables']['fuel']['map']['cells']
   await page.locator('#sec-fuel-source').select_option('tps');await page.locator('#engine-save').click();await page.locator('#toast').filter(has_text='load-axis basis').wait_for();assert device.engine.tune==original
   await page.locator('[data-sec-review="fuel"][data-action="initialize"]').click();assert 'Acknowledge' in await page.locator('#sec-fuel-error').inner_text();await page.locator('#sec-fuel-ack').check();await page.locator('[data-sec-review="fuel"][data-action="initialize"]').click();assert await page.locator('#engine-map-kind').input_value()=='secondary_fuel'
   assert await page.evaluate('engineTune.secondary_tables.fuel.map.cells')==original['secondary_tables']['fuel']['map']['cells']
   await page.locator('[data-cell="0"]').fill('150.125');await page.locator('[data-cell="0"]').dispatch_event('change');await page.locator('#engine-save').click();await page.locator('#engine-save-state').filter(has_text='Revision 2').wait_for();assert device.engine.tune['secondary_tables']['fuel']['map']['cells'][0]==150.125
   checks.append('Explicit cell and source review required; selectors/axis replacement preserve existing cells; native save publishes both metadata and map')
   await page.locator('#sec-spark-mode').select_option('add');await page.locator('#sec-spark-ack').check();await page.locator('[data-sec-review="spark"][data-action="neutral"]').click();assert await page.evaluate('engineTune.secondary_tables.spark.map.cells.every(x=>x===0)')
   await page.locator('[data-cell="0"]').fill('-2.125');await page.locator('[data-cell="0"]').dispatch_event('change');await page.locator('#engine-save').click();await page.locator('#engine-save-state').filter(has_text='Revision 3').wait_for();saved=copy.deepcopy(device.engine.tune);assert saved['secondary_tables']['spark']['map']['cells'][0]==-2.125
   checks.append('Explicit neutral additive fill and signed spark edits survive native save')
   async with page.expect_download() as download:await page.locator('#engine-msq').click()
   file=D/'browser009.msq';await (await download.value).save_as(file);assert pages(import_msq(file.read_bytes()))==pages(saved);assert 'DEV 009' in file.read_text();candidate=await page.evaluate('text=>engineFromMsq(text,engineTune)',file.read_text());assert pages(candidate)==pages(saved)
   checks.append('Browser current8192-byte MSQ exports/imports agree with independent native page serialization')
   old=R/'tuning/examples/tunerstudio-load-roundtrip.msq';await page.locator('#engine-import-file').set_input_files(old);await page.locator('#engine-save-state').filter(has_text='Imported edits').wait_for();candidate=await page.evaluate('engineTune');assert pages(candidate)==pages(import_msq(old.read_bytes(),base_revision=3));assert device.engine.tune==saved
   checks.append('Actual own008 application MSQ preserves load/AFR metadata, migrates secondaryOff and remains uncommitted for review')
   external=copy.deepcopy(saved);external['settings']['pump_prime_s']=3.75;code,value=device.engine.save(json.dumps(external).encode());assert code==200
   await page.locator('#engine-save').click();await page.locator('#toast').filter(has_text='revision changed').wait_for();assert device.engine.tune==value
   await page.locator('#engine-reload').click();await page.locator('#engine-save-state').filter(has_text='Revision 4').wait_for();assert pages(await page.evaluate('engineTune'))==pages(value)
   checks.append('Stale loaded editor cannot overwrite another editor; reload keeps full secondary fields')
   # Future timestamp is diagnostic evidence and may exceed control time.
   t=copy.deepcopy(value);r=t['secondary_tables']['fuel'];r.update(mode='input',cells='absolute');runtime=EngineRuntime(t)
   runtime.step(dict(rpm=2000,synced=True,table_switches=[dict(valid=True,level=True,observed_us='1000001'),dict(valid=False,level=False,observed_us='1000000')]),1000000,use_decoder=False);sample=runtime.data();runtime.close();assert sample['secondary_tables']['fuel']['reason']=='input_time_reversed'
   recorder=device.engine.data_recorder;assert recorder.command(dict(action='start',period_ms=20,duration_s=2),1000000)==200;assert recorder.append(sample,1000000);recorder.command(dict(action='stop',log_id=1),1000001);h=recorder.header();h['boot_id']=device.engine.data_boot;q=recorder.page(1,0);q['boot_id']=h['boot_id'];native=recorder.msl(1,h['boot_id'])
   result=await page.evaluate('''({h,q})=>{const logger=window.EcuEngineLogger,bad=[];for(const key of ['threshold','debounce_ms']){logger.adopt(h);const p=structuredClone(q);p.records[0].sample.secondary_tables.fuel[key]=null;try{logger.acceptPage(p);bad.push(false)}catch{bad.push(logger.inspect().rows===0&&logger.inspect().cursor===0)}}logger.adopt(h);logger.acceptPage(q);return {bad,msl:logger.exportMsl()};}''',dict(h=h,q=q));assert all(result['bad'])
   a=list(csv.reader(io.StringIO(native),delimiter='\t'));b=list(csv.reader(io.StringIO(result['msl']),delimiter='\t'));assert a[2:]==b[2:] and len(a[2])==188
   (D/'native188.msl').write_text(native);(D/'browser188.msl').write_text(result['msl']);row=dict(zip(a[2],a[4]));assert row['SecFuelObservedUs']=='1000001' and row['SecFuelInputQualified']=='0' and row['SecFuelInputRaw']=='1'
   checks.append('Actual Chrome/native188-field MSL006 match, including future input fault timestamp and unknown composition; malformed metadata rejects atomically')
   await page.locator('#engine-secondary-panel').scroll_into_view_if_needed();await page.screenshot(path=D/'secondary-desktop.png')
   for width in (320,390,768,1440):
    await page.set_viewport_size({'width':width,'height':1000});await page.evaluate('()=>new Promise(requestAnimationFrame)');assert await page.evaluate('()=>document.documentElement.scrollWidth<=innerWidth')
   await page.set_viewport_size({'width':390,'height':1000});await page.locator('#engine-secondary-panel').scroll_into_view_if_needed();await page.screenshot(path=D/'secondary-mobile.png');checks.append('Editor remains within320/390/768/1440px document bounds')
   assert not errors,errors
  finally:await browser.close()
 report=dict(passed=True,browser='Installed Chrome via Playwright',checks=checks,page_errors=errors);(D/'ui-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':
 with tempfile.TemporaryDirectory() as directory,ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
  server.device=Device(Path(directory)/'profile.json',load_bridge());thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:asyncio.run(run(f'http://127.0.0.1:{server.server_address[1]}',server.device))
  finally:server.shutdown();thread.join(2)
