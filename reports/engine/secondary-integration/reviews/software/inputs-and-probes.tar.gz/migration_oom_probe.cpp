#include "ecu/engine_json.hpp"
#include "ecu/tuning_layout.hpp"
#include <cassert>
#include <cstddef>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
static std::size_t calls=0,fail_at=0,live=0,peak=0;
struct alignas(std::max_align_t) Allocation{std::size_t n;};
static void* allocate(std::size_t n){++calls;if(fail_at&&calls==fail_at)return nullptr;auto*p=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+n));if(!p)return nullptr;p->n=n;live+=n;peak=std::max(peak,live);return p+1;}
static void release(void*v){if(!v)return;auto*p=static_cast<Allocation*>(v)-1;assert(live>=p->n);live-=p->n;std::free(p);}
static std::size_t trial(const std::string&body,std::size_t failure){
 fail_at=0;auto*j=cJSON_ParseWithOpts(body.c_str(),nullptr,true);assert(j);
 ecu::engine::Tune old;assert(ecu::engine::parse_tune(j,old));
 ecu::tuning::Page expected;ecu::tuning::encode_page(old,old.revision,expected);
 calls=0;fail_at=failure;const bool ok=ecu::engine::upgrade_tune_document(j);const auto count=calls;fail_at=0;
 if(!failure){assert(ok);ecu::engine::Tune upgraded;assert(ecu::engine::parse_tune(j,upgraded));ecu::tuning::Page page;ecu::tuning::encode_page(upgraded,upgraded.revision,page);assert(page==expected);}
 else assert(!ok);
 cJSON_Delete(j);assert(live==0);
 if(failure){
  std::string encoded="unchanged until a complete private candidate exists";ecu::engine::Tune retry;
  assert(ecu::engine::canonical_tune(body.c_str(),retry,encoded));assert(encoded.find("\"schema_version\":8")!=std::string::npos);
  ecu::tuning::Page page;ecu::tuning::encode_page(retry,retry.revision,page);assert(page==expected);assert(live==0);
 }
 return count;
}
int main(int argc,char**argv){assert(argc>1);cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);std::size_t total=0;
 for(int n=1;n<argc;++n){std::ifstream input(argv[n]);std::string body((std::istreambuf_iterator<char>(input)),{});const auto positions=trial(body,0);for(std::size_t p=1;p<=positions;++p)trial(body,p);total+=positions;}
 assert(live==0);cJSON_InitHooks(nullptr);std::cout<<"{\"passed\":true,\"legacy_schemas\":"<<argc-1<<",\"upgrade_allocation_failures\":"<<total<<",\"cjson_peak_bytes\":"<<peak<<"}\n";
}
