"""Publish the user's early-stop checkpoint from completed acceptance evidence."""
import gzip,hashlib,json,re,subprocess,zipfile
from pathlib import Path

ROOT=Path.cwd();CACHE=ROOT/'.cache/engine';OUT=ROOT/'reports/engine/bench-checkpoint'
BASE='22b2df6d2e6da3a7c9db0473f1dce3303b43261b'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
assert not OUT.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
files={}
def add(path,name):
 path=Path(path);name=str(name)
 assert path.is_file()and not path.is_symlink()and name not in files,path
 assert not Path(name).is_absolute()and'..'not in Path(name).parts
 files[name]=path
def tree(base,prefix,extensions):
 for p in sorted(base.rglob('*')):
  if p.is_file()and not p.is_symlink()and p.suffix in extensions:add(p,Path(prefix)/p.relative_to(base))

build=CACHE/'checkpoint-build-001';b=read(build/'summary.json')
assert b['exit_code']==0 and b['default_cache_unchanged']and b['source_inputs_unchanged']and not b['flashed']
assert not b['declared_generation_changes']and len(b['embedded_UI'])==3
assert all(row['current_index_in_flash_rodata']for row in b['embedded_UI'])
inputs=read(build/'sources-after.json')
assert inputs==read(build/'sources-before.json')
for name,expected in inputs.items():assert sha(ROOT/name)==expected,name
artifacts=[]
for row in b['artifacts']:
 assert sha(build/row['path'])==row['sha256'],row['path']
 artifacts.append(dict(**row,local_path=str((build/row['path']).relative_to(ROOT))))
for row in b['elf_archives']:
 assert sha(build/row['path'])==row['sha256']
 assert hashlib.sha256(gzip.decompress((build/row['path']).read_bytes())).hexdigest()==row['elf_sha256']
for name in ('summary.json','sources-before.json','sources-after.json','build.log','embed-web.log'):
 add(build/name,'build/'+name)
tree(build/'sdkconfigs-after','build/sdkconfigs-after',{'.compact_n16r8_web','.compact_n16r8_flex_dev','.compact_a3_web'})

native_log=CACHE/'checkpoint-native-001.log';native=native_log.read_text()
for marker in ('ERROR: AddressSanitizer','ERROR: LeakSanitizer','runtime error:','FAILED'):
 assert marker not in native,marker
assert 'Integrated engine boost and migration: 512 assertions passed'in native
assert '"shared_service_checks":2336'in native
add(native_log,'native/suite.log')
native_binaries={str(p.relative_to(ROOT)):sha(p)for p in sorted((CACHE/'checkpoint-native-001').iterdir())if p.is_file()and p.name.endswith('test')}
sdk_runs=[]
for line in native.splitlines():
 if line.startswith('{'):
  try:item=json.loads(line)
  except json.JSONDecodeError:continue
  if item.get('output'):
   folder=Path(item['output']);assert folder.is_relative_to(CACHE)and item['passed']
   sdk_runs.append(str(folder.relative_to(ROOT)));tree(folder,'native/'+folder.name,{'.json','.log'})
assert len(sdk_runs)==2

host=CACHE/'checkpoint-host-001.log';text=host.read_text()
match=re.search(r'Ran (\d+) tests in .*\n\nOK\s*$',text)
assert match and int(match[1])==99
add(host,'host/api-config-protocol-tests.log')
storage=CACHE/'checkpoint-storage-001';stored=read(storage/'result.json');assert stored['passed']
for name,expected in stored['source_sha256'].items():assert sha(ROOT/name)==expected,name
tree(storage,'storage',{'.json','.log'})
ui={}
for label,name,report in (
 ('profiles','checkpoint-profiles-ui-001','ui-tests.json'),
 ('tuning','checkpoint-tuning-ui-001','ui-tests.json'),
 ('pairing','checkpoint-pairing-ui-002','results.json'),
 ('led','checkpoint-led-ui-001','results.json')):
 folder=CACHE/name;data=read(folder/report);assert data['passed']and not data.get('page_errors',[])
 ui[label]=dict(report_sha256=sha(folder/report),checks=data.get('checks',data.get('results')))
 tree(folder,'browser/'+label,{'.json','.png','.msq','.csv'})
 add(folder.with_suffix('.log'),'browser/'+label+'.log')
assert read(CACHE/'checkpoint-pairing-ui-002/results.json')['source_sha256']==sha(ROOT/'tools/test_pairing_ui.py')
tree(CACHE/'checkpoint-led-fixtures-001','native/led-fixtures',{'.json','.log'})
add(CACHE/'checkpoint-pairing-ui-001.log','harness-history/CSP-wait-expression.log')

review=CACHE/'checkpoint-review-001';a=read(review/'assessment.json');w=read(review/'whitelist.json')
assert a['baseline_head']==BASE and a['open_findings_count']==0 and a['owned_processes_terminal']
assert a['supported_path_regressions_found']==0 and not a['devices_touched']and not a['source_edits_by_reviewer']
review_sources=read(review/'source-hashes.json')['current_sources']
for name,expected in review_sources.items():assert sha(ROOT/name)==expected,name
for item in w['files']:
 path=ROOT/item['path'];assert path.resolve().is_relative_to(review.resolve())
 assert path.stat().st_size==item['bytes']and sha(path)==item['sha256'],path
 add(path,Path('independent')/path.relative_to(review))
add(review/'whitelist.json','independent/whitelist.json')

retained=ROOT/'reports/engine/shaft-integration';earlier=read(retained/'manifest.json')
assert earlier['finite_reference_refinement_passed']is False
for name,identity in earlier['source_identities'].items():assert sha(ROOT/name)==identity['sha256'],name
for item in earlier['archives'].values():assert sha(retained/item['file'])==item['sha256']

sources=('docs/bench-checkpoint.md','docs/web-configuration.md','tuning/README.md','tools/test_pairing_ui.py')
for name in sources:add(ROOT/name,Path('checkpoint-sources')/name)
add(Path(__file__),'publish-checkpoint.py')
identities={name:dict(bytes=p.stat().st_size,sha256=sha(p))for name,p in sorted(files.items())}
OUT.mkdir(parents=True,exist_ok=False)
archive=OUT/'validation.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):
  info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,p.read_bytes(),compresslevel=9)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and set(z.namelist())==set(files)
 for name,p in files.items():assert sha(p)==identities[name]['sha256']==hashlib.sha256(z.read(name)).hexdigest()
manifest=dict(status='accepted_software_bench_checkpoint_feature_scope_frozen',runtime_baseline=BASE,
 goal_complete=False,feature_expansion_stopped_by_user=True,engine_outputs_inhibited=True,
 physical_engine_or_RF_or_vehicle_qualified=False,flashed=False,host_tests=99,
 native_suite_passed=True,native_test_binary_sha256=native_binaries,native_service_runs=sdk_runs,
 browser=ui,build=b,local_build_artifacts=artifacts,build_artifacts_rechecked_after_review=True,
 build_source_sha256=inputs,reviewed_source_sha256=review_sources,
 independent_review=dict(assessment_sha256=sha(review/'assessment.json'),open_findings=0,processes_terminal=True),
 existing_simulation_packet=dict(manifest_sha256=sha(retained/'manifest.json'),finite_reference_refinement_passed=False),
 limitations=['Normal engine outputs inhibited; no device/RF/physical fit/electrical/environmental qualification',
  'Own012 offline TunerStudio/MSQ and MSL009 file workflows; supported online TunerStudio remains unresolved',
  'Experimental reference convergence remains failed; no calibrated engine or controller equivalence claim',
  'A3 artifacts are historical; A6/A7/accessories and module/case fit remain development drafts',
  'Missing decoder/control/hardware features were not implemented in this early-stop checkpoint'],
 validation=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),payloads=identities))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
(OUT/'README.md').write_text('''# Verified software/bench checkpoint

Feature expansion is frozen at the user's requested early stop. Runtime firmware, UI and engine/simulator code remain at22b2df6. The current changes correct entry-point guides and add an actual pairing-control browser check. **Normal physical engine outputs remain inhibited.**

Acceptance: full native sanitizer suite,99 host/API/config/protocol checks, sensor NVS fault tests, four Chrome workflows, and three fresh inhibited firmware builds. Current UI bytes are present in each linked image; source inputs/default caches are unchanged. The independent reviewer found0 supported-path regressions and0 open findings. All owned review/test services are terminal; no device was flashed.

`validation.zip` contains logs, source/build identities, UI evidence and the independent review. Build binaries remain in the recorded local cache paths; reproduce using the source guide. A review-tool ELF-container rewrite was restored exactly from original verified archives and independently rehashed; firmware binaries and sources were unchanged. The first pairing harness wait expression was corrected for the existing CSP, without changing product policy.

This accepts the declared bench/software paths. Physical hardware/RF/fit and engine operation are unqualified; supported online TunerStudio, failed reference convergence and missing ECU features remain open. Historical A3 manufacturing/manual files and A6/A7 development drafts keep their original scope.

See [the checkpoint guide](../../../docs/bench-checkpoint.md) and [feature coverage](../../../docs/engine-feature-coverage.md). The broader feature goal is unfinished and is being paused at this checkpoint.
''')
print(json.dumps(dict(output=str(OUT),payloads=len(files),validation_bytes=archive.stat().st_size,host_tests=99,browser_workflows=4,builds=3)))
