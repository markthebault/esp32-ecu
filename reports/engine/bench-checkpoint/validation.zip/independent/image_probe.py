"""Read-only linked-image inspection of completed inhibited checkpoint builds."""
from pathlib import Path
import hashlib,json,re,struct,subprocess
R=Path(__file__).resolve().parent;ROOT=R.parents[2];B=ROOT/'.cache/engine/checkpoint-build-001';prefix=Path.home()/'.platformio/packages/toolchain-xtensa-esp-elf/bin/xtensa-esp32s3-elf-'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();summary=json.loads((B/'summary.json').read_text());html=(ROOT/'web/index.html').read_text().encode();reports={}
assert summary['exit_code']==0 and summary['default_cache_unchanged']and summary['source_inputs_unchanged']and not summary['flashed']
for env in ('compact_n16r8_web','compact_n16r8_flex_dev','compact_a3_web'):
 out=R/'images'/env;out.mkdir(parents=True,exist_ok=True);folder=B/'build'/env;elf=folder/'firmware.elf';image=folder/'firmware.bin'
 raw=out/'flash.rodata';subprocess.run([str(prefix)+'objcopy','--dump-section','.flash.rodata='+str(raw),str(elf),str(out/'objcopy-copy.elf')],check=True,capture_output=True)
 (out/'objcopy-copy.elf').unlink()
 rodata=raw.read_bytes();assert b'COMPILE-TIME INHIBITED\0'in rodata and b'hardware_timer_virtual_outputs\0'in rodata
 assert b'DUMMY LOADS ONLY\0'not in rodata and b'hardware_timer_dummy_loads\0'not in rodata
 assert html+b'\0'in rodata
 symbols=subprocess.check_output([str(prefix)+'nm','--defined-only','-S','-C',str(elf)],text=True)
 assert 'engine_target::(anonymous namespace)::output_pins'not in symbols
 rows=[x for x in symbols.splitlines()if 'engine_target'in x and'::on_alarm('in x];assert len(rows)==1
 address,size,*_=rows[0].split(maxsplit=3);start=int(address,16);end=start+int(size,16)
 dis=subprocess.check_output([str(prefix)+'objdump','-d','-C','--start-address='+hex(start),'--stop-address='+hex(end),str(elf)],text=True);assert '<GPIO>'not in dis
 (out/'on-alarm.txt').write_text(dis);(out/'policy-symbol.txt').write_text(rows[0]+'\n')
 partitions=[];blob=(folder/'partitions.bin').read_bytes()
 for offset in range(0,len(blob)-31,32):
  magic,kind,subtype,position,size,label,flags=struct.unpack_from('<HBBII16sI',blob,offset)
  if magic!=0x50aa:break
  partitions.append(dict(name=label.split(b'\0',1)[0].decode(),kind=kind,subtype=subtype,offset=position,size=size,flags=flags))
 factory=next(x for x in partitions if x['name']=='factory');nvs=next(x for x in partitions if x['name']=='engine_nvs')
 assert factory['size']==2097152 and image.stat().st_size<=factory['size'];assert nvs['offset']==0x210000 and nvs['size']==0x20000
 reports[env]=dict(elf_sha256=sha(elf),binary_sha256=sha(image),binary_bytes=image.stat().st_size,current_web_embedded=True,current_web_sha256=hashlib.sha256(html).hexdigest(),compiled_policy='engine actuation compile-time inhibited',physical_scheduler_pin_table_absent=True,on_alarm_GPIO_reference_absent=True,on_alarm_address=hex(start),partitions=partitions,scope='Static linked code/data/partition check; no flashing, actual pin measurement, runtime-memory or electrical qualification')
 raw.unlink()
 expected=next(x['sha256'] for x in summary['artifacts'] if x['path']==f'build/{env}/firmware.elf');assert sha(elf)==expected
(R/'image-results.json').write_text(json.dumps(dict(passed=True,build_summary_sha256=sha(B/'summary.json'),images=reports),indent=2)+'\n');print('PASS3 inhibited linked images with current UI and expected partitions')
