"""Private native/config/API/radio checks; no sockets, devices or SIL runs."""
from pathlib import Path
import copy,io,json,os,sys,types
R=Path(__file__).resolve().parent;ROOT=R.parents[2]
os.environ['ECU_NATIVE_CACHE_ROOT']=str(R/'native')
sys.path.insert(0,str(ROOT/'tools'))
# The recorder loader has a legacy fixed cache root. Redirect only that output
# through a private root with read-only source symlinks; no behavior changes.
import engine_observability as observable
O=R/'observer-root';O.mkdir()
for n in('tools','firmware'):(O/n).symlink_to(ROOT/n,target_is_directory=True)
observable.R=O
from web_server import Device,Handler,load_bridge
from engine_runtime import EngineStore
from radio_simulator import RadioSimulator
bridge=load_bridge();devices=[]
def device(name):
 d=Device(R/'states'/name,bridge);devices.append(d);return d
def finish():
 for d in devices:
  d.engine.runtime.close();d.engine.trigger_capture.close();d.engine.data_recorder.close();d.radio.close()
def request(d,path,method='GET',body=b'',token=True,origin=None,ctype='application/json'):
 reply=[];h=object.__new__(Handler);h.server=types.SimpleNamespace(device=d);h.path=path;h.command=method;h.headers={'Host':'checkpoint.local','Content-Type':ctype,'Content-Length':str(len(body))}
 if token:h.headers['X-ECU-Token']=d.token
 if origin is not None:h.headers['Origin']=origin
 h.rfile=io.BytesIO(body);h.reply=lambda code,value,*rest:reply.append((code,value))
 (h.do_GET if method=='GET'else h.mutate)();assert len(reply)==1
 return reply[0]
checks={}
try:
 d=device('main.json');initial=copy.deepcopy(d.profile);engine_initial=copy.deepcopy(d.engine.tune)
 assert initial['schema_version']==2 and engine_initial['schema_version']==11
 assert engine_initial['physical_outputs']=='inhibited'
 # Malformed native documents never mutate the live store.
 for raw in(b'{bad',b'[]',json.dumps({**initial,'unknown':1}).encode(),json.dumps(initial).encode()+b'\0',b'{"schema_version":2,"schema_version":2}'):
  assert d.save(raw)[0]==422 and d.profile==initial
 checks['invalid_profiles_before_mutation']=5
 changed=copy.deepcopy(initial);changed['sensors'][0].update(mode='linear',unit='kPa',y0=20,y1=120)
 code,saved=d.save(json.dumps(changed).encode());assert code==200 and saved['revision']==2
 assert d.save(json.dumps(changed).encode())[0]==409
 restarted=device('main.json');assert restarted.profile==saved
 checks['sensor_save_restart_CAS']=True
 # All engine validation/save paths retain the compiled inhibit policy.
 invalid=copy.deepcopy(engine_initial);invalid['physical_outputs']='enabled'
 assert d.engine.save(json.dumps(invalid).encode())[0]==422
 eight=copy.deepcopy(d.engine.tune);eight['engine'].update(cylinders=8,displacement_cc=4000);eight['strategy']='sequential';eight['timing']['firing_order']=[1,8,7,6,5,4,3,2];eight['cylinder_trims']['spark_deg'][7]=3.5;eight['cylinder_trims']['fuel_maps'][7]['cells'][0]=123.25
 code,eight_saved=d.engine.save(json.dumps(eight).encode());assert code==200
 assert d.engine.save(json.dumps(eight).encode())[0]==409
 four=copy.deepcopy(eight_saved);four['engine'].update(cylinders=4,displacement_cc=2000);four['timing']['firing_order']=[1,3,4,2,0,0,0,0]
 code,four_saved=d.engine.save(json.dumps(four).encode());assert code==200 and four_saved['cylinder_trims']['spark_deg'][7]==3.5 and four_saved['cylinder_trims']['fuel_maps'][7]['cells'][0]==123.25
 restored=device('main.json');assert restored.engine.tune==four_saved
 e=restored.engine.status();assert e['physical_outputs_enabled']is False and e['timing']['physical_high_mask']==0 and e['fitted_injector_commands']==e['fitted_coil_commands']==4 and not e['fresh']
 checks['engine_C8_persistence_inactive_retention_CAS_inhibit']=True
 # Error states preserve bytes and runtime; no recovery erases storage.
 corrupt=R/'states/corrupt.json';corrupt.write_text('{bad');bad=device('corrupt.json');assert not bad.storage_ok and bad.save(json.dumps(bad.profile).encode())[0]==503 and corrupt.read_text()=='{bad'
 engine_bad=R/'states/engine-bad.json.engine';engine_bad.write_text('{bad');bad_engine=device('engine-bad.json');assert not bad_engine.engine.storage_ok and bad_engine.engine.save(json.dumps(bad_engine.engine.tune).encode())[0]==503 and engine_bad.read_text()=='{bad'
 failing=device('failure.json');old=copy.deepcopy(failing.engine.tune);failing.engine.path.mkdir();assert failing.engine.save(json.dumps(old).encode())[0]==507 and failing.engine.tune==old and not failing.engine.storage_ok
 assert failing.engine.save(json.dumps(old).encode())[0]==503
 checks['corruption_and_commit_failure_preserve_state']=True
 # Invoke the actual handler methods in memory to check authentication and
 # route semantics. The parent's suites exercise actual HTTP/browser framing.
 assert request(d,'/api/radio',token=False)[0]==403
 assert request(d,'/api/radio',origin='http://elsewhere')[0]==403
 assert request(d,'/api/config','PUT',json.dumps(d.profile).encode(),token=False)[0]==403
 assert request(d,'/api/config','PUT',json.dumps(d.profile).encode(),origin='http://elsewhere')[0]==403
 assert request(d,'/api/config','PUT',b'{}',ctype='text/plain')[0]==415
 assert request(d,'/api/config','PUT',b' '*16385)[0]==413
 assert request(d,'/api/radio','POST',b'{"action":"enable_outputs"}')[0]==422
 assert request(d,'/api/radio','POST',b'{"action":"open"}')[0]==202
 _,r=request(d,'/api/radio');assert r['simulator'] and r['pairing'] and len(r['setup_key'])==32
 assert request(d,'/api/radio','POST',b'{"action":"simulate"}')[0]==202
 _,r=request(d,'/api/radio');command=json.dumps(dict(action='confirm',mac=r['candidate']['mac'],window=r['window'])).encode();assert request(d,'/api/radio','POST',command)[0]==202
 _,r=request(d,'/api/radio');assert not r['pairing'] and not r['setup_key'] and len(r['peers'])==1 and not r['peers'][0]['connected'] and not r['peers'][0]['engine_connected']
 assert not r['indicator']['available'] and r['engine_data_source']=='no_radio_observation'
 assert request(d,'/api/radio','POST',json.dumps(dict(action='unpair',mac=r['peers'][0]['mac'])).encode())[0]==202
 checks['handler_auth_bounds_pairing_synthetic_labels']=True
 status=d.status();assert status['simulator'] and not status['arm'] and status['output_state']=='All outputs OFF'
 checks['no_sockets_devices_or_simulator_research']=True
 (R/'probe-results.json').write_text(json.dumps(dict(passed=True,checks=checks,sensor_schema=2,engine_schema=11,scope=__doc__),indent=2)+'\n')
 print('PASS',checks,flush=True)
finally:finish()
