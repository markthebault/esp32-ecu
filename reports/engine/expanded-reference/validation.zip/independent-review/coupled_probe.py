"""Independent fixed-geometry causality/coupling checks for final002 fixture."""
import copy,gzip,hashlib,json,math,shutil,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/home/mark/persospace/esp32-ecu')
sys.path.insert(0,str(ROOT/'tools'))
from engine_geometry import EngineGeometry
from compare_engine_controllers import run,benchmark_tune
from speeduino_profiles_runtime import SpeeduinoProfilesRuntime
OUT=Path(__file__).parent/'coupled-002'
CHECKS=0
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(v,c):
 global CHECKS
 CHECKS+=1
 if not v:raise AssertionError(c)

def prescribed(r):
 events=[(us,0)for us in range(250,600001,250)]
 for tooth in range(1,601):
  if tooth%60<58:events.append((tooth*1000,1))
 for angle in range(540,3601,720):events.append((round(angle*1000/6),2))
 edges=[]
 for us,kind in sorted(events):
  edges+=(r.input_edge(us,1,True)+r.input_edge(us,1,False))if kind==2 else r.advance(us,tooth=kind==1)
 inverse={ch:pin for pin,ch in r.pin_map.items()}
 native=[(us,inverse[ch],high,advance,dwell)for us,ch,high,advance,dwell in edges]
 r.halt();return native,edges

def profile(n,mode):
 t=benchmark_tune();t['engine'].update(cylinders=n,displacement_cc=500*n)
 t['timing']['firing_order']=[1,*range(n,1,-1),*([0]*(8-n))];t['strategy']=mode
 return t

def main():
 OUT.mkdir(exist_ok=False)
 for name in ('speeduino-profiles','build-manifest.json'):
  shutil.copyfile(ROOT/'.cache/engine/expanded-reference-build-002'/name,OUT/name)
 binary=OUT/'speeduino-profiles';binary.chmod(0o755)
 sources=['tools/speeduino_profiles_runtime.py','tools/compare_engine_controllers.py','tools/engine_geometry.py',
  'tools/engine_research_plant.py','tools/engine_runtime.py','tools/target_runtime.py','tools/speeduino_profiles_sim.cpp',
  'scripts/build_speeduino_profiles.py']
 before={n:digest(ROOT/n)for n in sources}
 geometry=EngineGeometry(8,(1,8,7,6,5,4,3,2),4000)
 good=SpeeduinoProfilesRuntime(binary,geometry)
 bad=SpeeduinoProfilesRuntime(binary,geometry,wiring_order=range(1,9))
 try:
  a,physical_a=prescribed(good);b,physical_b=prescribed(bad)
  check(a==b,'prescribed native pin edge bytes unchanged by Python wiring translation')
  check(physical_a!=physical_b,'physical mapping actually changes')
  check(good.profile['physical_geometry']==bad.profile['physical_geometry']==geometry.summary(),'fixed physical geometry')
  wiring=dict(native_edges=a,correct_edges=physical_a,wrong_edges=physical_b,
   correct_profile=good.profile,wrong_profile=bad.profile)
 finally:good.close();bad.close()
 for order in ([1,2,3],[1]*8,[True,2,3,4,5,6,7,8],[2,1,3,4,5,6,7,8],[1,2,3,4,5,6,7,9]):
  with patch('speeduino_profiles_runtime.subprocess.Popen')as launch:
   try:SpeeduinoProfilesRuntime(binary,geometry,wiring_order=order)
   except ValueError:pass
   else:raise AssertionError(('invalid order accepted',order))
   check(not launch.called,('invalid wiring rejected before child launch',order))
 results={}
 cases=[('ours1','ours',1,'batch_wasted',250,None),('ref1','speeduino',1,'batch_wasted',250,None),
  ('ours8','ours',8,'sequential',250,None),('ref8','speeduino',8,'sequential',250,None),
  ('ours8-fine','ours',8,'sequential',125,None),('ref8-fine','speeduino',8,'sequential',125,None),
  ('ref8-wrong-wiring','speeduino',8,'sequential',250,list(range(1,9))),
  ('ref7','speeduino',7,'sequential',250,None)]
 for name,controller,n,mode,step,wiring_order in cases:
  t=profile(n,mode);g=EngineGeometry.from_tune(t)
  kwargs=dict(tune=t,target_dispatcher=True)if controller=='ours'else dict(reference_profile_fixture=binary,reference_wiring_order=wiring_order)
  result=run(controller,'warm_start',4,step,plant_geometry=g,sequential=mode=='sequential',**kwargs)
  (OUT/(name+'.json.gz')).write_bytes(gzip.compress(json.dumps(result,separators=(',',':'),allow_nan=False).encode(),mtime=0))
  s=result['summary'];results[name]=s
  check(s['plant_geometry']==g.summary(),(name,'physical geometry readback'))
  check(s['plant_air_parameters']['cylinders']==n,(name,'FMU cylinder readback'))
  check(math.isclose(s['plant_air_parameters']['displacement_m3'],500*n*1e-6,rel_tol=1e-12),(name,'FMU displacement readback'))
  check(s['final_outputs_high']==0 and not s['physical_outputs_enabled'],(name,'inhibited termination'))
  for key,bound in [('fuel_residual_mg',1e-7),('chemical_residual_j',1e-5),('shaft_residual_j',1e-5),('air_residual_kg',1e-8),('air_energy_residual_j',.02)]:
   check(abs(s['ledger'][key])<bound,(name,key,s['ledger'][key]))
  if wiring_order is None:
   check(s['final_rpm']>500,(name,'self-sustaining shaft after starter release',s['final_rpm']))
   check(all(v>0 for v in s['cylinder_fuel_mg']),(name,'fuel reaches every actual cylinder'))
   check(all(v>0 for v in s['cylinder_burned_mg']),(name,'every cylinder burns'))
  print(name,s['final_rpm'],s['max_spark_error_after_3s_deg'],flush=True)
 check(results['ref1']['reference_profile']['effective_before_start']['divider']==0,'corrected N1 divider')
 check(results['ref1']['reference_profile']['effective_before_start']['n_squirts']==2,'corrected N1 two-squirt startup')
 check(results['ref8']['plant_geometry']==results['ref8-wrong-wiring']['plant_geometry'],'wrong wiring holds actual geometry')
 ratio=results['ref8-wrong-wiring']['ledger']['combustion_shaft_j']/results['ref8']['ledger']['combustion_shaft_j']
 check(ratio<.7,('wrong wiring actually lowers physical work',ratio))
 check(results['ref8-wrong-wiring']['max_spark_error_after_3s_deg']>80,'wrong wiring visible in phase diagnostics')
 refinements={}
 for prefix in ('ours8','ref8'):
  a=results[prefix];b=results[prefix+'-fine']
  refinements[prefix]=dict(final_rpm_relative=abs(a['final_rpm']/b['final_rpm']-1),
   shaft_work_relative=abs(a['ledger']['combustion_shaft_j']/b['ledger']['combustion_shaft_j']-1),
   final_rpm_coarse=a['final_rpm'],final_rpm_fine=b['final_rpm'])
  check(refinements[prefix]['final_rpm_relative']<.05,(prefix,'finite refinement',refinements[prefix]))
 after={n:digest(ROOT/n)for n in sources};check(before==after,'coupled source identity stable')
 report=dict(passed=True,checks=CHECKS,results=results,wiring_control=wiring,refinement=refinements,
  wrong_wiring_work_ratio=ratio,source_sha256=before,binary_sha256=digest(binary),probe_sha256=digest(__file__),
  plant_manifests={name:json.loads((ROOT/p).read_text())for name,p in [('profile','.cache/engine/modelica-mvem/airpath-profiles/manifest.json'),('legacy','.cache/engine/modelica-mvem/airpath/manifest.json')]},
  limits=['Uncalibrated research MVEM air path and local pulse-driven combustion/free shaft',
   'Independent copies for both controllers, fixed500cc/cylinder even-fire physical fixture',
   'Declared1000us project worker and zero-cost native reference loop opportunities',
   'Refinement is finite125/250us check, not proof of numerical convergence or physical timing',
   'No target/HIL, physical engine, electrical, environmental, RF or supported online tuning qualification'])
 (OUT/'assessment.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print('PASS',CHECKS,flush=True)

if __name__=='__main__':main()
