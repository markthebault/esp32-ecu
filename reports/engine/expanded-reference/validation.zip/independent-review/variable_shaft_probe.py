"""Isolate native timing prediction with an analytic shaft, no plant coupling."""
import gzip,json,math,subprocess
from pathlib import Path
ROOT=Path(__file__).parent
OUT=ROOT/'variable-shaft-002'
BINARY=ROOT/'final-002/speeduino-profiles'

def angle(us,amplitude):
 t=us*1e-6
 return 6000*t+amplitude*math.sin(2*math.pi*t/.12)

def crossing(target,amplitude):
 lo=0.;hi=850000.
 for _ in range(60):
  mid=(lo+hi)/2
  if angle(mid,amplitude)<target:lo=mid
  else:hi=mid
 return round((lo+hi)/2)

def main():
 OUT.mkdir(exist_ok=False);results=[]
 for mode in ('wasted_cop','sequential'):
  for amplitude in (0,10,20):
   for period in (250,125,50):
    events=[(us,0,f'advance {us}')for us in range(period,800001,period)]
    tooth=1
    while tooth*6<=angle(800000,amplitude):
     if tooth%60<58:
      us=crossing(tooth*6,amplitude);events.append((us,1,f'tooth {us}'))
     tooth+=1
    if mode=='sequential':
     cam=540
     while cam<=angle(800000,amplitude):
      us=crossing(cam,amplitude);events.extend([(us,2,f'input {us} 1 1'),(us,3,f'input {us} 1 0')]);cam+=720
    program='sensors 100 20 85 25 14 14.7\n'+'\n'.join(s for us,k,s in sorted(events))+'\nstatus\nhalt\nquit\n'
    p=subprocess.run([str(BINARY.resolve()),'1',mode],input=program,text=True,capture_output=True,timeout=30)
    assert p.returncode==0,p.stderr
    edges=[list(map(int,s.split()[1:]))for s in p.stdout.splitlines()if s.startswith('edge ')]
    errors=[]
    for us,pin,high,sync,ign_span,*_ in edges:
     if pin==31 and not high and 400000<=us<800000:
      errors.append([us,math.remainder(90-angle(us,amplitude)-10,720 if mode=='sequential'and sync==2 and ign_span==720 else 360)])
    status=next(s for s in p.stdout.splitlines()if s.startswith('status '))
    assert int(status.split()[4])==10,status
    name=f'{mode}-amplitude{amplitude}-loop{period}'
    (OUT/(name+'.stdin.gz')).write_bytes(gzip.compress(program.encode(),mtime=0))
    (OUT/(name+'.stdout.gz')).write_bytes(gzip.compress(p.stdout.encode(),mtime=0))
    results.append(dict(mode=mode,angle_amplitude_deg=amplitude,
     analytic_rpm_min=1000-amplitude*2*math.pi/.12/6,
     analytic_rpm_max=1000+amplitude*2*math.pi/.12/6,loop_opportunity_us=period,
     late_spark_errors=errors,max_abs_deg=max(abs(e)for _,e in errors)))
    print(name,results[-1]['max_abs_deg'],flush=True)
 report=dict(passed=True,results=results,
  analytic_angle='6000*t + amplitude*sin(2*pi*t/0.12), degrees, t in seconds',
  scope='Independent nonlinear prescribed shaft isolates timing predictor/loop opportunity effects without a combustion or FMI plant; no target or physical timing qualification')
 (OUT/'assessment.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
