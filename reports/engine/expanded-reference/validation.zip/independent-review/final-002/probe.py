"""Independent raw-protocol/port/schedule review. No project source edits."""
import gzip,hashlib,json,math,os,shutil,subprocess,time
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=Path('/home/mark/persospace/esp32-ecu')
BUILD=ROOT/'.cache/engine/expanded-reference-build-002'
MODEL=json.loads((BUILD/'build-manifest.json').read_text())
PIN='9ff5aae44de51fdc00d3fb1c7c2bfc1f0d0b3e20'
BASE='046389d754c996c34cb7e7171b1e42088f5ae6c0615133a3c5e74743f9f6d52c'
PINS=[22,23,25,26,27,28,29,30,31,32,33,34,35,36,37,38]
CHECKS=0
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(v,context):
 global CHECKS
 CHECKS+=1
 if not v:raise AssertionError(context)

def invoke(args,input_text,stem,timeout=30):
 p=subprocess.run(args,input=input_text,text=True,capture_output=True,timeout=timeout)
 (OUT/(stem+'.stdout.gz')).write_bytes(gzip.compress(p.stdout.encode(),mtime=0))
 (OUT/(stem+'.stderr')).write_text(p.stderr)
 return p

def prescribed_program(rpm,duration=800000,cam=False):
 events=[]
 for us in range(250,duration+1,250):events.append((us,0,f'advance {us}'))
 tooth=1
 while round(tooth*1000000/rpm)<=duration:
  us=round(tooth*1000000/rpm)
  if tooth%60<58:events.append((us,1,f'tooth {us}'))
  tooth+=1
 if cam:
  angle=540
  while round(angle*1000000/(rpm*6))<=duration:
   us=round(angle*1000000/(rpm*6));angle+=720
   events.append((us,2,f'input {us} 1 1'));events.append((us,3,f'input {us} 1 0'))
 for us in range(20000,duration+1,20000):events.append((us,4,'geometry'))
 ordered=[cmd for us,priority,cmd in sorted(events)]
 return 'sensors 100 20 85 25 14 14.7\n'+'\n'.join(ordered)+'\nstatus\ngeometry\nhalt\ngeometry\nadvance 850000\ngeometry\nquit\n'

def parse_case(stdout,n,mode,rpm):
 lines=stdout.splitlines();check(lines[0]==('ready_profiles 19 18'if mode=='sequential'else'ready_profiles 19 0'),(n,mode,'greeting'))
 gs=[json.loads(s.split(' ',1)[1])for s in lines if s.startswith('geometry ')]
 edges=[list(map(int,s.split()[1:]))for s in lines if s.startswith('edge ')]
 check(len(gs)==44,(n,mode,'geometry observations',len(gs)))
 g=gs[0]
 check(g['requested_cylinders']==g['cylinders']==g['injectors']==n,(n,mode,'count'))
 check(g['native_output_pins']==PINS,(n,mode,'pin identity'))
 check(len(set(zip(g['native_port_ids'],g['native_port_masks'])))==16,(n,mode,'16 distinct ports'))
 check(all(m and m&(m-1)==0 for m in g['native_port_masks']),(n,mode,'single bit masks'))
 seq=mode=='sequential'
 check(g['requested_spark_mode']==(3 if seq else 2),(n,mode,'requested spark'))
 check(g['configured_spark_mode']==(3 if seq else 2 if n in (4,6,8)else 0),(n,mode,'spark fallback'))
 check(g['effective_injection_layout']==(3 if seq else 1 if n in (4,5,6,8)else 0),(n,mode,'injection fallback'))
 expected_inj=n if seq or n in (1,2,3)else 4 if n==5 else n//2
 expected_ign=n if seq or n in (1,2,3,5)else n//2
 check(g['primary_injector_outputs']==expected_inj,(n,mode,'injector schedule count'))
 check(g['ignition_outputs']==expected_ign,(n,mode,'ignition schedule count'))
 used=set();high={};widths={p:[]for p in PINS};errors=[];modes=set()
 for ts,pin,value,sync,ign_span,inj_span,layout,ign_count,inj_count in edges:
  check(pin in PINS,(n,mode,'unknown observed pin',pin));used.add(pin)
  check(value in (0,1) and sync in (0,1,2) and ign_span in (360,720)and inj_span in (120,180,360,720),(n,mode,'edge metadata'))
  check((pin in high)!=bool(value),(n,mode,'duplicate edge',ts,pin,value))
  modes.add((sync,ign_span,inj_span,layout,ign_count,inj_count))
  if value:high[pin]=ts
  else:
   width=ts-high.pop(pin);widths[pin].append(width);check(width>=0,(n,mode,'negative width'))
   if pin in PINS[8:]and ts>=400000 and ts<800000:
    index=PINS.index(pin)-8
    # Independent expected physical wiring for the reversed order used by
    # the parent runner. Native firing ordinal angles do not depend on names.
    pos=(index*((n+1)//2))%n if not seq and n in (3,5)else index
    actual_angle=ts*rpm*6/1000000
    target=90+720*pos/n
    errors.append(math.remainder(target-actual_angle-10,720 if seq and sync==2 and ign_span==720 else 360))
 check(not high,(n,mode,'halt left high',high))
 count=n if n!=7 or seq else 3
 expected=set(PINS[:count]+PINS[8:8+count])
 check(used==expected,(n,mode,'actual active outputs',sorted(used),sorted(expected)))
 check(all(ts<=800000 for ts,*_ in edges),(n,mode,'output after halt'))
 check(gs[-2]['halted']and gs[-1]['halted'],(n,mode,'halt readback'))
 check(gs[-1]['native_output_pins']==PINS,(n,mode,'unchanged bindings'))
 return dict(cylinders=n,requested_mode=mode,rpm=rpm,initial=g,final=gs[-1],observed_native_pins=sorted(used),
  edges=len(edges),mode_tuples=sorted(modes),max_completed_coil_width_us=max((max(widths[p],default=0)for p in PINS[8:]),default=0),
  max_completed_injector_width_us=max((max(widths[p],default=0)for p in PINS[:8]),default=0),
  late_spark_error_max_deg=max(map(abs,errors),default=None),spark_error_samples=len(errors),
  scope='Raw production GPIO observation on prescribed shaft; not coupled or physical engine proof')

def command(args,stem):
 with (OUT/(stem+'.log')).open('wb')as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)

def main():
 identities={str(p):digest(p)for p in [ROOT/'tools/speeduino_profiles_sim.cpp',ROOT/'tools/speeduino_profiles_runtime.py',ROOT/'tools/compare_engine_controllers.py',ROOT/'scripts/build_speeduino_profiles.py',BUILD/'build-manifest.json',BUILD/'speeduino-profiles']}
 check(subprocess.check_output(['git','-C',str(ROOT.parent/'speeduino'),'rev-parse','HEAD'],text=True).strip()==PIN,'upstream pin')
 check(MODEL['speeduino_sha']==PIN and MODEL['base_binary_sha256']==MODEL['numerical_relink_sha256']==BASE,'manifest attestation')
 for name,expected in MODEL['locked_original_input_hashes'].items():check(digest(name)==expected,('locked input',name))
 for name,expected in MODEL['object_hashes'].items():check(digest(name)==expected,('object',name))
 for name,expected in MODEL['library_hashes'].items():check(digest(name)==expected,('archive',name))
 relink=OUT/'original-relink'
 original=json.loads((ROOT/'.cache/engine/speeduino-sim/build-manifest.json').read_text())
 objects=[ROOT/'.cache/engine/speeduino-sim/obj'/(name.replace('/','_')+'.o')for name in original['source_hashes']if name!='tools/speeduino_sim_native.hpp']
 libraries=[str(ROOT.parent/'speeduino'/name)for name in original['dependency_hashes']if name.endswith('.a')]
 tail=['-Wl,--start-group',*libraries,'-Wl,--end-group','-lgcov','-pthread']
 command([original['compiler'],*map(str,objects),*tail,'-o',str(relink)],'relink')
 check(digest(relink)==BASE,'independent byte-exact baseline relink')
 binary=OUT/'speeduino-profiles';shutil.copyfile(BUILD/'speeduino-profiles',binary);binary.chmod(0o755)
 check(digest(binary)==MODEL['binary_sha256'],'copied reference identity')
 cases=[]
 for n in range(1,9):
  for mode in ('sequential','wasted_cop','semi'):
   text=prescribed_program(1000,cam=mode=='sequential')
   stem=f'raw-{n}-{mode}'
   (OUT/(stem+'.stdin.gz')).write_bytes(gzip.compress(text.encode(),mtime=0))
   p=invoke([str(binary),str(n),mode],text,stem)
   check(p.returncode==0,(n,mode,p.stderr));case=parse_case(p.stdout,n,mode,1000);cases.append(case)
   print(n,mode,case['edges'],case['late_spark_error_max_deg'],flush=True)
 source=(ROOT/'tools/speeduino_profiles_sim.cpp').read_text()
 retained=[str(p)for p in objects if p.name!='tools_speeduino_sim.cpp.o']
 faults=[]
 for label,prefix in [('auxiliary_collision','24,23,25'),('output_alias','22,22,25'),('map_oob','70,23,25')]:
  copied=OUT/(label+'.cpp');copied.write_text(source.replace('22,23,25',prefix,1))
  obj=OUT/(label+'.o');exe=OUT/label
  command([original['compiler'],*original['compile_flags'],'-I'+str(ROOT/'tools'),'-c',str(copied),'-o',str(obj)],label+'-compile')
  command([original['compiler'],*retained,str(obj),*tail,'-o',str(exe)],label+'-link')
  p=invoke([str(exe),'8','sequential'],'quit\n',label)
  check(p.returncode==2 and ('aliases'in p.stderr or 'alias'in p.stderr or 'exceeds native'in p.stderr),(label,p.stderr))
  faults.append(dict(kind=label,returncode=p.returncode,reason=p.stderr.strip(),source_sha256=digest(copied),binary_sha256=digest(exe)))
 witness=OUT/'io_witness.cpp'
 hook='else if(command=="witness") {for(unsigned i=1;i<=8;++i){openInjector(i);speeduino_sim_observe();closeInjector(i);speeduino_sim_observe();beginCoilCharge(i);speeduino_sim_observe();endCoilCharge(i);speeduino_sim_observe();}}\n            else if(command=="status")status();'
 witness.write_text('#include "scheduledIO_inj.h"\n#include "scheduledIO_ign.h"\n'+source.replace('else if(command=="status")status();',hook))
 obj=OUT/'io_witness.o';exe=OUT/'io_witness'
 command([original['compiler'],*original['compile_flags'],'-I'+str(ROOT/'tools'),'-c',str(witness),'-o',str(obj)],'witness-compile')
 command([original['compiler'],*retained,str(obj),*tail,'-o',str(exe)],'witness-link')
 p=invoke([str(exe),'8','sequential'],'witness\nhalt\nquit\n','witness')
 check(p.returncode==0,('witness return',p.stderr))
 transitions=[list(map(int,s.split()[1:]))for s in p.stdout.splitlines()if s.startswith('edge ')]
 check(len(transitions)==32,('witness transition count',len(transitions)))
 check(sorted((pin,value)for ts,pin,value,*_ in transitions)==sorted((pin,value)for pin in PINS for value in (0,1)),'one independent rise/fall on each actual GPIO')
 check(all(ts==0 for ts,*_ in transitions),'witness pre-clock')
 report=dict(passed=True,checks=CHECKS,cases=cases,negative_fixtures=faults,
  witness=dict(transitions=transitions,source_sha256=digest(witness),binary_sha256=digest(exe)),
  independent_original_relink_sha256=digest(relink),inputs_before=identities,
  inputs_after={p:digest(p)for p in identities},probe_sha256=digest(__file__),
  limits=['Unchanged production numerical objects, existing deterministic4us32-bit native HAL',
   'Prescribed shaft only; parent separately exercises coupled plants',
   'Four modified review-only entry points prove collision guards and realIO port observation, not extra production control algorithms',
   'No hardware, target/HIL, RF, electrical, physical engine or environmental qualification'])
 (OUT/'raw-assessment.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS',CHECKS,flush=True)

if __name__=='__main__':main()
