"""Two declared new-net paths, with native copper collision probes and audit.

This grid search is a layout aid. All-severity native DRC remains authoritative.
It never removes or moves existing objects, pads or footprints.
"""
import hashlib, heapq, json, math, shutil, sys, time
from pathlib import Path
import pcbnew as pcb
ROOT=Path('/home/mark/persospace/esp32-ecu')
sys.path.insert(0,str(ROOT/'scripts'))
from route_a5_idle_interface import geometry
from route_boost_hardware import pads
out=Path(__file__).resolve().parent
path=ROOT/'.cache/engine/boost-hardware-build-011/carrier/esp32-ecu.kicad_pcb'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(path,out/'before.kicad_pcb')
b=pcb.LoadBoard(str(path)); before=sorted(geometry(t) for t in b.GetTracks()); before_pads=pads(b)
step=250000; bucket=2000000

def vector(key):return pcb.VECTOR2I(key[0]*step,key[1]*step)

def route(net,layer,width,start,end):
    radius=pcb.FromMM(width/2+.215)
    index={}; shapes=[]
    for f in b.GetFootprints():
        for pad in f.Pads():
            if pad.GetNetname()!=net and pad.IsOnLayer(layer):shapes.append((pad,pad.GetEffectiveShape(layer)))
    for t in b.GetTracks():
        if t.GetNetname()!=net and t.IsOnLayer(layer):shapes.append((t,t.GetEffectiveShape(layer)))
    for obj,shape in shapes:
        box=obj.GetBoundingBox()
        for x in range((box.GetX()-radius)//bucket,(box.GetRight()+radius)//bucket+1):
            for y in range((box.GetY()-radius)//bucket,(box.GetBottom()+radius)//bucket+1):
                index.setdefault((x,y),[]).append(shape)
    def nearby(a,z):
        seen=set()
        for x in range(min(a.x,z.x)//bucket,max(a.x,z.x)//bucket+1):
            for y in range(min(a.y,z.y)//bucket,max(a.y,z.y)//bucket+1):
                for shape in index.get((x,y),[]):
                    if id(shape) not in seen:
                        seen.add(id(shape));yield shape
    blocked={}
    def free(key):
        if key not in blocked:
            x,y=key;v=vector(key)
            bad=(not 47<=x<=380 or not 47<=y<=200 or (14<=x/4<=44 and 29<=y/4<=40))
            blocked[key]=bad or any(s.Collide(v,radius) for s in nearby(v,v))
        return not blocked[key]
    def link(a,z):
        av,zv=vector(a),vector(z);seg=pcb.SEG(av,zv)
        return not any(s.Collide(seg,radius) for s in nearby(av,zv))
    first=tuple(round(v*4) for v in start);last=tuple(round(v*4) for v in end)
    assert free(first) and free(last),(net,'blocked endpoints')
    queue=[(math.dist(first,last),0,first)];cost={first:0};parent={};began=time.monotonic()
    while queue:
        _,g,a=heapq.heappop(queue)
        if g!=cost[a]:continue
        if a==last:break
        assert time.monotonic()-began<90,(net,'path search timeout')
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
            z=(a[0]+dx,a[1]+dy);ng=g+math.hypot(dx,dy)
            if ng>=cost.get(z,math.inf) or not free(z) or not link(a,z):continue
            parent[z]=a;cost[z]=ng;heapq.heappush(queue,(ng+math.dist(z,last),ng,z))
    else:raise RuntimeError((net,'no path',len(cost)))
    keys=[last]
    while keys[-1]!=first:keys.append(parent[keys[-1]])
    keys.reverse();compact=[keys[0]]
    for i in range(1,len(keys)-1):
        a,z,w=keys[i-1:i+2]
        if (z[0]-a[0],z[1]-a[1])!=(w[0]-z[0],w[1]-z[1]):compact.append(z)
    compact.append(keys[-1]);points=[(k[0]/4,k[1]/4) for k in compact]
    if tuple(points[0])!=tuple(start):points.insert(0,start)
    if tuple(points[-1])!=tuple(end):points.append(end)
    added=[]
    for a,z in zip(points,points[1:]):
        t=pcb.PCB_TRACK(b);t.SetNet(b.FindNet(net));t.SetLayer(layer);t.SetWidth(pcb.FromMM(width))
        t.SetStart(pcb.VECTOR2I(pcb.FromMM(a[0]),pcb.FromMM(a[1])));t.SetEnd(pcb.VECTOR2I(pcb.FromMM(z[0]),pcb.FromMM(z[1])))
        if t.GetStart()==t.GetEnd():continue
        b.Add(t);added.append(geometry(t))
    print(net,pcb.LayerName(layer),len(added),'segments',len(cost),'nodes',flush=True)
    return dict(net=net,layer=pcb.LayerName(layer),width_mm=width,points_mm=points,added_copper=added)

routes=[route('+5V',pcb.In2_Cu,.5,(23.5,16),(45.73,21.749999))]
for layer in (pcb.In2_Cu,pcb.F_Cu,pcb.In1_Cu,pcb.In4_Cu,pcb.B_Cu):
    try:
        routes.append(route('BOOST_CMD',layer,.3,(20.5,16),(75,37)))
        break
    except (RuntimeError,AssertionError) as error:
        print('Unsuccessful layout candidate',pcb.LayerName(layer),str(error),flush=True)
else:raise RuntimeError('No single-layer BOOST path')
assert pads(b)==before_pads
after=sorted(geometry(t) for t in b.GetTracks())
assert all(row in after for row in before)
pcb.ZONE_FILLER(b).Fill(b.Zones());pcb.SaveBoard(str(path),b)
audit=dict(input_board_sha256=sha(out/'before.kicad_pcb'),output_board_sha256=sha(path),tool_sha256=sha(Path(__file__)),
           routes=routes,original_objects_exact=True,pads_exact=True,new_route_antenna_keepout_mm=[14,29,44,40],
           qualification='Layout aid only. Native all-severity checks and independent electrical review required.',physical_outputs_enabled=False)
(out/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
