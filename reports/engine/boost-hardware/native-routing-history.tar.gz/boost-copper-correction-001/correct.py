import hashlib, json, shutil, sys
from pathlib import Path
import pcbnew as pcb
ROOT = Path('/home/mark/persospace/esp32-ecu')
sys.path.insert(0, str(ROOT/'scripts'))
from route_a5_idle_interface import geometry
from route_boost_hardware import pads
out = Path(__file__).resolve().parent
path = ROOT/'.cache/engine/boost-hardware-build-011/carrier/esp32-ecu.kicad_pcb'
result_path = ROOT/'.cache/engine/boost-route-002/carrier/routing-result.json'
source = json.loads(result_path.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(path) == source['output_board_sha256']
shutil.copyfile(path, out/'before.kicad_pcb')
board = pcb.LoadBoard(str(path)); before_pads = pads(board)
retained = sorted(geometry(t) for t in board.GetTracks() if t.IsLocked())
provenance_path = path.parent/'source-provenance.json'
provenance = json.loads(provenance_path.read_text())
assert retained == sorted(provenance['retained_copper'])
shutil.copyfile(provenance_path, out/'before-provenance.json')
objects = {t.m_Uuid.AsString(): t for t in board.GetTracks()}
removed=[]; detached=[]
for uid in ('5cd2bfc7-2a04-4327-ab59-56d2f24cf3ec', '7970be14-15b2-4640-b17c-de898a909464'):
    t = objects[uid]; g = geometry(t)
    assert not t.IsLocked() and t.GetNetname() == 'INJ1_LS'
    assert g in source['added_copper'] and g not in retained
    removed.append(dict(uuid=uid, geometry=g, reason='Rejected new router stitch on inherited injector net'))
    board.RemoveNative(t); detached.append(t)
assert sorted(geometry(t) for t in board.GetTracks() if t.IsLocked()) == retained
assert pads(board) == before_pads
pcb.ZONE_FILLER(board).Fill(board.Zones()); pcb.SaveBoard(str(path), board)
audit = dict(input_board_sha256=sha(out/'before.kicad_pcb'), output_board_sha256=sha(path),
             routing_result_sha256=sha(result_path), tool_sha256=sha(Path(__file__)), removed=removed,
             retained_copper_exact=True, pads_exact=True, physical_outputs_enabled=False)
(out/'audit.json').write_text(json.dumps(audit, indent=2)+'\n')
provenance.setdefault('pruned_added_copper', []).extend(removed)
provenance.setdefault('new_route_corrections', []).append(dict(audit=str(out/'audit.json'), sha256=sha(out/'audit.json')))
provenance_path.write_text(json.dumps(provenance, indent=2)+'\n')
print('Removed only the two recorded unauthorized router additions')
