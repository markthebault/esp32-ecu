"""Freeze the independent review after its final raw audit passes."""
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=json.loads((P/'circuit-full003-audit.json').read_text())
assert audit['passed'] and audit['independently_audited_cases']==30
run=ROOT/'.cache/engine/boost-circuit-full-003'
raw=json.loads((run/'results.json').read_text())
assert all(sha(Path(name))==value for name,value in raw['source_sha256'].items()), 'Final experiment inputs changed'
assert sha(ROOT/'tools/run_boost_circuit.py')==raw['source_sha256'][str(ROOT/'tools/run_boost_circuit.py')]
assert sha(ROOT/'scripts/build_boost_hardware.py')==raw['source_sha256'][str(ROOT/'scripts/build_boost_hardware.py')]
selected=['hardware/a7-boost-interface/esp32-ecu.kicad_pcb','hardware/a7-boost-interface/net_contract.json',
          'hardware/a7-boost-interface/source-provenance.json','hardware/a7-boost-interface/README.md',
          'hardware/a7-boost-interface/bom-grouped.csv','hardware/boost-isolated/isolated.kicad_pcb',
          'hardware/boost-isolated/net_contract.json','hardware/boost-isolated/source-provenance.json',
          'hardware/boost-isolated/README.md','hardware/boost-isolated/bom-grouped.csv',
          'hardware/boost-control/harness-bom.csv','docs/engine-boost-hardware.md',
          'scripts/build_boost_hardware.py','scripts/route_boost_hardware.py','tools/run_boost_circuit.py',
          'firmware/main/engine_target.cpp','firmware/main/app.cpp','firmware/include/ecu/idle_hardware.hpp',
          'firmware/include/ecu/pins.hpp','config/interface-guide.json']
inputs={name:sha(ROOT/name) for name in selected}
assert inputs['hardware/a7-boost-interface/esp32-ecu.kicad_pcb']==raw['source_sha256'][str(ROOT/'hardware/a7-boost-interface/esp32-ecu.kicad_pcb')]
assert inputs['hardware/boost-isolated/isolated.kicad_pcb']==raw['source_sha256'][str(ROOT/'hardware/boost-isolated/isolated.kicad_pcb')]
(P/'reviewed-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
result=dict(
 accepted_for_declared_native_and_conditional_circuit_scope=True,
 physical_release_accepted=False,target_hil_accepted=False,full_ecu_goal_complete=False,
 open_findings=[],
 scope='Final A7/BOOST-DRAFT1 native topology, exact inherited copper/pad accounting, nominal manufacturer footprint bindings, wiring/BOM review and30 declared conditional full-stage experiments with real controller-edge prefixes. Not a vehicle/physical engine, isolation certification, target-timing or full-Speeduino-parity acceptance.',
 native=dict(carrier_retained_parent_objects=3713,accessory_retained_parent_objects=143,
             carrier_named_pads=782,accessory_named_pads=135,
             carrier_new_objects=74,accessory_new_objects=111,
             carrier_width_mm=120,carrier_height_mm=120,accessory_width_mm=90,accessory_height_mm=60,
             original_source_hashes_unchanged=True,all_severity_erc_drc_connectivity_parity_zero=True,
             new_route_antenna_intrusion=False,
             note='Pad/track domain probe also finds no opposite-domain copper pair within5mm on either accessory layer. This is nominal copper geometry, not creepage/safety/isolation certification.'),
 full_stage=dict(cases=30,independently_audited_raw_rows=audit['raw_rows'],
                 source_results_sha256=audit['source_results_sha256'],
                 edge_replays=6,controller_sources=['ours','pinned production Speeduino'],
                 actual_cut_event_preserved=dict(time_us=6030000,channel=9,cause='cut:control'),
                 idle_coverage='Both original input buffers load shared RUN/5V/return. The original idle detector/coil power stage is not simulated in this boost network.',
                 semantics='Input/driver/opto/supervisor/regulator/power-stage and36ohm/30mH coil are authored conditional models, including explicit fixed12V electrical edge replay. No circuit feedback to engine plant.'),
 independent_controls=dict(unknown_case_cli_rejected_before_output=True,
                           actual_cut_witness=True,malformed_replay_controls_rejected=6,
                           grouped_bom_reference_coverage=True,phase1_selected_inventory_reverified=True),
 closed_findings=[
  dict(id='BH5',finding='Two current header opens, unauthorized thin inherited-net stitches and a new ground stub remained.',resolution='Exact unauthorized additions/stub removed, two permitted-net routes completed; final independent native/copper/pad checks pass.'),
  dict(id='BH6',finding='Dispatcher-only replay erased genuine control-cut transitions.',resolution='All actual channel9 changes are retained with validated clocks/sequences, and terminal fixture interventions are rejected. Actual6030000us cut witness and charged/overboost raw windows pass.'),
  dict(id='BH7',finding='Trace channel9 was described as GPIO9 in hardware prose.',resolution='Documentation now separates logical boost-channel9 from the inhibited GPIO45 carrier candidate.'),
  dict(id='BH8',finding='Shared-header silk still read IDLE only.',resolution='Exact single text replacement to IDLE/BOOST independently verified; copper/pads unchanged and final labeled carrier passes native checks.')],
 release_holds=[
  'Physical outputs remain inhibited, GPIO45 unallocated. Actual N16R8 identity, pin/strap/eFuse/reset/download behavior, target scheduler/loading/interrupt/HIL and actual two-device RF/screen tests remain open.',
  'Inherited loaded RUN/Q7/MAIN_IN and full-temperature/fault loading have no guarantee from the conditional500uA proxy or ideal source resistor.',
  'The inspected UCC27524P/P.B and supervisor evidence does not establish all procured-package timing/min/max limits. Driver hysteresis and supervisor maximum assertion behavior remain assumptions/holds.',
  'No physical minimum pulse or width/duty accuracy is assigned. Filters lose short commands and distort transmitted widths; optical threshold/pole and MOSFET capacitance/temperature models are unmeasured.',
  'No actual valve/current rating, R/L/plumbing response, current limit, thermal shutdown, calibrated flyback/supply/EMI/surge or feedback is established. A shorted drain requires an independent actuator disconnect.',
  'Exact passive MPNs, formed/trimmed leads, hand assembly, finished holes/crimps/splices, back-side clearance, live-tab insulation, enclosure/sealing/antenna and printed fit remain unqualified.',
  'The wider cylinder/trigger/VVT/knock/staging/other feature and supported online tuning-application gaps remain outside this checkpoint.' ],
 evidence_sha256={name:sha(P/name) for name in ['copper-audit.json','label-audit.json','native-checks.json',
    'carrier-final-native-check.json','isolation-clearance-probe.json','grouped-bom-audit.json',
    'unknown-case-control.json','replay-controls.json','phase1-inventory-check.json',
    'circuit-full001-audit.json','circuit-full002-audit.json','circuit-full003-audit.json','reviewed-inputs.json']})
(P/'assessment.json').write_text(json.dumps(result,indent=2)+'\n')
readme='''# Independent final boost hardware review

Accepted for the declared native and conditional circuit scope in assessment.json. Physical/target release and the full ECU goal remain unaccepted.

Fresh native checks, exact parent-copper/pad accounting, nominal5mm domain separation, harness mapping and grouped-BOM coverage pass. All30 final full-stage cases and2,318,987 raw rows are independently audited, including six original-source replay windows. The reachable6030000us control cut is preserved; dispatcher-only omission was corrected. Unknown selection and six malformed replay controls reject explicitly.

Both original idle input buffers contribute shared-harness loading. No idle coil or whole-system physical acceptance follows. Conditional optical/driver/supervisor/temperature/coil models do not assign a physical minimum pulse or prove real loaded RUN, target timing, thermal/current, RF, assembly or fit behavior. Read every release hold in assessment.json.

Earlier full001/full002 audits remain retained. The first reviewer terminal-control fixture mistakenly used a fixed11.75s window for an8s source, and correctly hit the out-of-range guard. The retained failed probe was corrected to inject a terminal cause inside a valid window; this was a reviewer fixture error.

The whitelist includes only regular review text/JSON/Python and selected native SVG/PNG views. No vendor PDFs, tool executables or native library bundles are included. External inputs are hash-bound in reviewed-inputs.json and source experiment records.
'''
(P/'README.md').write_text(readme)
files=[]
for path in sorted(P.rglob('*')):
 if path.name=='whitelist.json' or not path.is_file():continue
 assert not path.is_symlink(),path
 assert path.suffix.lower() in {'.json','.py','.md','.log','.svg','.png'},path
 files.append(dict(path=str(path.relative_to(P)),bytes=path.stat().st_size,sha256=sha(path)))
(P/'whitelist.json').write_text(json.dumps(dict(files=files,qualification='Independent review evidence only; no vendor PDFs or linked executable/library bundles.'),indent=2)+'\n')
print(json.dumps(dict(accepted=result['accepted_for_declared_native_and_conditional_circuit_scope'],files=len(files),bytes=sum(x['bytes'] for x in files),full_goal_complete=False),indent=2))
