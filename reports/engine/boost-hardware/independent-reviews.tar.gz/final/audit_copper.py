"""Independent native integer geometry/net/pad audit of the reviewed boost copies."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,math
import pcbnew as pcb
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def geom(t,rename=None):
 net=t.GetNetname();net=(rename or {}).get(net,net)
 if isinstance(t,pcb.PCB_VIA):return ('via',net,t.GetPosition().x,t.GetPosition().y,t.GetWidth(pcb.F_Cu),t.GetDrillValue(),t.TopLayer(),t.BottomLayer())
 if isinstance(t,pcb.PCB_ARC):raise ValueError('Unexpected arc; audit must be extended explicitly')
 return ('track',net,t.GetLayer(),t.GetStart().x,t.GetStart().y,t.GetEnd().x,t.GetEnd().y,t.GetWidth())

def padrow(p):
 return (p.GetPosition().x,p.GetPosition().y,p.GetSize().x,p.GetSize().y,p.GetDrillSize().x,p.GetDrillSize().y,int(p.GetShape()),int(p.GetAttribute()),str(p.GetLayerSet().FmtHex()))

def hits_rect(row,rect):
 if row[0]=='via':
  _,_,x,y,w,*_=row;return rect[0]-w/2<=x<=rect[2]+w/2 and rect[1]-w/2<=y<=rect[3]+w/2
 _,_,layer,x0,y0,x1,y1,w=row;r=w/2
 a,b,c,d=rect[0]-r,rect[1]-r,rect[2]+r,rect[3]+r
 tmin,tmax=0.,1.
 for u,v in [(-(x1-x0),x0-a),(x1-x0,c-x0),(-(y1-y0),y0-b),(y1-y0,d-y0)]:
  if u==0:
   if v<0:return False
  else:
   q=v/u
   if u<0:tmin=max(tmin,q)
   else:tmax=min(tmax,q)
   if tmin>tmax:return False
 return True

def audit(directory,kind,route):
 directory=directory.resolve();boardname='esp32-ecu.kicad_pcb' if kind=='carrier' else 'isolated.kicad_pcb'
 prov=json.loads((directory/'source-provenance.json').read_text());original=ROOT/prov['source']
 for name,value in prov['source_files_sha256'].items():assert sha(original/name)==value,('Old source changed',name)
 for name,value in prov['generator_source_sha256'].items():assert sha(directory/'generator-source'/name)==value,('Frozen generator source',name)
 old=pcb.LoadBoard(str(original/boardname));new=pcb.LoadBoard(str(directory/boardname))
 aliases={} if kind=='carrier' else json.loads((directory/'generator-source/hardware/boost-control/circuit-draft1.json').read_text())['net_renames']
 oldrows=Counter(geom(t,aliases) for t in old.GetTracks());newrows=Counter(geom(t) for t in new.GetTracks())
 retained=Counter(tuple(x) for x in prov['retained_copper']);omitted=Counter(tuple(x) for x in prov['omitted_parent_copper'])
 assert oldrows==retained+omitted,('Parent accounting',kind,oldrows-(retained+omitted),(retained+omitted)-oldrows)
 assert not(retained-newrows),('Retained geometry missing',kind)
 assert Counter(geom(t) for t in new.GetTracks() if t.IsLocked())==retained,('Retained lock/geometry mismatch',kind)
 after=newrows-retained
 routing=json.loads((route/'routing-result.json').read_text())
 assert Counter(tuple(x) for x in routing['protected_copper'])==retained
 pruned=Counter(tuple(x['geometry']) for x in prov.get('pruned_added_copper',[]))
 manual=Counter()
 if kind=='carrier':
  correction=json.loads((ROOT/'.cache/engine/boost-copper-correction-001/audit.json').read_text())
  paths=json.loads((ROOT/'.cache/engine/boost-manual-route-003/audit.json').read_text())
  assert correction['input_board_sha256']==routing['output_board_sha256']
  assert paths['input_board_sha256']==correction['output_board_sha256']
  label=json.loads((ROOT/'.cache/engine/boost-label-correction-001/audit.json').read_text())
  assert label['input_board_sha256']==paths['output_board_sha256']
  assert sha(directory/boardname)==label['output_board_sha256']
  manual=Counter(tuple(x) for r in paths['routes'] for x in r['added_copper'])
  assert {r[1] for r in after} <= {'IDLE_CMD','BOOST_CMD','RUN_5V','GND','+5V'}
 assert Counter(tuple(x) for x in routing['added_copper'])-pruned+manual==after
 assert all(r not in retained for r in pruned)
 assert not any(r[1]=='INJ1_LS' for r in after) if kind=='carrier' else True
 # Contract coverage counts every named physical pad, including declared NCs.
 contract=json.loads((directory/'net_contract.json').read_text());rows=contract['parts']
 declared={r.get('ref',r.get('reference')):r for r in rows}
 fps={f.GetReference():f for f in new.GetFootprints()}
 actual={(f.GetReference(),p.GetNumber()):p for f in new.GetFootprints() for p in f.Pads() if p.GetNumber()}
 expected={(ref,k):v for ref,row in declared.items() for k,v in row['pins'].items()}
 assert actual.keys()==expected.keys(),('Pad set mismatch',set(actual)-set(expected),set(expected)-set(actual))
 for pair,net in expected.items():
  actualnet=actual[pair].GetNetname()
  if net is None:assert actualnet.startswith('unconnected-') or actualnet.startswith('NC_'),('Unexpected connected NC',pair,actualnet)
  else:assert actualnet==net,('Pad net mismatch',pair,actualnet,net)
 for ref,row in declared.items():
  assert fps[ref].GetValue()==row['value'],('Part value mismatch',ref)
  assert str(fps[ref].GetFPID().GetLibItemName())==row['footprint'].split(':')[-1],('Footprint mismatch',ref)
 oldpads={(f.GetReference(),p.GetNumber()):p for f in old.GetFootprints() for p in f.Pads() if p.GetNumber()}
 changed=[]
 if kind=='carrier':
  for key,pad in oldpads.items():
   q=actual.get(key)
   if key[0]=='J21':continue
   assert q is not None and padrow(pad)==padrow(q),('Inherited pad geometry changed',key)
   if key!=('U3','37'):assert pad.GetNetname()==q.GetNetname(),('Inherited net changed',key,pad.GetNetname(),q.GetNetname())
   elif pad.GetNetname()!=q.GetNetname():changed.append(dict(reference='U3',pad='37',old=pad.GetNetname(),new=q.GetNetname()))
  assert set(declared)-{r.get('ref',r.get('reference')) for r in json.loads((original/'net_contract.json').read_text())['parts']}=={'R180'}
  assert expected[('J21','5')]=='BOOST_CMD' and expected[('U3','37')]=='BOOST_CMD'
  assert expected[('R180','1')]=='BOOST_CMD' and expected[('R180','2')]=='GND'
  antenna=[14000000,29000000,44000000,40000000]
  rf=[row for row in after if hits_rect(row,antenna)]
 else:rf=[]
 box=new.GetBoardEdgesBoundingBox();stroke_bounds=[box.GetX(),box.GetY(),box.GetWidth(),box.GetHeight()]
 edge_points=[(pt.x,pt.y) for item in new.GetDrawings() if item.GetLayer()==pcb.Edge_Cuts for pt in (item.GetStart(),item.GetEnd())]
 lo=[min(q[i] for q in edge_points) for i in [0,1]];hi=[max(q[i] for q in edge_points) for i in [0,1]]
 bounds=[*lo,hi[0]-lo[0],hi[1]-lo[1]]
 additions_by_net=Counter()
 for row,n in after.items():additions_by_net[row[1]]+=n
 result=dict(kind=kind,board_sha256=sha(directory/boardname),contract_sha256=sha(directory/'net_contract.json'),old_board_sha256=sha(original/boardname),
  source_files_checked=len(prov['source_files_sha256']),generator_files_checked=len(prov['generator_source_sha256']),old_copper=sum(oldrows.values()),retained_copper=sum(retained.values()),omitted_parent_copper=sum(omitted.values()),new_copper=sum(after.values()),
  added_by_net=dict(additions_by_net),removed_by_net=dict(Counter(r[1] for r in omitted.elements())),
  additions=[list(r) for r in sorted(after.elements())],omissions=[list(r) for r in sorted(omitted.elements())],
  footprint_count=len(fps),contract_parts=len(declared),named_pad_count=len(actual),changed_module_binding=changed,
  copper_layers=new.GetCopperLayerCount(),board_bounds_nm=bounds,stroke_inclusive_board_bounds_nm=stroke_bounds,new_route_hits_provisional_antenna=[list(r) for r in rf],
  physical_outputs_enabled=False,physical_qualification=False)
 assert new.GetCopperLayerCount()==(6 if kind=='carrier' else 2)
 assert bounds[2:]==([120000000,120000000] if kind=='carrier' else [90000000,60000000])
 assert not rf,('New route antenna intrusion',rf)
 return result

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--snapshot',type=Path,default=ROOT/'hardware');ap.add_argument('--routes',type=Path,default=ROOT/'.cache/engine/boost-route-002');ap.add_argument('--output',type=Path,default=P/'copper-audit.json')
 a=ap.parse_args();records=[audit(a.snapshot/d,k,a.routes/k) for k,d in [('carrier','a7-boost-interface'),('accessory','boost-isolated')]]
 a.output.write_text(json.dumps(records,indent=2)+'\n')
 for row in records:print(json.dumps({k:v for k,v in row.items() if k not in ['additions','omissions']},indent=2))
