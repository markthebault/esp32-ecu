"""Independent raw waveform, source binding and edge-prefix audit.

This checks declared conditional experiments, not vendor device guarantees.
"""
import argparse,gzip,hashlib,json,math
from pathlib import Path
import numpy as np

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ROOT=Path(__file__).resolve().parents[3]

def audit(directory):
    directory=directory.resolve()
    report=json.loads((directory/'results.json').read_text())
    assert report['source_unchanged'] and report['physical_execution'] is False
    assert report['circuit_engine_feedback'] is False
    assert report['validation']['passed']
    for name,value in report['source_sha256'].items():
        frozen=directory/'source-snapshot'/Path(name).relative_to(ROOT)
        assert sha(frozen)==value,(name,'snapshot bytes')
    cases={r['case']['name']:r for r in report['results']}
    assert len(cases)==len(report['results'])
    independent=[]
    for name,r in cases.items():
        d=directory/name;plain=d/'trace.tsv';compressed=d/'trace.tsv.gz'
        assert hashlib.sha256(gzip.decompress(compressed.read_bytes())).hexdigest()==sha(plain)
        a=np.loadtxt(plain,skiprows=1);t=a[:,0];c=r['case']
        assert a.shape==(r['rows'],25) and np.all(np.isfinite(a)) and np.all(np.diff(t)>=0)
        stop=.8 if c['cold'] else .2501 if r['controller_edge_replay'] else .012
        assert abs(float(t[-1])-stop)<1e-8
        late=t>stop-.0005
        avg=lambda col:float(np.trapezoid(a[late,col],t[late])/(t[late][-1]-t[late][0]))
        coil=avg(8);gate=avg(2)
        assert math.isclose(coil,r['final_coil_a'],abs_tol=1e-12)
        assert math.isclose(gate,r['final_gate_v'],abs_tol=1e-12)
        high=a[:,6]>1.5;starts=int(high[0])+int(np.count_nonzero(high[1:]&~high[:-1]))
        assert starts==r['observed_source_high_periods']
        replay=r['controller_edge_replay']
        replay_events=[]
        if replay:
            path=Path(c['edge_run'])
            assert all(sha(path/n)==v for n,v in replay['source_sha256'].items())
            source=[json.loads(s) for s in (path/'edges.jsonl').read_text().splitlines()]
            a_us,b_us=[round(v*1e6) for v in replay['interval_s']]
            physical=[x for x in source if x['ch']==9 and not x['cause'].startswith('fixture_') and x['cause']!='cut:simulation_end']
            replay_events=[x for x in physical if a_us<x['time_us']<=b_us]
            assert replay_events==replay['replayed_boost_edges'],(name,'actual channel9 source prefix differs')
            initial=next((x['high'] for x in reversed(physical) if x['time_us']<=a_us),False)
            assert initial==replay['initial_high']
            assert starts==int(initial)+sum(x['high'] for x in replay_events)
        independent.append(dict(name=name,rows=len(t),final_time_s=float(t[-1]),final_coil_a=coil,
            final_gate_v=gate,source_high_periods=starts,peak_coil_a=float(np.max(np.abs(a[:,8]))),
            peak_forward_pwm_led_a=float(np.max(a[:,9])),
            replay_non_dispatcher_events=[x for x in replay_events if x['cause']!='dispatcher'],
            trace_sha256=sha(plain),compressed_sha256=sha(compressed),deck_sha256=sha(d/'circuit.cir')))
    # Controls must show both the deenergizing paths and the explicitly unsafe
    # bridged-return/shorted-drain cases. These are conditional model results.
    r={x['name']:x for x in independent}
    assert .31<r['warm']['final_coil_a']<.35 and r['warm']['final_gate_v']>4
    for name in ['command_low','run_low','command_wire_open','run_wire_open','trunk_power_open',
                 'trunk_return_open','boost_stub_power_open','boost_stub_return_open',
                 'actuator_power_open','rail_drop','late_supervisor']:
        assert abs(r[name]['final_coil_a'])<.001 and abs(r[name]['final_gate_v'])<.1,name
    assert r['drain_short']['final_coil_a']>.2 and abs(r['drain_short']['final_gate_v'])<.1
    assert cases['return_bridge_negative']['mean_late_carrier_return_a']>.1
    assert cases['actuator_return_open']['mean_late_carrier_return_a']<.05
    assert cases['cold']['first_gate_above4v_s']>.15
    for name in ['hotplug_open','hotplug_cap_sensitivity']:
        assert cases[name]['conditional_nor_high_s']==0 and cases[name]['maximum_gate_v']<.1
    assert cases['pulse_1us']['maximum_gate_v']<.1
    assert cases['pulse_100us']['conditional_nor_high_s']>0
    return dict(passed=True,source_results_sha256=sha(directory/'results.json'),
                independently_audited_cases=len(independent),raw_rows=sum(x['rows'] for x in independent),
                records=independent,qualification='Numerical/raw trace and actual edge-prefix consistency only; conditional authored device models, no physical/target/fit/pulse guarantee.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=audit(a.directory);a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
