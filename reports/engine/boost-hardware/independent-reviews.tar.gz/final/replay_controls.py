"""Independent real cut-event witness and malformed replay controls."""
import hashlib,json,shutil,sys,tempfile
from dataclasses import replace
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import run_boost_circuit as model
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=sha(model.__file__)
source=ROOT/'.cache/engine/boost-coupled-study-004/charged-map-rail-ours/run'
result=json.loads((source/'result.json').read_text())
events=[json.loads(x) for x in (source/'edges.jsonl').read_text().splitlines()]
case=model.Case('independent_cut_witness',edge_run=str(source),edge_start_s=5.9)
wave=model.edge_waveform(case)
cut=[x for x in wave['replayed_boost_edges'] if x['cause']=='cut:control']
assert len(cut)==1 and cut[0]['time_us']==6030000 and cut[0]['high'] is False
rows=[dict(name='actual_reachable_cut',accepted=True,cut_event=cut[0])]
controls=[('duplicate_sequence','Unordered source sequence'),('reversed_clock','Unordered source clock'),
          ('non_boolean_state',''),('repeated_boost_state','Invalid boost transition history'),
          ('injected_terminal_cause','fixture terminal intervention')]
for name,expected in controls:
    changed=json.loads(json.dumps(events))
    if name=='duplicate_sequence':changed[1]['sequence']=changed[0]['sequence']
    elif name=='reversed_clock':changed[1]['time_us']=changed[0]['time_us']-1
    elif name=='non_boolean_state':changed[1]['high']=int(changed[1]['high'])
    elif name=='repeated_boost_state':
        selected=[i for i,x in enumerate(changed) if x['ch']==9]
        changed[selected[1]]['high']=changed[selected[0]]['high']
    else:
        next(x for x in changed if x['ch']==9 and x['time_us']==6030000)['cause']='fixture_halt'
    with tempfile.TemporaryDirectory() as d:
        d=Path(d);(d/'result.json').write_text(json.dumps(result))
        (d/'edges.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in changed))
        try:model.edge_waveform(replace(case,edge_run=str(d)))
        except AssertionError as e:
            assert expected in str(e),(name,str(e));rows.append(dict(name=name,rejected=True,message=str(e)))
        else:raise AssertionError((name,'malformed replay accepted'))
for name,start,expected in [('window_out_of_bounds',result['duration_s'],'Replay window exceeds')]:
    try:model.edge_waveform(replace(case,edge_start_s=start))
    except AssertionError as e:
        assert expected in str(e),(name,str(e));rows.append(dict(name=name,rejected=True,message=str(e)))
    else:raise AssertionError((name,'malformed replay accepted'))
assert sha(model.__file__)==before
shutil.copyfile(model.__file__,P/'reviewed-run_boost_circuit.py')
report=dict(passed=True,model_sha256=before,source_sha256={n:sha(source/n) for n in ('result.json','edges.jsonl')},
            cases=rows,scope='Actual control-cut edge preservation and malformed-source rejection; no physical waveform qualification.')
(P/'replay-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
