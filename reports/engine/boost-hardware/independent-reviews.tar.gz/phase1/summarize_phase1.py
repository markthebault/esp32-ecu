from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
base=json.loads((P/'input-final-fitted-results.json').read_text())['cases']
follow=json.loads((P/'input-final-followups.json').read_text())
dc=json.loads((P/'tn-dc-results.json').read_text())
assert len(base)==95 and len(follow['cases'])==6
assert all(all(row['terminal_control_low']) for row in base+follow['cases'])
assert all(len(row['observed_source_high_spans_s'])==3 for row in base+follow['cases'] if row['case']['mode']=='pulse')
hot=[r for r in base if r['case']['mode']=='hotplug']
assert len(hot)==16
assert all(max(r['maximum_pwm_forward_a'],r['maximum_run_forward_a'])<.00025 for r in hot)
assert all(not any(r['control_high_spans_s'].values()) for r in hot)
for row in base:
 c=row['case']
 if c['mode']=='pulse' and c.get('width_us') in (100,200,500) and not c['name'].startswith('prior'):
  assert all(len(v)==3 for v in row['control_high_spans_s'].values())
assert dc['fits_pass']['fit_room_low'] and dc['fits_pass']['fit_room_high']
initial={
 'hardware/boost-control/architecture.json':'ee46cfe1639ca8fbfc7815aed2a4addcf18d29a4a71ab58f8727f882c893e374',
 'hardware/a6-flex-rgb/net_contract.json':'2d2d8883d8035c43bde5d7781e491ee5b8cb470fb0c87e3c80975175e99b80e2',
 'hardware/idle-isolated/net_contract.json':'32bd3435b398d603d37606f78b65d9c9b06210ab307ba9b48bf33bb1356786bf',
 'hardware/idle-isolated/README.md':'37367f5345030da9882ef68325260ac981a88d1b6992cd1e4cf0143aaec29dca',
 'tools/run_idle_circuit.py':'aece1686d6f33c343f31d06f7d9ac566f8dcdf973b3d85ffbd6db7d041ecf711'}
for name,value in initial.items():
 assert sha(ROOT/name)==value,name
 target=P/'context'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
(P/'context-manifest.json').write_text(json.dumps(initial,indent=2)+'\n')
final_current=[r for r in base if not r['case']['name'].startswith('prior4')]
result=dict(accepted_for_declared_input_experiments=True,physical_release_accepted=False,cad_reviewed=False,full_ecu_goal_complete=False,
 scope='Phase1: primary-source architecture review, input-only conditional ngspice networks, finite25C scalar fits and retained negative/adverse probes. Not a complete accessory, isolation-return, CAD, engine or physical qualification.',
 tested_candidate=dict(command_series_ohm=1000,run_series_ohm=4700,gate_source_ohm=10000,gate_source_f=100e-9,
                       led_supply_ohm=47,led_supply_bulk_f=2.2e-6,led_supply_bypass_f=100e-9,led_series_ohm=357),
 independent_results=dict(completed_main_cases=95,completed_followup_cases=6,main_rows=sum(r['rows'] for r in base),total_rows=sum(r['rows'] for r in base+follow['cases']),
                          source_pulses='All pulse rows observe3 complete actual absolute-time PWL pulses at their declared frequency; sources/control are low at observation end.',
                          hotplug_cases=16,maximum_hotplug_forward_a=max(max(r['maximum_pwm_forward_a'],r['maximum_run_forward_a']) for r in hot),
                          no_hotplug_control_high=True,
                          pulse_transfer='100/200/500us transfer3 conditional pulses in the declared fits/hypotheses at10/24/50Hz.40us andshorter do not universally transfer; waveform widths are distorted.',
                          maximum_command_wired_low_delay_s=max(r['release_delay_s']['0.000251'] for r in base if r['case']['mode']=='release' and r['case']['signal']=='command' and r['case']['release']=='wired_low'),
                          maximum_run_wired_low_delay_s=max(r['release_delay_s']['0.000251'] for r in base if r['case']['mode']=='release' and r['case']['signal']=='run' and r['case']['release']=='wired_low'),
                          maximum_signal_open_delay_s=max(r['release_delay_s']['0.000251'] for r in base if r['case']['mode']=='release' and r['case']['release']=='wire_open'),
                          maximum_power_open_delay_s=max(r['release_delay_s']['0.000251'] for r in base if r['case']['mode']=='power_open'),
                          current_maxima_a={k:max(r[k] for r in final_current) for k in ['maximum_source_current_a','maximum_gpio_source_a','maximum_run_source_a']},
                          finite_refinement_max_timing_difference_s=max(v for row in follow['refinement'] for v in row['timing_difference_s'].values())),
 corrected_review_findings=[
  dict(id='BH1',finding='Carrier input power slew could emit LED flashes despite off input MOSFETs; a hard5mA-only optical transfer hid the uncertainty band.',resolution='Input gate bias/filter plus the47R/2.2uF LED supply passes16 finite hotplug hypotheses. Fitted100k/no-filter negatives still emit conditional highs at2mA. Physical guarantees remain open.'),
  dict(id='BH2',finding='VH4 valve connector collided with carrierJ8.',resolution='Parent selectedVH6, two contacts only. Actual new CAD/mating fit still needs review.'),
  dict(id='BH3',finding='Earlier Level1 fits used zero-Vds derivative approximations and failed actual finite-current datasheet points.',resolution='Retained as adverse sensitivities; two new25C fits pass actual external-terminal DC points and1mA threshold in real ngspice.'),
  dict(id='BH4',finding='Repeated-PULSE probes skipped narrow middle pulses and early observation windows could censor tails.',resolution='Rejected probes retained. Accepted input scope uses explicit absolute PWL sources, source-rise assertions, full pulse/release windows and terminal-low checks.')],
 remaining_release_holds=[
  'No exact electrical guarantee is established for actual procuredUCC27524P/P.B by the inspected current primary tables;MCP14E7has documentedPDIP/enable but no statedUVLO upgrade.',
  'InheritedRUN/Q7current, loadedMAIN_IN, startup/fault and temperature behavior remain unqualified. A conditional static500uA estimate is not a5V/full-temperature bound.',
  'Physical minimum pulse is null. Pulse widths and duty differ from digital requests;100us finite transfer is not a physical minimum guarantee.',
  'Low-bias/hot capacitance, actual optical threshold/delay, diode/MOSFET/regulator/supervisor behavior, lead/harness/PCB parasitics and electromagnetic transients are not manufacturer models or measured.',
  'Input-only experiments establish no isolation-return current behavior or complete power-stage/coil behavior. Full circuit and CAD review remain pending.',
  'Actual module identity/strapping/eFuses, thermal/current/valve/plumbing/cutoff, enclosure/antenna/sealing and physical/HIL tests remain open. Physical outputs must stay inhibited.'],
 evidence={name:sha(P/name) for name in ['probe_final_input_fitted.py','input-final-fitted-plan.json','input-final-fitted-results.json','final_followups.py','input-final-followups.json','probe_tn_dc.py','tn-dc-results.json','probe_static_final.py','conditional-static-budget-final.json']})
(P/'phase1-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['accepted_for_declared_input_experiments','physical_release_accepted','cad_reviewed','independent_results']},indent=2))
