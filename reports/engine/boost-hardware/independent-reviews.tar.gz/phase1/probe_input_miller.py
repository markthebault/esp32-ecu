import json,subprocess,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BIN=ROOT.parents[0]/'flex-frontend-review/toolchain/ngspice'
records=[]
for resistance in [100000,22000,10000,2200]:
 for rise_s in [1e-8,1e-7,1e-6,1e-5,1e-4]:
  name=f'gs{resistance}_rise{rise_s:g}'
  out=ROOT/'input-miller-002'/name;out.mkdir(parents=True,exist_ok=False)
  deck=f"""Proposed isolated LED MOSFET input, warm detector-side, both signals disconnected
* Authored sensitivity model, NOT vendor macro-model or physical bound.
* TN0702 minimum threshold0.5V, max Ciss200pF, max Crss60pF; Rds5ohm@2V fit.
* Both input branches identical; this row models each branch separately.
.options reltol=1e-6 abstol=1e-12 vntol=1e-8 method=gear
V5 supply 0 PWL(0 0 10u 0 {10e-6+rise_s} 5 600u 5)
Rsource supply cin5 .5
C9 cin5 0 100n
Rled cin5 anode 357
Vled anode la 0
Dled la drain LED
M1 drain gate 0 0 NM L=1u W=1u
Cgd drain gate 60p
Cgs gate 0 140p
Cds drain 0 65p
Rseries openpin gate 1000
Ropen openpin 0 1e12
Rgs gate 0 {resistance}
Dnegative 0 gate DCLAMP
.model NM NMOS(level=1 Vto=.5 Kp=.133333 Rd=0 Rs=0 Lambda=0)
.model LED D(Is=1e-18 N=1.5 Rs=3 Cjo=34p)
.model DCLAMP D(Is=1e-9 N=1.7 Rs=.2 Cjo=5p)
.control
set noaskquit
set wr_singlescale
set wr_vecnames
set numdgt=17
tran 10n 200u 0 10n uic
wrdata trace.tsv v(cin5) v(gate) v(drain) i(Vled)
quit
.endc
.end
"""
  (out/'probe.cir').write_text(deck)
  with (out/'ngspice.log').open('w') as stream:r=subprocess.run([str(BIN.resolve()),'-b','probe.cir'],cwd=out,stdout=stream,stderr=subprocess.STDOUT,timeout=30)
  if r.returncode:raise RuntimeError(name)
  rows=[]
  with (out/'trace.tsv').open() as stream:
   next(stream)
   for line in stream:
    row=list(map(float,line.split()));rows.append(row)
  # time,cin5,gate,drain,IF
  selected=[r for r in rows if r[4]>.005]
  record=dict(name=name,rgs_ohm=resistance,source_rise_s=rise_s,max_gate_v=max(r[2] for r in rows),max_led_current_a=max(r[4] for r in rows),
              span_over_5ma_s=selected[-1][0]-selected[0][0] if selected else 0,
              source_sha256=hashlib.sha256(deck.encode()).hexdigest(),rows=len(rows))
  records.append(record)
(ROOT/'input-miller-results.json').write_text(json.dumps(dict(qualification='Independent conditional Miller sensitivity. Not a physical guarantee or exact TN0702 macro-model.',cases=records),indent=2)+'\n')
print(json.dumps(records,indent=2))
