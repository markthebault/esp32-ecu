from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent
source=BASE/'probe_input_candidate.py'
space={'__file__':str(source)}
exec(source.read_text().split('\ncases=[]')[0],space)
original=space['circuit']
def circuit(case):
 deck,stop=original(case)
 lines=deck.splitlines()
 i=next(i for i,line in enumerate(lines) if line.startswith('tran '))
 tokens=lines[i].split();tokens[1]=tokens[4]=str(case['maximum_step_s']);lines[i]=' '.join(tokens)
 return '\n'.join(lines)+'\n',stop
space['circuit']=circuit
cases=[dict(name='refined_adverse_min17p6u',mode='hotplug',profile='hot_assumed',caps='larger_low_bias_hypothesis',rise_s=1e-8,power_r_ohm=10,power_c_f=17.6e-6+100e-9,maximum_step_s=.05e-6),
       dict(name='refined_source2us_50hz',mode='pulse',profile='room_high',gpio_v=2.4,hz=50,width_us=2,maximum_step_s=.1e-6)]
rows=[space['execute'](case) for case in cases]
plan=json.loads((BASE/'input-candidate-plan-002.json').read_text());main=json.loads((BASE/'input-candidate-results-002.json').read_text())['cases']
comparison=[]
for fine,coarse_name in zip(rows,['rc_hotplug_hot_assumed_larger_low_bias_hypothesis_1.76e-05f_1e-08s','pulse_room_high_2.4v_50hz_2us']):
 coarse=next(r for r in main if r['case']['name']==coarse_name)
 d=dict(coarse=coarse_name,fine=fine['case']['name'],max_gate_difference_v=abs(coarse['maximum_gate_v']-fine['maximum_gate_v']),
        maximum_forward_difference_a=abs(coarse['maximum_pwm_forward_a']-fine['maximum_pwm_forward_a']),span_differences_s={})
 for threshold in space['THRESHOLDS']:
  key=str(threshold);a=coarse['control_high_spans_s'][key];b=fine['control_high_spans_s'][key]
  assert len(a)==len(b)
  error=max([abs(x-y) for ar,br in zip(a,b) for x,y in zip(ar,br)],default=0)
  assert error<.1e-6,(coarse_name,key,error)
  d['span_differences_s'][key]=error
 comparison.append(d)
result=dict(results=rows,comparison=comparison,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),refinement_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),qualification='Finite recheck of retained adverse and narrow pulse witnesses. No uniform convergence or physical transfer guarantee.')
(BASE/'input-refinement-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(comparison,indent=2))
