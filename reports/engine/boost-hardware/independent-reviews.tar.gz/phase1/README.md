# Boost architecture and input review, phase 1

This independent review covers the proposed isolated input interface, primary-source electrical checks and conditional input-only ngspice experiments. Physical release, complete power-stage/return behavior, native CAD and the full ECU goal remain pending.

The final candidate uses command1k, RUN4k7,10k gate-source bias,100nF film gate-source filtering, and a47R/2.2uF/100nF LED-supply filter. R17 is5%; the gate resistors are1% and bulk capacitor20%. The current ZH4 connector proposal and rejected PA4 source are bound separately. Their reviewed electrical component values and pin maps agree. The parent's placement trials, manufacturer mating dimensions and actual printed/assembled fit are separate evidence.

## Results

The retained fitted study contains95 initial cases, four finite step refinements, two working negative controls and four actualR17-tolerance witnesses. Full source pulses and final low states are checked. Earlier models, skipped-PULSE probes and censored observations remain retained as rejected/adverse evidence.

- All16 initial final-candidate hotplug hypotheses, plus the two actualR17−5% cases, remain below250uA LED forward current and produce no conditional control highs. The hottest/larger low-bias capacitance case is an authored hypothesis, not a measured component bound.
-100/200/500us source pulses transfer three conditional pulses at10/24/50Hz in the declared fits.40us and shorter do not transfer universally. Physical minimum pulse remains null.
- Source100us at24Hz/2.4V becomes approximately52.7us at the high fit/5mA hypothesis,122.7us at the low fit/5mA hypothesis, or290us in the declared hot/251uA hypothesis. Pulse count alone cannot establish electrical duty or valve action.
- The largest modeled command-wired-low, RUN-wired-low and signal-open release times are0.267/0.966/3.000ms. ActualR17-tolerance power-wire-open persistence reaches1.981ms. These input-network times include stored charge; they are separate from inductive-coil decay.
- The four finite refinement checks change observed edge times by at most12.1ns. This is a finite recheck, not a uniform convergence or physical-timing proof.

The latest static bound uses actualR17±5%: symmetric LED current6.03..12.43mA under its stated VF/Rds/source assumptions; ideal5.5V inrush123.2mA, peak resistor power0.678W and maximum capacitor stored energy41.4uJ. Actual source impedance, resistor/capacitor selection, rail disturbance and thermal behavior remain unqualified.

## Source review

Microchip TN0702 DS20005941A table3-1 maps1source/2gate/3drain. Its three on-resistance points are specified at25C with finite drain currents. The two final authored Level1 fits are checked at those actual currents and the diode-connected1mA threshold in real ngspice. The former derivative approximations fail one or more table limits and remain labelled adverse sensitivities. A scalar fit is not a manufacturer macro-model or a thermal/AC guarantee.

Vishay84732 guarantees an off-input region through250uA and an on region from5mA; its threshold is2mA typical and5mA maximum. A5mA-only transfer hid the earlier input-power flashes. The final experiments retain251uA/2mA/5mA optical hypotheses and two fitted100k/no-filter negatives that still produce conditional highs at2mA.

SN74HCT08's output characterization does not close the inherited RUN/Q7 issue. AtRUN3.84V, assuming500uA Q7 input and stated resistor extremes gives MAIN_IN2.985V. That current bound is specified at10V/25C, and the Q7 threshold is not its5V on-resistance guarantee. The new input's static/transient loading is recorded separately; physical loaded RUN, MAIN_IN, faults, startup and temperature remain holds.

The inspected UCC27524 primary electrical tables do not establish the actual procuredP/P.B guarantees. The supposed legacyG URL redirects toH and its cached body isH. MCP14E7 explicitly documents PDIP/enable but provides no stated UVLO upgrade. The exact driver guarantee remains a release item.

Primary URLs and downloaded-file identities are in the manufacturer source manifests. ST/JST fetch failures are recorded rather than replaced by invented PDF hashes. Public primary references include:

- [Microchip TN0702](https://ww1.microchip.com/downloads/en/DeviceDoc/TN0702-N-Channel-Enhancement-Mode-Vertical-DMOS-FET-Data-Sheet-20005941A.pdf)
- [Vishay6N137](https://www.vishay.com/docs/84732/6n137_vo2601_vo2611.pdf)
- [TI SN74HCT08](https://www.ti.com/lit/ds/symlink/sn74hct08.pdf)
- [ST VNP35N07-E](https://www.st.com/resource/en/datasheet/vnp35n07-e.pdf)
- [TI UCC27524](https://www.ti.com/lit/ds/symlink/ucc27524.pdf)
- [Microchip MCP14E7](https://ww1.microchip.com/downloads/aemDocuments/documents/APID/ProductDocuments/DataSheets/MCP14E6-7-8-Data-Sheet-DS20005006.pdf)

## Evidence and reproduction

`phase1-final-assessment.json` is the final phase1 verdict. `phase1-assessment.json` is the earlier101-case record; actualR17-tolerance and connector bindings are appended in the final record. Neither accepts native CAD or physical operation.

`phase1-whitelist.json` includes complete scripts, plans, case decks/logs/results, raw identities and representative exact waveform windows. The full unthinned vectors remain in the local cache. `waveform-windows.json` records exact retained row ranges and omitted constant-control spans; window rows are not rounded or resampled. Only the representative windows listed in the whitelist are included in the compact publication selection. Four additional tolerance traces are included complete. Manufacturer PDFs and native executables are excluded from publication.

To rerun, copy the relevant scripts into a new empty directory beneath`.cache/engine`, with the recorded ngspice45.2 executable available at the recorded relative path. Existing case directories are deliberately rejected. Run `probe_tn_dc.py`, `probe_final_input_fitted.py`, `final_followups.py` and `probe_actual_tolerance.py` in that order. Program, binary and deck hashes accompany the results. The input probes do not execute engine firmware or establish isolation-return current behavior.

Actual low-bias/hot capacitance, optical delays/thresholds, physical minimum pulse and duty, supervisor/regulator behavior, inductive switch/valve action, complete returns, PCB/harness parasitics, exact parts, module strapping, enclosure/RF/sealing and HIL measurements remain open. Physical outputs remain inhibited.
