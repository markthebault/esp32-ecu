from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
main=json.loads((P/'input-final-fitted-results.json').read_text())['cases']
follow=json.loads((P/'input-final-followups.json').read_text())['cases']
tolerance=json.loads((P/'input-actual-tolerance-results.json').read_text())['cases']
records=main+follow+tolerance
assert len(records)==105 and all(all(r['terminal_control_low']) for r in records)
# Freeze both connector proposals without claiming a native/physical review.
bindings={}
for label,directory in [('pa4-rejected',ROOT/'.cache/engine/boost-hardware-pa4-rejected-source-001'),('zh4-current',ROOT/'hardware/boost-control')]:
 for name in ['circuit-draft1.json','interface-draft2.json']:
  source=directory/name;target=P/'source-binding'/label/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  bindings[str(target.relative_to(P))]=dict(original=str(source),sha256=sha(source))
a=json.loads((P/'source-binding/pa4-rejected/circuit-draft1.json').read_text())['circuit']
b=json.loads((P/'source-binding/zh4-current/circuit-draft1.json').read_text())['circuit']
a={r['reference']:r for r in a['parts']};b={r['reference']:r for r in b['parts']}
for ref in ['R1','R2','R3','R4','R5','R6','R17','C9','C11','C12','C13','Q2','Q3','J3']:
 for field in ['value','pins']:
  assert a[ref][field]==b[ref][field],(ref,field)
assert a['J1']['pins']==b['J1']['pins']
for ref,value in {'R1':'1k 1%','R2':'4k7 1%','R5':'10k 1%','R6':'10k 1%','R17':'47R 1W 5%','C11':'100nF FILM 25V+ 5%','C12':'100nF FILM 25V+ 5%','C13':'2.2uF 16V 20%'}.items():assert b[ref]['value']==value
(P/'proposal-source-bindings.json').write_text(json.dumps(dict(files=bindings,electrical_part_values_and_pin_maps_equal=True,connector_change='PA4 proposal rejected by author placement trials; ZH4 draft is bound as a new proposal. Native/physical mating/fit acceptance remains pending.'),indent=2)+'\n')
budget=dict(r17_tolerance=.05,minimum_led_a=(4.5-1.7)/(357*1.01+5+2*47*1.05),maximum_zero_vf_led_a=5.5/(357*.99+2*47*.95),
            maximum_ideal_inrush_a=5.5/(47*.95),maximum_ideal_initial_resistor_w=5.5**2/(47*.95),maximum_capacitor_stored_j=.5*(2.64e-6+.1e-6)*5.5**2,
            qualification='Corrected actualR17±5% static bounds. This supersedes the earlier±1%R17 arithmetic, not its retained input/trace evidence. TN/VF/current/temp and physical limitations remain open.')
(P/'actual-r17-budget.json').write_text(json.dumps(budget,indent=2)+'\n')
summary=json.loads((P/'phase1-assessment.json').read_text())
summary['phase']='Final architecture/input phase; actualR17±5% and PA-to-ZH source binding appended.'
summary['independent_results'].update(completed_total_cases=105,total_rows=sum(r['rows'] for r in records),actual_tolerance_cases=4,
 maximum_hotplug_forward_a=max(max(r['maximum_pwm_forward_a'],r['maximum_run_forward_a']) for r in records if r['case']['mode']=='hotplug' and not r['case']['name'].startswith('fitted_negative')),
 maximum_power_open_delay_s=max(r['release_delay_s']['0.000251'] for r in records if r['case']['mode']=='power_open'))
summary['source_bindings_sha256']=sha(P/'proposal-source-bindings.json')
summary['actual_r17_budget_sha256']=sha(P/'actual-r17-budget.json')
summary['connector_status']='Current ZH4 proposal is electrically bound to the reviewed numerical values; geometry/native/CAD review is pending.'
summary['evidence'].update({n:sha(P/n) for n in ['probe_actual_tolerance.py','input-actual-tolerance-results.json','waveform-windows.json']})
(P/'phase1-final-assessment.json').write_text(json.dumps(summary,indent=2)+'\n')
# Every full raw identity is retained even where only selected windows publish.
identities=[]
for r in records:
 folder=P/'input-final-fitted-001'/r['case']['name']
 assert sha(folder/'trace.tsv')==r['trace_sha256']
 identities.append(dict(case=r['case']['name'],raw_sha256=r['trace_sha256'],raw_bytes=(folder/'trace.tsv').stat().st_size,
                        rows=r['rows'],gzip_sha256=sha(folder/'trace.tsv.gz'),gzip_bytes=(folder/'trace.tsv.gz').stat().st_size))
(P/'all-fitted-waveform-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
# The whitelist deliberately includes a representative subset of exact windows.
selected=['pulse_room_high_2p4v_24hz_40us','pulse_room_high_2p4v_24hz_100us','pulse_room_low_2p4v_24hz_100us',
          'pulse_hot_assumed_2p4v_24hz_100us','hotplug_hot_larger_low_bias_hypothesis_5.5v_1e-08s','film_8e-08f_hotplug',
          'release_hot_assumed_command_wired_low','release_hot_assumed_run_wired_low','release_hot_assumed_run_wire_open',
          'power_open_2.64e-06f_5.5v','fitted_negative100k_1e-08s','fitted_negative100k_1e-06s','prior4p7n_fitted_24hz']
files=set(P.glob('*.py'))|set(P.glob('*.json'))|{P/'README.md'}
files.update(p for directory in ['context','source-binding'] for p in (P/directory).rglob('*') if p.is_file())
for r in records:
 folder=P/'input-final-fitted-001'/r['case']['name']
 files.update(folder/name for name in ['probe.cir','ngspice.log','result.json'])
files.update(P/'publication-waveforms'/(name+'.tsv.gz') for name in selected)
files.update(P/'input-final-fitted-001'/r['case']['name']/'trace.tsv.gz' for r in tolerance)
files.update((P/'tn-dc-002'/name) for name in ['probe.cir','ngspice.log'])
# A manifest is not self-hashed; parent packets may bind it externally.
files={p for p in files if p.name not in ['phase1-whitelist.json','whitelist.json']}
rows=[dict(path=str(p.relative_to(P)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)]
(P/'phase1-whitelist.json').write_text(json.dumps(dict(files=rows,selected_exact_windows=selected,full_raw_locally_retained=True,qualification='Phase1 source/evidence only; no native executables or manufacturer PDF redistribution. Most unthinned vectors remain hash-bound locally; selected exact waveform windows and4 complete tolerance traces are included.'),indent=2)+'\n')
print(json.dumps(dict(files=len(rows),bytes=sum(r['bytes'] for r in rows),cases=len(records),full_rows=sum(r['rows'] for r in records),source_bindings=bindings,actual_r17_budget=budget),indent=2))
