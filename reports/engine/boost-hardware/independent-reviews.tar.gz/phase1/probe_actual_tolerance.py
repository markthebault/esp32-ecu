from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
source=P/'probe_final_input_fitted.py';space={'__file__':str(source)}
exec(source.read_text().split('\ncases=[]')[0],space)
original=space['circuit']
def circuit(case):
 deck,stop=original(case)
 if 'run_v' in case:
  assert deck.count('Vrun runsrc 0 DC 5')==1
  deck=deck.replace('Vrun runsrc 0 DC 5',f'Vrun runsrc 0 DC {case["run_v"]}')
 return deck,stop
space['circuit']=circuit
cases=[
 dict(name='actual5pct_hotplug_95n',mode='hotplug',profile='hot_assumed',caps='larger_low_bias_hypothesis',rise_s=1e-8,carrier_v=5.5,power_r_ohm=47*.95,power_c_f=1.76e-6+100e-9,rgs_ohm=10100,external_cgs_f=95e-9),
 dict(name='actual5pct_hotplug_80n_sensitivity',mode='hotplug',profile='hot_assumed',caps='larger_low_bias_hypothesis',rise_s=1e-8,carrier_v=5.5,power_r_ohm=47*.95,power_c_f=1.76e-6+100e-9,rgs_ohm=10100,external_cgs_f=80e-9),
 dict(name='actual5pct_power_open',mode='power_open',power_r_ohm=47*.95,power_c_f=2.64e-6+100e-9,carrier_v=5.5),
 dict(name='actual5pct_margin_pulse',mode='pulse',profile='room_high',gpio_v=2.4,run_v=3.84,carrier_v=4.5,power_r_ohm=47*1.05,hz=50,width_us=500),
]
rows=[space['execute'](case) for case in cases]
assert all(not any(r['control_high_spans_s'].values()) for r in rows[:2])
assert all(max(r['maximum_pwm_forward_a'],r['maximum_run_forward_a'])<.00025 for r in rows[:2])
assert all(len(v)==3 for v in rows[-1]['control_high_spans_s'].values())
result=dict(cases=rows,probe_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),tolerance_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            qualification='Additional actualR17±5% witnesses. Remaining component/thermal/harness limits are not established.')
(P/'input-actual-tolerance-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['case','maximum_pwm_forward_a','maximum_source_current_a','control_high_spans_s','release_delay_s'] if k in r} for r in rows],indent=2))
