"""Publish unmodified waveform windows, preserving identities of full local traces."""
from pathlib import Path
import gzip,hashlib,json
P=Path(__file__).resolve().parent
main=json.loads((P/'input-final-fitted-results.json').read_text())['cases']
follow=json.loads((P/'input-final-followups.json').read_text())['cases']
output=P/'publication-waveforms';output.mkdir(exist_ok=False)
manifest=[]
for record in main+follow:
 name=record['case']['name'];folder=P/'input-final-fitted-001'/name;raw=folder/'trace.tsv'
 case=record['case'];mode=case['mode']
 if mode=='pulse':
  windows=[(0,.0035)]+[(a-20e-6,b+.001) for a,b in record['observed_source_high_spans_s']]
 elif mode in ('release','power_open'):
  last=max((b for spans in record['control_high_spans_s'].values() for a,b in spans if b>=.004),default=.004)
  windows=[(0,.001),(.0035,last+.0002)]
 else:windows=[(0,.0015)]
 windows.sort();merged=[]
 for a,b in windows:
  if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
  else:merged.append([a,b])
 target=output/(name+'.tsv.gz');h=hashlib.sha256();ranges=[];omitted=[];current=None;gap=None;kept=total=0
 with raw.open('rb') as source,gzip.open(target,'wb',compresslevel=9) as dest:
  header=source.readline();h.update(header);dest.write(header)
  for index,line in enumerate(source,1):
   h.update(line);parts=line.split();stamp=float(parts[0]);total=index
   retain=any(a<=stamp<=b for a,b in merged) or index==record['rows']
   if retain:
    kept+=1;dest.write(line)
    if current is None:current=dict(first_row=index,last_row=index,first_s=stamp,last_s=stamp)
    else:current.update(last_row=index,last_s=stamp)
    if gap is not None:omitted.append(gap);gap=None
   else:
    levels=[float(parts[n]) for n in [6,7,8]]
    if gap is None:gap=dict(first_row=index,last_row=index,first_s=stamp,last_s=stamp,control_min=levels.copy(),control_max=levels.copy(),pwm_forward_max_a=float(parts[4]))
    else:
     gap.update(last_row=index,last_s=stamp,pwm_forward_max_a=max(gap['pwm_forward_max_a'],float(parts[4])))
     gap['control_min']=[min(a,b) for a,b in zip(gap['control_min'],levels)]
     gap['control_max']=[max(a,b) for a,b in zip(gap['control_max'],levels)]
    if current is not None:ranges.append(current);current=None
  if current is not None:ranges.append(current)
  if gap is not None:omitted.append(gap)
 assert h.hexdigest()==record['trace_sha256'] and total==record['rows'],name
 for gap in omitted:
  assert gap['control_min']==gap['control_max'],('Omitted control transition',name,gap)
  if mode=='pulse':assert gap['pwm_forward_max_a']<.000251,('Omitted command light',name,gap)
 row=dict(case=name,full_trace_sha256=h.hexdigest(),full_trace_bytes=raw.stat().st_size,full_rows=total,kept_rows=kept,
          window_file=str(target.relative_to(P)),window_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),window_bytes=target.stat().st_size,
          retained_row_ranges=ranges,omitted_ranges=omitted)
 manifest.append(row)
result=dict(qualification='Unmodified numeric rows selected around startup, all declared pulses and release transitions. Omitted spans contain no conditional control transitions. Full unthinned vectors remain locally retained; this is explicitly a windowed publication artifact.',
            traces=manifest,full_rows=sum(r['full_rows'] for r in manifest),kept_rows=sum(r['kept_rows'] for r in manifest),
            full_gzip_bytes=sum((P/'input-final-fitted-001'/r['case']/'trace.tsv.gz').stat().st_size for r in manifest),
            window_gzip_bytes=sum(r['window_bytes'] for r in manifest),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(P/'waveform-windows.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='traces'},indent=2))
