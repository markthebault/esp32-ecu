"""Conditional resistor budgets for the proposed isolated boost input."""
from pathlib import Path
import hashlib,itertools,json
P=Path(__file__).resolve().parent
ROOT=P.parents[2]
rows=[]
for run,iq7 in itertools.product([3.84,4.5,5,5.5],[0,.0005,.02]):
 r47=9500;r50=1050;r53=9500;r_idle=2200*.99;rgs=22000*.99;rs=330*.99
 algebraic_main=(run-r50*iq7)/(1+r50/r53)
 infeasible=algebraic_main<0
 i47=run/r47;idle=max((run-.5)/r_idle,0);gate=run/(rgs+rs)+1e-7;hct=10e-6
 main_branch=(run-algebraic_main)/r50 if not infeasible else None
 rows.append(dict(run_v=run,assumed_q7_input_a=iq7,main_in_v=algebraic_main if not infeasible else None,
                  algebraic_infeasible_if_negative=infeasible,
                  run_load_a=i47+main_branch+idle+gate+hct if not infeasible else None,
                  current_terms_a=dict(r47=i47,main_branch=main_branch,idle_buffer=idle,boost_buffer=gate,hct_inputs=hct),
                  notes='No positive-voltage equilibrium for the assumed constant20mA fault sink; a real output collapses/limits. No negative voltage prediction.' if infeasible else 'Assumed Q7 current is not a full-temperature5V bound.',physical_guarantee=False))
static_led=dict(min_current_a=(4.5-1.7)/(357*1.01+5+2*10*1.01),
                maximum_zero_vf_bound_a=5.5/(357*.99+2*10*.99),
                maximum_resistor_steady_w=(2*5.5/(357*.99+2*10*.99))**2*10*1.01,
                qualification='Conditional symmetric static branches.5ohm TN is25C/Vgs2V. VFmax is1.7V atIF10mA. Full-temp/supply/assembly behavior remains unqualified.')
inrush=dict(carrier_v=5.5,r_min_ohm=9.9,cap_max_f=26.4e-6+.1e-6,initial_current_a=5.5/9.9,
            initial_resistor_w=5.5**2/9.9,stored_cap_energy_j=.5*(26.4e-6+.1e-6)*5.5**2,
            qualification='Ideal step/zero external source impedance. Actual resistor pulse curve, capacitor ESR and carrier rail response remain required.')
inputs={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ('hardware/a6-flex-rgb/net_contract.json','hardware/idle-isolated/net_contract.json')}
d=dict(qualification=__doc__,input_sha256=inputs,run_records=rows,led=static_led,inrush=inrush,
       full_qualification=False,q7_note='IISS500uA is only specified atVin10V/Tcase25C. Rds is specified atVin5V and10V. Max threshold3V is not an on-state guarantee.',
       hct_note='SN74HCT08 providesVOH>=3.84V atVCC4.5V/IOH4mA overits stated range; this alone does not establishMAIN_IN or actualRUN.')
(P/'conditional-static-budget.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(run_corner=rows[1],led=static_led,inrush=inrush),indent=2))
