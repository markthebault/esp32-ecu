"""Independent conditional TN0702 input-only experiment, no vendor macro-model."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import gzip,hashlib,json,math,subprocess
BASE=Path(__file__).resolve().parent
BIN=(BASE.parent/'flex-frontend-review/toolchain/ngspice').resolve()
PROFILES={
 'room_low':dict(vto=.5,kp=.19,rd=.01,rs=.01),
 'room_high':dict(vto=.90463,kp=.22,rd=.01,rs=.01),
 'hot_assumed':dict(vto=.1,kp=.1,rd=.01,rs=.01),
}
CAPS={'20v_test_values':(200e-12,60e-12),'low_bias_hypothesis':(1e-9,300e-12),'larger_low_bias_hypothesis':(2e-9,1e-9)}
THRESHOLDS=[.000251,.002,.005]

def circuit(c):
 mode=c['mode'];rise=c.get('rise_s',1e-8);width=c.get('width_us',40)*1e-6;period=1/c.get('hz',24)
 power_r=c.get('power_r_ohm',47);power_c=c.get('power_c_f',2.2e-6+100e-9);carrier=c.get('carrier_v',5)
 voltage=c.get('gpio_v',3.3);rcommand=c.get('cmd_rg_ohm',1000);rrun=c.get('run_rg_ohm',4700);rgs=c.get('rgs_ohm',10000);cg=c.get('external_cgs_f',100e-9)
 ciss,crss=CAPS[c.get('caps','20v_test_values')];profile=PROFILES[c.get('profile','room_low')]
 if mode=='pulse':
  points=[(0,0)]
  for cycle in range(3):
   begin=.002+cycle*period
   points += [(begin,0),(begin+1e-9,voltage),(begin+1e-9+width,voltage),(begin+2e-9+width,0)]
  gpio='PWL('+' '.join(f'{t:.17g} {v:.17g}' for t,v in points)+')';run='DC 5';power=f'DC {carrier}';stop=.002+2*period+width+.002;step=50e-6;wireg='DC 1';wirer='DC 1'
 elif mode=='hotplug':
  gpio='DC 0';run='DC 0';power=f'PWL(0 0 10u 0 {10e-6+rise} {carrier})';stop=.004 if power_c>1e-6 else .0004;step=.1e-6 if power_c>1e-6 else 20e-9;wireg=wirer='DC 0'
 elif mode=='release':
  source='command' if c['signal']=='command' else 'run'
  gpio=f'PWL(0 {voltage} 4m {voltage} 4.000001m 0)' if source=='command' and c['release']=='wired_low' else f'DC {voltage}'
  run='PWL(0 5 4m 5 4.000001m 0)' if source=='run' and c['release']=='wired_low' else 'DC 5'
  wire='PWL(0 1 4m 1 4.000001m 0)' if c['release']=='wire_open' else 'DC 1'
  wireg=wire if source=='command' else 'DC 1';wirer=wire if source=='run' else 'DC 1'
  power=f'DC {carrier}';stop=.012;step=.1e-6
 elif mode=='power_open':
  gpio=f'DC {voltage}';run='DC 5';power=f'DC {carrier}';stop=.04;step=1e-6;wireg=wirer='DC 1'
 else:raise ValueError(mode)
 power_switch='PWL(0 1 4m 1 4.000001m 0)' if mode=='power_open' else 'DC 1'
 text=f'''Independent proposed TN0702 input-only sensitivity / {c['name']}
* Two real input networks. Three alternative conditional optical hypotheses.
* No vendor model, assembled timing guarantee, extracted parasitics or return-isolation proof.
* Datasheet capacitance test voltage is20V. Low-bias profiles are authored sensitivity values.
.temp 25
.options reltol=1e-6 abstol=1e-12 vntol=1e-8 method=gear
V5 supply5 0 {power}
Vpwrctl pwrctl 0 {power_switch}
Spower supply5 source5 pwrctl 0 WIRE
Rpower source5 cin5 {power_r}
C9 cin5 0 {power_c}
Vgpio gpiosrc 0 {gpio}
Rgpio gpiosrc gpio 30
Rcarrierbias gpio 0 2200
Vrun runsrc 0 {run}
Rrun runsrc run 47
Vwireg cgctl 0 {wireg}
Vwirer crctl 0 {wirer}
Sgpio gpio gpin cgctl 0 WIRE
Srun run rpin crctl 0 WIRE
Rgp_leak gpin 0 1e12
Rrp_leak rpin 0 1e12
R1 gpin pg {rcommand}
R2 rpin rg {rrun}
R5 pg 0 {rgs}
R6 rg 0 {rgs}
Cgs_extp pg 0 {cg}
Cgs_extr rg 0 {cg}
Cgs_intp pg 0 {ciss-crss}
Cgs_intr rg 0 {ciss-crss}
Cgd_p pc pg {crss}
Cgd_r rc rg {crss}
Cds_p pc 0 65p
Cds_r rc 0 65p
D3 0 pg DCLAMP
D4 0 rg DCLAMP
R3 cin5 pla 357
R4 cin5 rla 357
Vpwmled pla pl 0
Vrunled rla rl 0
* The sense sources measure only forward conduction, excluding the explicit34p LED junction caps.
Dpw pl pc LED
Dru rl rc LED
Cpw pla pc 34p
Cru rla rc 34p
M2 pc pg 0 0 TNMODEL L=1u W=1u
M3 rc rg 0 0 TNMODEL L=1u W=1u
Vdetector detector 0 5.1645
.model TNMODEL NMOS(level=1 Vto={profile['vto']} Kp={profile['kp']} Rd={profile['rd']} Rs={profile['rs']} Tnom=25 Lambda=0)
.model LED D(Is=1e-18 N=1.5 Rs=3 Cjo=0)
.model DCLAMP D(Is=1e-9 N=1.7 Rs=.2 Cjo=5p)
.model WIRE SW(Ron=.01 Roff=1e12 Vt=.5 Vh=0)
.model OPTO SW(Ron=80 Roff=1e12 Vt=.5 Vh=0)
'''
 for i,threshold in enumerate(THRESHOLDS):
  text+=f'''Bp{i} rawp{i} 0 V=(i(Vpwmled)>{threshold} ? 1 : 0)
Br{i} rawr{i} 0 V=(i(Vrunled)>{threshold} ? 1 : 0)
Rp{i} rawp{i} pwf{i} 1000
Rr{i} rawr{i} runf{i} 1000
Cp{i} pwf{i} 0 .2n
Cr{i} runf{i} 0 .2n
Sp{i} pwmn{i} 0 pwf{i} 0 OPTO
Sr{i} runn{i} 0 runf{i} 0 OPTO
Rpp{i} detector pwmn{i} 1000
Rrp{i} detector runn{i} 1000
Cpp{i} pwmn{i} 0 100p
Crp{i} runn{i} 0 100p
Bnor{i} nor{i} 0 V=(v(pwmn{i})<.8 && v(runn{i})<.8 ? 5.1645 : 0)
'''
 text+='.ic '+ ' '.join(f'v(pwmn{i})=5.1645 v(runn{i})=5.1645 v(pwf{i})=0 v(runf{i})=0' for i in range(3))+'\n'
 text+=f'''.control
set noaskquit
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step} {stop} 0 {step} uic
wrdata trace.tsv v(cin5) v(pg) v(rg) i(Vpwmled) i(Vrunled) v(nor0) v(nor1) v(nor2) v(gpiosrc) v(runsrc) i(V5) i(Vgpio) i(Vrun)
quit
.endc
.end
'''
 return text,stop

def spans(rows,column,threshold,start=0):
 output=[];active=None;last=None
 for row in rows:
  if row[0]<start:continue
  level=row[column]>threshold
  if level and active is None:active=row[0]
  if not level and active is not None:output.append([active,row[0]]);active=None
  last=row[0]
 if active is not None:output.append([active,last])
 return output

def execute(c):
 out=BASE/'input-final-fitted-001'/c['name'];out.mkdir(parents=True,exist_ok=False)
 data,stop=circuit(c);(out/'probe.cir').write_text(data)
 with (out/'ngspice.log').open('w') as stream:
  done=subprocess.run([str(BIN),'-b','probe.cir'],cwd=out,stdout=stream,stderr=subprocess.STDOUT,timeout=30)
 if done.returncode:raise RuntimeError(c['name'])
 rows=[]
 with (out/'trace.tsv').open() as stream:
  header=next(stream)
  for line in stream:rows.append(list(map(float,line.split())))
 record=dict(case=c,rows=len(rows),final_s=rows[-1][0],maximum_gate_v=max(r[2] for r in rows),maximum_run_gate_v=max(r[3] for r in rows),
             maximum_pwm_forward_a=max(r[4] for r in rows),maximum_run_forward_a=max(r[5] for r in rows),
             pwm_forward_spans_s={str(x):spans(rows,4,x,5e-6) for x in THRESHOLDS},
             control_high_spans_s={str(x):spans(rows,i+6,2.4,5e-6) for i,x in enumerate(THRESHOLDS)},
             deck_sha256=hashlib.sha256(data.encode()).hexdigest())
 if c['mode']=='pulse':
  observed=spans(rows,9,.5)
  assert len(observed)==3,('pulse source missing',c['name'],observed)
  record['observed_source_high_spans_s']=observed
  assert rows[-1][9]<.1,('unfinished source pulse',c['name'])
 if c['mode'] in ('release','power_open'):
  record['release_delay_s']={str(x):max((r[1]-.004 for r in spans(rows,i+6,2.4,.003) if r[1]>=.004),default=0) for i,x in enumerate(THRESHOLDS)}
 record['maximum_source_current_a']=max(-r[11] for r in rows)
 record['maximum_gpio_source_a']=max(-r[12] for r in rows)
 record['maximum_run_source_a']=max(-r[13] for r in rows)
 record['maximum_gpio_sink_a']=max(r[12] for r in rows)
 record['maximum_run_sink_a']=max(r[13] for r in rows)
 record['resistor_energy_j']=sum((b[0]-a[0])*.5*(a[11]**2+b[11]**2)*c.get('power_r_ohm',47) for a,b in zip(rows,rows[1:]))
 record['terminal_control_low']=[rows[-1][i]<.1 for i in [6,7,8]]
 assert all(record['terminal_control_low']),('right-censored control tail',c['name'])
 original=(out/'trace.tsv').read_bytes()
 with gzip.open(out/'trace.tsv.gz','wb',compresslevel=9) as stream:stream.write(original)
 # Keep the original raw file as evidence; compressed copy is the publication candidate.
 record['trace_sha256']=hashlib.sha256(original).hexdigest()
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 return record

cases=[]
# All actual frequencies and required pulse widths, at the adverse low source.
for profile in PROFILES:
 for hz in [10,24,50]:
  for width in [40,100,200,500]:
   cases.append(dict(name=f'pulse_{profile}_2p4v_{hz}hz_{width}us',mode='pulse',profile=profile,gpio_v=2.4,hz=hz,width_us=width))
# Nominal3.3V pulse widths are kept separately from the adverse source.
for hz in [10,24,50]:
 for width in [40,100,200,500]:
  cases.append(dict(name=f'pulse_room_low_3p3v_{hz}hz_{width}us',mode='pulse',profile='room_low',gpio_v=3.3,hz=hz,width_us=width))
for profile in PROFILES:
 for width in [1,10]:
  cases.append(dict(name=f'short_{profile}_{width}us',mode='pulse',profile=profile,gpio_v=2.4,hz=24,width_us=width))
# Worst hot/threshold profile; zero/low-bias capacitance bounds remain hypotheses.
for caps in CAPS:
 for voltage in [4.5,5.5]:
  for rise in [1e-8,1e-4]:
   cases.append(dict(name=f'hotplug_hot_{caps}_{voltage:g}v_{rise:g}s',mode='hotplug',profile='hot_assumed',caps=caps,rise_s=rise,carrier_v=voltage,power_c_f=1.76e-6+100e-9))
for rise in [1e-8,1e-4]:
 cases.append(dict(name=f'hotplug_room_high_nominal_{rise:g}s',mode='hotplug',profile='room_high',rise_s=rise))
for profile in PROFILES:
 for signal in ['command','run']:
  for release in ['wired_low','wire_open']:
   cases.append(dict(name=f'release_{profile}_{signal}_{release}',mode='release',profile=profile,signal=signal,release=release))
for bulk in [1.76e-6,2.2e-6,2.64e-6]:
 for carrier in [4.5,5.5]:
  cases.append(dict(name=f'power_open_{bulk:g}f_{carrier:g}v',mode='power_open',power_c_f=bulk+100e-9,carrier_v=carrier))
# Explicit gate-film sensitivity; no frozen procurement capacitance is inferred.
for cg in [80e-9,120e-9]:
 for width in [40,100]:
  cases.append(dict(name=f'film_{cg:g}f_pulse_{width}us',mode='pulse',profile='room_high',gpio_v=2.4,hz=50,width_us=width,external_cgs_f=cg))
for cg in [80e-9,120e-9]:
 cases.append(dict(name=f'film_{cg:g}f_hotplug',mode='hotplug',profile='hot_assumed',caps='larger_low_bias_hypothesis',rise_s=1e-8,carrier_v=5.5,power_c_f=1.76e-6+100e-9,external_cgs_f=cg))
# Correct the prior high-threshold test-fit without overwriting its adverse witness.
for hz in [10,24,50]:
 cases.append(dict(name=f'prior4p7n_fitted_{hz}hz',mode='pulse',profile='room_high',gpio_v=2.4,hz=hz,width_us=1,cmd_rg_ohm=330,run_rg_ohm=330,rgs_ohm=22000,external_cgs_f=4.7e-9,power_r_ohm=10,power_c_f=22e-6+100e-9))
plan=dict(cases=cases,profiles=PROFILES,caps=CAPS,optical_threshold_a=THRESHOLDS,ngspice_sha256=hashlib.sha256(BIN.read_bytes()).hexdigest(),probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),qualification=__doc__)
(BASE/'input-final-fitted-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(execute,cases))
(BASE/'input-final-fitted-results.json').write_text(json.dumps(dict(cases=records,qualification=__doc__),indent=2)+'\n')
print(json.dumps(dict(completed=len(records),hotplug_control_high={str(thr):sum(bool(r['control_high_spans_s'][str(thr)]) for r in records if r['case']['mode']=='hotplug') for thr in THRESHOLDS},release_max_s={str(thr):max(r['release_delay_s'][str(thr)] for r in records if 'release_delay_s' in r) for thr in THRESHOLDS}),indent=2))
