from pathlib import Path
import json,hashlib
BASE=Path(__file__).resolve().parent
source=BASE/'probe_final_input_fitted.py'
space={'__file__':str(source)}
exec(source.read_text().split('\ncases=[]')[0],space)
original=space['circuit']
def circuit(case):
 deck,stop=original(case)
 if 'maximum_step_s' in case:
  lines=deck.splitlines();i=next(i for i,line in enumerate(lines) if line.startswith('tran '))
  t=lines[i].split();t[1]=t[4]=str(case['maximum_step_s']);lines[i]=' '.join(t);deck='\n'.join(lines)+'\n'
 return deck,stop
space['circuit']=circuit
base=json.loads((BASE/'input-final-fitted-results.json').read_text())['cases']
requests=[('hotplug_hot_larger_low_bias_hypothesis_5.5v_1e-08s',.05e-6),
          ('pulse_room_high_2p4v_50hz_100us',.1e-6),
          ('release_hot_assumed_run_wire_open',.05e-6),
          ('power_open_2.64e-06f_5.5v',.5e-6)]
rows=[];differences=[]
for index,(name,step) in enumerate(requests):
 coarse=next(row for row in base if row['case']['name']==name)
 case={**coarse['case'],'name':f'refined_final_{index}','maximum_step_s':step}
 fine=space['execute'](case);rows.append(fine)
 check=dict(coarse=name,fine=case['name'],max_gate_difference_v=abs(coarse['maximum_gate_v']-fine['maximum_gate_v']),
            maximum_forward_difference_a=abs(coarse['maximum_pwm_forward_a']-fine['maximum_pwm_forward_a']),timing_difference_s={})
 for threshold in space['THRESHOLDS']:
  key=str(threshold);a=coarse['control_high_spans_s'][key];b=fine['control_high_spans_s'][key]
  assert len(a)==len(b),(name,key,'event count')
  error=max([abs(x-y) for ar,br in zip(a,b) for x,y in zip(ar,br)],default=0)
  assert error<1e-6,(name,key,error)
  check['timing_difference_s'][key]=error
 differences.append(check)
for rise in [1e-8,1e-6]:
 case=dict(name=f'fitted_negative100k_{rise:g}s',mode='hotplug',profile='room_low',rise_s=rise,cmd_rg_ohm=1000,run_rg_ohm=1000,rgs_ohm=100000,external_cgs_f=0,power_r_ohm=.5,power_c_f=100e-9)
 row=space['execute'](case)
 assert row['control_high_spans_s']['0.002'], 'Fitted negative no longer demonstrates the declared typical-threshold glitch'
 rows.append(row)
result=dict(cases=rows,refinement=differences,probe_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),followup_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            qualification='Four finite step checks and two negative controls using the tested25C fit. Not uniform convergence or physical qualification.')
(BASE/'input-final-followups.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(refinement=differences,negative_controls=[{k:row[k] for k in ['case','control_high_spans_s','maximum_pwm_forward_a']} for row in rows if row['case']['name'].startswith('fitted_negative')]),indent=2))
