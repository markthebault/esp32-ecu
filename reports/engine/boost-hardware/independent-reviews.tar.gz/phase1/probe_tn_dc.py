"""Check actual external-terminal TN model points against the declared25C table."""
from pathlib import Path
import json,hashlib,re,subprocess
P=Path(__file__).resolve().parent
B=(P.parent/'flex-frontend-review/toolchain/ngspice').resolve()
profiles={
 'prior_room_low':dict(vto=.5,kp=.18,rd=0,rs=0),
 'prior_room_high1p0':dict(vto=1.0,kp=.2,rd=0,rs=0),
 'prior_room_high0p9':dict(vto=.9,kp=.2,rd=0,rs=0),
 'fit_room_low':dict(vto=.5,kp=.19,rd=.01,rs=.01),
 'fit_room_high':dict(vto=.90463,kp=.22,rd=.01,rs=.01),
}
text='TN model external DC test points, no thermal dynamics or vendor model\n.temp 25\n.options reltol=1e-9 abstol=1e-13 vntol=1e-10\n'
variables=[];records=[]
for index,(name,param) in enumerate(profiles.items()):
 model='MODEL'+str(index)
 text+=f'.model {model} NMOS(Level=1 Vto={param["vto"]} Kp={param["kp"]} Rd={param["rd"]} Rs={param["rs"]} Tnom=25 Lambda=0)\n'
 for j,(vg,current,limit) in enumerate([(2,.05,5),(3,.2,2.5),(5,.5,1.3)]):
  d=f'd{index}_{j}';g=f'g{index}_{j}'
  text+=f'Vg{index}_{j} {g} 0 {vg}\nId{index}_{j} 0 {d} {current}\nM{index}_{j} {d} {g} 0 0 {model} L=1u W=1u\n.nodeset v({d})=.5\n'
  variables.append('v('+d+')');records.append(dict(profile=name,kind='rds',gate_v=vg,current_a=current,limit_ohm=limit,node=d))
 d=f'th{index}'
 text+=f'Ith{index} 0 {d} .001\nMth{index} {d} {d} 0 0 {model} L=1u W=1u\n.nodeset v({d})=1\n'
 variables.append('v('+d+')');records.append(dict(profile=name,kind='vgs_threshold',current_a=.001,minimum_v=.5,maximum_v=1,node=d))
text+='.control\nop\nprint '+' '.join(variables)+'\nquit\n.endc\n.end\n'
out=P/'tn-dc-002';out.mkdir(exist_ok=False)
(out/'probe.cir').write_text(text)
done=subprocess.run([str(B),'-b','probe.cir'],cwd=out,capture_output=True,text=True,timeout=30)
(out/'ngspice.log').write_text(done.stdout+done.stderr)
if done.returncode:raise RuntimeError(done.stderr)
values=dict((m[0],float(m[1])) for m in re.findall(r'v\(([^)]+)\)\s*=\s*([\d.eE+-]+)',done.stdout))
for row in records:
 value=values[row['node']];row['external_terminal_voltage_v']=value
 if row['kind']=='rds':row['actual_rds_ohm']=value/row['current_a'];row['within_stated_limit']=row['actual_rds_ohm']<=row['limit_ohm']
 else:row['within_stated_limit']=row['minimum_v']<=value<=row['maximum_v']
result=dict(profiles=profiles,records=records,deck_sha256=hashlib.sha256(text.encode()).hexdigest(),probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            qualification=__doc__,fits_pass={name:all(r['within_stated_limit'] for r in records if r['profile']==name) for name in profiles})
assert result['fits_pass']['fit_room_low'] and result['fits_pass']['fit_room_high']
(P/'tn-dc-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
