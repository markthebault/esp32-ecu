#include "/home/mark/persospace/esp32-ecu/firmware/main/web_config.cpp"
#include <fstream>
#include <iterator>
#include <iostream>
#include <stdexcept>
namespace ecu::engine_target {inline unsigned review_begins=0,review_finishes=0,review_revision=0;void begin_configuration(){++review_begins;}void finish_configuration(std::uint32_t,std::uint32_t revision){++review_finishes;review_revision=revision;}}
unsigned checks=0;void require(bool ok,const char*what){++checks;if(!ok)throw std::runtime_error(what);}
std::string read(const char*path){std::ifstream f(path);return std::string((std::istreambuf_iterator<char>(f)),{});}
httpd_req_t request(const std::string&body){httpd_req_t req;req.body=body;req.content_len=body.size();req.headers["Content-Type"]="application/json";req.headers["X-ECU-Token"]="review";return req;}
int main(int argc,char**argv){try{
 require(argc==2,"args");const auto old=read(argv[1]);review_store.legacy_exists=true;review_store.legacy=old;ecu::web::init();std::strcpy(ecu::web::token,"review");
 require(ecu::web::storage_ok,"legacy boot ready");auto req=request(old);require(ecu::web::config_put(&req)==ESP_OK&&req.status=="200 OK","actual PUT long migrated profile succeeds");
 require(ecu::web::active.revision==2&&review_store.blob.size()>4000,"revision published after blob commit");require(review_store.legacy==old,"legacy remains untouched");require(ecu::engine_target::review_begins==1&&ecu::engine_target::review_finishes==1&&ecu::engine_target::review_revision==2,"configuration fences after success");
 auto before=ecu::web::document,blob=review_store.blob;auto writes=review_store.writes;req=request(old);ecu::web::config_put(&req);require(req.status=="409 Conflict"&&review_store.writes==writes,"stale CAS cannot write");
 review_store.commit_error=ESP_FAIL;req=request(before);ecu::web::config_put(&req);require(req.status=="507 Insufficient Storage","actual PUT reports commit failure");require(!ecu::web::storage_ok&&ecu::web::active.revision==2&&ecu::web::document==before,"failure blocks writes and retains runtime");require(ecu::engine_target::review_revision==2&&ecu::engine_target::review_begins==2&&ecu::engine_target::review_finishes==2,"failure finishes configuration with previous revision");
 writes=review_store.writes;review_store.commit_error=0;req=request(before);ecu::web::config_put(&req);require(req.status=="503 Service Unavailable"&&review_store.writes==writes,"next save blocked before new write despite cleared fake error");require(ecu::engine_target::review_begins==2,"blocked retry never begins configuration");
 ecu::web::init();require(ecu::web::storage_ok&&ecu::web::document==before,"reboot loads valid saved blob");
 review_store.blob="malformed";ecu::web::init();req=request(before);writes=review_store.writes;ecu::web::config_put(&req);require(req.status=="503 Service Unavailable"&&!ecu::web::storage_ok&&review_store.writes==writes,"corrupt blob blocks actual PUT without legacy fallback");
 std::cout<<"actual config_put HTTP handler integration checks="<<checks<<"; fake HTTP/NVS/fences only, no ESP32/flash execution\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
