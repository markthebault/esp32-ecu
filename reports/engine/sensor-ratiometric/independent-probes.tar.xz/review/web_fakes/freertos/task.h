#pragma once
#include "fake_target.hpp"
inline void vTaskDelay(unsigned){}
