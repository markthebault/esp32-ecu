#pragma once
inline int esp_netif_init(){return 0;}
inline void esp_netif_create_default_wifi_ap(){}
inline void esp_netif_create_default_wifi_sta(){}
