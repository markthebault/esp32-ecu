#pragma once
#include "fake_target.hpp"
inline std::int64_t esp_timer_get_time(){return fake_now;}
