#pragma once
#include "fake_target.hpp"
#include <string>
using nvs_handle_t=unsigned;
constexpr esp_err_t ESP_ERR_NVS_NOT_FOUND=1,ESP_ERR_NVS_INVALID_LENGTH=2,ESP_ERR_NVS_TYPE_MISMATCH=3;
enum nvs_open_mode_t {NVS_READONLY,NVS_READWRITE};
struct ReviewStore{bool namespace_exists=true,blob_exists=false,legacy_exists=false;std::string legacy,blob,pending;int open_error=0,read_error=0,set_error=0,commit_error=0;unsigned writes=0,commits=0,closes=0;};
inline ReviewStore review_store;
inline esp_err_t nvs_open(const char*space,nvs_open_mode_t mode,nvs_handle_t*h){assert(std::strcmp(space,"ecu_config")==0);if(review_store.open_error)return review_store.open_error;if(mode==NVS_READONLY&&!review_store.namespace_exists)return ESP_ERR_NVS_NOT_FOUND;*h=1;return ESP_OK;}
inline esp_err_t nvs_get_blob(nvs_handle_t,const char*key,void*out,std::size_t*size){assert(std::strcmp(key,"profile_blob")==0);if(review_store.read_error)return review_store.read_error;if(!review_store.blob_exists)return ESP_ERR_NVS_NOT_FOUND;if(out){if(*size<review_store.blob.size())return ESP_ERR_NVS_INVALID_LENGTH;std::memcpy(out,review_store.blob.data(),review_store.blob.size());}*size=review_store.blob.size();return ESP_OK;}
inline esp_err_t nvs_get_str(nvs_handle_t,const char*key,char*out,std::size_t*size){assert(std::strcmp(key,"profile")==0);if(!review_store.legacy_exists)return ESP_ERR_NVS_NOT_FOUND;if(out){if(*size<review_store.legacy.size()+1)return ESP_ERR_NVS_INVALID_LENGTH;std::memcpy(out,review_store.legacy.c_str(),review_store.legacy.size()+1);}*size=review_store.legacy.size()+1;return ESP_OK;}
inline esp_err_t nvs_set_blob(nvs_handle_t,const char*key,const void*value,std::size_t size){assert(std::strcmp(key,"profile_blob")==0);++review_store.writes;if(review_store.set_error)return review_store.set_error;review_store.pending.assign(static_cast<const char*>(value),size);return ESP_OK;}
inline esp_err_t nvs_commit(nvs_handle_t){++review_store.commits;if(review_store.commit_error)return review_store.commit_error;review_store.blob=review_store.pending;review_store.blob_exists=true;return ESP_OK;}
inline void nvs_close(nvs_handle_t){++review_store.closes;}
