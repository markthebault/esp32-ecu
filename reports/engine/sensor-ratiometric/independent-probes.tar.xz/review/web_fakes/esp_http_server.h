#pragma once
#include "fake_target.hpp"
#include <string>
#include <map>
struct httpd_req_t{std::size_t content_len=0;std::string body,status="200 OK",response;std::size_t cursor=0;std::map<std::string,std::string>headers;};
constexpr int HTTPD_500_INTERNAL_SERVER_ERROR=500,HTTP_GET=0,HTTP_PUT=1,HTTP_POST=2;
constexpr int HTTPD_RESP_USE_STRLEN=-1;
inline std::size_t httpd_req_get_hdr_value_len(httpd_req_t*r,const char*name){return r->headers[name].size();}
inline esp_err_t httpd_req_get_hdr_value_str(httpd_req_t*r,const char*name,char*out,std::size_t size){auto value=r->headers.find(name);if(value==r->headers.end()||value->second.size()+1>size)return ESP_FAIL;std::memcpy(out,value->second.c_str(),value->second.size()+1);return ESP_OK;}
inline int httpd_req_recv(httpd_req_t*r,char*out,int size){auto n=std::min(std::size_t(size),r->body.size()-r->cursor);std::memcpy(out,r->body.data()+r->cursor,n);r->cursor+=n;return n;}
inline esp_err_t httpd_resp_set_status(httpd_req_t*r,const char*s){r->status=s;return ESP_OK;}
inline esp_err_t httpd_resp_set_type(httpd_req_t*,const char*){return ESP_OK;}
inline esp_err_t httpd_resp_set_hdr(httpd_req_t*,const char*,const char*){return ESP_OK;}
inline esp_err_t httpd_resp_send(httpd_req_t*r,const char*data,int size){r->response.assign(data,size<0?std::strlen(data):std::size_t(size));return ESP_OK;}
inline esp_err_t httpd_resp_send_chunk(httpd_req_t*r,const char*data,int size){if(data)r->response.append(data,size<0?std::strlen(data):std::size_t(size));return ESP_OK;}
inline esp_err_t httpd_resp_send_err(httpd_req_t*r,int,const char*text){r->status="500 Internal Server Error";r->response=text;return ESP_OK;}
inline std::size_t httpd_req_get_url_query_len(httpd_req_t*){return 0;}
inline esp_err_t httpd_req_get_url_query_str(httpd_req_t*,char*,std::size_t){return ESP_FAIL;}
struct httpd_config_t{unsigned stack_size=0,max_uri_handlers=0;bool lru_purge_enable=false;int recv_wait_timeout=0,send_wait_timeout=0;};
#define HTTPD_DEFAULT_CONFIG() httpd_config_t{}
using httpd_handle_t=void*;
struct httpd_uri_t{const char*uri;int method;esp_err_t(*handler)(httpd_req_t*);void*ctx;};
inline esp_err_t httpd_start(httpd_handle_t*,httpd_config_t*){return ESP_OK;}
inline esp_err_t httpd_register_uri_handler(httpd_handle_t,const httpd_uri_t*){return ESP_OK;}
