#pragma once
#include "fake_target.hpp"
struct wifi_init_config_t{};
#define WIFI_INIT_CONFIG_DEFAULT() wifi_init_config_t{}
constexpr int WIFI_STORAGE_RAM=0,WIFI_IF_AP=0,WIFI_MODE_APSTA=0,WIFI_AUTH_WPA2_PSK=0;
struct wifi_config_t{struct{unsigned char ssid[33]{},password[65]{};unsigned ssid_len=0,channel=0,authmode=0,max_connection=0;struct{bool required=false;}pmf_cfg;}ap;};
inline int esp_wifi_init(wifi_init_config_t*){return 0;}
inline int esp_wifi_set_storage(int){return 0;}
inline int esp_wifi_get_mac(int,unsigned char*out){std::memset(out,0,6);return 0;}
inline int esp_wifi_set_mode(int){return 0;}
inline int esp_wifi_set_config(int,wifi_config_t*){return 0;}
inline int esp_wifi_start(){return 0;}
