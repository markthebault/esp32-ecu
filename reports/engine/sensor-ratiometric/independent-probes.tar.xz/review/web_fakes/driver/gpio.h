#pragma once
#include "fake_target.hpp"
inline int gpio_get_level(gpio_num_t){return 0;}
