"""Reproduce the reviewed pre-fix NVS string boundary using the actual parser."""
from pathlib import Path
import os,sys,ctypes,json
root=next(p for p in Path(__file__).resolve().parents if (p/'firmware/include/ecu/config.hpp').is_file())
out=Path(__file__).resolve().parent
os.environ['ECU_NATIVE_CACHE_ROOT']=str(out/'native')
sys.path.insert(0,str(root/'tools'))
from web_server import load_bridge
bridge=load_bridge();old=(out/'nvs-limit-profile1.json').read_bytes()
buffer=ctypes.create_string_buffer(16385)
assert bridge.validate_profile(old) and bridge.normalize_profile(old,buffer,len(buffer))
new=buffer.value
assert len(old)==3775 and len(new)==4033
assert bridge.validate_profile(new)
assert len(old)+1<=4000<len(new)+1
print(json.dumps({'old_bytes':len(old),'normalized_bytes':len(new),'old_fits_NVS_string':True,'new_fits_NVS_string':False,'resolved_by_current_blob_storage':True}))
