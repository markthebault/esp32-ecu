import sys,copy,json,threading,os
from pathlib import Path
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
R=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tools'))
from web_server import Device,Handler,load_bridge
checks=[];errors=[];observations={}
def done(s):checks.append(s)
def assert_close(a,b,e=.003):assert abs(a-b)<e,(a,b)
with ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
 server.device=Device(out/'state'/'profile.json',load_bridge())
 initial=copy.deepcopy(server.device.profile);initial['sensors'][0].update(mode='linear',unit='kPa',y0=10,y1=110,confirmed=True)
 assert server.device.save(json.dumps(initial).encode())[0]==200
 threading.Thread(target=server.serve_forever,daemon=True).start()
 os.chdir(out/'tmp');os.environ['TMPDIR']='.'
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='chrome',headless=True,args=['--no-sandbox'])
  try:
   page=browser.new_page(viewport={'width':390,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto('http://127.0.0.1:'+str(server.server_address[1]));page.locator('#ratiometric').wait_for()
   page.wait_for_function('()=>status&&status.fresh&&status.sensors[0].valid')
   assert not page.locator('#ratiometric').is_checked();assert page.locator('#confirmed').is_checked()
   page.locator('#ratiometric').check();assert not page.locator('#confirmed').is_checked();done('Changing live editor to ratio clears confirmation')
   page.locator('#f-reference_supply_v').fill('5.1')
   page.locator('[data-capture="v0"]').click()
   pair=page.evaluate('()=>({captured:profile.sensors[0].v0,expected:status.sensors[0].sensor_v*5.1/status.sensor_5v,saved:savedProfile.sensors[0].ratiometric})')
   assert_close(pair['captured'],pair['expected']);assert not pair['saved'];observations['capture_unsaved_reference']=pair;done('Actual server ADC-derived reading captures using unsaved reference; saved basis remains Off')
   page.evaluate('()=>api("/api/simulate",{method:"POST",body:JSON.stringify({sensor:"map",fault:"rail_4v8"})})')
   page.wait_for_function('()=>status&&Math.abs(status.sensor_5v-4.8)<.01')
   page.locator('[data-capture="v0"]').click()
   pair=page.evaluate('()=>({captured:profile.sensors[0].v0,expected:status.sensors[0].sensor_v*5.1/status.sensor_5v,raw:status.sensors[0].sensor_v,supply:status.sensor_5v})')
   assert_close(pair['captured'],pair['expected']);assert abs(pair['raw']-pair['captured'])>.1;observations['capture_4v8_server']=pair;done('Supply fault control at4.8V exercises actual host C++ basis with actual status capture')
   page.locator('#f-v0').fill('.5');page.locator('#f-reference_supply_v').fill('5');page.locator('#confirmed').check();page.locator('#save').click()
   page.locator('#toast').filter(has_text='Profile validated and saved').wait_for();assert server.device.profile['sensors'][0]['ratiometric']
   page.wait_for_function('()=>status.revision===profile.revision&&status.sensors[0].ratiometric&&status.sensors[0].valid')
   observed=page.evaluate('()=>structuredClone(status.sensors[0])');assert_close(observed['transfer_voltage_v'],observed['sensor_v']*5/4.8,.006);observations['saved_ratio_status']=observed;done('Explicit saved ratio profile persists and actual C++ status reports ratio basis')
   page.evaluate('()=>api("/api/simulate",{method:"POST",body:JSON.stringify({sensor:"map",fault:"rail"})})')
   page.wait_for_function('()=>status.sensor_5v<4&&!status.sensors[0].valid')
   before=page.locator('#f-v0').input_value();page.locator('[data-capture="v0"]').click();assert page.locator('#f-v0').input_value()==before;assert 'No fresh ADC sample' in page.locator('#toast').inner_text();done('Actual low rail rejects capture and reports unavailable converted value')
   old=copy.deepcopy(initial);old['schema_version']=1
   for sensor in old['sensors']:sensor.pop('ratiometric');sensor.pop('reference_supply_v')
   page.locator('#import-file').set_input_files({'name':'old.json','mimeType':'application/json','buffer':json.dumps(old).encode()})
   assert page.evaluate('()=>profile.schema_version===2&&profile.sensors.every(s=>s.ratiometric===false&&s.reference_supply_v===5)');done('Import of schema1 clears enabled state across every sensor')
   for width in (320,390,768,1440):
    page.set_viewport_size({'width':width,'height':1100});assert page.evaluate('()=>document.documentElement.scrollWidth<=innerWidth')
   page.locator('#conversion').screenshot(path=out/'ui-calibration.png');done('Controls fit four viewport widths')
   assert not errors,errors
  finally:browser.close()
 server.shutdown()
result={'passed':True,'checks':checks,'page_errors':errors,'observations':observations,'fixture_scope':'Uses actual local HTTP Device sampling/C++ bridge and authored host supply controls; no injected JS measurement values and no physical sensor evidence.'}
(out/'ui-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
