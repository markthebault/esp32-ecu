#include "/home/mark/persospace/esp32-ecu/firmware/main/espnow.cpp"
#include <iostream>
#include <stdexcept>
namespace ecu::engine_target {std::uint64_t clock_us(){return fake_now;}}
namespace ecu::board_status {
void request(status_led::Pattern){}
cJSON*snapshot(){return cJSON_CreateObject();}
}
static unsigned checks=0;
void requirement(bool ok,const char*expr,unsigned line){++checks;if(!ok){std::cerr<<line<<": "<<expr<<"\n";throw std::runtime_error("wire assertion");}}
#define must(x) requirement((x),#x,__LINE__)
float get(const std::uint8_t*p){float f;std::memcpy(&f,p,4);return f;}
int main(){try{
 namespace r=ecu::radio;r::start();fake_radio_now=5000000;
 ecu::web::Sample sample;sample.adc_ok=true;sample.raw.fill(2000);ecu::config::Config c;
 auto&s=c.sensors[0];s.mode=ecu::config::Mode::Linear;s.ratiometric=true;s.confirmed=true;s.v0=.5;s.v1=4.5;s.y0=10;s.y1=110;
 std::array<double,6> filter{};filter.fill(2.1);
 auto adc=[](double v){return static_cast<unsigned>(std::round(v*.6/3.3*4095));};
 for(double supply:{4.01,4.8,5.,5.29}){
  sample.raw[7]=adc(supply);sample.raw[0]=adc(.42*supply);r::publish(sample,c,filter);
  must(xQueueReceive(r::samples,&r::live,0)==pdTRUE);must(r::live.data[26]&1);must(std::abs(get(r::live.data+56)-50)<1e-4);
  must((r::live.data[28]|(unsigned(r::live.data[29])<<8))==sample.raw[0]);must(std::abs(get(r::live.data+52)-supply)<.002);
 }
 filter[0]=NAN;r::publish(sample,c,filter);must(xQueueReceive(r::samples,&r::live,0)==pdTRUE);must(!(r::live.data[26]&1));must(std::isnan(get(r::live.data+56)));must(r::live.fault);
 filter[0]=2.1;sample.raw[0]=0;r::publish(sample,c,filter);must(xQueueReceive(r::samples,&r::live,0)==pdTRUE);must(!(r::live.data[26]&1));
 sample.raw[0]=adc(2.1);sample.raw[7]=adc(2.4);r::publish(sample,c,filter);must(xQueueReceive(r::samples,&r::live,0)==pdTRUE);must(!(r::live.data[26]&1));
 sample.raw[7]=adc(5);sample.adc_ok=false;r::publish(sample,c,filter);must(xQueueReceive(r::samples,&r::live,0)==pdTRUE);must(!(r::live.data[26]&1));
 sample.adc_ok=true;s.ratiometric=false;filter[0]=2.016;sample.raw[7]=adc(4.8);r::publish(sample,c,filter);must(xQueueReceive(r::samples,&r::live,0)==pdTRUE);must(r::live.data[26]&1);must(std::abs(get(r::live.data+56)-47.9)<1e-4);
 std::cout<<"actual ESP-NOW publication checks="<<checks<<"; fake SDK queue/time only, no RF qualification\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
