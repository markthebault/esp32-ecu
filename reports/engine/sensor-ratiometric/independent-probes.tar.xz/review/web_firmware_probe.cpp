#include "/home/mark/persospace/esp32-ecu/firmware/main/web_config.cpp"
#include <iostream>
#include <fstream>
#include <iterator>
#include <stdexcept>
namespace ecu::radio {inline unsigned review_publications=0;inline std::array<double,6> review_filter{};void publish(const web::Sample&,const config::Config&,const std::array<double,6>&filter){++review_publications;review_filter=filter;}}
unsigned checks=0;void require(bool ok,const char*text){++checks;if(!ok)throw std::runtime_error(text);}
std::string read(const char*path){std::ifstream f(path);return std::string((std::istreambuf_iterator<char>(f)),{});}
void boot(){ecu::web::last_sample=0;ecu::web::filtered_revision=0;ecu::web::init();}
int main(int argc,char**argv){try{
 require(argc==3,"args");const auto legacy=read(argv[1]),upgraded=read(argv[2]);
 review_store=ReviewStore{};review_store.legacy_exists=true;review_store.legacy=legacy;boot();
 require(ecu::web::storage_ok,"legacy boot usable");require(ecu::web::document==upgraded,"actual firmware boot canonical normalization");require(!review_store.blob_exists&&review_store.writes==0&&review_store.legacy==legacy,"boot does not rewrite storage");
 require(ecu::config_storage::save(ecu::web::document.data(),ecu::web::document.size())==ESP_OK,"migrated long document saves as blob");require(review_store.blob==upgraded&&review_store.legacy==legacy,"new blob and retained old string");
 review_store.legacy="invalid";boot();require(ecu::web::storage_ok&&ecu::web::document==upgraded,"present valid blob preferred over invalid legacy");
 review_store.blob="invalid";review_store.legacy=legacy;boot();require(!ecu::web::storage_ok,"invalid blob blocks writes instead of fallback");require(ecu::web::document!=upgraded,"invalid blob uses defaults");
 review_store.blob=upgraded;review_store.blob[10]=0;boot();require(!ecu::web::storage_ok,"embedded NUL blob rejects");
 review_store.blob=upgraded;review_store.read_error=ESP_ERR_NVS_TYPE_MISMATCH;boot();require(!ecu::web::storage_ok,"wrong-type blob rejects without legacy fallback");
 review_store=ReviewStore{};review_store.namespace_exists=false;boot();require(ecu::web::storage_ok,"missing namespace uses defaults");
 auto ratio=ecu::web::active;ratio.revision=123;ratio.sensors[0].ratiometric=true;ratio.sensors[0].mode=ecu::config::Mode::Linear;ratio.sensors[0].v0=.5;ratio.sensors[0].v1=4.5;ratio.sensors[0].y0=10;ratio.sensors[0].y1=110;ecu::web::active=ratio;
 auto adc=[](double voltage){return unsigned(std::round(voltage*.6/3.3*4095));};ecu::web::Sample sample;sample.adc_ok=true;sample.raw.fill(adc(2));sample.raw[7]=adc(5);sample.raw[0]=adc(2.1);fake_now=1000000;ecu::web::publish(sample);
 const auto first=ecu::radio::review_filter[0];sample.raw[7]=adc(4.8);sample.raw[0]=adc(.42*4.8);fake_now+=5000;ecu::web::publish(sample);require(std::abs(ecu::radio::review_filter[0]-first)<.001,"actual firmware publish normalizes before smoothing");
 sample.adc_ok=false;fake_now+=5000;ecu::web::publish(sample);require(!std::isfinite(ecu::radio::review_filter[0]),"actual publish ADC failure invalidates ratio basis");sample.adc_ok=true;fake_now+=5000;ecu::web::publish(sample);require(std::isfinite(ecu::radio::review_filter[0]),"actual publish reseeds recovered ratio");
 ratio.sensors[0].reference_supply_v=4.8;ratio.revision++;ecu::web::active=ratio;fake_now+=5000;ecu::web::publish(sample);require(std::abs(ecu::radio::review_filter[0]-sample.raw[0]*ratio.adc_reference_v/4095/.6*4.8/(sample.raw[7]*ratio.adc_reference_v/4095/.6))<1e-12,"actual publish revision change resets basis");
 std::cout<<"actual web_config.cpp boot/load/publish checks="<<checks<<"; fake NVS/timer/mutex, no ESP-IDF or physical flash execution\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
