#include "config_json.hpp"
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iterator>
#include <random>
#include <stdexcept>
static unsigned checks=0; static long budget=-1;
void must(bool ok,const char*what){++checks;if(!ok)throw std::runtime_error(what);}
void near(double a,double b){must(std::isfinite(a)&&std::isfinite(b)&&std::abs(a-b)<1e-9,"numeric invariant");}
void* alloc(std::size_t n){if(budget==0)return nullptr;if(budget>0)--budget;return std::malloc(n);}
int main(int argc,char**argv){try{
 must(argc==2,"args");std::ifstream f(argv[1]);std::string text((std::istreambuf_iterator<char>(f)),{});
 auto*j=cJSON_Parse(text.c_str());ecu::config::Config c;must(j&&ecu::web::parse(j,c),"defaults");
 auto s=c.sensors[0];s.mode=ecu::config::Mode::Linear;s.ratiometric=true;s.reference_supply_v=5;s.fault_low_v=.02;s.fault_high_v=5.3;s.v0=.5;s.v1=4.5;s.y0=10;s.y1=110;s.filter_ms=100;
 std::mt19937_64 rng(0x11D3E);std::uniform_real_distribution<double> voltage(.6,3.8),rail(4,5.3),outputs(-1000,1000);
 for(unsigned n=0;n<10000;++n){double basis=voltage(rng),supply=rail(rng);s.reference_supply_v=rail(rng);s.y0=outputs(rng);s.y1=outputs(rng);double raw=basis*supply/s.reference_supply_v;auto r=ecu::config::convert(s,raw,raw*.6,supply);must(r.valid,"ratio invariance validity");near(r.transfer_v,basis);near(r.value,s.y0+(basis-.5)/4*(s.y1-s.y0));near(r.sensor_v,raw);}
 s.reference_supply_v=5;s.y0=10;s.y1=110;double previous=2.1;
 for(double supply:{4.,4.8,5.,5.3}){double physical=.42*supply;previous=ecu::config::readout_filter(s,physical,supply,previous,5,false);near(previous,2.1);}
 s.fault_low_v=.45;auto low=ecu::config::convert(s,.4,.24,0);must(!low.valid&&!std::strcmp(low.fault,"below input range"),"raw low fault precedence");
 s.fault_high_v=4.6;auto high=ecu::config::convert(s,4.7,2.82,0);must(!high.valid&&!std::strcmp(high.fault,"above input range"),"raw high fault precedence");s.fault_low_v=.02;s.fault_high_v=5.3;
 for(double supply:std::array<double,5>{0.,3.99,5.31,NAN,INFINITY}){must(!ecu::config::convert(s,2.1,1.26,supply).valid,"bad rail conversion");previous=ecu::config::readout_filter(s,2.1,supply,previous,5,false);must(!std::isfinite(previous),"bad rail filter");previous=ecu::config::readout_filter(s,2.016,4.8,previous,5,false);near(previous,2.1);}
 must(!std::isfinite(ecu::config::readout_filter(s,2.1,5,2.1,5,false,false)),"failed ADC poisons ratio filter");
 s.mode=ecu::config::Mode::Table;s.point_count=3;s.points[0]={.5,0};s.points[1]={2.1,30};s.points[2]={4.5,90};near(ecu::config::convert(s,2.88,1.728,4.8).value,52.5);
 auto*old=cJSON_Duplicate(j,true);cJSON_SetNumberValue(cJSON_GetObjectItemCaseSensitive(old,"schema_version"),1);for(unsigned i=0;i<6;++i){auto*row=cJSON_GetArrayItem(cJSON_GetObjectItemCaseSensitive(old,"sensors"),i);cJSON_DeleteItemFromObjectCaseSensitive(row,"ratiometric");cJSON_DeleteItemFromObjectCaseSensitive(row,"reference_supply_v");c.sensors[i].ratiometric=true;c.sensors[i].reference_supply_v=4.8;}
 must(ecu::web::parse(old,c),"legacy parse into enabled config");for(const auto&row:c.sensors)must(!row.ratiometric&&row.reference_supply_v==5,"legacy sticky reset");
 unsigned failed=0,succeeded=0;for(long n=0;n<40;++n){auto*copy=cJSON_Duplicate(old,true);cJSON_Hooks hooks{alloc,std::free};budget=n;cJSON_InitHooks(&hooks);bool ok=ecu::web::upgrade_profile_document(copy);cJSON_InitHooks(nullptr);budget=-1;if(ok){++succeeded;must(ecu::web::parse(copy,c),"migrated doc valid");}else ++failed;cJSON_Delete(copy);}
 must(failed>0&&succeeded>0,"allocation fault coverage");cJSON_Delete(old);cJSON_Delete(j);
 std::cout<<"independent checks="<<checks<<" migration failures="<<failed<<" successes="<<succeeded<<" random seed=0x11D3E\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
