#!/usr/bin/env python3
"""Exact filled-polygon RF area check on an owned immutable candidate copy."""
import collections,hashlib,json,pathlib
import pcbnew
R=pathlib.Path(__file__).resolve().parent;F=R/'RF-delta-freeze-001';P=F/'.cache/engine/flex-circuit/a6-prune-001/round-010/esp32-ecu.kicad_pcb'
B=pcbnew.LoadBoard(str(P));OLD=pcbnew.LoadBoard(str(R/'freeze-001/.cache/engine/flex-circuit/a6-finish-002/trial-035/esp32-ecu.kicad_pcb'))
rects=[(16,29,43,36),(20,32,39,40)];CU={B.GetLayerName(l) for l in B.GetEnabledLayers().Seq() if pcbnew.IsCopperLayer(l)}
areas=[z for z in B.Zones() if z.GetIsRuleArea()];assert len(areas)==2
for z in areas:assert {B.GetLayerName(l) for l in z.GetLayerSet().Seq()}==CU and z.GetDoNotAllowTracks() and z.GetDoNotAllowVias() and z.GetDoNotAllowCopperPour()
assert set(t.GetClass() for t in B.GetTracks())=={'PCB_TRACK','PCB_VIA'}
def clip(a,z,rect):
    lo,hi=0.,1.;dx=z[0]-a[0];dy=z[1]-a[1]
    for p,q in [(-dx,a[0]-rect[0]),(dx,rect[2]-a[0]),(-dy,a[1]-rect[1]),(dy,rect[3]-a[1])]:
        if p==0:
            if q<0:return False
        elif p<0:lo=max(lo,q/p)
        else:hi=min(hi,q/p)
        if lo>hi:return False
    return lo<=hi
crossings=[]
for t in B.GetTracks():
    if t.GetClass()=='PCB_VIA':
        a=(pcbnew.ToMM(t.GetPosition().x),pcbnew.ToMM(t.GetPosition().y));z=a;rad=pcbnew.ToMM(t.GetWidth(pcbnew.F_Cu))/2
    else:
        a=(pcbnew.ToMM(t.GetStart().x),pcbnew.ToMM(t.GetStart().y));z=(pcbnew.ToMM(t.GetEnd().x),pcbnew.ToMM(t.GetEnd().y));rad=pcbnew.ToMM(t.GetWidth())/2
    if any(clip(a,z,(x0-rad,y0-rad,x1+rad,y1+rad)) for x0,y0,x1,y1 in rects):crossings.append(t.m_Uuid.AsString())
assert not crossings,crossings
pad_bbox_overlaps=[]
for fp in B.GetFootprints():
    for p in fp.Pads():
        box=p.GetBoundingBox();a=[pcbnew.ToMM(box.GetX()),pcbnew.ToMM(box.GetY()),pcbnew.ToMM(box.GetRight()),pcbnew.ToMM(box.GetBottom())]
        if any(min(a[2],x1)>max(a[0],x0) and min(a[3],y1)>max(a[1],y0) for x0,y0,x1,y1 in rects):pad_bbox_overlaps.append([fp.GetReference(),p.GetNumber()])
assert not pad_bbox_overlaps,pad_bbox_overlaps
intersections=[]
for z in B.Zones():
    if z.GetIsRuleArea():continue
    for rect in rects:
        box=pcbnew.SHAPE_POLY_SET();box.NewOutline();x0,y0,x1,y1=rect
        for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]:box.Append(pcbnew.FromMM(x),pcbnew.FromMM(y))
        # Clone before BooleanIntersection: original board/filled polys untouched.
        poly=pcbnew.SHAPE_POLY_SET(z.GetFilledPolysList(z.GetLayer()));poly.BooleanIntersection(box)
        area=poly.Area()/1e12;intersections.append({'net':z.GetNetname(),'layer':B.GetLayerName(z.GetLayer()),'RF_rect':rect,'intersection_area_mm2':area})
        assert area==0,(z.GetNetname(),area)
critical={'FLEX_RAW','FLEX_INPUT_MID','FLEX_IN','FLEX_REF','FLEX_CMP','FLEX','LED_5V','+5V','+3V3'}
def states(b):
    return {t.m_Uuid.AsString():(t.GetNetname(),t.GetStart().x,t.GetStart().y,t.GetEnd().x,t.GetEnd().y,t.GetWidth(pcbnew.F_Cu) if t.GetClass()=='PCB_VIA' else t.GetWidth(),t.GetLayerSet().FmtHex()) for t in b.GetTracks() if t.GetNetname() in critical}
assert states(OLD)==states(B)
d=json.loads((F/'.cache/engine/flex-circuit/a6-prune-001/round-010/finish-drc.json').read_text());assert not d['violations'] and not d['unconnected_items'] and not d['schematic_parity']
result={'board_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'both_RF_rules_all6_Cu_layers':True,'track_body_expanded_rectangle_crossings':crossings,
 'pad_bounding_box_area_overlaps':pad_bbox_overlaps,'actual_plane_filled_polygon_intersections':intersections,
 'critical_analog_supply_LED_Cu_identical_to035':True,'parent_saved_DRC_counts':[0,0,0],
 'RF_geometry_finding_closed':True,'physical_RF_or_final_Cu_acceptance':False,
 'boundary_note':'Initial grid sampler included the exact polygon boundary, which HitTestFilledArea counts as touching. Exact cloned polygon intersection areas are zero; no positive-area fill intrusion exists.'}
with open(R/'RF-delta-check-001.json','x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
