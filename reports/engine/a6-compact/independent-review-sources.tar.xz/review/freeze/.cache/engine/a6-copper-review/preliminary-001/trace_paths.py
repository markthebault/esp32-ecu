#!/usr/bin/env python3
"""Read-only copper centerline measurements; no extracted RF/RC/current model."""
import collections,hashlib,heapq,itertools,json,math,pathlib
import pcbnew
from PIL import Image,ImageDraw,ImageFont
R=pathlib.Path(__file__).resolve().parent;P=R/'freeze-001/.cache/engine/flex-circuit/a6-finish-002/trial-035';B=pcbnew.LoadBoard(str(P/'esp32-ecu.kicad_pcb'))
CU=list(l for l in B.GetEnabledLayers().Seq() if pcbnew.IsCopperLayer(l));FPS={f.GetReference():f for f in B.GetFootprints()};PADS={(f.GetReference(),p.GetNumber()):p for f in B.GetFootprints() for p in f.Pads()}
T=collections.defaultdict(list)
for t in B.GetTracks():T[t.GetNetname()].append(t)
def point(v):return v.x,v.y
def uid(t):return t.m_Uuid.AsString()
def node(layer,p):return layer,p[0],p[1]
def graph(net):
    tracks=T[net];segments=[t for t in tracks if t.GetClass()=='PCB_TRACK'];vias=[t for t in tracks if t.GetClass()=='PCB_VIA'];nodes=set();pn={};g=collections.defaultdict(list)
    def add(a,b,d,kind):g[a].append((b,d,kind));g[b].append((a,d,kind))
    for t in segments:
        nodes.add(node(t.GetLayer(),point(t.GetStart())));nodes.add(node(t.GetLayer(),point(t.GetEnd())))
    for key,p in PADS.items():
        if p.GetNetname()!=net:continue
        ns=[node(l,point(p.GetPosition())) for l in CU if p.IsOnLayer(l)];pn[key]=ns;nodes.update(ns)
        for a,b in zip(ns,ns[1:]):add(a,b,0,{'kind':'pad_barrel','pad':key})
    for t in vias:
        ns=[node(l,point(t.GetPosition())) for l in CU if t.IsOnLayer(l)];nodes.update(ns)
        for a,b in zip(ns,ns[1:]):add(a,b,0,{'kind':'via','uuid':uid(t)})
    bylayer=collections.defaultdict(list)
    for n in nodes:bylayer[n[0]].append(n)
    for t in segments:
        a=point(t.GetStart());b=point(t.GetEnd());dx=b[0]-a[0];dy=b[1]-a[1];den=dx*dx+dy*dy
        if not den:continue
        cuts=[]
        for n in bylayer[t.GetLayer()]:
            u=((n[1]-a[0])*dx+(n[2]-a[1])*dy)/den
            if -.0000001<=u<=1.0000001 and math.hypot(n[1]-a[0]-u*dx,n[2]-a[1]-u*dy)<=10:cuts.append((u,n))
        cuts.sort()
        for (_,n),(_,q) in zip(cuts,cuts[1:]):
            add(n,q,math.dist(n[1:],q[1:])/1e6,{'kind':'track','uuid':uid(t),'layer':B.GetLayerName(t.GetLayer()),'width_mm':pcbnew.ToMM(t.GetWidth())})
    for key,ns in pn.items():
        p=PADS[key]
        for n in nodes:
            if p.IsOnLayer(n[0]) and p.HitTest(pcbnew.VECTOR2I(n[1],n[2])):
                c=node(n[0],point(p.GetPosition()));add(c,n,math.dist(c[1:],n[1:])/1e6,{'kind':'pad_land','pad':key})
    return g,pn
CACHE={}
def path(a,b):
    p,q=PADS[a],PADS[b];net=p.GetNetname();assert net==q.GetNetname(),(a,b)
    if net not in CACHE:CACHE[net]=graph(net)
    g,pn=CACHE[net];start=pn[a][0];target=pn[b][0];dist={start:0.};prev={};heap=[(0.,start)]
    while heap:
        d,n=heapq.heappop(heap)
        if d!=dist[n]:continue
        if n==target:break
        for v,w,meta in g[n]:
            new=d+w
            if new<dist.get(v,math.inf):dist[v]=new;prev[v]=(n,meta);heapq.heappush(heap,(new,v))
    if target not in dist:return {'from':a,'to':b,'net':net,'strict_centerline_path_found':False}
    pts=[];metas=[];n=target
    while n!=start:
        pts.append(n);n0,meta=prev[n];metas.append(meta);n=n0
    pts.append(start);pts.reverse();metas.reverse()
    return {'from':a,'to':b,'net':net,'strict_centerline_path_found':True,'centerline_plus_pad_land_mm':dist[target],
            'direct_mm':math.dist(point(p.GetPosition()),point(q.GetPosition()))/1e6,
            'track_layers':sorted(set(x['layer'] for x in metas if x['kind']=='track')),
            'track_uuids':list(dict.fromkeys(x['uuid'] for x in metas if x['kind']=='track')),
            'path_mm':[[B.GetLayerName(l),x/1e6,y/1e6] for l,x,y in pts]}
PAIRS=[(('R158','2'),('U18','3')),(('R159','1'),('U18','3')),(('R160','2'),('U18','3')),(('U18','1'),('R160','1')),
       (('C159','1'),('U18','2')),(('R162','1'),('U18','2')),(('R161','2'),('U18','2')),(('C158','1'),('R158','1')),
       (('C160','1'),('U18','8')),(('C161','1'),('U19','18')),(('C162','1'),('U20','2')),
       (('R179','2'),('J23','1')),(('R164','2'),('U3','32')),(('R163','1'),('C161','1'))]
paths=[path(a,b) for a,b in PAIRS]
stats={}
for net in ['FLEX_RAW','FLEX_INPUT_MID','FLEX_IN','FLEX_REF','FLEX_CMP','FLEX','LED_5V','+5V','+3V3','VIN_PROT','VIN_FILTERED','VBAT_FUSED','SENSOR_5V','MAIN_LS','PUMP_LS','FAN_LS','CHASSIS']:
    seg=[t for t in T[net] if t.GetClass()=='PCB_TRACK'];stats[net]={'length_mm':sum(pcbnew.ToMM(t.GetLength()) for t in seg),'segments':len(seg),'vias':sum(t.GetClass()=='PCB_VIA' for t in T[net]),
       'widths_mm':dict(collections.Counter(str(pcbnew.ToMM(t.GetWidth())) for t in seg)),'layers':dict(collections.Counter(B.GetLayerName(t.GetLayer()) for t in seg))}
fills=[]
for key in [('U18','4'),('U18','5'),('C160','2'),('C159','2'),('C158','2'),('C161','2'),('C162','2')]:
    p=PADS[key];x,y=point(p.GetPosition());samples={}
    for z in B.Zones():
        if z.GetNetname()!='GND' or z.GetIsRuleArea():continue
        # Samples outside the nominal pad/thermal gap are only filled-Cu geometry,
        # not a proof of HF return impedance or actual assembly.
        samples[B.GetLayerName(z.GetLayer())]=sum(z.HitTestFilledArea(z.GetLayer(),pcbnew.VECTOR2I(x+int(1.5e6*math.cos(a)),y+int(1.5e6*math.sin(a)))) for a in [i*math.pi/4 for i in range(8)])
    fills.append({'pad':key,'GND_filled_sample_counts_8_directions_at_1p5mm':samples})
result={'board_sha256':hashlib.sha256((P/'esp32-ecu.kicad_pcb').read_bytes()).hexdigest(),'scope':'Centerline/nominal land graph only; zero-cost PTH/via barrel transitions. No planes in path graph, and no extracted capacitance/inductance/current/thermal bounds.',
        'pairs':paths,'net_stats':stats,'GND_near_pad_samples':fills}
with open(R/'trace-paths-001.json','x') as f:json.dump(result,f,indent=2);f.write('\n')
for v in paths:print(v['from'],v['to'],v.get('centerline_plus_pad_land_mm'),v.get('direct_mm'),v.get('track_layers'))

# Numeric-data drawing, not a fabrication export. Actual filled planes omitted.
def plot(name,box,highlight):
    scale=26;pad=50;w=int((box[2]-box[0])*scale)+2*pad;h=int((box[3]-box[1])*scale)+2*pad
    im=Image.new('RGB',(w,h),'white');dr=ImageDraw.Draw(im);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
    def xy(v):return (pad+(pcbnew.ToMM(v.x)-box[0])*scale,pad+(pcbnew.ToMM(v.y)-box[1])*scale)
    for net,ts in T.items():
        color=highlight.get(net,'#d7d7d7')
        for t in ts:
            if t.GetClass()=='PCB_TRACK':dr.line([xy(t.GetStart()),xy(t.GetEnd())],fill=color,width=max(1,round(pcbnew.ToMM(t.GetWidth())*scale)))
    for key,p in PADS.items():
        x,y=xy(p.GetPosition())
        if not(0<x<w and 0<y<h):continue
        rad=max(3,pcbnew.ToMM(p.GetSize().x)*scale/2);dr.ellipse([x-rad,y-rad,x+rad,y+rad],outline=highlight.get(p.GetNetname(),'#999999'),width=2)
        if p.GetNetname() in highlight:dr.text((x+4,y+4),key[0]+'.'+key[1],fill='black',font=font)
    dr.rectangle([pad,pad,w-pad,h-pad],outline='black');dr.text((8,8),name+'; all-layer centerlines, filled planes omitted',fill='black',font=font)
    y=25
    for net,color in highlight.items():dr.text((8,y),net,fill=color,font=font);y+=15
    im.save(R/(name+'.png'))
plot('flex-traces',(77,89,115,121),{'FLEX_INPUT_MID':'#117744','FLEX_IN':'#0055dd','FLEX_REF':'#bb6600','FLEX_CMP':'#dd0055','+5V':'#555555'})
plot('RGB-traces',(48,80,90,120),{'LED_5V':'#dd0055','+5V':'#555555','+3V3':'#2266bb','LED_RESET_N':'#117744'})
