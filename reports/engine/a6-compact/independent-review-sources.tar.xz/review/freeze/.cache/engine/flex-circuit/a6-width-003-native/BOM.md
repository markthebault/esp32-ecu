# A6 development BOM, fabrication on hold

The native contract contains 263 footprints and 248 fitted electronic references. The [grouped draft shopping CSV](bom-shopping.csv), [per-reference assembly CSV](bom.csv) and [carrier pinout](connector-pinout.csv) describe this separate draft.

All listed MPNs are candidates. Match actual power, tolerance, temperature, ESR, lead pitch, upright formed body and height. Direct-solder DIP devices; only the ESP32 uses sockets. The old enclosure/material BOM remains historical and does not establish A6 fit. The PCB has no fabrication release.

J22 sensor supply is not18V limited, and its external sensor pinout is unresolved. J23 PH5 has four populated contacts; pin5 remains empty. R179330R limits its common supply in addition to the three cathode resistors; the conditional ground-fault bound does not establish brightness or a physical protection rating. R179 is the upright330R MRS16 candidate on its smaller DIN0204 footprint. Match the stated body/rating, formed leads and actual assembly; thermal and case fit remain unqualified. The RGB supervisor is MCP121-270E/TO; release hysteresis has a25C table condition. Rail headroom, loaded GPIO/readback, reset, heat, optics and sealed installation require physical checks.
