"""Independent compact-increment native/contract/BOM and geometric inspection.

Read-only on frozen native files. Measurements are CAD geometry, not qualification.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv, hashlib, heapq, json, math, re, xml.etree.ElementTree as ET
import pcbnew as k

OUT = Path(__file__).resolve().parent
F = OUT / 'freeze'
D = F / '.cache/engine/flex-circuit/a6-compact-width-001-native'
OLD = F / '.cache/engine/flex-circuit/a6-width-003-native'
B = k.LoadBoard(str(D / 'esp32-ecu.kicad_pcb'))
O = k.LoadBoard(str(OLD / 'esp32-ecu.kicad_pcb'))
CU = [k.F_Cu,k.In1_Cu,k.In2_Cu,k.In3_Cu,k.In4_Cu,k.B_Cu]
FPS = {f.GetReference():f for f in B.GetFootprints()}
PADS = {(f.GetReference(),p.GetNumber()):p for f in B.GetFootprints() for p in f.Pads() if p.GetNumber()}
C = json.loads((D/'net_contract.json').read_text())
CP = {p['ref']:p for p in C['parts']}
PROFILE = json.loads((F/'hardware/flex-input/frontend-compact.json').read_text())
errors=[]
def check(test,context):
    if not test: errors.append(context)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def xy(v): return [v.x/1e6,v.y/1e6]
def integer(v): return v.x,v.y
def uid(v): return v.m_Uuid.AsString()
def fields(f): return {p.GetName():p.GetText() for p in f.GetFields()}
def fpname(f):
    i=f.GetFPID()
    return i.GetLibItemName()
def normalized_net(n): return None if not n or n.startswith('unconnected-(') else n
def padnets(f): return {q.GetNumber():normalized_net(q.GetNetname()) for q in f.Pads() if q.GetNumber()}
def geometry(f):
    return [xy(f.GetPosition()),f.GetOrientationDegrees(),f.GetLayer(),fpname(f),
            sorted((q.GetNumber(),xy(q.GetPosition()),xy(q.GetSize()),xy(q.GetDrillSize()),q.GetLayerSet().FmtHex()) for q in f.Pads())]
check(len(FPS)==len(list(B.GetFootprints()))==len(CP)==len(C['parts'])==264,'Native or contract duplicate/missing references')
for ref,p in CP.items():
    f=FPS[ref]
    check(padnets(f)==p['pins'],[ref,'native pins',padnets(f),p['pins']])
    for name,actual,expected in [('value',f.GetValue(),p['value']),('MPN',fields(f).get('MPN',''),p['mpn']),('footprint',fpname(f),p['footprint'].split(':')[-1]),('DNP',bool(f.GetAttributes()&k.FP_DNP),p.get('dnp',False))]:
        check(actual==expected,[ref,name,actual,expected])
    check(max(abs(a-b) for a,b in zip(xy(f.GetPosition()),p['placed_xy_mm']))<2e-6,[ref,'placement'])
    check(abs((f.GetOrientationDegrees()-p['placed_angle_deg']+180)%360-180)<1e-6,[ref,'angle'])
for p in PROFILE['parts']+list(PROFILE['existing_package_changes'].values()):
    ref=p['ref'];actual=CP[ref]
    for name in ['value','pins']:
        check(actual[name]==p[name],[ref,'profile',name])
    if 'mpn' in p: check(actual['mpn']==p['mpn'],[ref,'profile MPN'])
    if 'mounting' in p:
        check(actual['footprint'].split(':')[-1]==p['mounting']['footprint'],[ref,'profile package'])
        check(B.GetLayerName(FPS[ref].GetLayer())==p['mounting']['side'],[ref,'profile side'])
check(C['flex_input']['source_sha256']==digest(F/'hardware/flex-input/frontend-compact.json'),'Contract compact profile SHA')
check(C['flex_input']['contract']==PROFILE['contract'],'Contract compact identity')
netlist=ET.parse(OUT/'native-netlist.xml').getroot()
components={c.get('ref'):c for c in netlist.findall('./components/comp')}
nets={}
for net in netlist.findall('./nets/net'):
    for n in net.findall('node'):nets[n.get('ref'),n.get('pin')]=normalized_net(net.get('name'))
mechanical=sorted(ref for ref,f in FPS.items() if not any(q.GetNumber() for q in f.Pads()))
check(set(components)==set(CP)-set(mechanical),'XML reference set differs from contract minus no-number mechanical pads')
for ref,e in components.items():
    p=CP[ref]
    check(e.findtext('value')==p['value'],[ref,'XML value'])
    check(e.findtext('footprint','').split(':')[-1]==p['footprint'].split(':')[-1],[ref,'XML footprint'])
    ef={x.get('name'):x.text or '' for x in e.findall('./fields/field')}
    check(ef.get('MPN','')==p['mpn'],[ref,'XML MPN',ef.get('MPN',''),p['mpn']])
    for pin,expected in p['pins'].items():check(nets.get((ref,pin))==expected,[ref,pin,'XML net',nets.get((ref,pin)),expected])
def csvrows(name):
    with(D/name).open(newline='') as f:return list(csv.DictReader(f))
bom=csvrows('bom.csv');br={r['Reference']:r for r in bom}
check(len(bom)==len(br)==len(CP),'Assembly BOM reference set')
for ref,p in CP.items():
    for name,key in [('Value','value'),('MPN','mpn'),('Footprint','footprint')]:check(br[ref][name]==p[key],[ref,'BOM',name])
    check(br[ref]['DNP']==str(p.get('dnp',False)),[ref,'BOM DNP'])
groups=defaultdict(list)
for ref,p in CP.items():
    if not ref.startswith(('H','TP')):groups[p['value'],p['mpn'],p['footprint'],p.get('dnp',False)].append(ref)
shopping=csvrows('bom-shopping.csv');pcb_shopping=[r for r in shopping if r['Section']=='PCB'];shopping_refs=[]
for r in pcb_shopping:
    refs=r['References / use'].split(', ');shopping_refs+=refs;part=CP[refs[0]];key=(part['value'],part['mpn'],part['footprint'],part.get('dnp',False))
    check(set(refs)==set(groups[key]),['shopping group',refs])
    check(int(r['Quantity'])==(0 if key[3] else len(refs)),['shopping quantity',refs])
    check(int(r['Optional quantity'])==(len(refs) if key[3] else 0),['shopping optional quantity',refs])
    check(r['MPN / specification']==key[1] or not key[1],['shopping MPN',refs])
check(len(shopping_refs)==len(set(shopping_refs))==sum(len(v) for v in groups.values()),'Shopping reference set/duplicates')
pinout=csvrows('connector-pinout.csv');crimps=Counter()
for r in pinout:
    ref,pin=r['Connector'],r['PCB pin'];net=CP[ref]['pins'][pin]
    check(r['Net']==(net or 'NC'),['pinout net',ref,pin])
    check(r['Contact populated']==str(net is not None),['pinout contact',ref,pin])
    if net is not None and r['Mating housing'].startswith(('VHR-','XHP-','PHR-')):crimps[r['Mating housing'].split('-')[0]]+=1
check({(r['Connector'],r['PCB pin']) for r in pinout}=={(ref,pin)for ref,p in CP.items()if re.fullmatch('J[0-9]+',ref) for pin in p['pins']},'Pinout completeness')
check(crimps==Counter(VHR=24,XHP=28,PHR=10),'Crimp counts')
j20=[r for r in pinout if r['Connector']=='J20'];check(len(j20)==2 and all(r['Mating housing']=='PHR-2' for r in j20),'J20 housing')
for r in shopping:
    if r['Section']=='Ancillary' and r['References / use'] in crimps:
        check(int(r['Quantity'])==crimps[r['References / use']],['shopping crimp count',r])
check(any(r['Section']=='Ancillary' and r['MPN / specification']=='PHR-2' and r['References / use']=='J20' and r['Quantity']=='1' for r in shopping),'J20 housing shopping')
check(any(r['Section']=='Ancillary' and r['References / use']=='PHR' and r['MPN / specification']=='SPH-002T-P0.5S by wire' for r in shopping),'PH crimp identity shopping')
oldfps={f.GetReference():f for f in O.GetFootprints()};allowed=set(PROFILE['compact_layout_intent']['movable_frontend_references'])|{'U18','J20','C164'}
changed_fixed=[];changed_topology=[]
for ref,old in oldfps.items():
    if ref not in allowed and geometry(old)!=geometry(FPS[ref]):changed_fixed.append(ref)
    if padnets(old)!=padnets(FPS[ref]):changed_topology.append(ref)
check(not changed_fixed,['Unauthorized existing package/placement change',changed_fixed]);check(not changed_topology,['Changed old topology',changed_topology])
check(set(FPS)-set(oldfps)=={'C164'},'Unexpected added component')
def centroid(f):
    q=[xy(p.GetPosition()) for p in f.Pads()];return [sum(v[i] for v in q)/len(q) for i in range(2)]
u18_delta=[a-b for a,b in zip(centroid(FPS['U18']),centroid(oldfps['U18']))]
check(max(abs(a-b) for a,b in zip(u18_delta,[.1,.05]))<2e-6,'U18 body-center transform')
check(abs((FPS['U18'].GetOrientationDegrees()-oldfps['U18'].GetOrientationDegrees())%360-90)<1e-6,'U18 rotation')
def courtyard(f):
    pts=[]
    for s in f.GraphicalItems():
        if s.GetLayer()==k.F_CrtYd:pts += [xy(s.GetStart()),xy(s.GetEnd())]
    return [min(v[0] for v in pts),min(v[1] for v in pts),max(v[0] for v in pts),max(v[1] for v in pts)]
oc,nc=courtyard(oldfps['J20']),courtyard(FPS['J20'])
check(oc[0]<=nc[0] and oc[1]<=nc[1] and oc[2]>=nc[2] and oc[3]>=nc[3],'J20 courtyard not contained')
check(padnets(FPS['H5'])=={'1':'CHASSIS'},'H5 no longer CHASSIS lug')
for ref in ('C158','C159','C160','C164'):
    f=FPS[ref];check(len(list(f.Pads()))==2 and all(abs(q.GetDrillSize().x/1e6-.8)<1e-6 for q in f.Pads()),[ref,'C315 holes'])
    q=list(f.Pads());check(abs(math.dist(xy(q[0].GetPosition()),xy(q[1].GetPosition()))-2.54)<1e-6,[ref,'C315 pitch'])

# Independent global width policy scan, with exactly the three literal prior necks.
power={'GND','VBAT_FUSED','VIN_PROT','VIN_FILTERED'}|{f'INJ{i}_LS' for i in range(1,5)}
supply={'+5V','+3V3','SENSOR_5V','FLEX_12V','MAIN_LS','PUMP_LS','FAN_LS'}
necks={'0b7ea104-b013-488f-93e3-d6a76c61494c':((113051500,10900000),(113051500,10944300)), '0f7d20d6-419f-4559-84dd-fcca2c17c76a':((103800000,10900000),(103800000,10944300)), '885ffd1f-71be-4c13-8ade-664dadba50ad':((113051500,10900000),(103800000,10900000))}
tracks=[t for t in B.GetTracks()if t.GetClass()=='PCB_TRACK'];vias=[t for t in B.GetTracks()if t.GetClass()=='PCB_VIA'];byuid={uid(t):t for t in B.GetTracks()};widths=defaultdict(Counter)
for t in tracks:
    n=t.GetNetname();minimum=1000000 if n in power else 500000 if n in supply else 250000;widths[n][t.GetWidth()/1e6]+=1
    if uid(t) in necks:check(t.GetWidth()==800000 and n=='INJ1_LS' and t.GetLayer()==k.In3_Cu and (integer(t.GetStart()),integer(t.GetEnd()))==necks[uid(t)],['Literal neck mismatch',uid(t)])
    else:check(t.GetWidth()>=minimum,['Width below policy',uid(t),n])
check(set(necks)<=set(byuid),'Missing literal neck')
for v in vias:
    check(v.GetViaType()==k.VIATYPE_THROUGH and v.TopLayer()==k.F_Cu and v.BottomLayer()==k.B_Cu and v.GetDrillValue()>=300000 and all(v.IsOnLayer(l) and v.GetWidth(l)>=600000 and v.GetWidth(l)-v.GetDrillValue()>=200000 for l in CU),['Via policy',uid(v)])

# Compare local receipt identities with actual objects, then independently measure pad paths.
local=json.loads((F/'.cache/engine/flex-circuit/a6-local-route-001/local-analog-results.json').read_text())
local_board=k.LoadBoard(str(F/'.cache/engine/flex-circuit/a6-local-route-001/trial-016/esp32-ecu.kicad_pcb'))
local_before=k.LoadBoard(str(F/'.cache/engine/flex-circuit/a6-compact-009-native/esp32-ecu.kicad_pcb'))
local_objects={uid(t):t for t in local_board.GetTracks()}
before_objects={uid(t):t for t in local_before.GetTracks()}
def copper_geometry(t):
    return [t.GetClass(),t.GetNetname(),integer(t.GetStart()),integer(t.GetEnd()),t.GetLayer(),t.GetWidth(k.F_Cu) if t.GetClass()=='PCB_VIA' else t.GetWidth()]
priority_ids={u for r in local['trials']for u in r['added_uuids']}
check(set(local_objects)-set(before_objects)==priority_ids,'Local stage added unreceipted objects')
check(all(copper_geometry(local_objects[u])==copper_geometry(byuid[u])for u in priority_ids),'Priority objects changed geometry after local routing')
check(all(copper_geometry(t)==copper_geometry(local_objects[u])for u,t in before_objects.items()),'Local routing altered previous objects')
local_checks=[]
for r in local['trials']:
    ts=[byuid[u]for u in r['added_uuids']];length=sum(t.GetLength()/1e6 for t in ts)
    check(all(t.GetNetname()==r['net'] and B.GetLayerName(t.GetLayer())==r['layer'] and abs(t.GetWidth()/1e6-r['width_mm'])<1e-9 for t in ts),['local binding',r['branch']])
    check(abs(length-r['length_mm'])<1e-5,['local length',r['branch'],length,r['length_mm']])
    local_checks.append(dict(branch=r['branch'],start=r['start'],end=r['end'],length_mm=length,layer=r['layer'],objects=len(ts)))

def graph(net):
    segs=[t for t in tracks if t.GetNetname()==net];vv=[v for v in vias if v.GetNetname()==net];pn={};nodes=set();g=defaultdict(list)
    def node(l,v):return l,v.x,v.y
    def edge(a,b,w,meta):g[a].append((b,w,meta));g[b].append((a,w,meta))
    for t in segs:nodes.update((node(t.GetLayer(),t.GetStart()),node(t.GetLayer(),t.GetEnd())))
    for key,p in PADS.items():
        if p.GetNetname()!=net:continue
        ns=[node(l,p.GetPosition())for l in CU if p.IsOnLayer(l)];pn[key]=ns;nodes.update(ns)
        for a,b in zip(ns,ns[1:]):edge(a,b,0,('PTH',key))
    for v in vv:
        ns=[node(l,v.GetPosition())for l in CU if v.IsOnLayer(l)];nodes.update(ns)
        for a,b in zip(ns,ns[1:]):edge(a,b,0,('via',uid(v)))
    for t in segs:
        a,b=integer(t.GetStart()),integer(t.GetEnd());dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy
        if not den:continue
        cuts=[]
        for n in nodes:
            if n[0]!=t.GetLayer():continue
            u=((n[1]-a[0])*dx+(n[2]-a[1])*dy)/den
            if -1e-9<=u<=1+1e-9 and math.hypot(n[1]-a[0]-u*dx,n[2]-a[1]-u*dy)<=10:cuts.append((u,n))
        cuts.sort()
        for (_,a),(_,b)in zip(cuts,cuts[1:]):edge(a,b,math.dist(a[1:],b[1:])/1e6,('track',uid(t)))
    for key,ns in pn.items():
        p=PADS[key]
        for n in nodes:
            if p.IsOnLayer(n[0]) and p.HitTest(k.VECTOR2I(n[1],n[2])):
                c=node(n[0],p.GetPosition());edge(c,n,math.dist(c[1:],n[1:])/1e6,('land',key))
    return g,pn
cache={}
paths=[]
for r in local['trials']:
    a=tuple(r['start'].split('.'));b=tuple(r['end'].split('.'));net=PADS[a].GetNetname()
    if net not in cache:cache[net]=graph(net)
    g,pn=cache[net];s,t=pn[a][0],pn[b][0];dist={s:0};prior={};queue=[(0,s)]
    while queue:
        d,u=heapq.heappop(queue)
        if d!=dist[u]:continue
        if u==t:break
        for v,w,meta in g[u]:
            if d+w<dist.get(v,math.inf):dist[v]=d+w;prior[v]=(u,meta);heapq.heappush(queue,(d+w,v))
    check(t in dist,['Path absent',a,b])
    if t not in dist:continue
    metas=[];points=[t];u=t
    while u!=s:u,meta=prior[u];metas.append(meta);points.append(u)
    ids=list(dict.fromkeys(v for kind,v in metas if kind=='track'));layers=sorted({B.GetLayerName(byuid[u].GetLayer())for u in ids})
    paths.append(dict(start=r['start'],end=r['end'],net=net,centerline_plus_land_mm=dist[t],direct_mm=math.dist(xy(PADS[a].GetPosition()),xy(PADS[b].GetPosition())),layers=layers,track_uuids=ids,via_count=len({v for kind,v in metas if kind=='via'}),points=[[B.GetLayerName(l),x/1e6,y/1e6]for l,x,y in reversed(points)]))

# Ground return observations use the actual filled polygons; they are not impedance calculations.
ground_zones=[z for z in B.Zones()if not z.GetIsRuleArea() and z.GetNetname()=='GND'];returns=[]
for key in [('U18','4'),('U18','5'),('C160','2'),('C164','2'),('C159','2'),('C158','2')]:
    p=PADS[key];x,y=integer(p.GetPosition());samples={}
    for z in ground_zones:
        l=z.GetLayer();samples[B.GetLayerName(l)]={str(radius):sum(bool(z.HitTestFilledArea(l,k.VECTOR2I(x+round(radius*1e6*math.cos(a)),y+round(radius*1e6*math.sin(a))))) for a in [i*math.pi/8 for i in range(16)])for radius in (.5,1,1.5)}
    returns.append(dict(pad='.'.join(key),xy_mm=xy(p.GetPosition()),radial_filled_counts_of_16=samples))
plane_under_routes=[]
for r in local['trials']:
    plane=k.In4_Cu if r['layer']=='B.Cu' else k.In1_Cu;z=next(z for z in ground_zones if z.GetLayer()==plane);total=filled=0
    for u in r['added_uuids']:
        t=byuid[u];a,b=xy(t.GetStart()),xy(t.GetEnd());n=max(2,math.ceil(math.dist(a,b)/.05))
        for j in range(n+1):
            v=k.VECTOR2I(round((a[0]+(b[0]-a[0])*j/n)*1e6),round((a[1]+(b[1]-a[1])*j/n)*1e6));total+=1;filled+=bool(z.HitTestFilledArea(plane,v))
    plane_under_routes.append(dict(branch=r['branch'],plane=B.GetLayerName(plane),filled_samples=filled,total_samples=total))

# Actual nearby non-ground traces: every parallel pair, all layers; no assumption of extracted pF.
near=[]
for t in tracks:
    if t.GetNetname() not in {'FLEX_IN','FLEX_INPUT_MID','FLEX_REF'}:continue
    a,b=xy(t.GetStart()),xy(t.GetEnd());length=math.dist(a,b)
    if length<.25:continue
    d=[(b[i]-a[i])/length for i in range(2)]
    for u in tracks:
        if u.GetNetname()in {t.GetNetname(),'GND'}:continue
        c,e=xy(u.GetStart()),xy(u.GetEnd());ul=math.dist(c,e)
        if ul<.25:continue
        ud=[(e[i]-c[i])/ul for i in range(2)]
        if abs(d[0]*ud[1]-d[1]*ud[0])>.001:continue
        q=[sum((v[i]-a[i])*d[i]for i in range(2))for v in (c,e)];overlap=min(length,max(q))-max(0,min(q))
        spacing=abs((c[0]-a[0])*d[1]-(c[1]-a[1])*d[0])
        if overlap<.5 or spacing>1:continue
        same=t.GetLayer()==u.GetLayer();edge=spacing-(t.GetWidth()+u.GetWidth())/2e6 if same else None
        near.append(dict(input=t.GetNetname(),other=u.GetNetname(),layers=[B.GetLayerName(t.GetLayer()),B.GetLayerName(u.GetLayer())],overlap_mm=overlap,projected_center_spacing_mm=spacing,same_layer_edge_mm=edge,uuids=[uid(t),uid(u)]))

# RF checks apply to bodies, pads, all actual pour polygons, and all six rule layers.
rf=[z for z in B.Zones()if z.GetIsRuleArea()];rf_result=[]
for z in rf:
    check(set(z.GetLayerSet().Seq())==set(CU) and z.GetDoNotAllowTracks() and z.GetDoNotAllowVias() and z.GetDoNotAllowPads() and z.GetDoNotAllowCopperPour(),'RF rule enforcement')
    box=z.Outline().BBox();rect=[box.GetX()/1e6,box.GetY()/1e6,box.GetRight()/1e6,box.GetBottom()/1e6]
    def clipped(a,b,r):
        lo,hi=0,1;dx,dy=b[0]-a[0],b[1]-a[1]
        for p,q in [(-dx,a[0]-r[0]),(dx,r[2]-a[0]),(-dy,a[1]-r[1]),(dy,r[3]-a[1])]:
            if p==0:
                if q<0:return False
            elif p<0:lo=max(lo,q/p)
            else:hi=min(hi,q/p)
            if lo>hi:return False
        return True
    hits=[];padhits=[];fills=[]
    for t in B.GetTracks():
        radius=(t.GetWidth(k.F_Cu) if t.GetClass()=='PCB_VIA' else t.GetWidth())/2e6;r=[rect[0]-radius,rect[1]-radius,rect[2]+radius,rect[3]+radius]
        if clipped(xy(t.GetStart()),xy(t.GetEnd()),r):hits.append(uid(t))
    for key,p in PADS.items():
        box=p.GetBoundingBox();r=[box.GetX()/1e6,box.GetY()/1e6,box.GetRight()/1e6,box.GetBottom()/1e6]
        if min(r[2],rect[2])>max(r[0],rect[0]) and min(r[3],rect[3])>max(r[1],rect[1]):padhits.append(key)
    for pour in B.Zones():
        if pour.GetIsRuleArea():continue
        poly=k.SHAPE_POLY_SET(pour.GetFilledPolysList(pour.GetLayer()));poly.BooleanIntersection(z.Outline());area=poly.Area()/1e12
        fills.append(dict(net=pour.GetNetname(),layer=B.GetLayerName(pour.GetLayer()),intersection_mm2=area));check(area==0,['RF pour intrusion',area])
    check(not hits and not padhits,['RF track/pad intrusion',hits,padhits]);rf_result.append(dict(rect_mm=rect,track_body_overlaps=hits,pad_box_overlaps=padhits,pour_intersections=fills))
result=dict(passed=not errors,errors=errors,board_sha256=digest(D/'esp32-ecu.kicad_pcb'),native_counts=dict(footprints=len(FPS),schematic_components=len(components),numbered_pads=len(PADS),tracks=len(tracks),vias=len(vias)),mechanical_no_number_refs=mechanical,summary=dict(pcb_purchase_groups=len(groups),fitted_electronic_refs=sum(len(v)for key,v in groups.items()if not key[3]),DNP=sorted(ref for ref,p in CP.items()if p.get('dnp')),crimps=dict(crimps)),old_to_new=dict(fixed_packages_changed=changed_fixed,old_topology_changed=changed_topology,U18_body_translation_mm=u18_delta,J20_old_courtyard_mm=oc,J20_new_courtyard_mm=nc),priority_objects_exact_geometry_preserved=len(priority_ids),local_stage_added_only_receipted_tracks_no_vias=True,local_receipt_measurements=local_checks,independent_paths=paths,GND_return_samples=returns,plane_under_route_samples=plane_under_routes,nearby_parallel_pairs=near,RF_geometry=rf_result,net_track_width_counts_mm={n:dict(c)for n,c in widths.items()},qualification='CAD geometry and literal native/contract/BOM agreement only. No extraction, thermal/current/RF/fit or supply transient qualification.')
(OUT/'independent-native-inspection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['passed','errors','native_counts','summary','old_to_new']},indent=2))
