from pathlib import Path
import datetime,hashlib,json

P=Path(__file__).resolve().parent
def read(name):return json.loads((P/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
native=read('independent-native-inspection.json');model=read('independent-model-inspection.json');pub=read('publication-comparison.json');neg=read('independent-native-negative-controls.json');guard=read('declared-audit-controls.json');stability=read('source-stability.json');manifest=read('freeze-manifest.json')
assert all(r['passed'] for r in [native,model,pub,neg,guard])
assert all(x['native_provenance_identical']and x['all_asset_bytes_identical']and x['declared_hash_matches']for x in read('footprint-provenance-checks.json'))
assert stability['all_sources_still_identical']and stability['all_frozen_files_still_identical']
assert not read('native-drc.json')['violations']and not read('native-drc.json')['unconnected_items']and not read('native-drc.json')['schematic_parity']
assert not any(s['violations']for s in read('native-erc.json')['sheets'])
assert read('matrix-rerun-command.json')['exit_code']==read('binding-tests-command.json')['exit_code']==0
rel='.cache/engine/a6-compact-increment-review/revision001'
commands=[]
for row in read('native-commands.json'):commands.append(dict(cwd='/home/mark/persospace/esp32-ecu',**row))
for name in ['matrix-rerun-command.json','binding-tests-command.json','native-svg-command.json']:commands.append(dict(cwd='/home/mark/persospace/esp32-ecu',**read(name)))
for row in neg['controls']:commands.append(dict(cwd='/home/mark/persospace/esp32-ecu',command=row['command'],exit_code=row['exit_code'],seconds=row['seconds']))
for script,log in [('inspect_native.py','independent-native-inspection.log'),('negative_native.py','independent-native-negative-controls.log'),('inspect_models.py','independent-model-inspection.log'),('inspect_publication.py','publication-comparison.log'),('inspect_guardrails.py','declared-audit-controls.log'),('inspect_assets.py','footprint-provenance-checks.log'),('render_locality.py','render-locality.log')]:
    commands.append(dict(cwd='/home/mark/persospace/esp32-ecu',shell_command=f'python3 -B {rel}/{script} > {rel}/{log} 2>&1',script_sha256=sha(P/script),result='completed; result files and logs retained'))
(P/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
source_suffixes=['hardware/flex-input/frontend.json','hardware/flex-input/frontend-compact.json','hardware/a6-flex-rgb/net_contract.json','hardware/a6-flex-rgb/esp32-ecu.kicad_pcb','hardware/a6-flex-rgb/esp32-ecu.kicad_pro','hardware/a6-flex-rgb/esp32-ecu.kicad_dru','scripts/apply_a6_analog_solution.py','scripts/route_a6_local_analog.py','scripts/restore_a6_copper.py','scripts/finish_a6_routes.py','scripts/prune_a6_stubs.py','scripts/update_a6_contracts.py','scripts/add_a6_width_rules.py','scripts/audit_a6_copper.py','tools/run_flex_circuit.py','tools/test_flex_frontend.py','tools/flex_circuit_capture.cpp','firmware/include/ecu/flex_fuel.hpp','.cache/engine/flex-circuit/a6-compact-width-001-native/net_contract.json','.cache/engine/flex-circuit/a6-compact-width-001-native/esp32-ecu.kicad_pcb','.cache/engine/flex-circuit/a6-width-003-native/esp32-ecu.kicad_pcb','.cache/engine/flex-circuit/compact-matrix-001/index.json','.cache/engine/a6-copper-review/preliminary-001/review.json']
source_hashes={s:sha(P/'freeze'/s)for s in source_suffixes}
priority={r['start']+'->'+r['end']:r for r in native['local_receipt_measurements']}
open_findings=[
 dict(id='INC-PARASITICS-01',priority='physical_qualification_hold',finding='No physical 5pF/15pF/10pF comparator-input/output/GPIO bound has been established. The previous same-layer IN/CMP parallel witness is absent. Actual current FLEX_IN on In2 and ADC7 on adjacent In3 have 2.25mm parallel overlap with 0.025mm projected center spacing; no ground layer lies between these two signal layers. This is a geometric coupling witness, not a demonstrated excess capacitance or functional defect.',action='Keep the capacitance assumptions conditional. Use a specified dielectric/copper stack and extraction or physical measurements, including ADC activity, before claiming a post-layout parasitic bound. No mandatory routing change follows from this review alone.',evidence=['independent-native-inspection.json:nearby_parallel_pairs','native-locality-six-layers.png']),
 dict(id='INC-SUPPLY-01',priority='physical_qualification_hold',finding='C160 and C164 improve native locality, but every executed deck models nominal ideal 100nF capacitors on assumed sources. X7R effective capacitance, DC bias, ESR/ESL and actual rail impedance/transients are outside these results. Ground sampling shows connected, broadly continuous In1/In4 pours and normal PTH clearances; it does not prove a continuous screen under every segment or a return-impedance bound.',action='Retain the supply-stability hold and validate the selected assembled capacitors and rails physically or with justified nonideal supply models. Do not describe the ideal-cap matrix as a supply-transient or full-temperature stability guarantee.',evidence=['independent-model-inspection.json','independent-native-inspection.json:GND_return_samples','independent-native-inspection.json:plane_under_route_samples','native-locality-six-layers.png']),
 dict(id='INC-CURRENT-01',priority='current_thermal_qualification_hold',finding='The three literal prior INJ1 0.8mm objects remain the sole audited power-width exceptions. The native floor deliberately permits 0.8mm on INJ1 generally; native zero-DRC alone would also accept an extra 0.8mm segment or a 10um change to an authorized neck. Both the independent exact policy and the actual frozen audit reject those mutations. Width and nominal P70 arithmetic are not current, derating, pulse, I2t or assembled-temperature ratings.',action='Retain the exact UUID/net/layer/endpoints audit as a required companion to native DRC. Close the current/thermal/fuse hold with load-specific evidence before fabrication or operation.',evidence=['independent-native-negative-controls.json','declared-audit-controls.json','independent-native-inspection.json','independent-model-inspection.json:resistor_peak_w']),
 dict(id='INC-ASSEMBLY-01',priority='physical_fit_qualification_hold',finding='Native compact package identities, holes/pitches, fixed-part preservation and J20 courtyard containment are coherent. They do not qualify formed MRS16 leads, C315 pitch tolerance and finished 0.8mm holes, hand-solder thermal behavior, PH crimp/strap performance, N16R8 stack/antenna, printed parts or case fit. J20 remains an internal two-pin CHASSIS bond with no normal load return; H5 remains CHASSIS.',action='Retain actual-part lead-form/finished-hole/thermal and assembled module/case/RF checks. Preserve the separate unresolved external J22 sensor pin mapping and unqualified FLEX_12V behavior.',evidence=['independent-native-inspection.json','footprint-provenance-checks.json','publication-comparison.json'])]
report=dict(schema=1,review='A6 compact frontend / native routing / model increment',reviewed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewer='Independent delegated reviewer; no subagents; no source edits, services, flashing, external messages or physical output actions',accepted=True,decision='ACCEPT_DEVELOPMENT_DRAFT_WITH_EXPLICIT_HOLDS',publication_may_proceed=True,development_publication_blockers=[],scope='Frozen compact candidate and exact native publication copy only. Logical/profile/native/BOM consistency, circuit reproducibility, width enforcement, locality, nearby copper and RF geometry were checked. This is no fabrication, sensor hookup, engine-operation or physical qualification approval.',candidate=dict(path='.cache/engine/flex-circuit/a6-compact-width-001-native',pcb_sha256=native['board_sha256'],contract_sha256=source_hashes['.cache/engine/flex-circuit/a6-compact-width-001-native/net_contract.json']),publication=dict(path='hardware/a6-flex-rgb',pcb_sha256=pub['pcb_sha256'],contract_sha256=pub['published_contract_sha256'],all_78_delivered_noncontract_files_identical=True,only_changed_contract_fields=pub['contract_changed_fields'],metadata_state_correction_accepted=True,validation_report_was_review_pending_at_freeze=True,review_result_may_be_added_to_report=True),source_freeze=dict(directory='freeze',manifest='freeze-manifest.json',manifest_sha256=sha(P/'freeze-manifest.json'),source_files=len(manifest['sources']),original_and_frozen_files_unchanged_at_check=True,stability_report='source-stability.json',key_sha256=source_hashes),accepted_scope=[
 'All 264 native footprint identities/values/MPNs/pin nets/DNP/placements agree with the contract; all 260 electrical schematic components and all 779 numbered pads agree with fresh KiCad XML. The four unnumbered mechanical holes are H1..H4.',
 'BOM/pinout recomputation agrees: 99 electronic purchase groups, 249 fitted electronic references, R32/R33/R41/R43 DNP, and 24 VH / 28 XH / 10 PH connected contacts. J20 uses one PHR-2 and the PH contact group uses SPH-002T-P0.5S.',
 'Existing topology is preserved; C164 is the only added footprint. All fixed packages/pads retain exact geometry. U18 body translation is +0.1/+0.05mm with +90deg rotation. New J20 courtyard [107.51,106.8,114.41,112.3]mm lies entirely within old [105.55,102.8,114.41,112.3]mm.',
 'C315 and PH2 retained provenance/asset hashes match the actual project library. This verifies provenance binding, not manufacturer dimensional/assembly qualification.',
 'All 87 priority copper objects exactly match the frozen local-routing stage after the completed restoration/routing/pruning/metadata steps. That local stage added exactly the 87 receipted tracks and no vias.',
 'The previous comparator bypass, remote pullup bypass, immediate feedback/summing detours and same-layer IN/CMP parallel witness have been addressed geometrically. Physical circuit/parasitic qualification stays open.',
 'Both RF rectangles apply to all six copper layers, deny tracks/vias/pads/pours, and have zero expanded trace/via-body, pad-box and actual filled-polygon area intrusions.',
 'The current compact profile has the same numeric circuit as the retained matrix profile; exactly nine nominal_body_mm->maximum_body_mm metadata key renames are the only differences. All 62 current compact decks match retained inputs, all 62 legacy decks match actual matrix-007 decks, and C164 is explicitly present once in every compact deck.'
 ],independent_native_checks=dict(DRC_violations=0,unconnected_items=0,schematic_parity=0,ERC_violations=0,severities=['error','warning','exclusion'],counts=native['native_counts'],native_width_controls=neg['controls'],global_copper_policy_passed=True,repository_audit_controls_passed=guard['passed'],prior_severities_unchanged=True,native_exclusions=[],ignored_categories=guard['disabled_native_categories'],note='All enabled severities were requested. The five inherited ignored categories are explicitly listed, and none was newly disabled. Independent package/net/BOM checks and actual width mutations complement native DRC.'),independent_numerical_checks=dict(binding_tests=6,full_fresh_ngspice_capture_rerun=True,ngspice_elf_sha256=read('matrix-rerun-command.json')['ngspice_elf_sha256'],case_count=62,retained_raw_rows=3978182,capture_observations=4300,raw_gzip_bytes_and_case_replay_payloads_identical=True,negative_capture_controls=model['negative_capture_controls'],resistor_peak_w=model['resistor_peak_w'],max_compact_resistor_peak_w=model['resistor_peak_w']['R157']['peak_w'],max_750R_pullup_peak_w=max(model['resistor_peak_w'][r]['peak_w']for r in ['R155','R156','R166']),power_scope='All retained rows independently parsed; actual executed resistor values used for V^2/R. Peaks are below nominal P70 references only; no assembled derating, thermal, pulse or physical protection rating.'),local_priority_centerline_lengths_mm={key:priority[key]['length_mm']for key in ['U18.1->R160.1','R160.2->U18.3','C160.1->U18.8','C164.1->R163.1','R158.2->U18.3','R159.1->U18.3','C159.1->U18.2']},measurement_note='Priority-object centerline sums and independent shortest track/land paths are both retained. The latter can be slightly shorter through shared pad lands; no zone shortcuts or physical barrel-length model are invented.',closed_layout_actions=['CU-DECOUPLE-01: short C160/U18 supply branch','CU-PULLUP-01: added C164 and short R163 local supply branch','CU-FEEDBACK-01: immediate summing/feedback shortening and IN/CMP layer separation','CU-RULES-01: active native width rules plus exact INJ1 exception audit','CU-RF-01: prior six-layer geometric RF closure preserved','Publication state: stale native_checks_required corrected on an exact native copy'],open_findings=open_findings,remaining_context='Physical engine outputs remain inhibited by the existing development policy; this review authorizes no output enablement. Full Speeduino feature parity and TunerStudio online are unfinished and outside this increment. No physical RF, timing, sensor, vehicle, thermal, splash or enclosure qualification follows.',manufacturing_release=False,physical_qualification=False,engine_operation_release=False,sensor_connection_release=False,evidence=dict(commands='commands.json',native='independent-native-inspection.json',models='independent-model-inspection.json',negative_controls='independent-native-negative-controls.json',declared_audit='declared-audit-controls.json',publication='publication-comparison.json',assets='footprint-provenance-checks.json',native_DRC='native-drc.json',native_ERC='native-erc.json',fresh_netlist='native-netlist.xml',full_matrix='matrix-rerun/index.json',plot='native-locality-six-layers.png'))
(P/'review.json').write_text(json.dumps(report,indent=2)+'\n')
text='''ACCEPT: coherent development draft may be published with explicit holds.

PCB SHA256: 2cfc0d9328337cccce873d8882cc32c2a305b6afd9e53c2393769a298af8b4b2.
Candidate: .cache/engine/flex-circuit/a6-compact-width-001-native.
Publication: hardware/a6-flex-rgb. All 78 delivered non-contract files are identical;
only status/native_checks_required/native_validation change in its contract.
The HOLD status and false fabrication/physical release fields remain intact.

Fresh KiCad 9.0.8 DRC/ERC: zero findings, opens or schematic parity issues,
with error/warning/exclusion severities requested. Independent native/contract/
fresh XML/BOM checks agree on 264 footprints, 260 schematic components, 779 pins,
3588 tracks, 151 vias; 99 BOM groups, 249 fitted electronic refs, 4 DNP,
24 VH / 28 XH / 10 PH connected contacts. H1..H4 explain the four-component gap.
Existing topology/fixed package geometry is preserved; C164 is the only addition.
J20 PH2 is fully contained in its old courtyard, both pins CHASSIS; H5 is preserved.

All 87 local copper objects retain exact geometry; no local vias were added.
Priority branch lengths: output-feedback 3.798mm, feedback-input 6.165mm,
C160 supply 3.333mm, C164 pullup 2.257mm. Immediate IN/CMP use separate layers.
In1/In4 ground pours are broadly continuous, with PTH clearances. Both RF areas
enforce all six copper layers and have zero actual body/pad/pour intrusions.
Four fresh actual-board negative controls pass: native width rules reject the
supply/power changes; the actual exact audit also rejects extra or altered INJ1
necks that the native 0.8mm floor intentionally permits. No exclusions were added.

Six binding tests pass. A full fresh 62-case ngspice/capture run reproduces all
3,978,182 raw rows and 4,300 capture observations byte-for-byte in raw gzip and
case payloads. All 62 current compact decks match retained inputs, all legacy
decks match actual matrix-007, and all compact decks contain C164. The only profile
delta after the retained run is nine nominal-to-maximum dimension-field renames.
Independent all-row power peaks: compact R157 45.536mW; three 750R pullups
422.504mW each, below nominal P70 references only.

Open holds: effective X7R/ESR/ESL and real supply transients; physical 5/15/10pF
parasitic bounds and timing; current/thermal/I2t including the three literal INJ1
necks; actual formed leads, finished holes, crimp/strap, module/antenna and case
fit. A 2.25mm FLEX_IN/ADC7 overlap on adjacent In2/In3 remains a geometric coupling
witness, not a demonstrated defect or extracted capacitance. Keep qualification
pending; do not convert this review into fabrication, sensor hookup or engine
operation approval. Full Speeduino parity and TunerStudio online remain unfinished.

No concrete reviewed-source/native/model/BOM mismatch blocks draft publication.
Exact freezes/hashes: freeze-manifest.json; all 1486 original and frozen files
were unchanged at final check. Commands: commands.json. Detailed evidence and
actionable qualification holds: review.json and the referenced inspection files.
'''
(P/'review.txt').write_text(text)
print(json.dumps(dict(accepted=True,decision=report['decision'],review_sha256=sha(P/'review.json'),text_sha256=sha(P/'review.txt'),source_files=len(manifest['sources']),evidence_directory=str(P))))
