from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;f=p/'freeze/hardware/flex-input/footprints';d=p/'freeze/.cache/engine/flex-circuit/a6-compact-width-001-native/lib';checks=[]
for name in ['compact-capacitor-provenance.json','compact-shield-connector-provenance.json']:
    x=json.loads((f/name).read_text());asset=x.get('asset',x.get('authored_asset'));candidates=list(f.rglob(asset));actual=d/'ecu.pretty'/asset;sha=hashlib.sha256(actual.read_bytes()).hexdigest();checks.append(dict(provenance=name,native_provenance_identical=(f/name).read_bytes()==(d/name).read_bytes(),authored_asset_paths=[str(q.relative_to(p))for q in candidates],asset_sha256=sha,declared_sha256=x.get('sha256',x.get('adapted_sha256')),declared_hash_matches=(sha==x.get('sha256',x.get('adapted_sha256'))),all_asset_bytes_identical=bool(candidates)and all(q.read_bytes()==actual.read_bytes()for q in candidates)))
(p/'footprint-provenance-checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(dict(passed=all(x['native_provenance_identical']and x['declared_hash_matches']and x['all_asset_bytes_identical']for x in checks))))
