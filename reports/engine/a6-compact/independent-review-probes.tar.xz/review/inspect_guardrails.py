from pathlib import Path
import hashlib,json,sys
import pcbnew as k
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'freeze/scripts'))
import audit_a6_copper as declared
records=[]
paths=[('candidate',p/'freeze/.cache/engine/flex-circuit/a6-compact-width-001-native/esp32-ecu.kicad_pcb')]+[(n,p/'negative-native'/n/'esp32-ecu.kicad_pcb')for n in ['supply','power','extra-INJ1-neck','alter-literal-neck']]
for name,path in paths:
    r=declared.audit(k.LoadBoard(str(path)));records.append(dict(name=name,passed=r['passed'],findings=r['findings'],track_count=r['track_count'],via_count=r['via_count']))
project=json.loads((paths[0][1].parent/'esp32-ecu.kicad_pro').read_text());old=json.loads((p/'freeze/.cache/engine/flex-circuit/a6-width-003-native/esp32-ecu.kicad_pro').read_text());ds=project['board']['design_settings'];old_ds=old['board']['design_settings'];disabled={name:severity for name,severity in ds['rule_severities'].items()if severity=='ignore'}
result=dict(passed=records[0]['passed']and all(not r['passed']for r in records[1:])and ds['rule_severities']==old_ds['rule_severities']and ds['drc_exclusions']==[],declared_audit_sha256=hashlib.sha256((p/'freeze/scripts/audit_a6_copper.py').read_bytes()).hexdigest(),actual_audit_results=records,disabled_native_categories=disabled,severities_unchanged_from_prior_baseline=ds['rule_severities']==old_ds['rule_severities'],exclusions=ds['drc_exclusions'],scope='Global geometric policy and physical width mutations; no claim that ignored library/type/missing-courtyard/editor-tuning categories were active.')
(p/'declared-audit-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],control_count=len(records)-1,exclusions=ds['drc_exclusions'])))
