"""Independently exercise actual candidate width rules and exact neck policy."""
from pathlib import Path
import hashlib,json,subprocess,shutil,time
import pcbnew as k
OUT=Path(__file__).resolve().parent
SRC=OUT/'freeze/.cache/engine/flex-circuit/a6-compact-width-001-native'
NECKS={'0b7ea104-b013-488f-93e3-d6a76c61494c':((113051500,10900000),(113051500,10944300)),'0f7d20d6-419f-4559-84dd-fcca2c17c76a':((103800000,10900000),(103800000,10944300)),'885ffd1f-71be-4c13-8ade-664dadba50ad':((113051500,10900000),(103800000,10900000))}
def uid(t):return t.m_Uuid.AsString()
def explicit(board):
    failures=[];seen=set()
    power={'GND','VBAT_FUSED','VIN_PROT','VIN_FILTERED'}|{f'INJ{i}_LS'for i in range(1,5)}
    supply={'+5V','+3V3','SENSOR_5V','FLEX_12V','MAIN_LS','PUMP_LS','FAN_LS'}
    for t in board.GetTracks():
        if t.GetClass()!='PCB_TRACK':continue
        if uid(t)in NECKS:
            seen.add(uid(t));a,b=t.GetStart(),t.GetEnd()
            if not(t.GetNetname()=='INJ1_LS' and t.GetWidth()==800000 and t.GetLayer()==k.In3_Cu and ((a.x,a.y),(b.x,b.y))==NECKS[uid(t)]):failures.append(uid(t))
        elif t.GetWidth()<(1000000 if t.GetNetname()in power else 500000 if t.GetNetname()in supply else 250000):failures.append(uid(t))
    return sorted(set(failures)|set(NECKS)-seen)
results=[]
for name,net,old,new,expected_native in [('supply','+5V',500000,250000,True),('power','VIN_PROT',1000000,800000,True),('extra-INJ1-neck','INJ1_LS',1000000,800000,False),('alter-literal-neck','INJ1_LS',800000,800000,False)]:
    d=OUT/'negative-native'/name;d.mkdir(parents=True,exist_ok=False)
    for s in SRC.iterdir():
        if s.is_file()and(s.suffix in ['.kicad_pcb','.kicad_sch','.kicad_pro','.kicad_dru']or s.name in ['sym-lib-table','fp-lib-table']):shutil.copy2(s,d/s.name)
    shutil.copytree(SRC/'lib',d/'lib')
    b=k.LoadBoard(str(d/'esp32-ecu.kicad_pcb'));t=next(t for t in b.GetTracks()if t.GetClass()=='PCB_TRACK'and t.GetNetname()==net and t.GetWidth()==old and ((uid(t)in NECKS)==(name=='alter-literal-neck')))
    target=uid(t)
    if name=='alter-literal-neck':
        a=t.GetStart();t.SetStart(k.VECTOR2I(a.x+10000,a.y))
    else:t.SetWidth(new)
    failures=explicit(b);k.ZONE_FILLER(b).Fill(b.Zones());k.SaveBoard(str(d/'esp32-ecu.kicad_pcb'),b)
    cmd=['kicad-cli','pcb','drc','--format','json','--all-track-errors','--schematic-parity','--severity-all','--exit-code-violations','-o',str(d/'drc.json'),str(d/'esp32-ecu.kicad_pcb')];start=time.time();p=subprocess.run(cmd,capture_output=True,text=True);(d/'drc.log').write_text(p.stdout+p.stderr);r=json.loads((d/'drc.json').read_text())
    native_width=any(v['type']=='track_width'and any(i['uuid']==target for i in v['items'])for v in r['violations'])
    row=dict(name=name,net=net,target_uuid=target,native_target_width_rejected=native_width,expected_native_width_rejection=expected_native,independent_exact_policy_rejected=(target in failures),explicit_rejection_uuids=failures,native_types=[v['type']for v in r['violations']],unconnected=len(r['unconnected_items']),parity=len(r['schematic_parity']),command=cmd,exit_code=p.returncode,seconds=time.time()-start,pcb_sha256=hashlib.sha256((d/'esp32-ecu.kicad_pcb').read_bytes()).hexdigest(),passed=(native_width==expected_native and target in failures))
    results.append(row);print(json.dumps(row),flush=True)
report=dict(passed=all(r['passed']for r in results),controls=results,native_caveat='Native INJ1 floor intentionally allows 0.8mm everywhere on INJ1; separate exact UUID/geometry audit must remain mandatory.',qualification=False)
(OUT/'independent-native-negative-controls.json').write_text(json.dumps(report,indent=2)+'\n')
