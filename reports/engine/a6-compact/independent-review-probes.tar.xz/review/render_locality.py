from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import xml.etree.ElementTree as ET,gi
gi.require_version('Rsvg','2.0')
from gi.repository import Rsvg
p=Path(__file__).resolve().parent;out=Image.new('RGB',(1500,1050),'white');dr=ImageDraw.Draw(out);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
for i,layer in enumerate(['F_Cu','In1_Cu','In2_Cu','In3_Cu','In4_Cu','B_Cu']):
    s=p/'native-svg'/f'esp32-ecu-{layer}.svg';root=ET.fromstring(s.read_text());root.set('viewBox','86 92 31 28');root.set('width','496px');root.set('height','450px');handle=Rsvg.Handle.new_from_data(ET.tostring(root));pix=handle.get_pixbuf();png=p/'native-svg'/f'local-{layer}.png';pix.savev(str(png),'png',[],[]);im=Image.open(png).convert('RGBA');bg=Image.new('RGB',im.size,'white');bg.paste(im,mask=im.getchannel('A'));x=(i%3)*500;y=(i//3)*510+35;out.paste(bg,(x,y));dr.text((x+8,y-27),layer.replace('_','.')+' native copper; top view',fill='black',font=font)
dr.text((10,1020),'Frozen compact board, native SVG crop near comparator / pullup. Filled planes included.',fill='black',font=font);out.save(p/'native-locality-six-layers.png')
