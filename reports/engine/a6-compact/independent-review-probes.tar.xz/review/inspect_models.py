"""Check actual profile diffs, emitted decks, full rerun and retained raw numbers."""
from pathlib import Path
import gzip,hashlib,importlib.util,json,sys,math
import numpy as np
OUT=Path(__file__).resolve().parent;F=OUT/'freeze';M=F/'.cache/engine/flex-circuit/compact-matrix-001';R=OUT/'matrix-rerun'
sys.path.insert(0,str(F/'tools'));import run_flex_circuit as runner
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diff(a,b,path=''):
    if isinstance(a,dict)and isinstance(b,dict):return sum((diff(a.get(k),b.get(k),path+'/'+str(k))for k in sorted(set(a)|set(b))),[])
    if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return sum((diff(x,y,path+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))),[])
    return []if a==b else [dict(path=path,before=a,after=b)]
errors=[]
def check(b,why):
    if not b:errors.append(why)
original=json.loads((M/'index.json').read_text());rerun=json.loads((R/'index.json').read_text());oldprofile=json.loads((M/'sources/hardware/flex-input/frontend-compact.json').read_text());profile=json.loads((F/'hardware/flex-input/frontend-compact.json').read_text());profile_changes=diff(oldprofile,profile)
expected=[]
for i,p in enumerate(profile['parts']):
    if p['ref'] in {f'R{j}'for j in range(157,166)}:
        expected +=[dict(path=f'/parts/{i}/mounting/maximum_body_mm',before=None,after=[3.6,1.6]),dict(path=f'/parts/{i}/mounting/nominal_body_mm',before=[3.6,1.6],after=None)]
check(sorted(profile_changes,key=lambda v:v['path'])==sorted(expected,key=lambda v:v['path']),'Profile changes exceed the nine nominal->maximum field renames')
check(rerun['cases']==original['cases'],'Fresh full simulation/capture case payload differs from retained matrix')
check(len(original['cases'])==len(rerun['cases'])==62,'case count')
source_checks=[]
for rel,sha in json.loads((M/'source-hashes.json').read_text()).items():
    actual=digest(M/'sources'/rel);check(actual==sha,['retained source SHA',rel]);current=digest(F/rel);source_checks.append(dict(path=rel,retained_sha256=actual,current_sha256=current,exact=(actual==current)))
decks=[];peaks={};rows=0;observations=0;rejections={};positive_width_extrema={};power_by_case=[];equal_printed_timestamps={}
nodecols={'0':None,'flex_raw':2,'flex_in':3,'flex_ref':4,'flex_cmp':5,'gpio':6,'rail33':7,'rail5':8,'flex_bias':9,'flex_pull_mid':10,'flex_input_mid':11,'flex_pull_mid2':15}
legacyroot=F/'.cache/engine/flex-circuit/matrix-007'
for result in original['cases']:
    c=runner.Case(**result['case']);folder=M/c.name;d=folder/'circuit.cir';deck=d.read_text();newdeck=runner.deck(c,Path('hardware/flex-input/frontend-compact.json'));legacydeck=runner.deck(c)
    check(newdeck==deck,[c.name,'Current compact emission differs from retained deck'])
    check((R/c.name/'circuit.cir').read_text()==deck,[c.name,'Fresh executed deck differs'])
    check((legacyroot/c.name/'circuit.cir').read_text()==legacydeck,[c.name,'Legacy deck regression'])
    check(deck.count('C164 rail33 0 1e-07\n')==1,[c.name,'C164 absent/duplicate'])
    raw=folder/'values.txt.gz';fresh=R/c.name/'values.txt.gz';check(raw.read_bytes()==fresh.read_bytes(),[c.name,'Raw simulation output differs'])
    with gzip.open(raw,'rt')as f:a=np.loadtxt(f,skiprows=1,ndmin=2)
    check(a.shape==(result['rows'],16)and np.isfinite(a).all(),[c.name,'Invalid raw rows'])
    check(c.dc or bool(np.all(np.diff(a[:,0])>=0)),[c.name,'Decreasing printed times'])
    if not c.dc:equal_printed_timestamps[c.name]=int(np.sum(np.diff(a[:,0])==0))
    rows+=len(a);local={}
    for line in deck.splitlines():
        words=line.split()
        if not words or words[0]not in {f'R{j}'for j in range(155,167)}:continue
        ref,n1,n2,value=words;ohm=float(value);v1=0 if nodecols[n1]is None else a[:,nodecols[n1]];v2=0 if nodecols[n2]is None else a[:,nodecols[n2]];watts=np.asarray((v1-v2)**2/ohm);j=int(np.argmax(watts));peak=float(watts[j]);local[ref]=peak
        if ref not in peaks or peak>peaks[ref]['peak_w']:peaks[ref]=dict(peak_w=peak,case=c.name,time_s=None if c.dc else float(a[j,0]),raw_scale_value=float(a[j,0]),simulated_ohm=ohm,nominal_P70_w=.4 if 157<=int(ref[1:])<=165 else .6)
    power_by_case.append(dict(case=c.name,peak_resistor_w=local))
    ob=[o for pat in result['threshold_replays']for o in pat['capture_replay_10_clock_phases']];observations+=len(ob)
    expected_valid=c.expect_capture_valid if c.expect_capture_valid is not None else c.fault_v is None and c.powered
    check(all(o['valid']==expected_valid for o in ob),[c.name,'Capture validity mismatch'])
    if c.expect_capture_valid is False:rejections[c.name]=dict(observations=len(ob),invalid=sum(not o['valid']for o in ob))
    if expected_valid and 'low_pulse_us'in result:positive_width_extrema[c.name]=[min(result['low_pulse_us']),max(result['low_pulse_us'])]
    decks.append(dict(case=c.name,compact_sha256=digest(d),legacy_sha256=hashlib.sha256(legacydeck.encode()).hexdigest(),raw_gzip_sha256=digest(raw),rows=len(a),observation_count=len(ob)))
check(rows==3978182 and observations==4300,'Raw row / replay observation count')
for ref,peak in peaks.items():check(peak['peak_w']<peak['nominal_P70_w'],[ref,'Peak exceeds nominal P70 reference'])
# Check the rail bypasses are ideal nominal shunts, not a swept supply/ESR/ESL model.
check(all('C160 rail5 0 1e-07' in (M/c['case']['name']/'circuit.cir').read_text()for c in original['cases']),'C160 deck binding')
report=dict(passed=not errors,errors=errors,case_count=len(decks),raw_rows=rows,capture_observations=observations,profile_metadata_only_changes=profile_changes,current_profile_sha256=digest(F/'hardware/flex-input/frontend-compact.json'),retained_profile_sha256=digest(M/'sources/hardware/flex-input/frontend-compact.json'),source_checks=source_checks,all_62_current_compact_decks_identical_to_retained=True,all_62_legacy_decks_identical_to_matrix007=True,fresh_62_case_payloads_and_raw_gzip_bytes_identical=True,negative_capture_controls=rejections,resistor_peak_w=peaks,positive_width_extrema_us=positive_width_extrema,cases=decks,power_by_case=power_by_case,duplicate_printed_timestamp_counts=equal_printed_timestamps,printed_time_note='ngspice wrdata decimal precision can repeat timestamps at very small adaptive intervals. They are nondecreasing; all retained rows are used. DC op shared scales are not elapsed time.',scope='Independent actual-file comparisons and raw-row resistor arithmetic. Entire ngspice/capture matrix was also rebuilt and rerun from frozen current sources. Nominal ideal capacitors and authored source/device equivalents only. No effective X7R, ESR/ESL, supply impedance/transient, physical capacitance/delay/thermal guarantee.')
(OUT/'independent-model-inspection.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['passed','errors','case_count','raw_rows','capture_observations','negative_capture_controls','resistor_peak_w']},indent=2))
