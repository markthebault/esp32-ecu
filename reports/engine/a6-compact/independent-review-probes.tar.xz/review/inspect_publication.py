"""Compare the concrete publication's native files and allowed contract delta."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent;F=OUT/'freeze';SRC=F/'.cache/engine/flex-circuit/a6-compact-width-001-native';PUB=F/'hardware/a6-flex-rgb'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((SRC/'net_contract.json').read_text());b=json.loads((PUB/'net_contract.json').read_text());keys=sorted(k for k in set(a)|set(b)if a.get(k)!=b.get(k));files=[];fail=[]
for p in sorted(f for f in PUB.rglob('*')if f.is_file()):
    rel=p.relative_to(PUB)
    if rel==Path('net_contract.json'):continue
    expected=SRC/rel
    if not expected.exists():fail.append(['Unexpected publication file',str(rel)]);continue
    same=p.read_bytes()==expected.read_bytes();files.append(dict(path=str(rel),sha256=digest(p),identical=same))
    if not same:fail.append(['Publication file differs',str(rel)])
# Historical negative-control boards and router receipts stay in the cache;
# root native documents and the actual project library must all be included.
required=[p for p in SRC.iterdir()if p.is_file()and(p.suffix in ['.kicad_pcb','.kicad_sch','.kicad_pro','.kicad_dru']or p.name in ['fp-lib-table','sym-lib-table','BOM.md','README.md','bom.csv','bom-shopping.csv','bom-summary.json','connector-pinout.csv'])]+[p for p in (SRC/'lib').rglob('*')if p.is_file()]
missing=[str(p.relative_to(SRC))for p in required if not(PUB/p.relative_to(SRC)).is_file()]
sha=digest(PUB/'esp32-ecu.kicad_pcb');expected_report='../../reports/engine/a6-compact/validation.json'
good=(keys==['native_checks_required','native_validation','status']and not fail and not missing and b['manufacturing_release']is False and b['physical_fit_tested']is False and b['native_checks_required']is False and b['status']=='NATIVE_ROUTED_COMPACT_DEVELOPMENT_HOLD' and b['native_validation']==dict(report=expected_report,pcb_sha256=sha,erc_violations=0,drc_violations=0,unconnected_items=0,schematic_parity_issues=0,manufacturing_release=False,physical_qualification=False))
validation=json.loads((F/'reports/engine/a6-compact/validation.json').read_text())
report=dict(passed=good,before_contract_sha256=digest(SRC/'net_contract.json'),published_contract_sha256=digest(PUB/'net_contract.json'),pcb_sha256=sha,contract_changed_fields=keys,changes={k:dict(before=a.get(k),after=b.get(k))for k in keys},published_files_checked=files,failures=fail,missing_required_native_files=missing,validation_at_freeze=validation,review_note='The native_validation reference correctly records completed native checks. Publication report was frozen while independent review was still pending. This review result may be linked into it without changing the accepted native bytes.')
(OUT/'publication-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(passed=good,identical_files=len(files),changed_contract_fields=keys,failures=fail,missing=missing),indent=2))
