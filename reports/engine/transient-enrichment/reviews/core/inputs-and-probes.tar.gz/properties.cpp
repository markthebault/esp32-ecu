#include "ecu/engine.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
#include <random>
namespace tr=ecu::transient;namespace en=ecu::engine;
en::Inputs input(std::uint64_t now,double tps=10){en::Inputs in;in.rpm=1000;in.map_kpa=50;in.tps_pct=tps;in.clt_c=85;in.iat_c=25;in.lambda=1.1;in.battery_v=14;in.sensor_v=5;in.sampled_us=now;in.synced=in.phase_synced=in.sensors_valid=in.lambda_ready=true;return in;}
int main(){
 unsigned rejected=0;
 for(auto field:tr::scalar_fields)for(float value:{NAN,INFINITY,-INFINITY}){tr::Config c;c.*field.member=value;assert(!tr::valid(c));rejected++;}
 for(auto field:tr::array_fields)for(unsigned index=0;index<4;index++)for(float value:{NAN,INFINITY,-INFINITY}){tr::Config c;(c.*field.member)[index]=value;assert(!tr::valid(c));rejected++;}
 unsigned accounting=0,capacity=0;
 for(auto strategy:{en::Strategy::BatchWasted,en::Strategy::Sequential,en::Strategy::SemiSequential})for(auto apply:{tr::Apply::Multiply,tr::Apply::AddReference})for(double map:{10.,50.,100.})for(float ve:{20.f,85.f,120.f})for(float warmup:{80.f,100.f,200.f})for(float lambda:{.75f,1.f,1.2f}){
  en::Tune tune;tune.strategy=strategy;tune.dfco_enabled=false;tune.ego_enabled=true;tune.afterstart_pct=15;tune.ve.cells.fill(ve);tune.lambda.cells.fill(lambda);tune.warmup_pct.fill(warmup);tune.transient_enrichment.mode=tr::Mode::TpsRate;tune.transient_enrichment.apply=apply;tune.transient_enrichment.tps_min_change_pct=0;
  en::Controller controller;en::Output out;en::Inputs in;
  for(unsigned n=0;n<=4;n++){in=input(n*5000,10+n*.5);in.map_kpa=map;out=controller.step(tune,in,n*5000);}
  const double ratio=out.transient_enrichment.values[tr::CorrectionPct]/100.0;
  const double air=map*1000*(tune.displacement_cc/tune.cylinders*1e-6)*(ve/100)/(287.05*(in.iat_c+273.15))*1e6;
  const double baseline=air/(tune.stoich_afr*lambda)*(warmup/100)*out.afterstart;
  const double reference=100000*(tune.displacement_cc/tune.cylinders*1e-6)/(287.05*298.15)*1e6/tune.stoich_afr;
  const double fuel=apply==tr::Apply::Multiply?baseline*ratio:baseline+reference*(ratio-1);
  const double openings=strategy==en::Strategy::Sequential?1:2,flow=tune.injector_cc_min*tune.fuel_density_g_cc/60;
  const double pulse=fuel/openings/flow+out.deadtime_ms,duty=pulse/(60000/in.rpm*(strategy==en::Strategy::Sequential?2:1))*100;
  assert(out.ego==1);
  if(pulse>tune.max_injection_ms||duty>tune.max_duty*100){assert(out.faults&en::Capacity);assert(out.pulse_ms==0&&out.fuel_cut&&out.spark_cut);capacity++;}
  else{assert(!out.faults&&std::abs(out.pulse_ms-pulse)<1e-6);assert(out.transient_enrichment.active());accounting++;}
 }
 for(auto strategy:{en::Strategy::BatchWasted,en::Strategy::Sequential,en::Strategy::SemiSequential})for(auto apply:{tr::Apply::Multiply,tr::Apply::AddReference})for(double battery:{9.,14.,16.}){
  en::Tune tune;tune.strategy=strategy;tune.dfco_enabled=false;tune.ego_enabled=true;tune.transient_enrichment.mode=tr::Mode::TpsRate;tune.transient_enrichment.apply=apply;tune.transient_enrichment.tps_min_change_pct=0;tune.transient_enrichment.decel_fuel_pct=0;en::Controller controller;en::Output out;
  for(unsigned n=0;n<=4;n++){auto in=input(n*5000,20-n*.5);in.battery_v=battery;out=controller.step(tune,in,n*5000);}
  assert(!out.faults&&out.fuel_cut&&!out.spark_cut&&out.pulse_ms==0&&out.dwell_ms>0&&out.ego==1);for(auto pulse:out.cylinder_pulse_ms)assert(pulse==0);
 }
 // Strong negative trims apply to the whole reference-added effective dose.
 {en::Tune tune;tune.strategy=en::Strategy::Sequential;tune.dfco_enabled=false;tune.afterstart_pct=0;tune.max_injection_ms=4;tune.cylinder_trims_enabled=true;for(auto&map:tune.cylinder_fuel)map.cells.fill(50);tune.transient_enrichment.mode=tr::Mode::TpsRate;tune.transient_enrichment.apply=tr::Apply::AddReference;en::Controller controller;en::Output out;
  for(unsigned n=0;n<=4;n++)out=controller.step(tune,input(n*5000,10+n*.5),n*5000);
  assert(!out.faults&&out.pulse_ms>4);for(auto pulse:out.cylinder_pulse_ms)assert(pulse<4);
 }
 std::mt19937 random(0x7007);unsigned sampled=0;
 for(unsigned test=0;test<200;test++){
  tr::Config config;config.mode=test%2?tr::Mode::TpsRate:tr::Mode::MapRate;config.apply=test%3?tr::Apply::Multiply:tr::Apply::AddReference;config.sample_period_ms=5+random()%96;config.duration_ms=random()%2001;config.decel_fuel_pct=random()%101;config.max_enrichment_pct=random()%651;config.cold_multiplier_pct=100+random()%156;assert(tr::valid(config));tr::Controller controller;double tps=50,map=60;
  for(unsigned n=0;n<2000;n++){tps=std::clamp(tps+(int(random()%401)-200)*.01,0.,100.);map=std::clamp(map+(int(random()%401)-200)*.01,10.,110.);tr::Input in{tps,map,1000,30,n*5000ULL,n%101!=0};auto out=controller.step(config,in,in.sampled_us+1500);assert(std::isfinite(out.values[tr::CorrectionPct])&&out.values[tr::CorrectionPct]>=0&&out.values[tr::CorrectionPct]<=750);assert(out.values[tr::RemainingMs]>=0&&out.values[tr::RemainingMs]<=config.duration_ms);assert(out.active()==bool(out.flags&tr::Active));if(!in.eligible)assert(!out.active()&&out.correction()==1);if(out.flags&tr::RateValid){assert(std::isfinite(out.values[tr::TpsDot])&&std::abs(out.values[tr::TpsDot])<=2550);assert(std::isfinite(out.values[tr::MapDot])&&std::abs(out.values[tr::MapDot])<=2550);}sampled++;}
 }
 std::cout<<"nonfinite_configs_rejected="<<rejected<<" dose_cases="<<accounting<<" capacity_cuts="<<capacity<<" decel_zero_battery_strategy_apply_cases=18 negative_trim_capacity=passed randomized_samples="<<sampled<<"\n";
}
