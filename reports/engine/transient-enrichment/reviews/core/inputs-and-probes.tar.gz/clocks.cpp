#include "ecu/transient_enrichment.hpp"
#include <cassert>
#include <iostream>
using namespace ecu::transient;
Input input(std::uint64_t sampled,double tps=10){return {tps,40,1000,85,sampled,true};}
int main(){
 Config c;c.mode=Mode::TpsRate;c.tps_min_change_pct=0;Controller controller;Output out;
 out=controller.step(c,input(0),0);assert(!out.active());out=controller.step(c,input(0,90),5000);assert(!out.active()&&!(out.flags&RateValid));
 for(unsigned n=1;n<=4;n++)out=controller.step(c,input(n*5000,10+n*.5),n*5000+5000);
 assert(out.active());out=controller.step(c,input(20000,90),40000);assert(out.active());out=controller.step(c,input(20000,90),40001);assert(!out.active()&&out.reason==Reason::Inhibited);
 out=controller.step(c,input(45000,90),45000);assert(!out.active());out=controller.step(c,input(45000,90),45000);assert(!out.active()&&out.reason==Reason::ControlClock);
 controller.reset();for(unsigned n=0;n<=4;n++)out=controller.step(c,input(n*5000,10+n*.5),n*5000);assert(out.active());out=controller.step(c,input(19000,80),25000);assert(!out.active()&&out.reason==Reason::AcquisitionClock);out=controller.step(c,input(30000,80),30000);assert(!out.active());
 controller.reset();controller.step(c,input(0),0);out=controller.step(c,input(20001,80),20001);assert(!out.active()&&out.reason==Reason::AcquisitionGap);
 controller.reset();out=controller.step(c,input(1),0);assert(!out.active()&&out.reason==Reason::Inhibited);
 controller.reset();auto start=UINT64_MAX-25000;for(unsigned n=0;n<=4;n++)out=controller.step(c,input(start+n*5000,10+n*.5),start+n*5000);assert(!out.active()&&out.reason==Reason::AcquisitionClock);
 controller.reset();for(unsigned n=0;n<=4;n++)out=controller.step(c,input(n*5000,10+n*.5),n*5000);assert(out.active());c.apply=Apply::AddReference;out=controller.step(c,input(25000,90),25000);assert(!out.active()&&out.reason==Reason::Priming);
 std::cout<<"Acquisition duplicates/future/stale/gap/reversal, control duplicate, deadline overflow and config history reset passed\n";
}
