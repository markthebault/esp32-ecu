#include "ecu/transient_enrichment.hpp"
#include "ecu/engine.hpp"
#include <cassert>
#include <iostream>
using namespace ecu::transient;
Input source(std::uint64_t stamp,double tps){return {tps,40,1000,85,stamp,true};}
int main(){
 Config config;config.mode=Mode::TpsRate;config.duration_ms=20;config.tps_min_change_pct=0;
 Controller immediate,delayed;
 for(unsigned n=0;n<=4;n++){auto in=source(n*5000,10+n*.5);immediate.step(config,in,in.sampled_us);delayed.step(config,in,in.sampled_us);}
 // Identical acquired endpoints and stronger second ramp. The second delivery
 // is1ms later, after an expiry-only poll with the previous acquisition.
 for(unsigned n=1;n<=3;n++){auto in=source(20000+n*5000,12+n);immediate.step(config,in,in.sampled_us);delayed.step(config,in,in.sampled_us);}
 auto first=immediate.step(config,source(40000,16),40000);
 delayed.step(config,source(35000,15),40000);
 auto second=delayed.step(config,source(40000,16),41000);
 std::cout<<"expiry_collision immediate_active="<<first.active()<<" immediate_reason="<<reason_name(first.reason)<<" delayed_active="<<second.active()<<" delayed_reason="<<reason_name(second.reason)<<" rate="<<first.values[TpsDot]<<"/"<<second.values[TpsDot]<<" remaining="<<second.values[RemainingMs]<<'\n';
 config.duration_ms=200;config.tps_min_change_pct=.5;
 Controller reverse;
 for(unsigned n=0;n<=4;n++){auto in=source(n*5000,10+n*.5);reverse.step(config,in,in.sampled_us);}
 Output out;
 for(unsigned n=1;n<=4;n++){auto in=source(20000+n*5000,12-n*.15);out=reverse.step(config,in,in.sampled_us);}
 std::cout<<"subthreshold_reversal rate="<<out.values[TpsDot]<<" threshold="<<config.tps_threshold_pct_s<<" active="<<out.active()<<" reason="<<reason_name(out.reason)<<'\n';
}
