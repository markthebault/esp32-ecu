// Native execution adapter for the pinned production Speeduino ECU.
// The adapter supplies configuration and virtual pins. Engine algorithms stay
// in the external GPL source; this executable never opens hardware devices.
#include "FakeMega.h"
#include "globals.h"
#include "storage.h"
#include "pages.h"
#include "sensors.h"
#include "corrections.h"
#include "decoders.h"
#include "decoder_init.h"
#include "timers.h"
#include "init.h"
#include "logger.h"
#include "scheduler_fuel_controller.h"
#include "scheduler_ignition_controller.h"
#include "units.h"
#include "src/controllers/idle/idle.h"
#include <SimpleArduinoFake.h>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <limits.h>

extern void setup();
extern void loop();
extern "C" uint64_t speeduino_sim_micros();
extern "C" void speeduino_sim_advance(uint64_t);
namespace {
std::stringstream& serial_stream() { static auto* value = new std::stringstream; return *value; }
struct EarlySetup { EarlySetup() { fakeMega(serial_stream(), serial_stream()); } };
EarlySetup early_setup __attribute__((init_priority(65534)));
int adc[256]{};
int pins[256]{};
void (*interrupts_by_pin[256])(){};
int interrupt_modes[256]{};
std::string log_kind="none";
bool record_edges = false;
bool use_per_tooth = false;
bool logger_cam = false;
bool sequential_profile = false;
bool semi_sequential_profile = false;
bool idle_profile=false,idle_high=false;
unsigned review_ae_mode=0,review_min_change=0;
volatile uint8_t* output_ports[8]{};
uint8_t output_masks[8]{};
uint8_t output_pins[8]{};
bool output_high[8]{};
void prepare_hal() {
    using namespace fakeit;
    auto& mock = SimpleArduinoFake::getContext()._Function;
    When(Method(mock, micros)).AlwaysDo([]() -> unsigned long { return uint32_t(speeduino_sim_micros()); });
    When(Method(mock, millis)).AlwaysDo([]() -> unsigned long { return uint32_t(speeduino_sim_micros()/1000); });
    When(Method(mock, delay)).AlwaysDo([](unsigned long ms) { speeduino_sim_advance(speeduino_sim_micros()+ms*1000); });
    When(Method(mock, delayMicroseconds)).AlwaysDo([](unsigned int us) { speeduino_sim_advance(speeduino_sim_micros()+us); });
    When(Method(mock, analogRead)).AlwaysDo([](uint8_t pin) { return adc[pin]; });
    When(Method(mock, digitalRead)).AlwaysDo([](uint8_t pin) { return pins[pin]; });
    When(Method(mock, digitalWrite)).AlwaysDo([](uint8_t pin, uint8_t value) {
        pins[pin] = value;
        auto port=portOutputRegister(digitalPinToPort(pin));auto mask=digitalPinToBitMask(pin);
        if(value) *port |= mask; else *port &= ~mask;
    });
    When(Method(mock, attachInterrupt)).AlwaysDo([](uint8_t pin, void (*cb)(), int mode) { interrupts_by_pin[pin] = cb;interrupt_modes[pin]=mode; });
    When(Method(mock, detachInterrupt)).AlwaysDo([](uint8_t pin) { interrupts_by_pin[pin] = nullptr; });
}
void configure() {
    setStorageAPI(getBoardStorageApi());
    setTuneToEmpty();
    configPage2.pinMapping = 3;
    configPage2.nCylinders = 4;
    configPage2.nInjectors = 4;
    configPage2.strokes = FOUR_STROKE;
    configPage2.injType = INJ_TYPE_PORT;
    configPage2.injLayout = (logger_cam||sequential_profile)?INJ_SEQUENTIAL:INJ_SEMISEQUENTIAL;
    configPage2.divider = 2;
    configPage2.injTiming = (sequential_profile||semi_sequential_profile)?1:0;
    if(sequential_profile||semi_sequential_profile){for(unsigned n=0;n<4;++n){configPage2.injAng[n]=sequential_profile?540:180;configPage2.injAngRPM[n]=5+20*n;}}
    if(semi_sequential_profile)configPage4.inj4cylPairing=INJ_PAIR_13_24;
    configPage2.reqFuel = 107; // 2L/4cyl,300cc/min,14.7 AFR,25C rounded to0.1ms
    configPage2.injOpen = 9;
    configPage2.multiplyMAP = MULTIPLY_MAP_MODE_100;
    configPage2.fuelAlgorithm = LOAD_SOURCE_MAP;
    configPage2.perToothIgn = use_per_tooth;
    configPage2.ignAlgorithm = LOAD_SOURCE_MAP;
    configPage2.dutyLim = 80;
    configPage2.stoich = 147;
    configPage2.tpsMin = 0; configPage2.tpsMax = 255;
    configPage2.mapMin = 0; configPage2.mapMax = 200;
    configPage2.baroMin = 0; configPage2.baroMax = 200;
    configPage2.fpPrime = 2;
    configPage2.taeThresh = 255; configPage2.maeThresh = 255;
    configPage4.TrigPattern = DECODER_MISSING_TOOTH;
    configPage4.triggerTeeth = 60; configPage4.triggerMissingTeeth = 2;
    configPage4.triggerAngle = -90;
    configPage4.crankRPM = 45;
    configPage4.CrankAng = 5;
    configPage4.sparkMode = sequential_profile?IGN_MODE_SEQUENTIAL:IGN_MODE_WASTEDCOP;
    configPage4.TrigSpeed=CRANK_SPEED;configPage4.trigPatternSec=SEC_TRIGGER_SINGLE;
    configPage4.IgInv = 0; // virtual active-high charging
    configPage4.dwellRun = 28; configPage4.dwellCrank = 28;
    configPage4.useDwellLim = 1; configPage4.dwellLimit = 4;
    configPage4.sparkDur = 10;
    configPage4.floodClear = 95;
    configPage4.HardRevLim = 65; configPage4.SoftRevLim = 62;
    configPage4.engineProtectMaxRPM = 65;
    configPage6.engineProtectType = PROTECT_CUT_BOTH;
    configPage9.hardRevMode = HARD_REV_FIXED;
    configPage2.SoftLimitMode = SOFT_LIMIT_RELATIVE;
    configPage4.SoftLimRetard = 10;configPage4.SoftLimMax = 255;
    for (unsigned n = 0; n < 10; ++n) { configPage4.wueBins[n] = n*20; configPage2.wueValues[n] = 100; }
    for (unsigned n = 0; n < 6; ++n) {
        configPage6.voltageCorrectionBins[n] = 80+n*20;
        configPage6.injVoltageCorrectionValues[n] = 100;
        configPage4.dwellCorrectionValues[n] = 100;
        configPage4.iatRetBins[n] = n*40;
        configPage4.cltAdvBins[n] = n*40; configPage4.cltAdvValues[n] = 15;
    }
    for (unsigned n = 0; n < 9; ++n) { configPage6.airDenBins[n] = n*25; configPage6.airDenRates[n] = 100; }
    for (unsigned n = 0; n < 8; ++n) { configPage4.baroFuelBins[n] = 30+n*20; configPage4.baroFuelValues[n] = 100; }
    for (unsigned n = 0; n < 4; ++n) {
        configPage10.crankingEnrichBins[n] = n*60;
        configPage10.crankingEnrichValues[n] = 20; // stored in5% units
        configPage2.aseBins[n] = n*60;
    }
    for (unsigned n = 0; n < 32; ++n) {
        cltCalibrationTable.axis[n] = iatCalibrationTable.axis[n] = o2CalibrationTable.axis[n] = n*33;
        cltCalibrationTable.values[n] = iatCalibrationTable.values[n] = std::min(255u,n*8);
        o2CalibrationTable.values[n] = std::min(255u,80+n*5);
    }
    for (unsigned n = 0; n < 16; ++n) {
        fuelTable.axisX[n] = ignitionTable.axisX[n] = afrTable.axisX[n] = (n+1)*5;
        fuelTable.axisY[n] = ignitionTable.axisY[n] = afrTable.axisY[n] = (n+1)*8;
    }
    fuelTable.values.fill(85);
    ignitionTable.values.fill(40+10);
    afrTable.values.fill(147);
    // Persist through the real storage API, then let unmodified setup load it.

    configPage2.aeMode=review_ae_mode;
    configPage2.aeApplyMode=AE_MODE_MULTIPLIER;
    configPage2.taeThresh=configPage2.maeThresh=40;
    configPage2.taeMinChange=2;configPage2.maeMinChange=review_min_change;
    configPage2.aeTime=20;configPage2.decelAmount=70;
    configPage2.aeTaperMin=30;configPage2.aeTaperMax=60;
    configPage2.aeColdPct=100;configPage2.aeColdTaperMin=40;configPage2.aeColdTaperMax=100;
    configPage2.mapSample=MAPSamplingInstantaneous;
    configPage4.ADCFILTER_TPS=configPage4.ADCFILTER_MAP=0;
    const unsigned axes[4]={0,10,25,100},values[4]={0,10,25,50};
    for(unsigned i=0;i<4;i++){configPage4.taeBins[i]=configPage4.maeBins[i]=axes[i];configPage4.taeValues[i]=configPage4.maeRates[i]=values[i];}
    saveEEPROMVersion(27);
    do { saveAllPages(); } while (isEepromWritePending());
    saveAllCalibrationTables();
    saveLastBaro(100);
}
void set_sensors(double map, double tps, double clt, double iat, double battery, double afr) {
    adc[pinNumbers.pinMAP] = std::lround(map/200*1024);
    adc[pinNumbers.pinTPS] = std::lround(tps/100*1023);
    adc[pinNumbers.pinCLT] = std::lround((clt+40)*33/8);
    adc[pinNumbers.pinIAT] = std::lround((iat+40)*33/8);
    adc[pinNumbers.pinBat] = std::lround(battery*10/245*1024);
    adc[pinNumbers.pinO2] = std::lround((afr*10-80)*33/5);
}
void status() {
    std::cout << "status " << speeduino_sim_micros() << ' ' << currentStatus.RPM << ' '
              << fuelSchedule1.pw << ' ' << int(currentStatus.advance) << ' '
              << currentStatus.MAP << ' ' << unsigned(currentStatus.VE) << ' '
              << unsigned(currentStatus.corrections) << ' ' << currentStatus.coolant << ' '
              << currentStatus.IAT << ' ' << unsigned(currentStatus.battery10) << ' '
              << unsigned(currentStatus.decoder.getStatus().syncStatus) << ' '
              << unsigned(currentStatus.schedulerCutState.fuelChannels) << ' '
              << unsigned(currentStatus.schedulerCutState.ignitionChannels) << ' '
              << unsigned(currentStatus.softLimitActive) << '\n';
    std::cout << "diagnostic " << unsigned(fuelSchedule1._status) << ' ' << fuelSchedule1._counter.load() << ' ' << fuelSchedule1._compare.load() << ' ' << currentStatus.decoder.getCrankAngle() << ' '
              << unsigned(currentStatus.schedulerCutState.fuelChannels) << ' ' << unsigned(currentStatus.schedulerCutState.ignitionChannels) << ' '
              << unsigned(ignitionSchedule1._status) << ' ' << currentStatus.dwell << ' ' << CRANK_ANGLE_MAX_IGN << ' ' << CRANK_ANGLE_MAX_INJ << ' ' << unsigned(currentStatus.nSquirts) << '\n';
}
}
extern "C" void speeduino_sim_observe() {
    if (!record_edges) return;
    for(unsigned n=0;n<8;++n) {
        bool high=(*output_ports[n]&output_masks[n]) != 0;
        if(high!=output_high[n]) {
            output_high[n]=high;
            std::cout << "edge " << speeduino_sim_micros() << ' ' << unsigned(output_pins[n]) << ' ' << unsigned(high) << ' ' << unsigned(currentStatus.decoder.getStatus().syncStatus) << ' ' << CRANK_ANGLE_MAX_IGN << '\n';
        }
    }
    if(idle_profile){
        const bool high=(*portOutputRegister(digitalPinToPort(pinNumbers.pinIdle1))&digitalPinToBitMask(pinNumbers.pinIdle1))!=0;
        if(high!=idle_high){idle_high=high;std::cout<<"edge "<<speeduino_sim_micros()<<' '<<unsigned(pinNumbers.pinIdle1)<<' '<<unsigned(high)<<" 0 0\n";}
    }
}

int main(int argc,char**argv){
 if(argc!=3)return 2;review_ae_mode=std::stoul(argv[1]);review_min_change=std::stoul(argv[2]);
 setenv("GCOV_PREFIX","/home/mark/persospace/esp32-ecu/.cache/engine/transient-architecture-review/gcov",1);
 prepare_hal();configure();setPinMapping(3);set_sensors(40,0,85,25,14,14.7);setup();set_sensors(40,0,85,25,14,14.7);
 std::cout<<"#ae_profile mode="<<unsigned(configPage2.aeMode)<<" apply="<<unsigned(configPage2.aeApplyMode)<<" TPSminRaw="<<unsigned(configPage2.taeMinChange)<<" MAPminRaw="<<unsigned(configPage2.maeMinChange)<<" TPSthreshold="<<unsigned(configPage2.taeThresh)<<" MAPthreshold="<<unsigned(configPage2.maeThresh)<<" durationRaw="<<unsigned(configPage2.aeTime)<<" tpsFilter="<<unsigned(configPage4.ADCFILTER_TPS)<<" mapFilter="<<unsigned(configPage4.ADCFILTER_MAP)<<" mapSample="<<unsigned(configPage2.mapSample)<<"\n";
 std::cout<<"time_us,input_tps,input_map,tps_halfpct,tpsdot,map_kpa,map_delta,map_delta_us,mapdot,AEamount,accelerating,decelerating,AEstart_us,corrections,loop_flags\n";
 for(unsigned ms=1;ms<=1500;ms++){
  double tps=0,map=40;
  if(ms>=600&&ms<700){tps=(ms-600)*.2;map=40+(ms-600)*.4;}
  else if(ms>=700&&ms<720){tps=20;map=80;}
  else if(ms>=720&&ms<820){tps=20-(ms-720)*.1;map=80-(ms-720)*.2;}
  else if(ms>=820){tps=10;map=60;}
  set_sensors(map,tps,85,25,14,14.7);speeduino_sim_advance(ms*1000);
  currentStatus.LOOP_TIMER=getAndClearTimerMask();
  readPolledSensors(currentStatus.LOOP_TIMER);currentStatus.RPM=1000;currentStatus.rotationStatus=EngineRotationStatus::Running;
  const auto corrections=correctionsFuel();
  std::cout<<ms*1000<<','<<tps<<','<<map<<','<<unsigned(currentStatus.TPS)<<','<<currentStatus.tpsDOT<<','<<currentStatus.MAP<<','<<getMAPDelta()<<','<<getMAPDeltaTime()<<','<<currentStatus.mapDOT<<','<<currentStatus.AEamount<<','<<currentStatus.isAcceleratingTPS<<','<<currentStatus.isDeceleratingTPS<<','<<currentStatus.AEStartTime<<','<<corrections<<','<<unsigned(currentStatus.LOOP_TIMER)<<'\n';
 }
}
