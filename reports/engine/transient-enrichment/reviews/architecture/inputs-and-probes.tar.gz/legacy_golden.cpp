#include "ecu/engine.hpp"
#include <iomanip>
#include <iostream>
using namespace ecu::engine;
Inputs input(double tps,double rpm,std::uint64_t sampled){Inputs in;in.tps_pct=tps;in.rpm=rpm;in.map_kpa=45;in.clt_c=85;in.iat_c=25;in.lambda=1;in.battery_v=14;in.sensor_v=5;in.sampled_us=sampled;in.synced=in.sensors_valid=in.lambda_ready=true;return in;}
void emit(const char*case_name,Controller&controller,Tune&t,Inputs in,std::uint64_t now){auto out=controller.step(t,in,now);std::cout<<case_name<<','<<now<<','<<in.sampled_us<<','<<in.tps_pct<<','<<in.rpm<<','<<out.accel<<','<<out.ego<<','<<out.pulse_ms<<','<<unsigned(out.state)<<','<<out.faults<<','<<out.fuel_cut<<'\n';}
int main(){
 std::cout<<std::setprecision(17)<<"case,control_us,sampled_us,tps,rpm,accel,ego,pulse_ms,state,faults,fuel_cut\n";
 Tune t;Controller c;
 emit("step_decay",c,t,input(0,900,0),0);emit("step_decay",c,t,input(1,900,5000),5000);emit("step_decay",c,t,input(1,900,10000),10000);emit("step_decay",c,t,input(0,900,15000),15000);
 c.reset();emit("ramp_cap",c,t,input(0,900,0),0);emit("ramp_cap",c,t,input(.1,900,5000),5000);emit("ramp_cap",c,t,input(.5,900,10000),10000);emit("ramp_cap",c,t,input(3,900,15000),15000);emit("ramp_cap",c,t,input(2,900,20000),20000);
 c.reset();emit("same_sample_stamp",c,t,input(0,900,0),0);emit("same_sample_stamp",c,t,input(1,900,0),5000);emit("same_sample_stamp",c,t,input(1,900,0),10000);
 c.reset();emit("stale_recovery",c,t,input(0,900,0),0);emit("stale_recovery",c,t,input(20,900,0),30000);emit("stale_recovery",c,t,input(21,900,35000),35000);
 c.reset();emit("crank_to_run",c,t,input(0,300,0),0);emit("crank_to_run",c,t,input(20,900,5000),5000);emit("crank_to_run",c,t,input(20,900,10000),10000);
 c.reset();t.ego_enabled=true;t.afterstart_pct=0;emit("ego_gating",c,t,input(0,900,0),0);emit("ego_gating",c,t,input(1,900,5000),5000);emit("ego_gating",c,t,input(1,900,10000),10000);
}
