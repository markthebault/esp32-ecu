"""Isolated production Speeduino sensor/corrections probe; no checkout edits."""
import csv,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
source=subprocess.check_output(['git','show','64c21ed:tools/speeduino_sim.cpp'],cwd=ROOT,text=True)
source=source.replace('#include "sensors.h"','#include "sensors.h"\n#include "corrections.h"')
source=source.replace('bool idle_profile=false,idle_high=false;','bool idle_profile=false,idle_high=false;\nunsigned review_ae_mode=0,review_min_change=0;')
needle='    saveEEPROMVersion(27);'
profile=r'''
    configPage2.aeMode=review_ae_mode;
    configPage2.aeApplyMode=AE_MODE_MULTIPLIER;
    configPage2.taeThresh=configPage2.maeThresh=40;
    configPage2.taeMinChange=2;configPage2.maeMinChange=review_min_change;
    configPage2.aeTime=20;configPage2.decelAmount=70;
    configPage2.aeTaperMin=30;configPage2.aeTaperMax=60;
    configPage2.aeColdPct=100;configPage2.aeColdTaperMin=40;configPage2.aeColdTaperMax=100;
    configPage2.mapSample=MAPSamplingInstantaneous;
    configPage4.ADCFILTER_TPS=configPage4.ADCFILTER_MAP=0;
    const unsigned axes[4]={0,10,25,100},values[4]={0,10,25,50};
    for(unsigned i=0;i<4;i++){configPage4.taeBins[i]=configPage4.maeBins[i]=axes[i];configPage4.taeValues[i]=configPage4.maeRates[i]=values[i];}
'''
assert source.count(needle)==1;source=source.replace(needle,profile+needle)
start=source.index('int main(')
source=source[:start]+r'''
int main(int argc,char**argv){
 if(argc!=3)return 2;review_ae_mode=std::stoul(argv[1]);review_min_change=std::stoul(argv[2]);
 setenv("GCOV_PREFIX","/home/mark/persospace/esp32-ecu/.cache/engine/transient-architecture-review/gcov",1);
 prepare_hal();configure();setPinMapping(3);set_sensors(40,0,85,25,14,14.7);setup();set_sensors(40,0,85,25,14,14.7);
 std::cout<<"#ae_profile mode="<<unsigned(configPage2.aeMode)<<" apply="<<unsigned(configPage2.aeApplyMode)<<" TPSminRaw="<<unsigned(configPage2.taeMinChange)<<" MAPminRaw="<<unsigned(configPage2.maeMinChange)<<" TPSthreshold="<<unsigned(configPage2.taeThresh)<<" MAPthreshold="<<unsigned(configPage2.maeThresh)<<" durationRaw="<<unsigned(configPage2.aeTime)<<" tpsFilter="<<unsigned(configPage4.ADCFILTER_TPS)<<" mapFilter="<<unsigned(configPage4.ADCFILTER_MAP)<<" mapSample="<<unsigned(configPage2.mapSample)<<"\n";
 std::cout<<"time_us,input_tps,input_map,tps_halfpct,tpsdot,map_kpa,map_delta,map_delta_us,mapdot,AEamount,accelerating,decelerating,AEstart_us,corrections,loop_flags\n";
 for(unsigned ms=1;ms<=1500;ms++){
  double tps=0,map=40;
  if(ms>=600&&ms<700){tps=(ms-600)*.2;map=40+(ms-600)*.4;}
  else if(ms>=700&&ms<720){tps=20;map=80;}
  else if(ms>=720&&ms<820){tps=20-(ms-720)*.1;map=80-(ms-720)*.2;}
  else if(ms>=820){tps=10;map=60;}
  set_sensors(map,tps,85,25,14,14.7);speeduino_sim_advance(ms*1000);
  currentStatus.LOOP_TIMER=getAndClearTimerMask();
  readPolledSensors(currentStatus.LOOP_TIMER);currentStatus.RPM=1000;currentStatus.rotationStatus=EngineRotationStatus::Running;
  const auto corrections=correctionsFuel();
  std::cout<<ms*1000<<','<<tps<<','<<map<<','<<unsigned(currentStatus.TPS)<<','<<currentStatus.tpsDOT<<','<<currentStatus.MAP<<','<<getMAPDelta()<<','<<getMAPDeltaTime()<<','<<currentStatus.mapDOT<<','<<currentStatus.AEamount<<','<<currentStatus.isAcceleratingTPS<<','<<currentStatus.isDeceleratingTPS<<','<<currentStatus.AEStartTime<<','<<corrections<<','<<unsigned(currentStatus.LOOP_TIMER)<<'\n';
 }
}
'''
(OUT/'reference_probe.cpp').write_text(source)
cache=ROOT/'.cache/engine/speeduino-sim';manifest=json.loads((cache/'build-manifest.json').read_text());obj=OUT/'reference_probe.o';binary=OUT/'reference_probe'
subprocess.run(['c++',*manifest['compile_flags'],'-c',str(OUT/'reference_probe.cpp'),'-o',str(obj)],check=True)
objects=[p for p in sorted((cache/'obj').glob('*.o')) if p.name!='tools_speeduino_sim.cpp.o']
libraries=sorted(p for p in (ROOT.parent/'speeduino/.pio/build/native_code_coverage').rglob('*.a') if p.name not in ('libArduinoFake.a','libUnity.a'))
subprocess.run(['c++',*map(str,objects),str(obj),'-Wl,--start-group',*map(str,libraries),'-Wl,--end-group','-lgcov','-pthread','-o',str(binary)],check=True)
summaries=[]
for mode,minimum in ((0,0),(1,0),(1,2)):
 result=subprocess.run([str(binary),str(mode),str(minimum)],capture_output=True,text=True,check=True);name=f'reference-mode{mode}-mapmin{minimum}.csv';(OUT/name).write_text(result.stdout)
 lines=result.stdout.splitlines();rows=list(csv.DictReader(lines[1:]));active=[r for r in rows if int(r['time_us'])>=600000 and int(r['accelerating'])];decel=[r for r in rows if int(r['time_us'])>=600000 and int(r['decelerating'])]
 reversals=[r for r in rows if int(r['time_us'])>=720000 and int(r['tpsdot' if mode==0 else 'mapdot'])<0 and int(r['accelerating'])]
 summaries.append(dict(mode=mode,map_min_change=minimum,profile=lines[0],peak_AE=max(int(r['AEamount']) for r in rows if int(r['time_us'])>=600000),accel_samples=len(active),decel_samples=len(decel),weaker_negative_kept_accel_samples=len(reversals),first_accel=active[0] if active else None,last_accel=active[-1] if active else None))
report=dict(scope='Production sensor and corrections functions with unmodified pinned algorithms; direct controlled RPM1000, no scheduler/closed-loop plant comparison; native32 only',reference_commit=manifest['speeduino_sha'],binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),summaries=summaries)
(OUT/'reference-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
