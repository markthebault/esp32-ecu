#include "ecu/tuning_session.hpp"
#include "ecu/engine_log.hpp"
#include <iostream>
int main(){std::cout<<"Tune="<<sizeof(ecu::engine::Tune)<<" RuntimeSample="<<sizeof(ecu::engine::RuntimeSample)<<" Row="<<sizeof(ecu::engine_log::Row)<<" Recorder="<<sizeof(ecu::engine_log::Recorder)<<" Session="<<sizeof(ecu::tuning::Session)<<" Page="<<ecu::tuning::page_bytes<<" Live="<<ecu::tuning::live_bytes<<"\n";}
