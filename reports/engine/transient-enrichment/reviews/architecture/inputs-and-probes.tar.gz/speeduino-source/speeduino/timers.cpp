/*
Speeduino - Simple engine management for the Arduino Mega 2560 platform
Copyright (C) Josh Stewart
A full copy of the license may be found in the projects root directory
*/

/*
Timers are used for having actions performed repeatedly at a fixed interval (Eg every 100ms)
They should not be confused with Schedulers, which are for performing an action once at a given point of time in the future

Timers are typically low resolution (Compared to Schedulers), with maximum frequency currently being approximately every 10ms
*/
#include "timers.h"
#include "globals.h"
#include "sensors.h"
#include "scheduler_fuel_controller.h"
#include "scheduler_ignition_controller.h"
#include "comms.h"
#include "maths.h"
#include "preprocessor.h"
#include "scheduledIO_ign.h"
#include "scheduledIO_inj.h"
#include "src/pins/boardOutputPin.h"
#include "src/controllers/fuelPump/fuelPumpController.h"
#include "src/controllers/fan/fanController.h"
#include "src/controllers/tacho/tachoController.h"

volatile uint16_t lastRPM_100ms; //Need to record this for rpmDOT calculation
volatile byte loop5ms;
volatile byte loop20ms;
volatile byte loop33ms;
volatile byte loop66ms;
volatile byte loop100ms;
volatile byte loop250ms;
volatile int loopSec;

void __attribute__((optimize("Os"))) initialiseTimers(void)
{
  lastRPM_100ms = 0;
  loop5ms = 0;
  loop20ms = 0;
  loop33ms = 0;
  loop66ms = 0;
  loop100ms = 0;
  loop250ms = 0;
  loopSec = 0;
}

TESTABLE_STATIC volatile uint8_t TIMER_mask;

uint8_t getAndClearTimerMask(void)
{
  ATOMIC() {
    uint8_t mask = TIMER_mask;
    TIMER_mask = 0U;
    return mask;
  }
  // LCOV_EXCL_START
  return 0U; // Suppress false compiler warning
  // LCOV_EXCL_STOP
}

void oneMSInterval(void)
{
  BIT_SET(TIMER_mask, BIT_TIMER_1KHZ);

  //Increment Loop Counters
  loop5ms++;
  loop20ms++;
  loop33ms++;
  loop66ms++;
  loop100ms++;
  loop250ms++;
  loopSec++;

  applyOverDwellProtection(configPage4, currentStatus);
  tachoControl(currentStatus);

  //200Hz loop
  if(loop5ms == 5)
  {
    loop5ms = 0; //Reset counter
    BIT_SET(TIMER_mask, BIT_TIMER_200HZ);
  }

  //50Hz loop
  if(loop20ms == 20)
  {
    loop20ms = 0; //Reset counter
    BIT_SET(TIMER_mask, BIT_TIMER_50HZ);
  }

  //30Hz loop
  if (loop33ms == 33)
  {
    loop33ms = 0;
    BIT_SET(TIMER_mask, BIT_TIMER_30HZ);
  }

  //15Hz loop
  if (loop66ms == 66)
  {
    loop66ms = 0;
    BIT_SET(TIMER_mask, BIT_TIMER_15HZ);
  }

  //10Hz loop
  if (loop100ms == 100)
  {
    loop100ms = 0; //Reset counter
    BIT_SET(TIMER_mask, BIT_TIMER_10HZ);

    currentStatus.rpmDOT = (currentStatus.RPM - lastRPM_100ms) * 10; //This is the RPM per second that the engine has accelerated/decelerated in the last loop
    lastRPM_100ms = currentStatus.RPM; //Record the current RPM for next calc

    if ( currentStatus.rotationStatus==EngineRotationStatus::Running ) { runSecsX10++; }
    else { runSecsX10 = 0; }

    if ( (currentStatus.injPrimed == false) && (seclx10 >= configPage2.primingDelay) && (currentStatus.RPM == 0) && (currentStatus.initialisationComplete == true) ) 
    { 
      beginInjectorPriming(currentStatus, configPage4); 
      currentStatus.injPrimed = true; 
    }
    seclx10++;
  }

  //4Hz loop
  if (loop250ms == 250)
  {
    loop250ms = 0; //Reset Counter
    BIT_SET(TIMER_mask, BIT_TIMER_4HZ);
    #if defined(CORE_STM32) //debug purpose, only visual for running code
      digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    #endif
  }

  //1Hz loop
  if (loopSec == 1000)
  {
    loopSec = 0; //Reset counter.
    BIT_SET(TIMER_mask, BIT_TIMER_1HZ);

    currentStatus.crankRPM = ((unsigned int)configPage4.crankRPM * 10);

    //**************************************************************************************************************************************************
    //This updates the runSecs variable
    //If the engine is running or cranking, we need to update the run time counter.
    if (currentStatus.rotationStatus!=EngineRotationStatus::Stopped)
    { //NOTE - There is a potential for a ~1sec gap between engine crank starting and the runSec number being incremented. This may delay ASE!
      if (currentStatus.runSecs <= (UINT8_MAX-1U)) //Ensure we cap out at 255 and don't overflow. (which would reset ASE and cause problems with the closed loop fuelling (Which has to wait for the O2 to warmup))
        { currentStatus.runSecs++; } //Increment our run counter by 1 second.
    }
    //**************************************************************************************************************************************************
    //increment secl (secl is simply a counter that increments every second and is used to track whether the system has unexpectedly reset
    currentStatus.secl++;
    //**************************************************************************************************************************************************

    //**************************************************************************************************************************************************
    //Set the flex reading (if enabled). The flexCounter is updated with every pulse from the sensor. If cleared once per second, we get a frequency reading
    if(configPage2.flexEnabled == true)
    {
      byte tempEthPct = 0; 
      if(flexCounter < configPage2.flexFreqLow)
      {
        tempEthPct = 0U; //Standard GM Continental sensor reads from 50Hz (0 ethanol) to 150Hz (Pure ethanol). Subtracting 50 from the frequency therefore gives the ethanol percentage.
        flexCounter = 0U;
      }
      else if (flexCounter > (configPage2.flexFreqHigh + 1) ) //1 pulse buffer
      {

        if(flexCounter < (configPage2.flexFreqHigh + 20)) //20Hz above the max freq is considered an error condition. Everything below that should be treated as max value
        {
          tempEthPct = 100U;
          flexCounter = 0U;
        }
        else
        {
          //This indicates an error condition. Spec of the sensor is that errors are above 170Hz)
          tempEthPct = 0U;
          flexCounter = 0U;
        }
      }
      else
      {
        tempEthPct = flexCounter - configPage2.flexFreqLow; //Standard GM Continental sensor reads from 50Hz (0 ethanol) to 150Hz (Pure ethanol). Subtracting 50 from the frequency therefore gives the ethanol percentage.
        flexCounter = 0;
      }

      //Off by 1 error check
      if (tempEthPct == 1U) { tempEthPct = 0U; }
      if (tempEthPct > 100U) { tempEthPct = 100U; }

      currentStatus.ethanolPct = (uint8_t)LOW_PASS_FILTER((uint16_t)tempEthPct, configPage4.FILTER_FLEX, (uint16_t)currentStatus.ethanolPct);

      //Continental flex sensor fuel temperature can be read with following formula: (Temperature = (41.25 * pulse width(ms)) - 81.25). 1000μs = -40C and 5000μs = 125C
      flexPulseWidth = constrain(flexPulseWidth, 1000UL, 5000UL);
      int32_t tempX100 = (int32_t)rshift<10>((uint32_t)(4224UL * flexPulseWidth)) - 8125L; //Split up for MISRA compliance
      currentStatus.fuelTemp = div100((int16_t)tempX100);     
    }
  }

#if defined(CORE_AVR) //AVR chips use the ISR for this
    //Reset Timer2 to trigger in another ~1ms
    TCNT2 = 131;            //Preload timer2 with 100 cycles, leaving 156 till overflow.
#endif
}
