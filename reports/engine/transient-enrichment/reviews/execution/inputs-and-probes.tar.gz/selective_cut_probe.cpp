#include "ecu/engine_scheduler.hpp"
#include <cassert>
#include <iostream>
#include <algorithm>
#include <vector>
using namespace ecu::engine;
struct Result{unsigned strategy,slots,closed=0,coil_lows=0;std::uint64_t first=0,cut=0,installed=0,maximum=0;};
Result run(Strategy strategy,unsigned slots){
 AngleScheduler s;AngleConfig t;t.strategy=strategy;Output o;o.state=State::Running;o.rpm=1000;o.pulse_ms=3;o.dwell_ms=2;o.advance_deg=15;
 bool high[8]{};std::uint64_t rose[8]{};Result r{unsigned(strategy),slots};
 const auto duration=std::uint64_t(600000);unsigned tooth=0;std::uint64_t tooth_time=1;
 for(;;){
  const auto due=std::min(tooth_time,s.next_time());if(due>duration)break;
  if(r.first&&!r.cut&&due>=r.first+500){r.cut=r.first+500;o.fuel_cut=true;o.pulse_ms=0;}
  if(s.next_time()==due){
   Edge e;assert(s.pop(e)&&!s.event_forced_cut());assert(high[e.channel]!=e.high);high[e.channel]=e.high;
   if(e.high){if(e.channel<4){assert(!r.installed||due<r.installed);if(!r.first)r.first=due;}rose[e.channel]=due;}
   else if(e.channel<4){const auto width=due-rose[e.channel];assert(width==3000);r.maximum=std::max(r.maximum,width);if(r.installed&&due>=r.installed)++r.closed;}
   else if(r.installed&&due>=r.installed)++r.coil_lows;
   continue;
  }
  if(r.cut&&!r.installed)r.installed=due;
  const auto index=tooth%(slots*(strategy==Strategy::Sequential?2:1));
  assert(s.tooth(t,o,due,index,slots,due,due));assert(!s.failed());
  do{++tooth;tooth_time=1+std::uint64_t(std::llround(tooth*60000000.0/(1000*slots)));}while(tooth%slots>=slots-2);
 }
 assert(r.first&&r.cut&&r.installed&&r.closed&&r.coil_lows);assert(r.installed>=r.cut);assert(r.installed-r.cut<=5000);for(unsigned c=0;c<4;++c)assert(!high[c]);return r;
}
int main(){std::cout<<"[";unsigned n=0;for(auto strategy:{Strategy::BatchWasted,Strategy::Sequential,Strategy::SemiSequential})for(auto slots:{36u,60u,120u}){auto r=run(strategy,slots);if(n++)std::cout<<",";std::cout<<"{\"strategy\":"<<r.strategy<<",\"slots\":"<<r.slots<<",\"first_injector_rise_us\":"<<r.first<<",\"cut_request_us\":"<<r.cut<<",\"cut_installed_on_tooth_us\":"<<r.installed<<",\"retained_injector_closures\":"<<r.closed<<",\"coil_lows_after_cut\":"<<r.coil_lows<<",\"injector_width_us\":"<<r.maximum<<"}";}std::cout<<"]\n";}
