import pathlib,json,hashlib,datetime
R=pathlib.Path('/home/mark/persospace/esp32-ecu');O=R/'.cache/engine/transient-execution-review'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((O/p).read_text())
initial=read('source-hashes.json');final={p:h(R/p) for p in initial};changes={p:{'before':initial[p],'after':v} for p,v in final.items() if initial[p]!=v};assert set(changes)=={'tools/run_transient_scenarios.py'}
images=read('images.json');core=read('probe.json');cuts=read('selective-cut-probe.json');matrix=read('matrix-probe.json');reference=read('reference-integrity.json')
for env,v in images.items():assert h(R/'firmware/.pio/build'/env/'firmware.elf')==v['elf_sha256']
q=matrix['versions']['matrix-qualified'];assert q['available_trace_count']==64 and q['summary']['passed']
qs=q['summary']['source_hashes'];qscheck={p:h(R/p)==v for p,v in qs.items()};assert all(qscheck.values())
qj=json.loads((R/q['summary']['path']).read_text());assert len(qj['refinement'])==8 and len(qj['negative'])==8;assert all(x['passed'] for x in qj['refinement']+qj['negative'])
for label in ['selected','generic','dummy']:
 a=read('isr-'+label+'/closure.json');assert not a['external'] and not a['literals_outside_iram'] and not a['unclassified_flash_pointers']
artifacts=['source-hashes.json','probe.cpp','probe.json','selective_cut_probe.cpp','selective-cut-probe.json','engine-transient-test.log','elf_probe.py','images.json','reference-readback.json','reference-integrity.json','matrix_probe.py','matrix-probe.json','runner-reviewed-initial.py','runner-reviewed-current.py','usb-selected.json','usb-generic.json']+[f'isr-{l}/closure.json' for l in ['selected','generic','dummy']]
report={
 'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Independent read-only transient execution increment: controller fuel math, selective cut/scheduler handoff, final ELF physical policy/IRAM/data/frame budgets, enlarged USB live response, and native reference/independent plant comparison. No production edits, rebuilds, services, child agents, device flashing or physical measurements.',
 'verdict':'PASS within the stated software/static scope; no remaining production blocker identified. Initial matrix coverage failures are preserved and separately closed by explicit profile/audit corrections.',
 'closed_findings':[
  {'id':'matrix-decel-threshold','initial':'The declared30%/s closing ramp was below the default40%/s threshold, so decel_zero never entered deceleration or fuel cut.','resolution':'Corrected profile explicitly selects20%/s, preserving the failed original traces. Both portable/target corrected traces contain20 sampled fuel-only-cut observations, no injector rise after1ms in the sampled cut interval3640000..4020000us, and44 coil lows. This observed1ms allowance is scenario-specific, not a universal cut-latency guarantee.'},
  {'id':'matrix-map-min-change','initial':'Slow MAP load motion was eliminated by the default0.5kPa minimum-change gate, yielding no qualified event.','resolution':'Corrected map_load profile explicitly selects1kPa/s and0kPa minimum change. It demonstrates a sensitivity profile, not default-tune AE.'},
  {'id':'reference-neutral-phase','initial':'Reference zero extra-fuel curves/neutral decel/zero duration retained production AE phase flags at100% correction. Requiring absent phase flags falsely failed the negative control.','resolution':'Corrected audit requires100% correction for all reference neutral observations; project off additionally has no phase. Negative sensitivity requires non100% corrected samples on, none off, and an executed-edge fuel ledger difference. No production algorithm is altered.'}],
 'controller_and_executor':{
  'fuel_math':'Effective full-cycle fuel mass receives multiplier or independent100kPa/25C/VE100/lambda1 reference adder; split by1 sequential or2 nonsequential openings; apply physical-cylinder fuel trim; add unchanged deadtime once per opening. Decel0 sets explicit fuel_cut and zero scalar/cylinder widths/duty; spark remains enabled. Partial decel scales fuel contribution before deadtime. EGO is gated while new transient phase is active.',
  'capacity':'Actual per-cylinder demand is judged against existing width/duty bounds; any capacity failure inhibits all eight channels. No15ms injector/3.5ms coil hardware limit was relaxed.',
  'handoff':'Controller and transient math remain producer-task owned. Command generation increments reject a candidate calculated from an older fuel-cut command. New selective cuts cancel unstarted injector events at the next accepted tooth; already active pulses retain exact bounded closing edges, spark continues. Command refresh alone does not immediately cancel pending starts: visibility in proposal telemetry precedes scheduling and is not proof of instantaneous electrical inhibition.',
  'faults':'Fault/stopped/stale/configuration cuts retain the existing common all-low/epoch paths. Normal transient fuel-only cut does not weaken independent producer/command/tooth/phase/high-time guards.',
  'independent_sanitizer_probe':core,'independent_selective_cut_cases':cuts,
  'compiled_test_log':'engine-transient-test.log'},
 'USB':{
  'maximum_live_data_bytes':320,'maximum_status_plus_data_payload_bytes':321,'maximum_enveloped_reply_bytes':327,'RX_ring_bytes':1024,'TX_ring_bytes':1024,
  'driver_ring_kind':'RINGBUF_TYPE_BYTEBUF for both; one327-byte frame fits the ring. This is capacity arithmetic, not a throughput guarantee.',
  'probe':'Patterned full live request independently exercised Stream/Session under ASan/UBSan; exact327-byte framing,321-byte payload, last byte and CRC verified, one sample and zero commits.',
  'runtime_bounds':'Existing64-byte RX slices,2ms send retry budget,1ms tick/mandatory yield, CPU0 priority1 and checked heap-owned session remain. Backpressure may still fail/truncate a reply and latch TX fault; physical sustained throughput is unmeasured.',
  'cache_safety':'Both exact image audits pass UART0-only/exclusive USB and local driver source checks. USB ISR is flash with flags0 and remains explicitly not cache-safe.'},
 'final_images':images,
 'memory_and_stack':{
  'native_type_sizes':core['sizes'],
  'actual_target_static_sizes':'ELF independently confirms Output368,Controller416,RuntimeSample352,Recorder94296,Executor5496 bytes, internal DRAM. Recorder is below its96KiB static assertion;256 rows and16-row pages remain fixed.',
  'page_allocation':'New native16-row Page is5976 bytes; HTTP uses checked heap_object<Page> and streams serialization outside recorder mutex, so it is not a task-stack Page local.',
  'frames':'Actual ELF prologues: timer ISR112,capture128,diagnostic96; target worker3760 plus command helper2448 in16KiB task; app_main6896 plus observe1472,Controller656 and finish192 in16KiB main task; USB run304 and Session::command784 in12KiB task. These are named static frames, not complete worst-case call-path/high-water proof.',
  'placement':'Fresh selected/generic/dummy closure audits pass30/30/29 functions, zero flash literals/unclassified flash pointers;63 pinned SDK assertion-only metadata arguments separately classified. Increased diagnostic/controller state adds no transient math, JSON, heap or IO to the engine ISR.',
  'limits':'Runtime heap minimum, actual stack high-water, lock/copy duration, control execution budget, IRQ latency and jitter remain unmeasured.'},
 'reference_and_plant':reference,
 'comparison_scope':{
  'source_ownership':'aeconfig changes only declared config/table bytes before virtual time starts, reads every byte back, and refuses repeat or post-start configuration; six32/16 TPS/MAP/neutral profile readbacks independently passed. Production correction/sensor/fuel/scheduler algorithms are retained.',
  'independent_plant':'Separate ResearchPlant instance for each controller; no ECU fuel/VE/transient config is injected into plant physics. Fixed injector300cc/min,0.9ms actuator deadtime, warm5%/50ms and cold45%/1.5s empirical film, fixed physical firing order. Only executed edges deliver fuel/work.',
  'declared_differences':'Project sample window, opposite-sign cancellation and maximum-extra clamp have no exact reference equivalent. Reference retains normal33ms TPS and1ms MAP dispatch, quantized sensor/rate/table arithmetic,32/16 virtual timers and zero CPU cost. Halving coupling step also changes reference loop cadence; refinement is not isolated solver convergence.',
  'cold_case_limit':'cold_adder selects a cold plant; its requested cold_multiplier_pct remains100, so this matrix does not establish equivalence of nonneutral cold AE taper behavior.',
  'matrix':{'initial_summary':matrix['versions']['matrix']['summary'],'corrected_summary_path':q['summary']['path'],'corrected_summary_sha256':q['summary']['sha256'],'corrected_passed':True,'controller_cases':48,'refinement_cases':8,'negative_cases':8,'total64_trace_edge_replays':True,'corrected_source_hash_count':len(qscheck),'all_corrected_source_hashes_match':True,'initial64_trace_edge_replays':True,'no_wait_for_matrix_required':'The corrected summary completed naturally before the bounded final snapshot; reviewer did not start/wait for matrix simulations.'}},
 'source_sha256_initial':initial,'source_sha256_final':final,'source_changes_during_review':changes,
 'artifact_sha256':{p:h(O/p) for p in artifacts},
 'initial_build_log_sha256':h(R/'.cache/engine/transient/target-builds.log'),
 'image_recheck':'Both web ELFs changed during review while all reviewed production core source hashes stayed identical. Initial audits are preserved under initial-build-audits/. Fresh ISR/USB/policy/data/frame audits were run against final_images; bench ELF remained unchanged.',
 'commands':[
  'c++ -std=c++17 -Wall -Wextra -Werror -g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer -I.cache/engine/transient-execution-review/snapshot .cache/engine/transient-execution-review/probe.cpp -o .cache/engine/transient-execution-review/probe',
  'ASAN_OPTIONS=detect_leaks=1 .cache/engine/transient-execution-review/probe',
  'c++ -std=c++17 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I.cache/engine/transient-execution-review/snapshot .cache/engine/transient-execution-review/selective_cut_probe.cpp -o .cache/engine/transient-execution-review/selective_cut_probe',
  'ASAN_OPTIONS=detect_leaks=1 .cache/engine/transient-execution-review/selective_cut_probe',
  'c++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I.cache/engine/transient-execution-review/snapshot .cache/engine/transient-execution-review/snapshot/engine_transient_test.cpp -o .cache/engine/transient-execution-review/engine_transient_test',
  'ASAN_OPTIONS=detect_leaks=1 .cache/engine/transient-execution-review/engine_transient_test',
  'python3 scripts/audit_target_isr.py firmware/.pio/build/<environment>/firmware.elf .cache/engine/transient-execution-review/isr-<selected|generic|dummy>',
  'python3 scripts/audit_tuning_build.py <compact_n16r8_web|compact_a3_web> .cache/engine/transient-execution-review/usb-<selected|generic>.json',
  'python3 .cache/engine/transient-execution-review/elf_probe.py',
  'PYTHONDONTWRITEBYTECODE=1 python3 .cache/engine/transient-execution-review/matrix_probe.py'],
 'remaining_limits':['Source/static/native simulation evidence only; no device was flashed or driven.','Selected/generic engine physical writes remain inhibited; separate bench engine dummy-load writes are compiled in with existing gates. Idle channel8 remains separately default0. CMake compile_commands absence was not used as macro evidence.','No calibrated engine, injector/driver loading, module pin/fit, gate latency, USB physical/cache-stall behavior, EMI/temperature or sustained-target qualification.','Native independent plant results establish bounded software behavior in declared scenarios, not an engine calibration or universal transient performance claim.']}
p=O/'review.json';p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(p.relative_to(R)),'sha256':h(p),'verdict':report['verdict'],'source_hashes':len(final),'qualified_matrix_source_hashes':len(qscheck),'ELFs':{k:v['elf_sha256'] for k,v in images.items()}},indent=2))
