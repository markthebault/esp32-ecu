import pathlib,json,hashlib,sys,collections
R=pathlib.Path('/home/mark/persospace/esp32-ecu');O=R/'.cache/engine/transient-execution-review'
def sha(b):return hashlib.sha256(b).hexdigest()
p=R/'tools/run_transient_scenarios.py';current=p.read_text();(O/'runner-reviewed-current.py').write_text(current)
old=current.replace(" # The tip's closing ramp is30%/s. Explicitly select20%/s for the zero-cut\n # exercise; the default40%/s correctly does not qualify that movement.\n if case[0]=='decel_zero':c['tps_threshold_pct_s']=20\n # This small dynamometer load produces slow MAP motion. Deliberately expose\n # it with a low threshold and no minimum gate, rather than claim a default AE.\n if case[0]=='map_load':c.update(map_threshold_kpa_s=1,map_min_change_kpa=0)\n",'').replace("             corrected_samples_after3=sum(r['time']>=3 and abs(r['correction_pct']-100)>1e-5 for r in rows),\n",'')
old=old.replace(" # Upstream has no off selector. Zero curves/neutral decel can still set its\n # internal phase flags, but must not change fuel. EGO is neutral in this test.\n if disabled:require(all(r['correction_pct']==100 and (not ours or not r['phase']) for r in rows if r['time']>=3),'disabled negative control has a transient fuel correction')", " if disabled:require(all(r['correction_pct']==100 and not r['phase'] for r in rows if r['time']>=3),'disabled negative control has a transient correction')")
old=old.replace("on['metrics']['corrected_samples_after3']>0 and off['metrics']['corrected_samples_after3']==0", "on['metrics']['active_samples_after3']>0 and off['metrics']['active_samples_after3']==0")
expected=json.loads((O/'source-hashes.json').read_text())['tools/run_transient_scenarios.py'];assert sha(old.encode())==expected,(sha(old.encode()),expected)
(O/'runner-reviewed-initial.py').write_text(old)
sys.path.insert(0,str(R/'tools'));import run_transient_scenarios as runner
out={'initial_runner_sha256':sha(old.encode()),'current_runner_sha256':sha(current.encode()),'versions':{}}
for directory in ['matrix','matrix-qualified']:
 base=R/'.cache/engine/transient'/directory;record={'available_trace_count':0,'rows':[],'decode_skipped':[]}
 summary=base/'summary.json'
 if summary.exists():
  b=summary.read_bytes();j=json.loads(b);record['summary']={'path':str(summary.relative_to(R)),'sha256':sha(b),'passed':j['passed'],'failures':j['failures'],'source_hashes':j['source_hashes']}
 for f in sorted(base.glob('*.json')):
  if f.name=='summary.json':continue
  try:b=f.read_bytes();j=json.loads(b)
  except json.JSONDecodeError:record['decode_skipped'].append(f.name);continue
  if 'summary' not in j or 'edges' not in j:continue
  s=j['summary'];states={};width=[0]*8;errors=[];pair_edges=[[] for _ in range(8)]
  for us,ch,high,*_ in j['edges']:
   if ch>=8:errors.append('channel range');continue
   if high:
    if ch in states:errors.append('duplicate high')
    states[ch]=us
   else:
    if ch not in states:errors.append('orphan low')
    else:width[ch]=max(width[ch],us-states.pop(ch))
   pair_edges[ch].append((us,bool(high)))
  if states:errors.append('final mask nonzero')
  if s['controller']=='ours' and (max(width[:4])>15000 or max(width[4:])>3500):errors.append('project high limit')
  if any(pair_edges[a]!=pair_edges[b] for a,b in [(0,3),(1,2),(4,7),(5,6)]):errors.append('pair mismatch')
  assert not errors,(f.name,errors)
  row={'path':str(f.relative_to(R)),'sha256':sha(b),'edge_count':len(j['edges']),'pair_and_final_low_replay':True,'maximum_high_us':width,'original_audit':s.get('audit')}
  if s['controller']=='ours' and s.get('case')=='decel_zero':
   cut=[r for r in j['trace'] if r['ecu'].get('fuel_cut') and r['ecu']['transient_enrichment'].get('phase_code')==2]
   row['decel_cut_samples']=len(cut)
   if cut:
    a,z=round(cut[0]['time']*1e6),round(cut[-1]['time']*1e6)
    row['sampled_cut_interval_us']=[a,z]
    row['injector_rises_after_1ms_in_sampled_cut_interval']=sum(ch<4 and high and a+1000<=us<=z for us,ch,high,*_ in j['edges'])
    row['coil_lows_in_same_interval']=sum(ch>=4 and not high and a+1000<=us<=z for us,ch,high,*_ in j['edges'])
    assert row['injector_rises_after_1ms_in_sampled_cut_interval']==0 and row['coil_lows_in_same_interval']>0
  if s.get('disabled'):
   row['post3_correction_non100']=sum(abs(r['correction_pct']-100)>1e-5 for r in runner.observations(j) if r['time']>=3)
  record['rows'].append(row);record['available_trace_count']+=1
 out['versions'][directory]=record
# Direct checks of the corrected runner, independent of waiting for the matrix.
a=runner.config(runner.CASES[5]);b=runner.config(runner.CASES[8]);assert a['tps_threshold_pct_s']==20 and b['map_threshold_kpa_s']==1 and b['map_min_change_kpa']==0
assert -30 < -a['tps_threshold_pct_s']
for name in ['speeduino32-tps_adder-off-250','speeduino16-cold_adder-off-250']:
 j=json.loads((R/'.cache/engine/transient/matrix'/(name+'.json')).read_text());case=next(c for c in runner.CASES if c[0]==j['summary']['case']);assert runner.audit(j,case,False,True)['passed']
out['corrected_runner_unit_checks']={'qualifying_decel_threshold':20,'qualifying_map_threshold':1,'map_min_change':0,'historical_neutral_reference_now_assessed_by_correction_not_phase':True}
(O/'matrix-probe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'initial_runner_sha256':out['initial_runner_sha256'],'current_runner_sha256':out['current_runner_sha256'],'trace_counts':{k:v['available_trace_count'] for k,v in out['versions'].items()},'decode_skipped':{k:v['decode_skipped'] for k,v in out['versions'].items()},'corrected_runner_unit_checks':out['corrected_runner_unit_checks']},indent=2))
