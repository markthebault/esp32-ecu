import pathlib,struct,subprocess,hashlib,json
R=pathlib.Path('/home/mark/persospace/esp32-ecu');O=R/'.cache/engine/transient-execution-review';P='/home/mark/.platformio/packages/toolchain-xtensa-esp-elf/bin/xtensa-esp32s3-elf-'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sections(b):
 e=struct.unpack_from('<16sHHIIIIIHHHHHH',b);s=[struct.unpack_from('<10I',b,e[6]+i*e[11]) for i in range(e[12])];ns=s[e[13]];n=b[ns[4]:ns[4]+ns[5]];return [(n[x[0]:].split(b'\0')[0].decode(),x) for x in s]
def addrbytes(b,a,size):
 for name,s in sections(b):
  if s[1]!=8 and s[3]<=a and a+size<=s[3]+s[5]:return name,b[s[4]+a-s[3]:s[4]+a-s[3]+size]
 raise ValueError(hex(a))
out={}
for env,label in [('compact_n16r8_web','selected'),('compact_a3_web','generic'),('compact_a3_timing_bench','dummy')]:
 p=R/'firmware/.pio/build'/env/'firmware.elf';b=p.read_bytes();nm=subprocess.check_output([P+'nm','-n','-S','-C',str(p)],text=True);rows=[]
 for line in nm.splitlines():
  t=line.split(maxsplit=3)
  if len(t)==4:
   try:a,z=int(t[0],16),int(t[1],16)
   except ValueError:continue
   rows.append((a,z,t[2],t[3]))
 strings={}
 for needle in ['DUMMY LOADS ONLY','COMPILE-TIME INHIBITED','hardware_timer_virtual_outputs','hardware_timer_dummy_loads']:
  strings[needle]=[]
  for name,s in sections(b):
   if s[2]&2 and s[1]!=8:
    at=b[s[4]:s[4]+s[5]].find(needle.encode()+b'\0')
    if at>=0:strings[needle].append({'section':name,'address':hex(s[3]+at)})
 desired=['app_main','ecu::engine_service::observe(','ecu::engine_target::(anonymous namespace)::run(void*)','ecu::engine_target::(anonymous namespace)::on_alarm(','ecu::engine_target::(anonymous namespace)::on_capture(','ecu::engine_target::(anonymous namespace)::on_trigger_capture(','ecu::engine_tuning::(anonymous namespace)::run(void*)','ecu::tuning::Session::command(','ecu::engine_service::tuning_commit(','ecu::engine::Controller::step(']
 frames=[]
 for a,z,t,n in rows:
  if t.lower() in ('t','w') and any(n==s or n.startswith(s) for s in desired):
   sn,raw=addrbytes(b,a,3);insn=int.from_bytes(raw,'little');frames.append({'symbol':n,'address':hex(a),'code_section':sn,'frame_bytes':(insn>>12)*8 if insn&0xfff==0x136 else None})
 static=[]
 for a,z,t,n in rows:
  if t.lower() in ('d','b') and any(n.endswith('::'+x) for x in ['controller','recorder','executor','idle_executor','output_pins','output','measured','latest','active','latest_data']):
   sn=next((name for name,s in sections(b) if s[3]<=a and a+z<=s[3]+s[5]),None);static.append({'symbol':n,'address':hex(a),'size':z,'section':sn})
 alarm=next(x for x in rows if 'engine_target' in x[3] and '::on_alarm(' in x[3]);a,z,_,_=alarm
 dis=subprocess.check_output([P+'objdump','-d','-C',f'--start-address=0x{a:x}',f'--stop-address=0x{a+z:x}',str(p)],text=True)
 (O/(label+'-on_alarm.txt')).write_text(dis)
 bench=label=='dummy';pinrow=next((x for x in rows if 'engine_target' in x[3] and x[3].endswith('::output_pins')),None)
 assert bool(strings['DUMMY LOADS ONLY'])==bench and bool(strings['COMPILE-TIME INHIBITED'])!=bench
 assert bool(pinrow)==bench
 if bench:
  sn,pindata=addrbytes(b,pinrow[0],32);pins=list(struct.unpack('<8I',pindata));assert pins==[4,5,6,7,15,16,17,18]
 else:pins=None;assert '<GPIO>' not in dis
 audit=json.loads((O/('isr-'+label)/'closure.json').read_text());assert audit['elf_sha256']==h(p)
 out[env]={'elf_sha256':h(p),'policy_strings':strings,'engine_dummy_policy':bench,'compiled_output_pins':pins,'on_alarm_gpio_literal_refs':dis.count('<GPIO>'),'static_internal_data_bss_bytes':sum(s[5] for n,s in sections(b) if n in ('.dram0.data','.dram0.bss')),'static_objects':static,'stack_frames':frames,'ISR_closure_current':True}
(O/'images.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{'sha256':v['elf_sha256'],'engine_dummy_policy':v['engine_dummy_policy'],'ram':v['static_internal_data_bss_bytes'],'stack_frames':[(x['symbol'],x['frame_bytes']) for x in v['stack_frames'] if 'lambda' not in x['symbol']]} for k,v in out.items()},indent=2))
