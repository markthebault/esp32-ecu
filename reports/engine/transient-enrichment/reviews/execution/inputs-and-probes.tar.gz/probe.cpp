#include "ecu/engine.hpp"
#include "ecu/timing_executor.hpp"
#include "ecu/tuning_stream.hpp"
#include "ecu/engine_log.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace ecu;
engine::Tune neutral(engine::Strategy strategy){engine::Tune t;t.strategy=strategy;t.afterstart_pct=0;t.warmup_pct.fill(100);t.crank_pct.fill(100);t.dfco_enabled=false;t.transient_enrichment.mode=transient::Mode::TpsRate;t.transient_enrichment.tps_min_change_pct=0;return t;}
engine::Inputs input(std::uint64_t stamp,double tps){engine::Inputs s;s.rpm=1200;s.map_kpa=50;s.tps_pct=tps;s.clt_c=85;s.iat_c=25;s.battery_v=14;s.sensor_v=5;s.sampled_us=stamp;s.synced=s.phase_synced=s.sensors_valid=true;return s;}
engine::Output falling(engine::Controller&c,const engine::Tune&t){engine::Output out;for(unsigned n=0;n<=4;++n)out=c.step(t,input(n*5000,12-n*.5),n*5000);return out;}
struct Backend:tuning::Backend{engine::Tune tune;unsigned commits=0,samples=0;tuning::Result load(engine::Tune&t)override{t=tune;return tuning::Result::Ok;}tuning::Result current(std::uint32_t&r)override{r=tune.revision;return tuning::Result::Ok;}tuning::Result commit(const engine::Tune&,std::uint32_t&r)override{++commits;r=++tune.revision;return tuning::Result::Ok;}void sample(std::array<std::uint8_t,tuning::live_bytes>&b)override{++samples;for(unsigned i=0;i<b.size();++i)b[i]=std::uint8_t(i^0x5a);}};
struct IO{unsigned mask=0;std::vector<engine::Edge> edges;timing::Executor*owner=nullptr;void all_low(){mask=0;}bool write(unsigned ch,bool high){mask=high?mask|(1u<<ch):mask&~(1u<<ch);return true;}};
int main(){
 unsigned dose_cases=0;
 for(auto strategy:{engine::Strategy::BatchWasted,engine::Strategy::Sequential,engine::Strategy::SemiSequential})for(auto apply:{transient::Apply::Multiply,transient::Apply::AddReference})for(float pct:{0.f,50.f,100.f}){
  auto t=neutral(strategy);t.transient_enrichment.apply=apply;t.transient_enrichment.decel_fuel_pct=pct;
  if(strategy==engine::Strategy::Sequential){t.cylinder_trims_enabled=true;t.cylinder_fuel[0].cells.fill(125);t.cylinder_fuel[1].cells.fill(50);}
  auto off=t;off.transient_enrichment.mode=transient::Mode::Off;engine::Controller a,b;
  auto out=falling(a,t),base=falling(b,off);assert(!out.faults&&!base.faults);assert(out.transient_enrichment.phase==transient::Phase::Deceleration);assert(!out.spark_cut&&out.dwell_ms==base.dwell_ms);
  for(unsigned ch=0;ch<4;++ch){auto expected=pct==0?0:(base.cylinder_pulse_ms[ch]-base.deadtime_ms)*pct/100+base.deadtime_ms;assert(std::abs(out.cylinder_pulse_ms[ch]-expected)<1e-6);}
  assert(out.fuel_cut==(pct==0));assert(engine::demand_valid(engine::angle_config(t),out,out.rpm));++dose_cases;
 }
 auto limited=neutral(engine::Strategy::SemiSequential);limited.max_injection_ms=8;limited.transient_enrichment.tps_added_pct.fill(255);limited.transient_enrichment.max_enrichment_pct=650;engine::Controller lc;engine::Output lo;
 for(unsigned n=0;n<=4;++n)lo=lc.step(limited,input(n*5000,10+n*.5),n*5000);
 assert(lo.faults&engine::Capacity);assert(lo.fuel_cut&&lo.spark_cut&&lo.pulse_ms==0&&lo.cylinder_capacity_mask);for(auto p:lo.cylinder_pulse_ms)assert(p==0);
 Backend back;tuning::Session session(back);tuning::Stream stream(session);std::vector<std::uint8_t> wire;auto send=[&](const std::uint8_t*p,std::size_t n){wire.insert(wire.end(),p,p+n);return true;};std::uint8_t f='F';stream.feed(&f,1,0,send);wire.clear();
 std::vector<std::uint8_t> request{0,7,'r',0,0x30,0,0,0x40,1};auto crc=tuning::Session::crc32(request.data()+2,7);for(int k=3;k>=0;--k)request.push_back(std::uint8_t(crc>>(k*8)));
 stream.feed(request.data(),request.size(),1000,send);assert(back.samples==1&&back.commits==0);assert(wire.size()==327&&wire[0]==1&&wire[1]==65&&wire[2]==0);assert(wire[3]==0x5a&&wire[322]==std::uint8_t(319^0x5a));std::uint32_t got=0;for(unsigned k=323;k<327;++k)got=(got<<8)|wire[k];assert(got==tuning::Session::crc32(wire.data()+2,321));
 timing::Executor core;IO io;timing::Command cmd;cmd.sequence=1;cmd.tune_revision=cmd.sensor_revision=cmd.configuration_epoch=1;cmd.command_us=cmd.sampled_us=1;cmd.output.state=engine::State::Running;cmd.output.rpm=1000;cmd.output.pulse_ms=1;cmd.output.dwell_ms=2;cmd.output.advance_deg=15;
 core.progress(1,io);core.command(cmd,1,io);timing::Executor::Candidate before;core.prepare(before,1000,20000);before.calculate(0,1000);assert(before.valid);assert(core.commit(before,1000,io)==timing::Executor::Commit::Accepted);
 timing::Executor::Candidate race;core.prepare(race,2000,20000);race.calculate(1,1000);++cmd.sequence;cmd.command_us=cmd.sampled_us=2000;cmd.output.fuel_cut=true;cmd.output.pulse_ms=0;core.command(cmd,2000,io);assert(core.commit(race,2000,io)==timing::Executor::Commit::Retry);
 timing::Executor::Candidate cut;core.prepare(cut,2000,20000);cut.calculate(1,1000);assert(core.commit(cut,2000,io)==timing::Executor::Commit::Accepted);assert(core.stats().fault==timing::Cause::None);assert(core.current_command().output.fuel_cut&&!core.current_command().output.spark_cut);
 std::cout<<"{\"dose_cases\":"<<dose_cases<<",\"zero_and_partial_decel_deadtime\":true,\"whole_command_capacity\":true,\"stale_candidate_retry_after_fuel_cut\":true,\"live_payload_bytes\":321,\"live_wire_bytes\":"<<wire.size()<<",\"sizes\":{\"Tune\":"<<sizeof(engine::Tune)<<",\"Output\":"<<sizeof(engine::Output)<<",\"Controller\":"<<sizeof(engine::Controller)<<",\"RuntimeSample\":"<<sizeof(engine::RuntimeSample)<<",\"Recorder\":"<<sizeof(engine_log::Recorder)<<",\"Page\":"<<sizeof(engine_log::Page)<<",\"Command\":"<<sizeof(timing::Command)<<",\"Candidate\":"<<sizeof(timing::Executor::Candidate)<<",\"Executor\":"<<sizeof(timing::Executor)<<",\"Session\":"<<sizeof(tuning::Session)<<",\"Stream\":"<<sizeof(tuning::Stream)<<"}}\n";
}
