#include "ecu/engine_log_json.hpp"
#include "ecu/tuning_session.hpp"
#include "ecu/tuning_stream.hpp"
extern "C" {
char review_target_size_Tune[sizeof(ecu::engine::Tune)];
char review_target_size_RuntimeSample[sizeof(ecu::engine::RuntimeSample)];
char review_target_size_Row[sizeof(ecu::engine_log::Row)];
char review_target_size_Page16[sizeof(ecu::engine_log::Page)];
char review_target_size_Recorder256[sizeof(ecu::engine_log::Recorder)];
char review_target_size_Session[sizeof(ecu::tuning::Session)];
char review_target_size_Stream[sizeof(ecu::tuning::Stream)];
char review_target_size_Reply[sizeof(ecu::tuning::Reply)];
char review_target_size_cJSON[sizeof(cJSON)];
}
