from helpers import *
import copy,json,xml.etree.ElementTree as ET
from engine_msq import export_msq,import_msq,tag
from engine_protocol import DEFAULT
results=[];t=copy.deepcopy(DEFAULT);t['revision']=37;body=export_msq(t)
def changed_origin(data,value):
 root=ET.fromstring(data)
 for page in root.findall(tag('page')):
  for element in list(page.findall(tag('constant'))):
   if element.get('name')=='baseRevision':
    if value is None:page.remove(element)
    else:element.text=value
 return ET.tostring(root)
assert import_msq(body)['revision']==37
assert import_msq(body,base_revision=43)['revision']==43
absent=changed_origin(body,None);assert import_msq(absent)['revision']==1 and import_msq(absent,base_revision=43)['revision']==43
for value in ['0','-1','1.5','4294967296','NaN','']:
 try:import_msq(changed_origin(body,value),base_revision=43);raise AssertionError(value)
 except ValueError:pass
for value in [True,False,0,-1,1.5,4294967296,float('nan')]:
 try:import_msq(body,base_revision=value);raise AssertionError(value)
 except ValueError:pass
for fixture in sorted((R/'tuning/examples').glob('*.msq')):
 data=fixture.read_bytes();root=ET.fromstring(data);signature=root.find(tag('versionInfo')).get('signature');whole=signature.startswith('ESP32ECU DEV ')
 without=changed_origin(data,None)
 if whole:assert import_msq(without,base_revision=43)['revision']==43
 else:
  try:import_msq(without,base_revision=43);raise AssertionError(signature)
  except ValueError:pass
 results.append(dict(fixture=fixture.name,signature=signature,optional_origin=whole))
# NUL file or HTTP-style save must fail without rewriting or replacing runtime.
import tempfile
with tempfile.TemporaryDirectory(prefix='ae-nul-review-') as temp:
 path=Path(temp)/'t.json';raw=body.encode() if isinstance(body,str) else body
 valid=json.dumps(t,separators=(',',':')).encode();path.write_bytes(valid);store=er.EngineStore(path,b);runtime=store.runtime
 assert store.save(valid+b'\0garbage')[0]==422 and store.runtime is runtime and path.read_bytes()==valid
 store.runtime.close();store.trigger_capture.close();store.data_recorder.close()
 broken=valid+b'\0garbage';path.write_bytes(broken);store=er.EngineStore(path,b);assert not store.storage_ok and path.read_bytes()==broken;assert store.save(valid)[0]==503 and path.read_bytes()==broken
 store.runtime.close();store.trigger_capture.close();store.data_recorder.close()
(OUT/'import-edge-results.json').write_text(json.dumps({'own007_origin':'Valid origin preserved; missing origin offline placeholder1; valid caller base43 overrides; malformed origin rejects before override; malformed caller rejects','historical':results,'embedded_nul':'Save rejects without runtime/file replacement; load preserves file and blocks saves'},indent=2)+'\n');print('Own007 origin, all historical origin gates and NUL preservation passed')
