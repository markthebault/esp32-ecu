#include "/home/mark/persospace/esp32-ecu/.cache/engine/transient-storage-review/snapshot/tools/engine_bridge.cpp"

namespace {long review_limit=-1,review_live_blocks=0;void*review_allocate(std::size_t n){if(review_limit==0)return nullptr;if(review_limit>0)--review_limit;auto*p=std::malloc(n);if(p)++review_live_blocks;return p;}void review_release(void*p){if(p){--review_live_blocks;std::free(p);}}}
extern "C" void review_budget(long n){review_limit=n;cJSON_Hooks h{review_allocate,review_release};cJSON_InitHooks(&h);}
extern "C" long review_live(){return review_live_blocks;}
