#include "ecu/engine_log_json.hpp"
#include "ecu/engine_log_msl.hpp"
#include "ecu/tuning_live.hpp"
#include "ecu/tuning_stream.hpp"
#include "baseline_log_msl_review.hpp"
#include <cassert>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cfloat>
#include <string>
#include <vector>
namespace {
struct alignas(std::max_align_t) Allocation { std::size_t size; };
std::size_t live_bytes=0,peak=0,calls=0,live_blocks=0;long fail_at=-1;
void* allocate(std::size_t n){if(fail_at==0)return nullptr;if(fail_at>0)--fail_at;auto*p=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+n));if(!p)return nullptr;p->size=n;live_bytes+=n;peak=std::max(peak,live_bytes);++calls;++live_blocks;return p+1;}
void release(void*p){if(!p)return;auto*h=static_cast<Allocation*>(p)-1;live_bytes-=h->size;--live_blocks;std::free(h);}
void reset(long failure=-1){assert(live_blocks==0&&live_bytes==0);peak=calls=0;fail_at=failure;}
struct Metrics {std::size_t allocations,dom,peak,output;};
template<class Build> Metrics measure(Build build){reset();auto*j=build();assert(j);const auto dom=live_bytes;char*p=cJSON_PrintUnformatted(j);assert(p);Metrics m{calls,dom,peak,std::strlen(p)};cJSON_Delete(j);cJSON_free(p);assert(live_blocks==0&&live_bytes==0);return m;}
template<class Build> std::size_t every_failure(Build build,std::size_t count){for(std::size_t n=0;n<count;++n){reset(long(n));auto*j=build();char*p=j?cJSON_PrintUnformatted(j):nullptr;assert(!p);cJSON_Delete(j);cJSON_free(p);assert(live_blocks==0&&live_bytes==0);}reset();return count;}
std::vector<std::string> split(const std::string&s,char delim){std::vector<std::string>v;std::size_t from=0;for(;;){auto to=s.find(delim,from);v.push_back(s.substr(from,to-from));if(to==std::string::npos)break;from=to+1;}return v;}
struct Backend:ecu::tuning::Backend {
 unsigned samples=0;ecu::tuning::Result load(ecu::engine::Tune&)override{return ecu::tuning::Result::Invalid;}
 ecu::tuning::Result current(std::uint32_t&r)override{r=123;return ecu::tuning::Result::Ok;}
 ecu::tuning::Result commit(const ecu::engine::Tune&,std::uint32_t&)override{return ecu::tuning::Result::Invalid;}
 void sample(std::array<std::uint8_t,ecu::tuning::live_bytes>&b)override{++samples;for(auto&x:b)x=std::uint8_t(samples);}
};
void metrics(const char*name,const Metrics&m){std::printf("\"%s\":{\"allocations\":%zu,\"dom_requested_bytes\":%zu,\"peak_requested_bytes\":%zu,\"printed_bytes\":%zu}",name,m.allocations,m.dom,m.peak,m.output);}
}
int main(){
 using namespace ecu; cJSON_Hooks hooks{allocate,release};cJSON_InitHooks(&hooks);
 engine_log::Page p;p.count=16;p.header.source=engine::DataSource::Target;p.header.log_id=p.header.period_ms=p.header.duration_s=p.header.total=p.header.retained=p.header.overwritten=p.header.missed_periods=p.header.repeated=p.header.invalid=UINT32_MAX;p.header.started_us=p.header.deadline_us=p.header.ended_us=UINT64_MAX;
 auto&r=p.rows[0];r.log_id=r.sequence=UINT32_MAX;r.recorded_us=UINT64_MAX;auto&s=r.sample;
 s.sequence=s.control_us=s.sampled_us=s.worker_sequence=s.worker_observed_us=s.idle_pid_updates=UINT64_MAX;
 s.source=engine::DataSource::Target;s.tune_revision=s.sensor_revision=s.phase_epoch=s.worker_epoch=s.worker_tune_revision=s.worker_sensor_revision=s.controller_faults=s.phase_losses=s.cam_rejected=s.idle_flags=UINT32_MAX;
 s.flags=UINT16_MAX;s.input_valid=s.board_flags=s.cylinder_valid=s.cylinder_enabled=s.cylinder_capacity_mask=s.cylinder_spark_clamp_mask=s.cylinder_retard_floor_mask=UINT8_MAX;s.cam_error_deg=-FLT_MAX;
 for(auto&x:s.inputs)x=-FLT_MAX;for(auto&x:s.proposals)x=-FLT_MAX;for(auto&x:s.idle_proposals)x=-FLT_MAX;
 for(auto*array:{&s.cylinder_pulse_ms,&s.cylinder_advance_deg,&s.cylinder_fuel_pct,&s.cylinder_duty_pct})for(auto&x:*array)x=-FLT_MAX;
 for(auto&x:s.raw_adc)x=UINT16_MAX;s.idle_available=true;auto&ae=s.transient_enrichment;ae.available=true;ae.mode=transient::Mode::MapRate;ae.apply=transient::Apply::AddReference;ae.phase=transient::Phase::Acceleration;ae.reason=transient::Reason::AcquisitionClock;ae.flags=31;for(auto&x:ae.values)x=-FLT_MAX;
 for(unsigned i=1;i<16;++i)p.rows[i]=r;
 const auto one=measure([&]{return engine_log::row_json(r);});const auto whole=measure([&]{return engine_log::page_json(p);});
 const auto rowfail=every_failure([&]{return engine_log::row_json(r);},one.allocations);const auto pagefail=every_failure([&]{return engine_log::page_json(p);},whole.allocations);
 char header[engine_log::text_capacity],line[engine_log::text_capacity],old_header[4096],old_line[4096];
 assert(engine_log::msl_header(p.header,header,sizeof(header),"0123456789abcdef0123456789abcdef"));assert(engine_log::msl_row(p.header,r,line,sizeof(line)));
 assert(engine_log_old::msl_header(p.header,old_header,sizeof(old_header),"0123456789abcdef0123456789abcdef"));assert(engine_log_old::msl_row(p.header,r,old_line,sizeof(old_line)));
 auto header_lines=split(header,'\n'),old_header_lines=split(old_header,'\n');for(unsigned i:{2U,3U}){auto cols=split(header_lines[i],'\t'),old_cols=split(old_header_lines[i],'\t');assert(cols.size()==105&&old_cols.size()==91);assert(std::equal(old_cols.begin(),old_cols.end(),cols.begin()));}
 auto cols=split(split(line,'\n')[0],'\t'),old_cols=split(split(old_line,'\n')[0],'\t');assert(cols.size()==105&&old_cols.size()==91&&std::equal(old_cols.begin(),old_cols.end(),cols.begin()));
 // Unknown transient values never masquerade as available JSON/MSL data.
 ae.available=false;reset();auto*j=engine::data_json(s,UINT64_MAX);assert(j);auto*obj=cJSON_GetObjectItemCaseSensitive(j,"transient_enrichment");assert(obj&&cJSON_IsFalse(cJSON_GetObjectItemCaseSensitive(obj,"available")));for(auto name:transient::value_names)assert(cJSON_IsNull(cJSON_GetObjectItemCaseSensitive(obj,name)));cJSON_Delete(j);assert(!live_blocks);
 assert(engine_log::msl_row(p.header,r,old_line,sizeof(old_line)));auto unknown=split(split(old_line,'\n')[0],'\t');for(unsigned i=91;i<99;++i)assert(unknown[i]=="NaN");assert(unknown[104]=="0");std::array<std::uint8_t,tuning::live_bytes>live;tuning::live_block(s,UINT64_MAX,live);for(unsigned i=256;i<288;++i)assert(!live[i]);assert(tuning::get_u32(live.data()+288)==ae.flags);
 ae.available=true;ae.flags=0;ae.values[0]=ae.values[1]=ae.values[2]=NAN;tuning::live_block(s,UINT64_MAX,live);assert(tuning::get_u32(live.data()+288)==256);for(unsigned i=256;i<268;++i)assert(!live[i]);for(unsigned i=308;i<320;++i)assert(!live[i]);
 Backend backend;tuning::Session session(backend);tuning::Stream stream(session);const std::array<std::uint8_t,7>cmd{'r',0,0x30,0,0,0x40,1};std::array<std::uint8_t,13>request{};request[1]=7;std::copy(cmd.begin(),cmd.end(),request.begin()+2);auto crc=tuning::Session::crc32(cmd.data(),cmd.size());for(unsigned i=0;i<4;++i)request[9+i]=std::uint8_t(crc>>(24-8*i));unsigned sends=0;std::vector<std::uint8_t>wire;stream.feed(request.data(),request.size(),100,[&](const std::uint8_t*bytes,std::size_t n){++sends;wire.assign(bytes,bytes+n);return true;});assert(backend.samples==1&&sends==1&&wire.size()==327&&wire[0]==1&&wire[1]==65);assert(tuning::Session::crc32(wire.data()+2,321)==(std::uint32_t(wire[323])<<24|std::uint32_t(wire[324])<<16|std::uint32_t(wire[325])<<8|wire[326]));
 std::printf("{\"native_pointer_bytes\":%zu,\"cjson_node_bytes\":%zu,\"sizes\":{\"Tune\":%zu,\"RuntimeSample\":%zu,\"Row\":%zu,\"Page16\":%zu,\"Recorder256\":%zu,\"Session\":%zu,\"Stream\":%zu,\"Reply\":%zu},",sizeof(void*),sizeof(cJSON),sizeof(engine::Tune),sizeof(engine::RuntimeSample),sizeof(engine_log::Row),sizeof(engine_log::Page),sizeof(engine_log::Recorder),sizeof(tuning::Session),sizeof(tuning::Stream),sizeof(tuning::Reply));metrics("one_row",one);std::printf(",");metrics("full16_native_page",whole);std::printf(",\"all_allocations_fail_closed\":{\"one_row\":%zu,\"full_page\":%zu},\"msl\":{\"columns\":105,\"legacy_prefix\":91,\"header_bytes\":%zu,\"max_numeric_row_bytes\":%zu,\"capacity\":3072},\"atomic_sample_calls\":1,\"single_frame_bytes\":327,\"unknown_ae_masks\":true}\n",rowfail,pagefail,std::strlen(header),std::strlen(line));
}
