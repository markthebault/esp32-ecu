from helpers import *
import copy,json,struct,tempfile,xml.etree.ElementTree as ET,subprocess,types,zlib
from unittest import mock
from engine_protocol import DEFAULT,pages,decode_pages,Session,Stream,envelope,SIGNATURE,SEMI_SIGNATURE,LIVE_BYTES
from engine_msq import export_msq,import_msq,tag
from transient_config import MODES,APPLIES,SCALARS,ARRAYS,SCALAR_OFFSETS,ARRAY_OFFSETS
compact=lambda x:json.dumps(x,separators=(',',':'),allow_nan=False).encode()
results={}
def old_tune(version):
 t=copy.deepcopy(DEFAULT);t.pop('transient_enrichment');t['schema_version']=version;t['revision']=37
 t['settings'].update(accel_threshold_pct_s=55.5,accel_gain=.003125,accel_decay_s=.5,idle_enabled=True)
 if version<4:t.pop('idle_control')
 else:t['idle_control'].update(frequency_hz=80,control_period_ms=25)
 if version<3:t.pop('cylinder_trims')
 else:
  t['cylinder_trims']['enabled']=True;t['cylinder_trims']['spark_deg']=[1.25,-2.5,3.75,-4]
  for i,m in enumerate(t['cylinder_trims']['fuel_maps']):m['cells']=[95+i*5+(c%4)*.25 for c in range(36)]
 if version==1:t.pop('timing');t['strategy']='batch_wasted_4cyl'
 else:t['strategy']='sequential_4cyl'
 return t
for version in range(1,6):
 t=old_tune(version)
 with tempfile.TemporaryDirectory(prefix='ae-migration-review-') as td:
  path=Path(td)/'tune.json';raw=json.dumps(t,indent=1).encode();path.write_bytes(raw);store=er.EngineStore(path,b)
  assert store.storage_ok and path.read_bytes()==raw and store.tune['schema_version']==6 and store.tune['revision']==37
  assert store.tune['transient_enrichment']==DEFAULT['transient_enrichment']
  for key in ('accel_threshold_pct_s','accel_gain','accel_decay_s'):assert store.tune['settings'][key]==t['settings'][key]
  if version>=4:assert store.tune['idle_control']==t['idle_control'] and store.tune['settings']['idle_enabled']
  else:assert not store.tune['settings']['idle_enabled']
  if version>=3:assert store.tune['cylinder_trims']==t['cylinder_trims']
  code,value=store.save(compact(store.tune));assert code==200 and value['revision']==38 and json.loads(path.read_bytes())['schema_version']==6
  store.runtime.close();store.trigger_capture.close();store.data_recorder.close()
results['migration']='Schemas1..5 retain raw bytes/revision/legacy AE settings; add legacy_tps/multiply config; idle/trim migration rules retained; explicit Save increments once'
# Strict schema6 fields and config validation cannot mutate an active tune.
t=copy.deepcopy(DEFAULT);t['transient_enrichment'].update(mode='map_rate',apply='add_reference',duration_ms=250,sample_period_ms=25,tps_threshold_pct_s=55,map_threshold_kpa_s=65)
t['transient_enrichment']['tps_added_pct']=[1,11,31,51];t['transient_enrichment']['map_added_pct']=[2,12,32,52]
required=list(t['transient_enrichment']);rejected=0
for key in required:
 bad=copy.deepcopy(t);bad['transient_enrichment'].pop(key);assert not b.engine_validate(compact(bad));rejected+=1
for key,value in [('mode','unknown'),('apply','unknown'),('sample_period_ms',0),('decel_fuel_pct',101),('duration_ms',2001),('tps_rates',[0,100,100,1500])]:
 bad=copy.deepcopy(t);bad['transient_enrichment'][key]=value;assert not b.engine_validate(compact(bad))
for v in range(1,6):
 bad=old_tune(v);bad['transient_enrichment']=t['transient_enrichment'];assert not b.engine_validate(compact(bad))
results['strict_config_fields']=rejected
with tempfile.TemporaryDirectory(prefix='ae-session-review-') as td:
 path=Path(td)/'t.json';store=er.EngineStore(path,b);session=Session(store);old=copy.deepcopy(store.tune);before=path.read_bytes() if path.exists() else None
 write=lambda offset,value:b'M'+struct.pack('<BBHH',0,1,offset,len(value))+value
 page=pages(t)[1];assert len(page)==5120
 # All19 transient constants stage as a single124-byte configuration patch.
 assert session.command(write(4992,page[4992:5116]))==b'\0';assert store.tune==old
 assert session.command(b'b\0\1')==b'\4';assert store.tune['revision']==2 and store.tune['transient_enrichment']==t['transient_enrichment']
 assert struct.unpack_from('<I',session.buffers[1],268)[0]==1
 # Reserve checks reject an entire mixed chunk without changing staged bytes.
 for offset,count in [(292,1),(4756,1),(4940,1),(4991,1),(5116,1),(5112,8)]:
  staged=session.buffers[1];payload=bytearray(staged[offset:offset+count]);payload[-1]^=1
  assert session.command(write(offset,payload))==b'\x84' and session.buffers[1]==staged
 # Invalid mode + following valid correction stays staged and cannot commit.
 assert session.command(write(4992,struct.pack('<I',4)))==b'\0';file_before=path.read_bytes();runtime=store.runtime
 assert session.command(b'b\0\1')==b'\x84' and path.read_bytes()==file_before and store.runtime is runtime
 assert session.command(write(4992,struct.pack('<I',3)))==b'\0'
 current=copy.deepcopy(store.tune);assert store.save(compact(current))[0]==200
 assert session.command(b'b\0\1')==b'\x84' and session.dirty and store.tune['revision']==3
 session.close()
 # Atomic320 live replies, including envelope CRC independently checked by zlib.
 session=Session(store)
 reply=session.command(b'r'+struct.pack('<BBHH',0,0x30,0,320));assert len(reply)==321 and reply[0]==0
 for offset,count in [(0,321),(319,2),(320,1),(0,0)]:assert session.command(b'r'+struct.pack('<BBHH',0,0x30,offset,count))==b'\x84'
 wire=session.feed(envelope(b'r'+struct.pack('<BBHH',0,0x30,0,320)),now_us=1000000);assert len(wire)==1 and len(wire[0])==327
 block=wire[0];length=struct.unpack('>H',block[:2])[0];assert length==321 and zlib.crc32(block[2:-4])&0xffffffff==struct.unpack('>I',block[-4:])[0]
 session.close();store.runtime.close();store.trigger_capture.close();store.data_recorder.close()
results['whole_tune']='Transient patch commits once; origin stable; reserved/mixed chunks reject atomically; invalid mode cannot activate; concurrent writer causes conflict'
results['live_frame']='Direct321-byte payload and327-byte CRC frame for atomic320 read; zero/321/out-of-range slices reject; M/page chunk remains256'
# Wire prefixes and legacy identities remain unchanged.
commit=json.loads((OUT/'snapshot-hashes.json').read_text())['baseline_commit'];old=types.ModuleType('old006');exec(subprocess.check_output(['git','show',commit+':tools/engine_protocol.py']).decode(),old.__dict__)
legacy=copy.deepcopy(t);legacy.pop('transient_enrichment');legacy['schema_version']=5
assert pages(t)[1][:4992]==old.pages(legacy)[1]
assert pages(decode_pages(pages(t),t))==pages(t)
body=export_msq(t);assert import_msq(body)==t
for key in ['ae_mode','ae_apply',*['ae_'+k for k in SCALARS+ARRAYS]]:
 root=ET.fromstring(body)
 for p in root.findall(tag('page')):
  for e in list(p.findall(tag('constant'))):
   if e.get('name')==key:p.remove(e)
 try:import_msq(ET.tostring(root));raise AssertionError(key)
 except ValueError:pass
for fixture in (R/'tuning/examples').glob('*.msq'):
 imported=import_msq(fixture.read_bytes(),base_revision=37)
 assert imported['schema_version']==6 and imported['transient_enrichment']['mode']=='legacy_tps' and imported['transient_enrichment']['apply']=='multiply'
results['legacy_msq']='All captured historical001..006 application fixtures import to legacy_tps/multiply; all19 new007 transient constants are mandatory'
# Checked migration DOM additions fail closed at every cJSON allocation budget.
counts={}
for version in (1,5):
 raw=compact(old_tune(version));fail=success=0
 for budget in range(3400):
  b.review_budget(budget);encoded=b.engine_canonicalize(raw);live=b.review_live();b.review_budget(-1);assert live==0,(version,budget,live)
  if encoded:
   result=json.loads(encoded);assert result['schema_version']==6 and result['revision']==37 and result['transient_enrichment']['mode']=='legacy_tps';success+=1
  else:fail+=1
 assert fail and success;counts[version]={'failures':fail,'successes':success,'leaks':0}
results['cjson_budget_sweeps']=counts
(OUT/'native-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
