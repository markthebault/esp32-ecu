from helpers import *
import json
runtime=er.EngineRuntime(bridge=b);runtime.step(dict(rpm=1234,map_kpa=46,tps_pct=12.5,lambda_ready=False,synced=True),1000000,use_decoder=False);sample=runtime.data();runtime.close()
rec=obs.EngineRecorder(ob);assert rec.command(dict(action='start',period_ms=100,duration_s=1),1000000,2)==200;assert rec.append(sample,1000000);rec.expire(2000000);page=rec.page(1,0);page['boot_id']='0'*32
(OUT/'logger-fixture.json').write_text(json.dumps(page,indent=2)+'\n');(OUT/'logger-native.msl').write_text(rec.msl(1));rec.close()
old=[]
from engine_protocol import DEFAULT
import copy
for version in range(1,6):
 t=copy.deepcopy(DEFAULT);t.pop('transient_enrichment');t['revision']=37;t['schema_version']=version;t['settings'].update(accel_threshold_pct_s=55.5,accel_gain=.003125,accel_decay_s=.5,idle_enabled=True)
 if version<4:t.pop('idle_control')
 if version<3:t.pop('cylinder_trims')
 if version==1:t.pop('timing');t['strategy']='batch_wasted_4cyl'
 else:t['strategy']='sequential_4cyl'
 old.append(t)
(OUT/'legacy-json-fixtures.json').write_text(json.dumps(old,indent=2)+'\n')
