from helpers import *
import json,runpy,hashlib
from unittest import mock
outputs=[]
def check_write(path,text,*args,**kwargs):
 data=text.encode(kwargs.get('encoding') or 'utf-8');existing=path.read_bytes();assert data==existing,str(path);outputs.append({'path':str(path.relative_to(R)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)});return len(text)
for script in ['generate_tuning_wire.py','generate_transient_ui.py','generate_tunerstudio_ini.py']:
 with mock.patch.object(Path,'write_text',check_write):runpy.run_path(str(R/'scripts'/script),run_name='__main__')
(OUT/'generator-results.json').write_text(json.dumps(outputs,indent=2)+'\n');print(json.dumps(outputs,indent=2))
