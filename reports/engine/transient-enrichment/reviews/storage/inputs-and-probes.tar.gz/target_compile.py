from pathlib import Path
import hashlib,json,shlex,subprocess,datetime
out=Path('.cache/engine/transient-storage-review').resolve();snap=out/'snapshot';root=Path.cwd();cc=root/'firmware/.pio/build/compact_n16r8_web/compile_commands.json'
manifest=json.loads((out/'snapshot-hashes.json').read_text())
for source,relative in [(cc,'target-build/compile_commands.json'),(cc.parent/'config/sdkconfig.h','target-build/sdkconfig.h')]:
 data=source.read_bytes();dest=snap/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);manifest.setdefault('review_additional_inputs',{})[relative]={'source':str(source),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'snapshot-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
database=json.loads((snap/'target-build/compile_commands.json').read_text());records=[]
for name in ['target_probe.cpp','engine_service.cpp','engine_tuning.cpp','engine_log_service.cpp','web_config.cpp']:
 ref=next(x for x in database if x['file'].endswith('/'+(name if name!='target_probe.cpp' else 'engine_service.cpp')))
 args=shlex.split(ref['command']);result=[];skip=False
 for arg in args:
  if skip:skip=False;continue
  if arg in ['-o','-c']:skip=True;continue
  if arg.startswith('-I'+str(root/'firmware/include')):arg='-I'+str(snap/'firmware/include')
  if arg.startswith('-I'+str(root/'firmware/components/esp_driver_usb_serial_jtag/include')):arg='-I'+str(snap/'firmware/components/esp_driver_usb_serial_jtag/include')
  if arg.startswith('-I'+str(cc.parent/'config')):arg='-I'+str(snap/'target-build')
  result.append(arg)
 source=out/name if name=='target_probe.cpp' else snap/'firmware/main'/name
 # PIO build_flags are applied by SCons rather than exported CMake entries.
 result+=['-I'+str(snap/'vendor/cJSON'),'-std=gnu++17','-DECU_COMPACT_A3=1','-DECU_CONFIG_WEB=1','-DECU_SELECTED_N16R8=1','-DECU_TUNING_USB=1','-fstack-usage','-o',str(out/(name+'.review.o')),'-c',str(source)]
 p=subprocess.run(result,cwd=ref['directory'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);records.append({'name':name,'returncode':p.returncode,'stdout':p.stdout,'command':result})
 print(name,p.returncode,p.stdout[-3000:]);assert p.returncode==0
(out/'target-compile-record.json').write_text(json.dumps(records,indent=2)+'\n')
nm=Path(result[0]).parent/'xtensa-esp32s3-elf-nm';obj=out/'target_probe.cpp.review.o'
text=subprocess.check_output([str(nm),'-S','--size-sort',str(obj)],text=True);(out/'target-sizes.txt').write_text(text)
sizes={line.split()[-1].removeprefix('review_target_size_'):int(line.split()[1],16) for line in text.splitlines() if 'review_target_size_' in line}
(out/'target-sizes.json').write_text(json.dumps(sizes,indent=2)+'\n');print(json.dumps(sizes))
