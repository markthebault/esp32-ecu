from pathlib import Path
import sys,json,copy,random,subprocess
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'source/tools'))
from engine_runtime import load_engine_bridge
base=json.loads((OUT/'source/config/engine/defaults.json').read_text());bridge=load_engine_bridge();rng=random.Random(20261104);names=('map','tps','imap_emap');axes=('map_kpa','tps_pct','imap_emap_pct');cases=[]
for index in range(2048):
 t=copy.deepcopy(base);c=t['load_model'];c.update(fuel_source=rng.choice(names),spark_source=rng.choice(names),lambda_source=rng.choice(names+('follow_fuel',)),trim_source=rng.choice(names+('follow_fuel',)),pressure=rng.choice(('none','map_100kpa','map_baro')),aux_role=rng.choice(('postcat_monitor','emap','baro')),baro_source=rng.choice(('fixed','aux')),afr=rng.choice(('off','target','measured')))
 t['settings']['ego_enabled']=bool(rng.getrandbits(1));t['cylinder_trims']['enabled']=bool(rng.getrandbits(1));t['strategy']='sequential_4cyl'
 def resolve(s):return c['fuel_source'] if s=='follow_fuel' else s
 for kind,key in [('ve','fuel_source'),('spark','spark_source'),('lambda','lambda_source'),('trim','trim_source')]:
  axis=axes[names.index(resolve(c[key]))];c[kind+'_axis']=axis
  for m in t['cylinder_trims']['fuel_maps'] if kind=='trim' else [t['maps'][kind]]:
   n=len(m['load']);lo=10 if axis=='map_kpa' else 0;hi=110 if axis=='map_kpa' else 100 if axis=='tps_pct' else 600;m['load']=[round(lo+(hi-lo)*i/(n-1),6) for i in range(n)]
 active=[c['fuel_source'],c['spark_source']]
 if c['afr']!='off' or t['settings']['ego_enabled']:active.append(c['lambda_source'])
 if t['cylinder_trims']['enabled']:active.append(c['trim_source'])
 needs_emap=any(resolve(s)=='imap_emap' for s in active);needs_baro=c['pressure']=='map_baro' and c['baro_source']=='aux'
 expected=(not needs_emap or c['aux_role']=='emap') and (not needs_baro or c['aux_role']=='baro')
 if index%7==0:c['spark_axis']=axes[(names.index(resolve(c['spark_source']))+1)%3];expected=False
 native=bool(bridge.engine_validate(json.dumps(t,separators=(',',':')).encode()));assert native==expected,(index,native,expected,c)
 cases.append(dict(index=index,tune=t,native=native,expected=expected))
(OUT/'config-cases.json').write_text(json.dumps(cases,separators=(',',':'))+'\n');print('2048 independent source/pressure/AFR/EGO/trim dependency cases match native acceptance')
