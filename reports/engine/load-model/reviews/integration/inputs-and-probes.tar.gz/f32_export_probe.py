from pathlib import Path
import sys,copy,json,subprocess,csv,io
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'source/tools'))
from engine_runtime import EngineRuntime
from engine_observability import EngineRecorder
r=EngineRuntime();r.step(dict(rpm=1200,synced=True),1000000,use_decoder=False);sample=r.data();r.close();sample['load_model']['fuel_load']=45.000002;sample['load_model']['baro_kpa']=100.0000045
rec=EngineRecorder();accepted=bool(rec.bridge.data_validate(json.dumps(sample).encode()));assert accepted;rec.command(dict(action='start',period_ms=20,duration_s=2),1000000);rec.append(sample,1000000);rec.command(dict(action='stop',log_id=1),1000001);h=rec.header();p=rec.page(1,0);h['boot_id']=p['boot_id']='0'*32;native=rec.msl(1);rec.close();(OUT/'f32-export-input.json').write_text(json.dumps(dict(h=h,p=p,original=sample),indent=2)+'\n')
# The native recorder itself has already quantized the values. Feed original
# observation directly to browser to exercise the two JSON boundaries equally.
p['records'][0]['sample']=sample
(OUT/'f32-export-browser-input.json').write_text(json.dumps(dict(h=h,p=p))+'\n')
script="""const fs=require('fs'),vm=require('vm');const root=process.argv[1];global.window={};vm.runInThisContext(fs.readFileSync(root+'/closure-source/web/load_model.js','utf8'));vm.runInThisContext(fs.readFileSync(root+'/source/web/engine_logger.js','utf8'));let {h,p}=JSON.parse(fs.readFileSync(root+'/f32-export-browser-input.json','utf8'));window.EcuEngineLogger.adopt(h);window.EcuEngineLogger.acceptPage(p);process.stdout.write(window.EcuEngineLogger.exportMsl());"""
browser=subprocess.check_output(['node','-e',script,str(OUT)],text=True);a=list(csv.reader(io.StringIO(native),delimiter='\t'));b=list(csv.reader(io.StringIO(browser),delimiter='\t'));ra=dict(zip(a[2],a[4]));rb=dict(zip(b[2],b[4]));result=dict(native_accepted=accepted,rows_equal=a[4]==b[4],differences={k:dict(native=ra[k],browser=rb[k]) for k in ra if ra[k]!=rb[k]});(OUT/'f32-export-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
