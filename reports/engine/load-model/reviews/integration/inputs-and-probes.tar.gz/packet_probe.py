from pathlib import Path
import sys,copy,json,math,struct,hmac
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'source/tools'))
from engine_runtime import EngineRuntime
from engine_observability import EngineRecorder
from engine_receiver import EngineReceiver,engine_telemetry,derive_engine_key
base=json.loads((OUT/'source/config/engine/defaults.json').read_text());native=EngineRecorder();lmk=bytes(range(16));nonce=bytes(range(16,32));key=derive_engine_key(lmk,nonce,123);cases=[]
for fuel in range(3):
 for spark in range(3):
  for pressure in range(3):
   for afr in range(3):
    t=copy.deepcopy(base);c=t['load_model'];sources=['map','tps','imap_emap'];axes=['map_kpa','tps_pct','imap_emap_pct'];c.update(fuel_source=sources[fuel],spark_source=sources[spark],pressure=['none','map_100kpa','map_baro'][pressure],afr=['off','target','measured'][afr]);c.update(ve_axis=axes[fuel],spark_axis=axes[spark],lambda_axis=axes[fuel],trim_axis=axes[fuel]);c['aux_role']='emap' if 2 in (fuel,spark) else 'postcat_monitor'
    for kind,idx in [('ve',fuel),('spark',spark),('lambda',fuel)]:
     m=t['maps'][kind];lo=10 if idx==0 else 0;hi=[110,100,600][idx];m['load']=[round(lo+(hi-lo)*i/15,6) for i in range(16)]
    for m in t['cylinder_trims']['fuel_maps']:
     lo=10 if fuel==0 else 0;hi=[110,100,600][fuel];m['load']=[lo+(hi-lo)*i/5 for i in range(6)]
    r=EngineRuntime(t);r.step(dict(rpm=1200,synced=True,aux_pressure_kpa=125,aux_pressure_qualified=True),1000000,use_decoder=False);s=r.data();r.close();packet=native.frame(s,lmk,nonce,123,1,schema=3)
    assert len(packet)==250 and struct.unpack_from('<H',packet,6)[0]==250 and packet[218:]==hmac.digest(key,packet[:218],'sha256')
    decoded=engine_telemetry(packet,key,3)['load_model'];assert decoded['fuel_source_code']==fuel and decoded['spark_source_code']==spark and decoded['pressure_code']==pressure and decoded['afr_code']==afr
    expected_legacy=fuel==spark==0 and pressure==1 and afr==1
    accepted=[]
    for version in (1,2):
     try:old=native.frame(s,lmk,nonce,123,1,schema=version);ok=True;assert len(old)==232 and old[200:]==hmac.digest(key,old[:200],'sha256')
     except ValueError:ok=False
     assert ok==expected_legacy;accepted.append(ok)
    cases.append(dict(fuel=fuel,spark=spark,pressure=pressure,afr=afr,bytes=len(packet),legacy=accepted))
native.close();(OUT/'packet-results.json').write_text(json.dumps(dict(cases=cases,count=len(cases),status='pass'),indent=2)+'\n');print('81 native source/pressure/AFR packet profiles authenticate, decode, and gate legacy schemas as expected')
