from pathlib import Path
import sys,json,copy,subprocess
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'source/tools'))
from engine_runtime import EngineRuntime
from engine_observability import EngineRecorder,encoded
r=EngineRuntime();r.step(dict(rpm=1200,synced=True),1000000,use_decoder=False);base=r.data();r.close();cases=[]
for name,key,value in [('valid',None,None),('unknown_key','unexpected',0),('F32_overflow_spark','spark_load',3.5e38),('F32_overflow_AFR','afr_factor',1e300),('F32_underflow_pressure','pressure_factor',1e-300),('reason_mismatch','reason','invalid'),('null_afr','afr_factor',None)]:
 s=copy.deepcopy(base)
 if key:s['load_model'][key]=value
 cases.append(dict(name=name,sample=s))
(OUT/'observation-cases.json').write_text(json.dumps(cases,indent=2)+'\n');native=EngineRecorder();results=[]
for case in cases:results.append(dict(name=case['name'],native=bool(native.bridge.data_validate(encoded(case['sample'])))))
native.close();js=json.loads(subprocess.check_output(['node',str(OUT/'observation-parity.js'),str(OUT/'observation-cases.json')],text=True))
for a,b in zip(results,js):a['browser']=b['accepted'];a['browser_error']=b['error']
(OUT/'observation-parity-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
