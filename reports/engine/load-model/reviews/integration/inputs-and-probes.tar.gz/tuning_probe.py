from pathlib import Path
import sys,tempfile,json,copy,struct
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'source/tools'))
from engine_runtime import EngineStore
from engine_protocol import Session,pages,decode_pages,envelope
base=json.loads((OUT/'source/config/engine/defaults.json').read_text())
def req(cmd,offset=0,body=None,count=4):return cmd+struct.pack('<BBHH',0,1,offset,len(body) if body is not None else count)+(body or b'')
def stage(s,t):
 data=pages(t)[1]
 for i in range(0,len(data),256):assert s.command(req(b'M',i,data[i:i+256]))==b'\0'
with tempfile.TemporaryDirectory(dir=OUT) as d:
 store=EngineStore(Path(d)/'tune.json');a=Session(store);b=Session(store)
 t=copy.deepcopy(base);c=t['load_model'];c.update(fuel_source='tps',spark_source='tps',pressure='none',afr='measured',afr_delay_s=12.25)
 for k in ('ve_axis','spark_axis','lambda_axis','trim_axis'):c[k]='tps_pct'
 for m in list(t['maps'].values())+t['cylinder_trims']['fuel_maps']:m['load']=[round(100*i/(len(m['load'])-1),6) for i in range(len(m['load']))]
 t['maps']['ve']['cells'][3]=1.25
 stage(a,t);assert a.command(b'b\0\1')==b'\4';assert store.tune['revision']==2 and store.tune['load_model']==c;wire=a.buffers[1];assert struct.unpack_from('<I',wire,268)[0]==1
 assert b.command(b'b\0\1')==b'\x84';assert store.tune['revision']==2
 assert a.command(req(b'M',5136,struct.pack('<I',1)))==b'\0';assert a.command(b'b\0\1')==b'\4';assert store.tune['revision']==3 and store.tune['load_model']['pressure']=='map_100kpa'
 assert json.loads(store.path.read_text())==store.tune
 assert a.command(req(b'M',5148,struct.pack('<I',0)))==b'\0';assert a.command(b'b\0\1')==b'\x84';assert store.tune['revision']==3
 before=a.buffers[1]
 for offset in (5116,5176,5375):assert a.command(req(b'M',offset,b'\1'))==b'\x84' and a.buffers[1]==before
 live=a.command(b'r'+struct.pack('<BBHH',0,0x30,0,416));assert len(live)==417 and len(envelope(live))==423
 a.close();b.close();store.runtime.close();store.data_recorder.close()
(OUT/'tuning-results.json').write_text(json.dumps(dict(status='pass',checks=['5376-byte complete source/basis transition persists low coefficient and measured-AFR delay','stale second writer409-compatible rejection preserves active revision','successive burn keeps session origin1 while base advances2 then3','inconsistent basis rejects at burn without publication','old and new reserved regions reject chunk atomically','single416-byte runtime response has423-byte framed envelope']),indent=2)+'\n');print((OUT/'tuning-results.json').read_text())
