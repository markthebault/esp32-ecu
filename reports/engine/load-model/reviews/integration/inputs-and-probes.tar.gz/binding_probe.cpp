#include "ecu/engine_binding.hpp"
#include "ecu/engine_log.hpp"
#include "ecu/tuning_session.hpp"
#include <cstdio>
#include <cstring>
int main(){
 ecu::config::Config c;const char*units[]={"kPa","%","C","C","lambda","kPa"};const double values[]={45,10,85,25,1,100};
 for(unsigned i=0;i<6;++i){auto&x=c.sensors[i];x.mode=ecu::config::Mode::Linear;x.confirmed=true;x.y0=x.y1=values[i];std::strcpy(x.unit,units[i]);}
 ecu::web::Sample s;s.adc_ok=true;s.synced=true;s.rpm=1200;s.raw.fill(2048);s.raw[6]=1317;s.raw[7]=3723;
 ecu::engine::Tune t;t.load_model.fuel_source=t.load_model.spark_source=ecu::load::Source::Tps;t.load_model.ve_axis=t.load_model.spark_axis=t.load_model.lambda_axis=t.load_model.trim_axis=ecu::load::Axis::TpsPercent;t.load_model.pressure=ecu::load::Pressure::None;
 for(auto*m:{&t.ve,&t.spark,&t.lambda})for(unsigned i=0;i<16;++i)m->load[i]=100.f*i/15;
 for(auto&m:t.cylinder_fuel)for(unsigned i=0;i<6;++i)m.load[i]=20.f*i;
 c.sensors[0].confirmed=false;
 std::puts("[");
 for(unsigned scenario=0;scenario<3;++scenario){c.sensors[2].confirmed=scenario!=1;s.overflow=scenario==2;auto b=ecu::engine::bind_inputs(s,c,1000000,&t);ecu::engine::Controller ctl;auto o=ctl.step(t,b.input,1000000);
 std::printf("{\"scenario\":%u,\"inputs_valid\":%s,\"controller_faults\":%u,\"reason\":\"%s\"}%s\n",scenario,b.input.sensors_valid?"true":"false",o.faults,b.reason,scenario==2?"":",");}
 std::printf("]\nLayouts RuntimeSample=%zu Recorder=%zu Session=%zu Tune=%zu\n",sizeof(ecu::engine::RuntimeSample),sizeof(ecu::engine_log::Recorder),sizeof(ecu::tuning::Session),sizeof(ecu::engine::Tune));
}
