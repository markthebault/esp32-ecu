"""Independent ambient parameter and conservation check on frozen plant code."""
from pathlib import Path
import importlib.util,json,shutil,sys
O=Path(__file__).resolve().parent
R=O.parents[2]
def run():
 runtime=O/'ambient-runtime';fmu=runtime/'.cache/engine/modelica-mvem/airpath';fmu.mkdir(parents=True,exist_ok=True)
 for name in ('manifest.json','EngineAirPath.fmu'):shutil.copyfile(R/'.cache/engine/modelica-mvem/airpath'/name,fmu/name)
 mo=runtime/'simulation/modelica/EngineAirPath.mo';mo.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(O/'source/simulation/modelica/EngineAirPath.mo',mo)
 sys.path.insert(0,str(O/'source/tools'));spec=importlib.util.spec_from_file_location('frozen_plant',O/'source/tools/engine_research_plant.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=runtime
 rows=[];initial_inventory=None
 for ambient in (100,50,80,110):
  p=m.ResearchPlant(ambient_kpa=ambient)
  try:
   assert p.air.initial['map_kpa']==ambient
   if initial_inventory is None:initial_inventory=p.air.initial['inventory_kg']
   assert abs(p.air.initial['inventory_kg']/initial_inventory-ambient/100)<1e-12
   for i in range(4000):p.integrate(i*.00025,.00025,starter=True)
   ledger=p.ledger();assert abs(ledger['air_residual_kg'])<1e-8 and abs(ledger['air_energy_residual_j'])<.05
   assert ledger['fuel_in_mg']==0 and ledger['combustion_shaft_j']==0
   rows.append(dict(ambient_kpa=ambient,initial_inventory_kg=p.air.initial['inventory_kg'],final_map_kpa=p.map_kpa,final_rpm=p.rpm,air_residual_kg=ledger['air_residual_kg'],air_energy_residual_j=ledger['air_energy_residual_j'],fuel_in_mg=ledger['fuel_in_mg']))
  finally:p.close()
 result=dict(passed=True,points=rows,scope='Existing FMU physical ambient parameter changed before initialization; motored free shaft has no combustion. No engine or altitude calibration claim.')
 (O/'ambient-results.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
 r=run();print(len(r['points']),'physical ambient/inventory/conservation cases passed')
