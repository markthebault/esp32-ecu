"""Independent cache-only frozen runtime lookup/endpoint probes.

lookup-probe adds only reviewlookup in the frozen host adapter. It calls pinned
getLoad/get3DTableValue/calculateAfrTarget against unchanged production objects.
The endpoint runtime uses the exact original frozen reference binary.
"""
from pathlib import Path
import copy,importlib.util,json
O=Path(__file__).resolve().parent
def runtime(root):
 spec=importlib.util.spec_from_file_location('frozen_runtime',O/'source/tools/speeduino_runtime.py')
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=root;return m.SpeeduinoRuntime
def nonflat():
 Runtime=runtime(O/'runtime');base=json.loads((O/'source/config/engine/defaults.json').read_text());raw=[5+3*i for i in range(16)];rpms=[500+500*i for i in range(16)]
 source=('map','tps','imap_emap');axis=('map_kpa','tps_pct','imap_emap_pct');out=[]
 for fuel in range(3):
  for spark in range(3):
   t=copy.deepcopy(base);t['load_model'].update(fuel_source=source[fuel],spark_source=source[spark],pressure='none',ve_axis=axis[fuel],spark_axis=axis[spark],lambda_axis=axis[fuel],trim_axis=axis[fuel],aux_role='emap' if 2 in (fuel,spark) else 'postcat_monitor',afr='target')
   for name,code in [('ve',fuel),('spark',spark),('lambda',fuel)]:
    z=t['maps'][name];z['rpm']=rpms;z['load']=[v/(2 if code==1 else .5) for v in raw]
    z['cells']=[20+2*y+x if name=='ve' else 10+y+2*x if name=='spark' else (120+y)/147 for y in range(16) for x in range(16)]
   p=Runtime()
   try:
    p.configure_load(t);lines=p.command('reviewlookup 2500 100 14 250');actual=list(map(int,lines[0].split()[1:]))
    coordinates=(100,28,40);rows=(15,3,5);expected=[coordinates[fuel],coordinates[spark],24+2*rows[fuel],18+rows[spark],120+rows[fuel]]
    assert actual==expected,(source[fuel],source[spark],actual,expected)
    out.append(dict(fuel_source=source[fuel],spark_source=source[spark],actual=actual,expected=expected,passed=True))
   finally:p.close()
 return out
def endpoint():
 Runtime=runtime(O/'endpoint-runtime');t=json.loads((O/'source/config/engine/defaults.json').read_text());t['load_model'].update(fuel_source='imap_emap',ve_axis='imap_emap_pct',lambda_axis='imap_emap_pct',trim_axis='imap_emap_pct',aux_role='emap')
 p=Runtime();out=[]
 try:
  p.configure_load(t);p.sensors(dict(map_kpa=60,tps_pct=12.5,clt_c=85,iat_c=25,battery_v=14,**{'lambda':1}))
  for i,value in enumerate((20,125,500,498,499,125),1):
   p.pressures(value,80);p.advance(i*1000);out.append(dict(requested_emap_kpa=value,virtual_adc_code=int(value/500*1024+.5),observed=p.load_status()))
 finally:p.close()
 assert [r['observed']['emap_kpa'] for r in out]==[20,125,125,498,498,125]
 return out
if __name__=='__main__':
 for name,rows in [('nonflat-table-results',nonflat()),('emap-endpoint-results',endpoint())]:
  (O/(name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
 print('9 non-flat production lookups and6 production sensor endpoint observations verified')
