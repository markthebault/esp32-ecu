"""Fresh pressure observations through frozen closure production sensors."""
from pathlib import Path
import importlib.util,json
O=Path(__file__).resolve().parent
def run():
 spec=importlib.util.spec_from_file_location('closure_runtime',O/'closure/source/tools/speeduino_runtime.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=O/'closure/runtime'
 t=json.loads((O/'source/config/engine/defaults.json').read_text());t['load_model'].update(fuel_source='imap_emap',ve_axis='imap_emap_pct',lambda_axis='imap_emap_pct',trim_axis='imap_emap_pct',aux_role='emap')
 out=[];startup=[]
 for bits in (32,16):
  p=m.SpeeduinoRuntime(timer_bits=bits)
  try:
   profile=p.configure_load(t);assert profile['raw_profile'][12:14]==[-20,620]
   p.sensors(dict(map_kpa=60,tps_pct=12.5,clt_c=85,iat_c=25,battery_v=14,**{'lambda':1}));p.pressures(20,50);p.advance(1);first=p.load_status();assert first['emap_kpa']==100 and first['fuel_load']==100;startup.append(dict(timer_bits=bits,first_loop_us=1,seeded_emap_kpa=first['emap_kpa'],fuel_load=first['fuel_load']))
   for i,(value,baro) in enumerate(((20,50),(100,80),(125,110),(500,100),(20,50),(500,110)),1):
    p.pressures(value,baro);p.advance(i*1000);d=p.load_status();assert d['emap_kpa']==value,(bits,value,d);assert d['baro_kpa']==50,(bits,baro,d)
    out.append(dict(timer_bits=bits,requested_emap_kpa=value,virtual_adc=int((value+20)/640*1024+.5),observed_emap_kpa=d['emap_kpa'],observed_baro_kpa=d['baro_kpa'],time_us=d['time_us']))
  finally:p.close()
 report=dict(passed=True,emap_calibration_kpa=[-20,620],startup_priming=startup,checks=out,scope='New fixture calibration yields fresh20/100/125/500 production EMAP readings on each1kHz update. Baro retains its actual1Hz production cadence after time0. No physical transducer selection is implied.')
 (O/'closure-endpoint-results.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
 r=run();print(len(r['checks']),'fresh closure EMAP observations passed')
