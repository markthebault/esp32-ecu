"""Independent reconstruction of frozen candidate traces and legacy equality."""
from pathlib import Path
import bisect,gzip,hashlib,json,math
O=Path(__file__).resolve().parent
R=O.parents[2]
def data(path):return json.loads(gzip.decompress(path.read_bytes())) if path.suffix=='.gz' else json.loads(path.read_text())
def bracket(axis,value):
 if value<=axis[0]:return [0]
 if value>=axis[-1]:return [len(axis)-1]
 i=bisect.bisect_right(axis,value)-1;return [i] if value==axis[i] else [i,i+1]
def run():
 summary=data(O/'matrix-final/summary.json');cal=data(O/'calibration-alpha.json');rows=[];usage=[]
 for row in summary['runs']:
  p=O/'matrix-final'/row['trace_file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['trace_sha256'];x=data(p);s=x['summary'];assert s==row['summary']
  high={};widths=[0]*8;previous=-1;channels=set();rises=0
  for stamp,channel,on,cause in x['edges']:
   assert type(stamp) is int and previous<=stamp<=s['duration_s']*1e6 and channel in range(8);previous=stamp;channels.add(channel)
   if on:assert channel not in high;high[channel]=stamp;rises+=1
   else:assert channel in high;widths[channel]=max(widths[channel],stamp-high.pop(channel))
  assert not high and s['final_outputs_high']==0
  assert max(widths[:4])==s['max_injector_high_us'] and max(widths[4:])==s['max_dwell_high_us']
  assert len(x['edges'])==s['edges']
  for key,tol in [('fuel_residual_mg',1e-6),('chemical_residual_j',1e-4),('shaft_residual_j',1e-4),('air_residual_kg',1e-7),('air_energy_residual_j',.05)]:assert math.isfinite(s['ledger'][key]) and abs(s['ledger'][key])<tol,(row['name'],key)
  if row['label'] in ('portable','target'):
   assert max(widths[:4])<=15000 and max(widths[4:])<=3500
   if row['case']=='zero_fuel':assert s['ledger']['fuel_in_mg']==0 and not any(c<4 and on for _,c,on,_ in x['edges']) and s['sparks']>0
   if row['case']=='alpha_guard':assert not any(4000000<t<4250000 and on for t,_,on,_ in x['edges'])
  if row['case'] in ('alpha','alpha_no_map','alpha_guard'):
   weighted=set()
   for z in x['trace']:
    e=z['ecu'];rpm=e.get('rpm',0);load=e['load_model']['fuel_load']
    if row['label'].startswith('speeduino'):load/=4
    if load is None:continue
    indices=[j*16+i for j in bracket(cal['tps_pct'],load) for i in bracket(cal['rpm'],rpm)]
    assert all(cal['points'][i]['status']=='steady' for i in indices),(row['name'],z['time'])
    weighted.update(indices)
   usage.append(dict(name=row['name'],calibration_cells_weighted=len(weighted),unqualified_cells_weighted=0))
  rows.append(dict(name=row['name'],edges=len(x['edges']),rises=rises,channels=sorted(channels),max_high_us=widths,passed=True))
 legacy=data(O/'legacy/summary.json');old=[]
 for c in legacy['cases']:
  x=data(O/'legacy'/(c['name']+'.json'));p=R/c['baseline_path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==c['baseline_sha256'];prior=data(p)
  checks={k:x[k]==prior[k] for k in ('edges','triggers','cams','dwell','spark_timing','injection_timing')}
  checks.update(ledger=x['summary']['ledger']==prior['summary']['ledger'],final_rpm=x['summary']['final_rpm']==prior['summary']['final_rpm']);assert all(checks.values());old.append(dict(name=c['name'],checks=checks))
 report=dict(passed=True,candidate_runs=len(rows),independently_replayed=rows,qualified_calibration_usage=usage,legacy_exact_cases=old)
 (O/'independent-final-evidence-results.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
 r=run();print(r['candidate_runs'],'edge/ledger traces and',len(r['legacy_exact_cases']),'exact legacy replays verified')
