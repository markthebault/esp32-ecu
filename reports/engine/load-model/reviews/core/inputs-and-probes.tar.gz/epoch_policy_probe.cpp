#include "ecu/engine.hpp"
#include <iostream>
#include <cassert>
#include <cmath>
using namespace ecu::engine;namespace l=ecu::load;
Inputs input(std::uint64_t now){Inputs i;i.rpm=1000;i.map_kpa=50;i.tps_pct=10;i.clt_c=85;i.iat_c=25;i.battery_v=14;i.sensor_v=5;i.lambda=1.2;i.sampled_us=now;i.synced=i.phase_synced=i.sensors_valid=i.lambda_ready=true;return i;}
int main(){unsigned cases=0;for(unsigned variant=0;variant<6;++variant){Tune t;t.afterstart_pct=25;t.afterstart_s=2;t.dfco_enabled=false;t.load_model.afr=l::Afr::Measured;t.load_model.afr_delay_s=.02f;Controller c;std::uint64_t now=1000000;auto o=c.step(t,input(now),now);for(unsigned n=0;n<20;++n){now+=5000;o=c.step(t,input(now),now);}assert(o.load_model.afr_state()==l::AfrState::Measured);
 for(unsigned n=0;n<100;++n){now+=5000;auto i=input(now);i.rpm=variant==2?1000:variant==3?200:0;i.synced=false;i.sensors_valid=false;if(variant==1)i.sampled_us=now-20001;if(variant==4)i.sampled_us=now+1;if(variant==5)i.sampled_us=now-20000;o=c.step(t,i,now);}
 now+=5000;o=c.step(t,input(now),now);bool reset=variant==0||variant==3||variant==5;assert(!o.faults);assert(o.load_model.afr_state()==(reset?l::AfrState::StartDelay:l::AfrState::Measured));double ase=1+.25*(1-double(now-1000000)/2e6);assert(std::abs(o.afterstart-ase)<1e-10);std::cout<<"variant="<<variant<<" afr="<<l::afr_state_name(o.load_model.afr_state())<<" ase_preserved="<<o.afterstart<<'\n';++cases;}
 std::cout<<"AFR possible-restart freshness, ongoing-fault continuity and independent ASE cases="<<cases<<" passed\n";}
