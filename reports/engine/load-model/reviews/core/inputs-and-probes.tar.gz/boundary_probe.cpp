#include "ecu/engine.hpp"
#include <iostream>
#include <iomanip>
int main(){
 using namespace ecu::engine;Tune t;t.lambda.cells.fill(1.2f);t.ve.cells.fill(20);t.afterstart_pct=0;t.dfco_enabled=false;t.load_model.afr=ecu::load::Afr::Measured;t.load_model.afr_delay_s=0;
 unsigned count=0,residue=0;std::cout<<std::setprecision(17);
 for(unsigned n=1;n<100000;++n){Inputs s;s.rpm=550+((n*7717)%550000)/100.;s.map_kpa=10+((n*1753)%100000)/1000.;s.tps_pct=20;s.clt_c=85;s.iat_c=25;s.battery_v=14;s.sensor_v=5;s.lambda=1;s.sampled_us=1000000;s.synced=s.phase_synced=s.sensors_valid=s.lambda_ready=true;Controller c;auto o=c.step(t,s,s.sampled_us);if(o.target_lambda>double(1.2f))++residue;if(o.faults||o.load_model.reason!=ecu::load::Reason::Ready){if(count++<8)std::cout<<"MAP="<<s.map_kpa<<" RPM="<<s.rpm<<" target="<<o.target_lambda<<" max="<<double(1.2f)<<" fault="<<o.faults<<" reason="<<ecu::load::reason_name(o.load_model.reason)<<'\n';}}
 std::cout<<"harmless_interpolation_residues="<<residue<<" unexpected_cases="<<count<<'\n';return count?1:0;
}
