#include "ecu/engine.hpp"
#include <iostream>
using namespace ecu::engine;namespace l=ecu::load;
Inputs input(std::uint64_t now){Inputs i;i.rpm=1000;i.map_kpa=50;i.tps_pct=10;i.clt_c=85;i.iat_c=25;i.battery_v=14;i.sensor_v=5;i.lambda=1.2;i.sampled_us=now;i.synced=i.phase_synced=i.sensors_valid=i.lambda_ready=true;return i;}
int main(){Tune t;t.afterstart_pct=0;t.dfco_enabled=false;t.load_model.afr=l::Afr::Measured;t.load_model.afr_delay_s=.02f;Controller c;std::uint64_t now=1000000;auto o=c.step(t,input(now),now);for(unsigned n=0;n<10;++n){now+=5000;o=c.step(t,input(now),now);}std::cout<<"before_stop="<<l::afr_state_name(o.load_model.afr_state())<<'\n';for(unsigned n=0;n<100;++n){now+=5000;auto i=input(now);i.rpm=0;i.synced=false;i.sensors_valid=false;o=c.step(t,i,now);}std::cout<<"during_stop_fault="<<o.faults<<'\n';now+=5000;o=c.step(t,input(now),now);std::cout<<"resume_without_qualified_stopped_sample="<<l::afr_state_name(o.load_model.afr_state())<<" faults="<<o.faults<<'\n';}
