"""Independent native adapters + JSON/binding regression probe, frozen snapshots only."""
import ctypes as C,copy,json,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent
BASE=json.loads((OUT.parent/'load-architecture-review/baseline-source/config/engine/defaults.json').read_text())
results=[]
for file in ['libengine-final.so','libtarget-final.so']:
 b=C.CDLL(str(OUT/file));b.engine_create.restype=C.c_void_p;b.engine_destroy.argtypes=[C.c_void_p];b.engine_validate.argtypes=[C.c_char_p];b.engine_validate.restype=C.c_int;b.engine_canonicalize.argtypes=[C.c_char_p];b.engine_canonicalize.restype=C.c_char_p;b.engine_configure.argtypes=[C.c_void_p,C.c_char_p];b.engine_configure.restype=C.c_int;b.engine_step.argtypes=[C.c_void_p,C.c_char_p,C.c_uint64,C.c_uint64];b.engine_step.restype=C.c_char_p;b.engine_data_json.argtypes=[C.c_void_p];b.engine_data_json.restype=C.c_char_p
 def enc(x):return json.dumps(x,separators=(',',':'),allow_nan=False).encode()
 canonical=json.loads(b.engine_canonicalize(enc(BASE)));assert canonical['schema_version']==7 and canonical['load_model']['pressure']=='map_100kpa' and canonical['load_model']['afr']=='target'
 invalid=json.loads((OUT.parent/'load-architecture-review/baseline-invalid-oracle.json').read_text())
 for case in invalid['json_cases']:
  path=OUT.parent/'load-architecture-review/invalid-oracle-cases'/(case['case']+'.json');actual=bool(b.engine_validate(path.read_bytes()));assert actual==(case['expected']=='accepted'),(file,case['case']);results.append({'adapter':file,'case':case['case'],'kind':'historical_validation','accepted':actual})
 for schema in range(1,7):
  old=copy.deepcopy(BASE);old['schema_version']=schema
  for key,minimum in [('timing',2),('cylinder_trims',3),('idle_control',4),('transient_enrichment',6)]:
   if schema<minimum:old.pop(key,None)
  for value in [85,0,120.001]:
   t=copy.deepcopy(old);t['maps']['ve']['cells'][0]=value;actual=bool(b.engine_validate(enc(t)));assert actual==(value==85),(file,schema,value);results.append({'adapter':file,'case':f'schema{schema}_ve{value}','kind':'historical_schema_validation','accepted':actual})
  migrated=json.loads(b.engine_canonicalize(enc(old)));assert migrated['schema_version']==7 and migrated['load_model']==canonical['load_model']
 alpha=copy.deepcopy(canonical);alpha['settings'].update(afterstart_pct=0,dfco_enabled=False);alpha['transient_enrichment']['mode']='off';m=alpha['load_model'];m.update(fuel_source='tps',spark_source='tps',pressure='none',ve_axis='tps_pct',spark_axis='tps_pct',lambda_axis='tps_pct',trim_axis='tps_pct')
 for g in alpha['maps'].values():g['load']=[100*n/15 for n in range(16)]
 alpha['maps']['ve']['cells']=[20]*256
 for g in alpha['cylinder_trims']['fuel_maps']:g['load']=[100*n/5 for n in range(6)]
 sample=dict(rpm=1000,map_kpa=None,map_qualified=False,tps_pct=10,clt_c=85,iat_c=25,lambda_ready=True,battery_v=14,sensor_v=5,synced=True,sensors_valid=True,use_decoder=False,phase_synced=True);sample['lambda']=1.1
 def run(name,tune,input,expect_fault=0):
  h=b.engine_create()
  try:
   assert b.engine_configure(h,enc(tune)),(file,name,'configure');o=json.loads(b.engine_step(h,enc(input),1000000,1000000));assert 'error' not in o,(file,name,o);assert o['faults']==expect_fault,(file,name,o);d=json.loads(b.engine_data_json(h));results.append({'adapter':file,'case':name,'kind':'step','faults':o['faults'],'load_reason':o['load_model']['reason'],'afr_state':o['load_model']['afr_state'],'input_qualified_flag':bool(d['flags']&16384),'target_lambda':o['target_lambda']});return o,d
  finally:b.engine_destroy(h)
 o,d=run('alpha_unknown_map',alpha,sample);assert d['inputs']['map_kpa'] is None and not d['input_valid_mask']&2 and o['load_model']['fuel_load']==10
 z=copy.deepcopy(alpha);z['maps']['ve']['cells']=[0]*256;o,d=run('zero_coefficient',z,sample);assert o['fuel_cut'] and o['pulse_ms']==0 and o['cylinders']['proposals'][0]['pulse_ms']==0
 off=copy.deepcopy(alpha);off['load_model'].update(afr='off',lambda_source='map',lambda_axis='map_kpa');off['maps']['lambda']['load']=copy.deepcopy(BASE['maps']['lambda']['load']);o,d=run('unused_map_lambda_off',off,sample);assert o['target_lambda'] is None and o['load_model']['afr_factor']==1
 off['settings']['ego_enabled']=True;run('map_lambda_ego_dependency',off,sample,4)
 ratio=copy.deepcopy(alpha);ratio['load_model'].update(fuel_source='imap_emap',ve_axis='imap_emap_pct',lambda_axis='imap_emap_pct',trim_axis='imap_emap_pct',aux_role='emap')
 for name in ['ve','lambda']:ratio['maps'][name]['load']=[600*n/15 for n in range(16)]
 for g in ratio['cylinder_trims']['fuel_maps']:g['load']=[600*n/5 for n in range(6)]
 inp=copy.deepcopy(sample);inp.update(map_kpa=100,map_qualified=True,aux_pressure_kpa=80,aux_pressure_qualified=True);o,d=run('ratio_125pct',ratio,inp);assert o['load_model']['fuel_load']==125 and o['load_model']['spark_load']==10
 inp['aux_pressure_qualified']=False;run('required_emap_unqualified',ratio,inp,4)
 measured=copy.deepcopy(alpha);measured['load_model'].update(afr='measured',afr_delay_s=0);inp=copy.deepcopy(sample);o,d=run('measured_ready',measured,inp);assert o['load_model']['afr_state']=='measured_ratio' and o['load_model']['afr_factor']>1
 inp['lambda_ready']=False;o,d=run('measured_not_ready_neutral',measured,inp);assert o['load_model']['afr_state']=='wideband_unavailable' and o['load_model']['afr_factor']==1 and d['inputs']['lambda'] is None
 inp=copy.deepcopy(sample);inp['lambda']=.64;o,d=run('measured_out_of_range_neutral',measured,inp);assert o['load_model']['afr_factor']==1
 for key,value in [('fuel_source','follow_fuel'),('spark_axis','map_kpa'),('fixed_baro_kpa',0),('afr','unknown')]:
  t=copy.deepcopy(alpha);t['load_model'][key]=value;assert not b.engine_validate(enc(t)),(key,value);results.append({'adapter':file,'case':'invalid_'+key,'kind':'new_validation','accepted':False})
 # Distinguish target-confirmed binding behavior from direct native caller qualification flags.
(OUT/'native-json-probe.json').write_text(json.dumps({'scope':'Own native JSON/core integration only, no loop/physical/UI claim','results':results,'status':'pass'},indent=2)+'\n');print(json.dumps({'cases':len(results),'adapters':2,'status':'pass'},indent=2))
