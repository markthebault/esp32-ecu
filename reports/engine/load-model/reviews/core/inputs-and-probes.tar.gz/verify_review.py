"""Rebuild final reviewed core probes from immutable epoch-snapshot only."""
import json,os,shlex,subprocess,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];CXX=shlex.split(os.environ.get('CXX','c++'));CC=shlex.split(os.environ.get('CC','cc'))
S=OUT/'epoch-snapshot';INCLUDE=['-I'+str(S/'firmware/include')];BASE=['-std=c++17','-Wall','-Wextra','-Werror'];O2=['-O2'];SAN=['-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-pie','-no-pie']
commands=[];runs=[]
def run(command):
 commands.append(command);r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,(command,r.stdout,r.stderr);return r.stdout+r.stderr
def binary(name,source,flags):run(CXX+BASE+flags+INCLUDE+[str(source),'-o',str(OUT/name)])
for name,source in [('load_model_test',S/'firmware/tests/load_model_test.cpp'),('engine_load_test',S/'firmware/tests/engine_load_test.cpp'),('composition_probe',OUT/'composition_probe.cpp'),('epoch_policy_probe',OUT/'epoch_policy_probe.cpp')]:
 binary(name,source,SAN);text=run([str(OUT/name)]);(OUT/(name+'-final.txt')).write_text(text);runs.append({'probe':name,'status':'pass','output':text})
for name,source in [('binding_probe_fixed',OUT/'binding_probe.cpp'),('boundary_probe_fixed',OUT/'boundary_probe.cpp'),('baseline_epoch',OUT.parent/'load-architecture-review/baseline_oracle.cpp')]:binary(name,source,O2+(['-Wno-misleading-indentation'] if name=='baseline_epoch' else []))
text=run([str(OUT/'binding_probe_fixed')]);(OUT/'binding-probe-after.csv').write_text(text)
text=run([str(OUT/'boundary_probe_fixed')]);(OUT/'boundary-probe-final.txt').write_text(text);assert 'unexpected_cases=0' in text
expected=(OUT.parent/'load-architecture-review/baseline-golden.csv').read_bytes();actual=subprocess.check_output([str(OUT/'baseline_epoch')]);assert actual==expected;(OUT/'baseline-epoch.csv').write_bytes(actual)
run(CC+['-O2','-fPIC','-c',str(OUT/'cJSON.c'),'-o',str(OUT/'cJSON.o')])
for source,target in [('engine_bridge.cpp','libengine-final.so'),('target_timing_bridge.cpp','libtarget-final.so')]:run(CXX+BASE+O2+['-shared','-fPIC','-I'+str(OUT),'-I'+str(S/'firmware/main')]+INCLUDE+[str(S/'tools'/source),str(OUT/'cJSON.o'),'-o',str(OUT/target)])
text=run(['python3',str(OUT/'native_json_probe.py')]);native=json.loads((OUT/'native-json-probe.json').read_text());assert native['status']=='pass'
result={'scope':'Read-only core/native JSON integration; cache-only builds, no GPIO/services/GUI/physical claim','status':'pass','sanitized_probes':runs,'baseline_cases':324,'baseline_sha256':hashlib.sha256(actual).hexdigest(),'boundary_samples':99999,'boundary_unexpected':0,'native_json_cases':len(native['results']),'native_json_adapters':2,'commands':commands}
(OUT/'verify-review-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('sanitized_probes','commands')},indent=2))
