#include "ecu/engine.hpp"
#include <cassert>
#include <iostream>
#include <cmath>
using namespace ecu::engine;namespace l=ecu::load;
unsigned cases=0;
double coordinate(l::Source source,const l::Config&c){source=l::resolve(source,c);return source==l::Source::Map?79.123:source==l::Source::Tps?22.789:100*79.123/101.25;}
template<class M>void surface(M&m,l::Axis basis,double intercept,double load_scale,double rpm_scale){double low=basis==l::Axis::MapKpa?5:0,high=basis==l::Axis::MapKpa?110:basis==l::Axis::TpsPercent?100:600;for(unsigned n=0;n<m.load.size();++n)m.load[n]=low+(high-low)*n/(m.load.size()-1);for(unsigned y=0;y<m.load.size();++y)for(unsigned x=0;x<m.rpm.size();++x)m.cells[y*m.rpm.size()+x]=intercept+load_scale*m.load[y]+rpm_scale*m.rpm[x];}
bool near(double a,double b,double tolerance=2e-5){return std::abs(a-b)<=tolerance*std::max(1.,std::abs(b));}
int main(){for(unsigned fuel=0;fuel<3;++fuel)for(unsigned spark=0;spark<3;++spark)for(unsigned lambda=0;lambda<4;++lambda)for(unsigned trim=0;trim<4;++trim)for(unsigned pressure=0;pressure<3;++pressure)for(unsigned afr=0;afr<3;++afr)for(bool trims:{false,true})for(bool ego:{false,true}){
 Tune t;auto&c=t.load_model;c.fuel_source=l::Source(fuel);c.spark_source=l::Source(spark);c.lambda_source=l::Source(lambda);c.trim_source=l::Source(trim);c.ve_axis=l::axis(c.fuel_source,c);c.spark_axis=l::axis(c.spark_source,c);c.lambda_axis=l::axis(c.lambda_source,c);c.trim_axis=l::axis(c.trim_source,c);c.pressure=l::Pressure(pressure);c.afr=l::Afr(afr);c.fixed_baro_kpa=83;c.afr_delay_s=0;c.aux_role=l::AuxRole::Emap;
 t.strategy=trims?Strategy::Sequential:Strategy::BatchWasted;t.cylinder_trims_enabled=trims;t.ego_enabled=ego;t.ego_kp=t.ego_ki=t.ego_limit=0;t.afterstart_pct=0;t.dfco_enabled=false;t.transient_enrichment.mode=ecu::transient::Mode::Off;t.warmup_pct.fill(100);t.crank_pct.fill(100);
 surface(t.ve,c.ve_axis,20,.03,.001);surface(t.spark,c.spark_axis,8,.01,.0005);surface(t.lambda,c.lambda_axis,.9,.00005,.000005);for(unsigned n=0;n<4;++n){surface(t.cylinder_fuel[n],c.trim_axis,95+n,.002,0);t.cylinder_spark_deg[n]=float(n)-1.5f;}
 assert(!validate(t));Inputs s;s.rpm=1234.5;s.map_kpa=79.123;s.tps_pct=22.789;s.aux_pressure_kpa=101.25;s.aux_pressure_qualified=true;s.clt_c=85;s.iat_c=25;s.battery_v=14;s.sensor_v=5;s.lambda=1.1;s.synced=s.phase_synced=s.sensors_valid=s.lambda_ready=true;s.sampled_us=1000000;Controller ctrl;auto o=ctrl.step(t,s,s.sampled_us);assert(!o.faults&&!o.fuel_cut&&!o.spark_cut);
 double fl=coordinate(c.fuel_source,c),sl=coordinate(c.spark_source,c),ll=coordinate(c.lambda_source,c),tl=coordinate(c.trim_source,c);double ve=20+.03*fl+.001*s.rpm,target=.9+.00005*ll+.000005*s.rpm,advance=8+.01*sl+.0005*s.rpm;
 assert(near(o.ve_pct,ve)&&near(o.target_lambda,target)&&near(o.advance_deg,advance));assert(near(o.load_model.values[l::FuelLoad],fl)&&near(o.load_model.values[l::SparkLoad],sl));
 double pf=pressure==0?1:pressure==1?s.map_kpa/100:s.map_kpa/c.fixed_baro_kpa;double air=100000*(t.displacement_cc/t.cylinders*1e-6)*(ve/100)/(287.05*(s.iat_c+273.15))*1e6*pf;double af=afr==0?1:afr==1?1/target:s.lambda/target;double flow=t.injector_cc_min*t.fuel_density_g_cc/60;double openings=trims?1:2;double effective=air/t.stoich_afr*af/(openings*flow);assert(near(o.air_mg,air)&&near(o.pulse_ms,effective+o.deadtime_ms));
 for(unsigned n=0;n<4;++n){double ft=trims?95+n+.002*tl:100;assert(near(o.cylinder_fuel_pct[n],ft)&&near(o.cylinder_pulse_ms[n],effective*ft/100+o.deadtime_ms));double sa=advance+(trims?float(n)-1.5f:0);assert(near(o.cylinder_advance_deg[n],sa));}++cases;
 }std::cout<<"Independent affine-surface/source/pressure/AFR/trim composition cases="<<cases<<" passed\n";
}
