// Native execution adapter for the pinned production Speeduino ECU.
// The adapter supplies configuration and virtual pins. Engine algorithms stay
// in the external GPL source; this executable never opens hardware devices.
#include "FakeMega.h"
#include "globals.h"
#include "storage.h"
#include "pages.h"
#include "sensors.h"
#include "load_source.h"
#include "fuel_calcs.h"
#include "secondaryTables.h"
#include "corrections.h"
#include "decoders.h"
#include "decoder_init.h"
#include "timers.h"
#include "init.h"
#include "logger.h"
#include "scheduler_fuel_controller.h"
#include "scheduler_ignition_controller.h"
#include "units.h"
#include "src/controllers/idle/idle.h"
#include <SimpleArduinoFake.h>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <limits.h>

extern void setup();
extern void loop();
extern "C" uint64_t speeduino_sim_micros();
extern "C" void speeduino_sim_advance(uint64_t);
namespace {
std::stringstream& serial_stream() { static auto* value = new std::stringstream; return *value; }
struct EarlySetup { EarlySetup() { fakeMega(serial_stream(), serial_stream()); } };
EarlySetup early_setup __attribute__((init_priority(65534)));
int adc[256]{};
int pins[256]{};
void (*interrupts_by_pin[256])(){};
int interrupt_modes[256]{};
std::string log_kind="none";
bool record_edges = false;
bool use_per_tooth = false;
bool logger_cam = false;
bool sequential_profile = false;
bool semi_sequential_profile = false;
bool idle_profile=false,idle_high=false;
bool ae_profile=false;
volatile uint8_t* output_ports[8]{};
uint8_t output_masks[8]{};
uint8_t output_pins[8]{};
bool output_high[8]{};
void prepare_hal() {
    using namespace fakeit;
    auto& mock = SimpleArduinoFake::getContext()._Function;
    When(Method(mock, micros)).AlwaysDo([]() -> unsigned long { return uint32_t(speeduino_sim_micros()); });
    When(Method(mock, millis)).AlwaysDo([]() -> unsigned long { return uint32_t(speeduino_sim_micros()/1000); });
    When(Method(mock, delay)).AlwaysDo([](unsigned long ms) { speeduino_sim_advance(speeduino_sim_micros()+ms*1000); });
    When(Method(mock, delayMicroseconds)).AlwaysDo([](unsigned int us) { speeduino_sim_advance(speeduino_sim_micros()+us); });
    When(Method(mock, analogRead)).AlwaysDo([](uint8_t pin) { return adc[pin]; });
    When(Method(mock, digitalRead)).AlwaysDo([](uint8_t pin) { return pins[pin]; });
    When(Method(mock, digitalWrite)).AlwaysDo([](uint8_t pin, uint8_t value) {
        pins[pin] = value;
        auto port=portOutputRegister(digitalPinToPort(pin));auto mask=digitalPinToBitMask(pin);
        if(value) *port |= mask; else *port &= ~mask;
    });
    When(Method(mock, attachInterrupt)).AlwaysDo([](uint8_t pin, void (*cb)(), int mode) { interrupts_by_pin[pin] = cb;interrupt_modes[pin]=mode; });
    When(Method(mock, detachInterrupt)).AlwaysDo([](uint8_t pin) { interrupts_by_pin[pin] = nullptr; });
}
void configure() {
    setStorageAPI(getBoardStorageApi());
    setTuneToEmpty();
    configPage2.pinMapping = 3;
    configPage2.nCylinders = 4;
    configPage2.nInjectors = 4;
    configPage2.strokes = FOUR_STROKE;
    configPage2.injType = INJ_TYPE_PORT;
    configPage2.injLayout = (logger_cam||sequential_profile)?INJ_SEQUENTIAL:INJ_SEMISEQUENTIAL;
    configPage2.divider = 2;
    configPage2.injTiming = (sequential_profile||semi_sequential_profile)?1:0;
    if(sequential_profile||semi_sequential_profile){for(unsigned n=0;n<4;++n){configPage2.injAng[n]=sequential_profile?540:180;configPage2.injAngRPM[n]=5+20*n;}}
    if(semi_sequential_profile)configPage4.inj4cylPairing=INJ_PAIR_13_24;
    configPage2.reqFuel = 107; // 2L/4cyl,300cc/min,14.7 AFR,25C rounded to0.1ms
    configPage2.injOpen = 9;
    configPage2.multiplyMAP = MULTIPLY_MAP_MODE_100;
    configPage2.fuelAlgorithm = LOAD_SOURCE_MAP;
    configPage2.perToothIgn = use_per_tooth;
    configPage2.ignAlgorithm = LOAD_SOURCE_MAP;
    configPage2.dutyLim = 80;
    configPage2.stoich = 147;
    configPage2.tpsMin = 0; configPage2.tpsMax = 255;
    configPage2.mapMin = 0; configPage2.mapMax = 200;
    configPage2.baroMin = 0; configPage2.baroMax = 200;
    configPage2.fpPrime = 2;
    configPage2.taeThresh = 255; configPage2.maeThresh = 255;
    configPage4.TrigPattern = DECODER_MISSING_TOOTH;
    configPage4.triggerTeeth = 60; configPage4.triggerMissingTeeth = 2;
    configPage4.triggerAngle = -90;
    configPage4.crankRPM = 45;
    configPage4.CrankAng = 5;
    configPage4.sparkMode = sequential_profile?IGN_MODE_SEQUENTIAL:IGN_MODE_WASTEDCOP;
    configPage4.TrigSpeed=CRANK_SPEED;configPage4.trigPatternSec=SEC_TRIGGER_SINGLE;
    configPage4.IgInv = 0; // virtual active-high charging
    configPage4.dwellRun = 28; configPage4.dwellCrank = 28;
    configPage4.useDwellLim = 1; configPage4.dwellLimit = 4;
    configPage4.sparkDur = 10;
    configPage4.floodClear = 95;
    configPage4.HardRevLim = 65; configPage4.SoftRevLim = 62;
    configPage4.engineProtectMaxRPM = 65;
    configPage6.engineProtectType = PROTECT_CUT_BOTH;
    configPage9.hardRevMode = HARD_REV_FIXED;
    configPage2.SoftLimitMode = SOFT_LIMIT_RELATIVE;
    configPage4.SoftLimRetard = 10;configPage4.SoftLimMax = 255;
    for (unsigned n = 0; n < 10; ++n) { configPage4.wueBins[n] = n*20; configPage2.wueValues[n] = 100; }
    for (unsigned n = 0; n < 6; ++n) {
        configPage6.voltageCorrectionBins[n] = 80+n*20;
        configPage6.injVoltageCorrectionValues[n] = 100;
        configPage4.dwellCorrectionValues[n] = 100;
        configPage4.iatRetBins[n] = n*40;
        configPage4.cltAdvBins[n] = n*40; configPage4.cltAdvValues[n] = 15;
    }
    for (unsigned n = 0; n < 9; ++n) { configPage6.airDenBins[n] = n*25; configPage6.airDenRates[n] = 100; }
    for (unsigned n = 0; n < 8; ++n) { configPage4.baroFuelBins[n] = 30+n*20; configPage4.baroFuelValues[n] = 100; }
    for (unsigned n = 0; n < 4; ++n) {
        configPage10.crankingEnrichBins[n] = n*60;
        configPage10.crankingEnrichValues[n] = 20; // stored in5% units
        configPage2.aseBins[n] = n*60;
    }
    for (unsigned n = 0; n < 32; ++n) {
        cltCalibrationTable.axis[n] = iatCalibrationTable.axis[n] = o2CalibrationTable.axis[n] = n*33;
        cltCalibrationTable.values[n] = iatCalibrationTable.values[n] = std::min(255u,n*8);
        o2CalibrationTable.values[n] = std::min(255u,80+n*5);
    }
    for (unsigned n = 0; n < 16; ++n) {
        fuelTable.axisX[n] = ignitionTable.axisX[n] = afrTable.axisX[n] = (n+1)*5;
        fuelTable.axisY[n] = ignitionTable.axisY[n] = afrTable.axisY[n] = (n+1)*8;
    }
    fuelTable.values.fill(85);
    ignitionTable.values.fill(40+10);
    afrTable.values.fill(147);
    // Persist through the real storage API, then let unmodified setup load it.
    saveEEPROMVersion(27);
    do { saveAllPages(); } while (isEepromWritePending());
    saveAllCalibrationTables();
    saveLastBaro(100);
}
void set_sensors(double map, double tps, double clt, double iat, double battery, double afr) {
    adc[pinNumbers.pinMAP] = std::lround(map/200*1024);
    adc[pinNumbers.pinTPS] = std::lround(tps/100*1023);
    adc[pinNumbers.pinCLT] = std::lround((clt+40)*33/8);
    adc[pinNumbers.pinIAT] = std::lround((iat+40)*33/8);
    adc[pinNumbers.pinBat] = std::lround(battery*10/245*1024);
    adc[pinNumbers.pinO2] = std::lround((afr*10-80)*33/5);
}
void status() {
    std::cout << "status " << speeduino_sim_micros() << ' ' << currentStatus.RPM << ' '
              << fuelSchedule1.pw << ' ' << int(currentStatus.advance) << ' '
              << currentStatus.MAP << ' ' << unsigned(currentStatus.VE) << ' '
              << unsigned(currentStatus.corrections) << ' ' << currentStatus.coolant << ' '
              << currentStatus.IAT << ' ' << unsigned(currentStatus.battery10) << ' '
              << unsigned(currentStatus.decoder.getStatus().syncStatus) << ' '
              << unsigned(currentStatus.schedulerCutState.fuelChannels) << ' '
              << unsigned(currentStatus.schedulerCutState.ignitionChannels) << ' '
              << unsigned(currentStatus.softLimitActive) << '\n';
    std::cout << "diagnostic " << unsigned(fuelSchedule1._status) << ' ' << fuelSchedule1._counter.load() << ' ' << fuelSchedule1._compare.load() << ' ' << currentStatus.decoder.getCrankAngle() << ' '
              << unsigned(currentStatus.schedulerCutState.fuelChannels) << ' ' << unsigned(currentStatus.schedulerCutState.ignitionChannels) << ' '
              << unsigned(ignitionSchedule1._status) << ' ' << currentStatus.dwell << ' ' << CRANK_ANGLE_MAX_IGN << ' ' << CRANK_ANGLE_MAX_INJ << ' ' << unsigned(currentStatus.nSquirts) << '\n';
}
}
extern "C" void speeduino_sim_observe() {
    if (!record_edges) return;
    for(unsigned n=0;n<8;++n) {
        bool high=(*output_ports[n]&output_masks[n]) != 0;
        if(high!=output_high[n]) {
            output_high[n]=high;
            std::cout << "edge " << speeduino_sim_micros() << ' ' << unsigned(output_pins[n]) << ' ' << unsigned(high) << ' ' << unsigned(currentStatus.decoder.getStatus().syncStatus) << ' ' << CRANK_ANGLE_MAX_IGN << '\n';
        }
    }
    if(idle_profile){
        const bool high=(*portOutputRegister(digitalPinToPort(pinNumbers.pinIdle1))&digitalPinToBitMask(pinNumbers.pinIdle1))!=0;
        if(high!=idle_high){idle_high=high;std::cout<<"edge "<<speeduino_sim_micros()<<' '<<unsigned(pinNumbers.pinIdle1)<<' '<<unsigned(high)<<" 0 0\n";}
    }
}

int main(){
 setenv("GCOV_PREFIX","/home/mark/persospace/esp32-ecu/.cache/engine/load-architecture-review/gcov",1);
 prepare_hal();configure();setPinMapping(3);set_sensors(100,0,85,25,14,14.7);setup();
 statuses current=currentStatus;current.RPM=1000;current.revolutionTime=60000;current.nSquirts=2;current.injLayout=INJ_SEMISEQUENTIAL;current.rotationStatus=EngineRotationStatus::Running;current.VE=100;current.corrections=100;current.batCorrection=100;current.O2=160;current.afrTarget=177;current.runSecs=10;
 std::cout<<"kind,MAP,TPS_raw_halfpercent,EMAP,baro,map_load,tps_load,ratio_load,pressure_mode,includeAFR,incorporateAFR,egoType,runSecs,target,pulse_us,secondary_ve\n";
 for(unsigned map:{50,100})for(unsigned tps:{20,100})for(unsigned emap:{80,200}){
  current.MAP=map;current.TPS=tps;current.EMAP=emap;current.baro=80;
  std::cout<<"coordinate,"<<map<<','<<tps<<','<<emap<<",80,"<<getLoad(LOAD_SOURCE_MAP,current)<<','<<getLoad(LOAD_SOURCE_TPS,current)<<','<<getLoad(LOAD_SOURCE_IMAPEMAP,current)<<",,,,,,,,\n";
 }
 auto p2=configPage2;auto p6=configPage6;auto p10=configPage10;p2.reqFuel=100;p2.injOpen=9;p2.dutyLim=80;p2.stoich=147;p6.ego_sdelay=5;
 afrTable.values.fill(120);current.MAP=50;current.TPS=100;current.EMAP=200;current.baro=80;
 for(unsigned pressure:{0,1,2})for(unsigned afrcase:{0,1,2,3,4,5}){
  p2.multiplyMAP=pressure;p2.includeAFR=afrcase>=2&&afrcase!=5;p2.incorporateAFR=afrcase==1||afrcase==3||afrcase==4;p6.egoType=afrcase==0||afrcase==1||afrcase==4?EGO_TYPE_OFF:EGO_TYPE_WIDE;current.runSecs=afrcase==5?0:10;current.afrTarget=177;current.fuelLoad=getLoad(LOAD_SOURCE_TPS,current);
  current.afrTarget=calculateAfrTarget(afrTable,current,p2,p6);auto pw=computePulseWidths(p2,p6,p10,current);
  std::cout<<"pulse,50,100,200,80,50,200,25,"<<pressure<<','<<unsigned(p2.includeAFR)<<','<<unsigned(p2.incorporateAFR)<<','<<unsigned(p6.egoType)<<','<<unsigned(current.runSecs)<<','<<unsigned(current.afrTarget)<<','<<pw.primary<<",\n";
 }
 for(unsigned mode:{0,1,2,3,4})for(unsigned rpm:{1000,1001}){
  p10.fuel2Mode=mode;p10.fuel2Algorithm=LOAD_SOURCE_TPS;p10.fuel2SwitchVariable=FUEL2_CONDITION_RPM;p10.fuel2SwitchValue=1000;p10.fuel2InputPolarity=1;pinNumbers.pinFuel2Input=25;pins[25]=1;fuelTable2.values.fill(50);current.RPM=rpm;current.VE1=current.VE=85;current.fuelLoad=50;
  calculateSecondaryFuel(p10,fuelTable2,current);
  std::cout<<"secondary_mode"<<mode<<"_rpm"<<rpm<<",50,100,200,80,50,200,25,,,,,,,,"<<unsigned(current.VE)<<'\n';
 }
 for(unsigned row=0;row<16;++row)for(unsigned col=0;col<16;++col)afrTable.values[row*16+col]=100+3*row;
 invalidate_cache(&afrTable.get_value_cache);p2.includeAFR=0;p2.incorporateAFR=1;p6.egoType=EGO_TYPE_OFF;current.RPM=1000;current.fuelLoad=50;current.VE1=current.VE=85;p10.fuel2Mode=FUEL2_MODE_INPUT_SWITCH;
 const auto before=calculateAfrTarget(afrTable,current,p2,p6);calculateSecondaryFuel(p10,fuelTable2,current);const auto after=calculateAfrTarget(afrTable,current,p2,p6);
 std::cout<<"lambda_before_secondary,50,100,200,80,50,200,25,0,0,1,0,10,"<<unsigned(before)<<",,"<<unsigned(current.VE)<<'\n';
 std::cout<<"lambda_after_secondary,50,100,200,80,50,200,25,0,0,1,0,10,"<<unsigned(after)<<",,"<<unsigned(current.VE)<<'\n';
 current.fuelLoad=200;const auto other=calculateAfrTarget(afrTable,current,p2,p6);std::cout<<"lambda_secondary_as_primary,50,100,200,80,50,200,25,0,0,1,0,10,"<<unsigned(other)<<",,"<<unsigned(current.VE)<<'\n';
 if(before!=after||before==other)return 2;

}
