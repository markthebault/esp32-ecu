"""Rebuild/read immutable1d6a9ac oracles. All outputs remain in this cache directory."""
import csv,hashlib,io,json,os,shlex,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
CXX=shlex.split(os.environ.get('CXX','c++'));CC=shlex.split(os.environ.get('CC','cc'))
FLAGS=['-std=c++17','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-I'+str(OUT/'baseline-source/firmware/include')]
commands=[CC+['-O2','-c',str(OUT/'vendor/cJSON/cJSON.c'),'-o',str(OUT/'vendor/cJSON/cJSON.o')],CXX+FLAGS+[str(OUT/'baseline_oracle.cpp'),'-o',str(OUT/'baseline_oracle')],CXX+FLAGS+['-I'+str(OUT/'vendor/cJSON'),str(OUT/'baseline_validate.cpp'),str(OUT/'vendor/cJSON/cJSON.o'),'-o',str(OUT/'baseline_validate')]]
for command in commands:subprocess.run(command,check=True)
golden=subprocess.check_output([str(OUT/'baseline_oracle')]);assert golden==(OUT/'baseline-golden.csv').read_bytes()
assert subprocess.check_output([str(OUT/'baseline_oracle')])==golden
assert subprocess.check_output([str(OUT/'baseline_oracle'),'inputs'])==(OUT/'baseline-input-oracle.csv').read_bytes()
invalid=json.loads((OUT/'baseline-invalid-oracle.json').read_text())
for case in invalid['json_cases']:
 path=OUT/'invalid-oracle-cases'/(case['case']+'.json')
 assert hashlib.sha256(path.read_bytes()).hexdigest()==case['sha256']
 actual=subprocess.check_output([str(OUT/'baseline_validate'),str(path)],text=True).strip();assert actual==case['expected'],(case['case'],actual)
result={'baseline_commit':invalid['baseline_commit'],'golden_cases':len(list(csv.DictReader(io.StringIO(golden.decode())))),'input_cases':invalid['input_case_count'],'json_contract_cases':len(invalid['json_cases']),'golden_sha256':hashlib.sha256(golden).hexdigest(),'commands':commands,'status':'pass'}
(OUT/'verify-baseline-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2))
