// Cache-only oracle. Compiles only against frozen1d6a9ac headers.
#include "ecu/engine.hpp"
#include "ecu/engine_data.hpp"
#include "ecu/engine_log.hpp"
#include "ecu/tuning_session.hpp"
#include <iomanip>
#include <iostream>
int main(int argc,char**argv){
 using namespace ecu::engine;
 if(argc>1&&std::strcmp(argv[1],"sizes")==0){std::cout<<"{\"Tune\":"<<sizeof(Tune)<<",\"Inputs\":"<<sizeof(Inputs)<<",\"Output\":"<<sizeof(Output)<<",\"RuntimeSample\":"<<sizeof(RuntimeSample)<<",\"Recorder\":"<<sizeof(ecu::engine_log::Recorder)<<",\"Session\":"<<sizeof(ecu::tuning::Session)<<",\"page_bytes\":"<<ecu::tuning::page_bytes<<",\"live_bytes\":"<<ecu::tuning::live_bytes<<"}\n";return 0;}
 if(argc>1&&std::strcmp(argv[1],"inputs")==0){
  Tune t;t.afterstart_pct=0;t.dfco_enabled=false;t.accel_gain=0;
  Inputs good;good.rpm=1000;good.map_kpa=45;good.tps_pct=10;good.clt_c=85;good.iat_c=25;good.lambda=1;good.battery_v=14;good.sensor_v=5;good.sampled_us=2000000;good.synced=good.phase_synced=good.sensors_valid=true;
  std::cout<<"case,state,faults,fuel_cut,spark_cut,pulse_ms\n";
  auto run=[&](const char*name,Inputs input){Controller c;auto o=c.step(t,input,2000000);std::cout<<name<<','<<unsigned(o.state)<<','<<o.faults<<','<<o.fuel_cut<<','<<o.spark_cut<<','<<std::setprecision(17)<<o.pulse_ms<<'\n';};
  run("valid",good);
  struct Field {const char*name;double Inputs::*p;double low,high;};
  const Field fields[]={{"map_kpa",&Inputs::map_kpa,10,110},{"tps_pct",&Inputs::tps_pct,0,100},{"clt_c",&Inputs::clt_c,-40,140},{"iat_c",&Inputs::iat_c,-40,110},{"battery_v",&Inputs::battery_v,7,18},{"sensor_v",&Inputs::sensor_v,4.75,5.25}};
  for(auto f:fields)for(unsigned mode=0;mode<6;++mode){Inputs input=good;input.*(f.p)=mode==0?f.low:mode==1?f.high:mode==2?f.low-.001:mode==3?f.high+.001:mode==4?NAN:INFINITY;std::string name=std::string(f.name)+std::to_string(mode);run(name.c_str(),input);}
  for(unsigned age:{0,20000,20001}){Inputs input=good;input.sampled_us-=age;std::string name="age_"+std::to_string(age);run(name.c_str(),input);}
  Inputs input=good;input.sampled_us+=1;run("future_sample",input);input=good;input.sensors_valid=false;run("unqualified",input);input=good;input.synced=false;run("unsynced",input);input=good;input.clt_c=115;run("overtemp115",input);return 0;
 }
 std::cout<<std::setprecision(17)<<"strategy,map_kpa,tps_pct,iat_c,rpm,trim_enabled,state,faults,ve_pct,target_lambda,advance_deg,air_mg,pulse_ms,deadtime_ms,duty_pct,pulse1,pulse2,pulse3,pulse4,advance1,advance2,advance3,advance4\n";
 unsigned count=0;
 for(auto strategy:{Strategy::BatchWasted,Strategy::Sequential,Strategy::SemiSequential})for(double map:{10.,45.,90.,110.})for(double tps:{0.,50.,100.})for(double iat:{0.,25.,60.})for(double rpm:{900.,2500.,6000.}){
  Tune t;t.strategy=strategy;t.afterstart_pct=0;t.accel_gain=0;t.dfco_enabled=false;t.ego_enabled=false;t.cylinder_trims_enabled=strategy==Strategy::Sequential;
  for(unsigned row=0;row<16;++row)for(unsigned col=0;col<16;++col){auto i=row*16+col;t.ve.cells[i]=50.f+2.f*row+.7f*col;t.spark.cells[i]=10.f+.5f*row+.2f*col;t.lambda.cells[i]=.9f+.005f*row+.001f*col;}
  for(unsigned c=0;c<4;++c){t.cylinder_spark_deg[c]=float(c)-1.5f;for(unsigned row=0;row<6;++row)for(unsigned col=0;col<6;++col)t.cylinder_fuel[c].cells[row*6+col]=85.f+5.f*c+.5f*row+.2f*col;}
  if(const char*error=validate(t)){std::cerr<<error<<'\n';return 2;}
  Inputs s;s.map_kpa=map;s.tps_pct=tps;s.iat_c=iat;s.rpm=rpm;s.clt_c=85;s.battery_v=14;s.sensor_v=5;s.sampled_us=2000000;s.synced=s.phase_synced=s.sensors_valid=true;s.lambda_ready=false;
  Controller controller;auto o=controller.step(t,s,s.sampled_us);
  if(o.faults||o.fuel_cut||o.spark_cut||!std::isfinite(o.pulse_ms)||!std::isfinite(o.air_mg)){std::cerr<<"Unexpected invalid golden case "<<count<<'\n';return 3;}
  std::cout<<unsigned(strategy)<<','<<map<<','<<tps<<','<<iat<<','<<rpm<<','<<t.cylinder_trims_enabled<<','<<unsigned(o.state)<<','<<o.faults<<','<<o.ve_pct<<','<<o.target_lambda<<','<<o.advance_deg<<','<<o.air_mg<<','<<o.pulse_ms<<','<<o.deadtime_ms<<','<<o.duty_pct;
  for(double v:o.cylinder_pulse_ms)std::cout<<','<<v;for(double v:o.cylinder_advance_deg)std::cout<<','<<v;std::cout<<'\n';++count;
 }
 return count==324?0:4;
}
