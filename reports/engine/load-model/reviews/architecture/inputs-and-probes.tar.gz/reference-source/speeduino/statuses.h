/**
 * @file
 * 
 * @brief The statuses struct and related defines. 
 * 
 */

#pragma once

#include <stdint.h>
#include "bit_manip.h"
#include "maths.h"
#include "decoder_t.h"

// Forward declares
struct config4;

using byte = uint8_t;

constexpr uint8_t BIT_TIMER_1HZ = 0;
constexpr uint8_t BIT_TIMER_4HZ = 1;
constexpr uint8_t BIT_TIMER_10HZ = 2;
constexpr uint8_t BIT_TIMER_15HZ = 3;
constexpr uint8_t BIT_TIMER_30HZ = 4;
constexpr uint8_t BIT_TIMER_50HZ = 5;
constexpr uint8_t BIT_TIMER_200HZ = 6;
constexpr uint8_t BIT_TIMER_1KHZ = 7;

/** @brief The current status of scheduler channel cuts */
enum class SchedulerCutStatus : uint8_t
{
  /** No cuts are in effect */
  None, 
  /** Rolling cut is in effect. */
  Rolling, 
  /** Full cut is applied. */
  Full, 
};


/** @brief The engine rotation status */
enum class EngineRotationStatus : uint8_t
{
  /** Not rotating */
  Stopped, 
  /** Rotating below the cranking threshold. */
  Cranking, 
  /** Rotating above the cranking threshold. */
  Running, 
};

struct vvtStatus_t
{
  bool angleError : 1;  ///< Is the cam angle within limits (false) or not (true)
  int16_t angle = 0;        ///< Measured cam angle
  uint8_t targetAngle = 0;  ///< Target angle
  uint8_t duty = 0;         ///< PWM duty

  vvtStatus_t()
  : angleError(false)
  {
  }
};

struct num_injector_t
{
  uint8_t primary : 4; /**< Number of primary injection outputs */
  uint8_t secondary : 4; /**< Number of secondary injection outputs (staged injection only)*/

  uint8_t getTotalInjectors(void) const
  {
    return primary + secondary;
  }
  bool isPrimaryInjector(uint8_t channel) const
  {
    return channel>0 && channel<=primary;
  }
  bool isSecondaryInjector(uint8_t channel) const
  {
    return channel>primary && channel<=getTotalInjectors();
  }
};

struct airConStatus_t
{
  bool acRequested : 1; ///< Indicates whether the A/C button is pressed
  bool compressorOn : 1; ///< Indicates whether the A/C compressor is running
  bool rpmLockoutActive : 1; ///< Indicates the A/C is locked out due to the RPM being too high/low, or the post-high/post-low-RPM "stand-down" lockout period
  bool tpsLockoutActive : 1; ///< Indicates the A/C is locked out due to high TPS, or the post-high-TPS "stand-down" lockout period
  bool turningOn : 1;  ///< Indicates the A/C request is on (i.e. A/C button pressed), the lockouts are off, however the start delay has not yet elapsed. This gives the idle up time to kick in before the compressor.
  bool cltLockoutActive : 1;  ///< Indicates the A/C is locked out either due to high coolant temp.
  bool fanOn : 1;  ///< Indicates whether the A/C fan is running

  bool isLockoutActive(void) const
  {
    return rpmLockoutActive
        || tpsLockoutActive
        || cltLockoutActive
        ;
  }
};

struct launchStatus_t
{
  bool launchingSoft : 1;
  bool launchingHard : 1;
  bool flatShiftingHard : 1;
  bool flatShiftingSoft : 1;
  bool previousClutchTrigger : 1;
  bool clutchTrigger : 1;
  uint16_t clutchEngagedRPM = 0; ///< The RPM at which the clutch was last depressed. Used for distinguishing between launch control and flat shift  

  launchStatus_t()
  : launchingSoft(false)
  , launchingHard(false)
  , flatShiftingHard(false)
  , flatShiftingSoft(false)
  , previousClutchTrigger(false)
  , clutchTrigger(false)
  {
  }
};

/** @brief The status struct with current values for all 'live' variables.
* 
* Instantiated as global currentStatus.
* 
* @note int *ADC (Analog-to-digital value / count) values contain the "raw" value from AD conversion, which get converted to
* unit based values in similar variable(s) without ADC part in name (see sensors.ino for reading of sensors).
*/
struct statuses {
  /** @brief Default construct */
  statuses(void);

#if defined(UNIT_TEST)
  /**
   * @brief Set the RPM field, keeping RPMDiv100 in sync.
   * 
   * @note Unit tests only. Firmware code must use setRevolutionTime(), so that RPM & revolutionTime remain consistent.
   * 
   * @param rpm 
   */
  void setRpm(uint16_t rpm);
#endif

  /**
   * @brief Set the crank revolution time & the values derived from it.
   *
   * This is the single point at which the engine speed is updated. It keeps the following in sync:
   * - revolutionTime
   * - RPM & RPMdiv100
   * - The crank angle<->time conversion factors (see setAngleConverterRevolutionTime())
   *
   * @param revTime The time in µS that one crank revolution takes at the current speed.
   * Zero means the engine speed is unknown (E.g. the engine has stopped): RPM will be zero and the
   * angle<->time conversion factors are left unchanged.
   */
  void setRevolutionTime(uint32_t revTime);

  bool isFixedCrankingIgnitionTimingActive(const config4 &page4) const;

  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool initialisationComplete : 1; ///< Tracks whether the setup() function has run completely
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  volatile bool injPrimed : 1; ///< Tracks whether or not the injector priming has been completed yet
    
  uint16_t RPM;   ///< RPM - Current Revs per minute
  byte RPMdiv100; ///< RPM value scaled (divided by 100) to fit a byte (0-255, e.g. 12000 => 120)
  uint16_t baroADC;
  uint16_t MAP;     ///< Manifold absolute pressure.
  uint16_t EMAP; ///< EMAP ... (See @ref config6.useEMAP for EMAP enablement)
  uint8_t baro;   ///< Barometric pressure is simply the initial MAP reading, taken before the engine is running. Alternatively, can be taken from an external sensor
  uint8_t TPS;    /**< The current TPS reading (0% - 100%). Is the tpsADC value after the calibration is applied */
  uint8_t tpsADC; /**< byte (valued: 0-255) representation of the TPS. Downsampled from the original 10-bit (0-1023) reading, but before any calibration is applied */
  int16_t tpsDOT; /**< TPS delta over time. Measures the % per second that the TPS is changing. Note that is signed value, because TPSdot can be also negative */
  byte TPSlast; /**< The previous TPS reading */
  int16_t mapDOT; /**< MAP delta over time. Measures the kpa per second that the MAP is changing. Note that is signed value, because MAPdot can be also negative */
  volatile int rpmDOT; /**< RPM delta over time (RPM increase / s ?) */
  byte VE;     /**< The current VE value being used in the fuel calculation. Can be the same as VE1 or VE2, or a calculated value of both. */
  byte VE1;    /**< The VE value from fuel table 1 */
  byte VE2;    /**< The VE value from fuel table 2, if in use (and required conditions are met) */
  uint8_t O2;     /**< Primary O2 sensor reading */
  uint8_t O2_2;   /**< Secondary O2 sensor reading */
  int coolant; /**< Coolant temperature reading */
  uint16_t cltADC;
  int IAT;     /**< Inlet air temperature reading */
  uint16_t iatADC;
  uint16_t O2ADC;
  uint16_t O2_2ADC;
  uint16_t dwell;          ///< dwell (coil primary winding/circuit on) time (in ms * 10 ? See @ref correctionsDwell)
  volatile uint16_t actualDwell;    ///< actual dwell time if new ignition mode is used (in uS)
  byte dwellCorrection; /**< The amount of correction being applied to the dwell time (in unit ...). */
  byte battery10;     /**< The current BRV in volts (multiplied by 10. Eg 12.5V = 125) */
  int8_t advance;     /**< The current advance value being used in the spark calculation. Can be the same as advance1 or advance2, or a calculated value of both */
  int8_t advance1;    /**< The advance value from ignition table 1 */
  int8_t advance2;    /**< The advance value from ignition table 2 */
  uint16_t corrections; /**< The total current corrections % amount */
  uint16_t AEamount;    /**< The amount of acceleration enrichment currently being applied. 100=No change. Varies above 255 */
  byte egoCorrection; /**< The amount of closed loop AFR enrichment currently being applied */
  byte wueCorrection; /**< The amount of warmup enrichment currently being applied */
  byte batCorrection; /**< The amount of battery voltage enrichment currently being applied */
  byte iatCorrection; /**< The amount of inlet air temperature adjustment currently being applied */
  byte baroCorrection; /**< The amount of correction being applied for the current baro reading */
  byte launchCorrection;   /**< The amount of correction being applied if launch control is active */
  byte flexCorrection;     /**< Amount of correction being applied to compensate for ethanol content */
  byte fuelTempCorrection; /**< Amount of correction being applied to compensate for fuel temperature */
  int8_t flexIgnCorrection;/**< Amount of additional advance being applied based on flex. Note the type as this allows for negative values */
  byte afrTarget;    /**< Current AFR Target looked up from AFR target table (x10 ? See @ref afrTable)*/
  byte CLIdleTarget; /**< The target idle RPM (when closed loop idle control is active) */
  bool idleUpActive; /**< Whether the externally controlled idle up is currently active */
  bool CTPSActive;   /**< Whether the externally controlled closed throttle position sensor is currently active */
  volatile byte ethanolPct; /**< Ethanol reading (if enabled). 0 = No ethanol, 100 = pure ethanol. Eg E85 = 85. */
  volatile int8_t fuelTemp;
  unsigned long AEStartTime; /**< The time (µS) at which AE (acceleration enrichment) was last turned on. AE ends once aeTime has elapsed from this point */

  // Status1 fields as defined in the INI
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool isDFCOActive : 1;  ///< Deceleration Fuel Cut Off status: true == active, false == inactive
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  volatile bool isToothLog1Full : 1; ///< Boost Cut status: true == active, false == inactive

  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool softLimitActive : 1; ///< Soft limit status: true == on, false == off 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool idleOn : 1; ///< Is the idle code active : true == active, false == inactive

  // Status3 fields as defined in the INI.   
  // TODO: resolve duplication with nitrous_status
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool nitrousActive : 1; ///< Nitrous on (true) or off (false)
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool secondFuelTableActive : 1; ///< Secondary fuel table is use (true) or not (false)
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool vssUiRefresh : 1; ///< Flag to indicate that the VSS value needs to be refreshed in the UI 

  // Status4 fields as defined in the INI.   
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool wmiTankEmpty : 1; ///< Is the Water Methanol Injection tank empty (true) or not (false) 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool burnPending : 1;  ///< Is an EEPROM burn pending (true) or not (false) 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool stagingActive : 1; ///< Is fuel injection staging active (true) or not (false) 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool commCompat : 1; ///< 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool allowLegacyComms : 1; ///< 

  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool secondSparkTableActive : 1; ///< Secondary spark table is use (true) or not (false)
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool knockRetardActive : 1; ///< Is knock retardation active (true) or not (false) 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool knockPulseDetected : 1;  ///<

  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool aseIsActive : 1; ///< Is After Start Enrichment (ASE) active (true) or not (false) 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool wueIsActive : 1; ///< Is Warm Up Enrichment (WUE) active (true) or not (false) 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  // TODO: acceleration has 3 states: Steady, Accelerating, Decelerating. Need to capture this better 
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool isAcceleratingTPS : 1;  ///< Are we accelerating (true) or not (false), based on TPS
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool isDeceleratingTPS : 1; ///< Are we decelerating (true) or not (false), based on TPS
  EngineRotationStatus rotationStatus;
  
  volatile byte runSecs; /**< Counter of seconds since cranking commenced (Maxes out at 255 to prevent overflow) */
  volatile byte secl; /**< Counter incrementing once per second. Will overflow after 255 and begin again. This is used by TunerStudio to maintain comms sync */
  volatile uint16_t loopsPerSecond; /**< A performance indicator showing the number of main loops that are being executed each second */ 
  // TODO: remove this: only updated & read in logger
  uint16_t freeRAM;
  volatile uint32_t startRevolutions; /**< A counter for how many revolutions have been completed since sync was achieved. */
  uint16_t boostTarget;
  // TODO: resolve conflict with testActive
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool isTestModeActive : 1; // Is hardware test mode on?
  bool testActive;    // Not in use ? Replaced by testOutputs ?
  uint16_t boostDuty; ///< Boost Duty percentage value * 100 to give 2 points of precision
  byte idleLoad;      ///< Either the current steps or current duty cycle for the idle control
  uint16_t canin[16]; ///< 16bit raw value of selected canin data for channels 0-15
  uint16_t crankRPM = 400; /**< The actual cranking RPM limit. This is derived from the value in the config page, but saves us multiplying it every time it's used (Config page value is stored divided by 10) */
  int16_t flexBoostCorrection; /**< Amount of boost added based on flex */
  byte nitrous_status;
  byte nSquirts;  ///< Number of injector squirts per cycle (per injector)
  uint16_t fuelLoad;
  uint16_t ignLoad;
  volatile byte syncLossCounter;
  byte knockRetard;
  volatile byte knockCount;
  bool toothLogEnabled;
  byte compositeTriggerUsed; // 0 means composite logger disabled, 2 means use secondary input (1st cam), 3 means use tertiary input (2nd cam), 4 means log both cams together
  uint16_t injAngle;
  byte ASEValue;
  uint16_t vss;      /**< Current speed reading. Natively stored in kph and converted to mph in TS if required */
  byte gear;         /**< Current gear (Calculated from vss) */
  byte fuelPressure; /**< Fuel pressure in PSI */
  byte oilPressure;  /**< Oil pressure in PSI */

  /** @brief Engine protection status fields. */
  struct engine_protect_flags_t
  {
    // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
    bool rpm : 1; ///< true if RPM limits have been breached, false otherwise
    // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
    bool coolant : 1; ///< true if coolant limits have been breached, false otherwise
    // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
    bool boostCut : 1; ///< true if the boost limit has been breached, false otherwise
    // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
    bool oil : 1; ///< true if the oil limit has been breached, false otherwise
    // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
    bool afr : 1; ///< true if the afr limit has been breached, false otherwise

    /** @brief Are any protections active */
    // cppcheck-suppress misra-c2012-8.10 ; False positive - cannot make this static
    inline bool isActive(void) const {
      return rpm
            || coolant
            || boostCut
            || oil
            || afr
            ;
    }

    /** @brief Reset all protections to off */
    // cppcheck-suppress misra-c2012-8.10 ; False positive - cannot make this static
    inline void reset(void) {
      rpm = false;
      boostCut = false;
      oil = false;
      afr = false;
      coolant = false;
    }  
  };
  engine_protect_flags_t engineProtect;
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool ioError : 1; ///< true if there is an analog pin conflict

  byte fanDuty;
  byte wmiPW;

  // SD card status fields.
  // TODO: conditional compile on SD_LOGGING once board definition is separated from globals.h
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool sdCardPresent : 1; ///< true if a card is present, false if not
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  unsigned int sdCardType : 1; ///< 0==SD, 1==SDHC
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool sdCardReady : 1; ///< true if ready, false if not
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool sdCardLogging : 1; ///< true if logging active, false if not
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool sdCardError : 1;  ///< true if error, false if not
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  unsigned int sdCardFS : 1;  ///< File system type 0=no FAT16, 1=FAT32
  // cppcheck-suppress misra-c2012-6.1 ; False positive - MISRA C:2012 Rule (R 6.1) permits the use of boolean for bit fields.
  bool sdCardUnused : 1;  ///< true if unused, false if not

  airConStatus_t acStatus = {};
  
  uint8_t systemTemp;
  uint32_t revolutionTime; //The time in uS that one revolution would take at current speed (The time tooth 1 was last seen, minus the time it was seen prior to that). Zero if the speed is unknown

  uint8_t maxIgnOutputs; /**< Number of ignition outputs being used by the current tune configuration */
  uint8_t injLayout : 3; ///< Normally the same value as config2::injLayout, but under some situations will change to one of the other INJ_* constants
  num_injector_t injOutputs;
  
  /** @brief Fuel and ignition scheduler cut state. @see calculateFuelIgnitionChannelCut */
  struct scheduler_cut_t
  {
    // Using bytes for compactness ATM, but that limits us to 8 fuel and 
    // 8 ignition channels
    byte ignitionChannelsPending = 0; ///< Any ignition channels that are pending injections before they are resumed
    byte ignitionChannels = 0xFF; ///< Which ignition channels are on (1) or off (0)
    byte fuelChannels = 0xFF; ///< Which fuel channels are on (1) or off (0)
    SchedulerCutStatus status = SchedulerCutStatus::None;
  };
  scheduler_cut_t schedulerCutState;

  decoder_t decoder; ///< The current decoder

  uint8_t LOOP_TIMER; ///< The timer flags currently in effect

  vvtStatus_t vvt1;
  vvtStatus_t vvt2;

  launchStatus_t launchStatus;
};
