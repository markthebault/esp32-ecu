"""Cache-only own001..007 frozen import contract fixtures, not GUI acceptance."""
from pathlib import Path
import copy,hashlib,json,sys,xml.etree.ElementTree as ET
OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(OUT/'baseline-source/tools'))
import engine_msq as msq,engine_protocol as protocol
# All functions below are the frozen1d6a9ac import/export implementation.
base=protocol.DEFAULT;cases=[]
profiles=[(protocol.LEGACY_SIGNATURE,dict(legacy=True,sequential=False,whole=False,idle=False,transient=False)),(protocol.SEQUENTIAL_SIGNATURE,dict(legacy=False,sequential=True,whole=False,idle=False,transient=False)),(protocol.CYLINDER_SIGNATURE,dict(legacy=False,sequential=False,whole=False,idle=False,transient=False)),(protocol.WHOLE_SIGNATURE,dict(legacy=False,sequential=False,whole=True,idle=False,transient=False)),(protocol.IDLE_SIGNATURE,dict(legacy=False,sequential=False,whole=True,idle=True,transient=False)),(protocol.SEMI_SIGNATURE,dict(legacy=False,sequential=False,whole=True,idle=True,transient=False)),(protocol.SIGNATURE,dict(legacy=False,sequential=False,whole=True,idle=True,transient=True))]
for i,(signature,options) in enumerate(profiles,1):
 for variant in ['valid','ve0','ve120_001']:
  tune=copy.deepcopy(base)
  if variant=='ve0':tune['maps']['ve']['cells'][0]=0
  if variant=='ve120_001':tune['maps']['ve']['cells'][0]=120.001
  root=ET.Element(msq.tag('msq'));pages=1 if options['whole'] else 4 if options['legacy'] or options['sequential'] else 5
  ET.SubElement(root,msq.tag('versionInfo'),fileFormat='5.0',firmwareInfo='controlled frozen review fixture',nPages=str(pages),signature=signature.decode())
  elements={i:ET.SubElement(root,msq.tag('page'),number=str(i)) for i in range(pages)}
  for page,name,values,shape in msq.constants(tune,**options):
   e=ET.SubElement(elements[page],msq.tag('constant'),name=name)
   if shape:e.set('rows',str(shape[0]));e.set('cols',str(shape[1]))
   e.text=' '.join(str(v) for v in values)
  body=ET.tostring(root,encoding='utf-8',xml_declaration=True);name=f'own{i:03d}-{variant}';path=OUT/'legacy-msq-oracles'/(name+'.msq');path.parent.mkdir(exist_ok=True)
  if path.exists():assert path.read_bytes()==body
  else:path.write_bytes(body)
  try:
   result=msq.import_msq(body);actual='accepted';semantic={'schema':result['schema_version'],'strategy':result['strategy'],'ve0':result['maps']['ve']['cells'][0],'map_load':result['maps']['ve']['load'],'idle_enabled':result['settings']['idle_enabled'],'ae_mode':result['transient_enrichment']['mode']}
  except ValueError as e:actual='rejected';semantic={'reason':str(e)}
  expected='accepted' if variant=='valid' else 'rejected';assert actual==expected,(name,actual)
  cases.append({'case':name,'signature':signature.decode(),'actual':actual,'expected':expected,'sha256':hashlib.sha256(body).hexdigest(),'semantic':semantic})
report={'baseline_commit':'1d6a9acb34838ea175f2dfa7ccd9786e96d2d11b','scope':'Constructed signature-specific fixtures using frozen constants/import, validated with frozen native engine core; no TunerStudio GUI run','cases':cases,'status':'pass'}
(OUT/'baseline-msq-oracle.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'cases':len(cases),'status':'pass'},indent=2))
