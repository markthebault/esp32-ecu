"""Cache-only pinned load/target/PW oracle, production functions, no plant claim."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
source=subprocess.check_output(['git','show','1d6a9ac:tools/speeduino_sim.cpp'],cwd=ROOT,text=True)
source=source.replace('#include "sensors.h"','#include "sensors.h"\n#include "load_source.h"\n#include "fuel_calcs.h"\n#include "secondaryTables.h"\n#include "corrections.h"')
source=source[:source.index('int main(')]+r'''
int main(){
 setenv("GCOV_PREFIX","/home/mark/persospace/esp32-ecu/.cache/engine/load-architecture-review/gcov",1);
 prepare_hal();configure();setPinMapping(3);set_sensors(100,0,85,25,14,14.7);setup();
 statuses current=currentStatus;current.RPM=1000;current.revolutionTime=60000;current.nSquirts=2;current.injLayout=INJ_SEMISEQUENTIAL;current.rotationStatus=EngineRotationStatus::Running;current.VE=100;current.corrections=100;current.batCorrection=100;current.O2=160;current.afrTarget=177;current.runSecs=10;
 std::cout<<"kind,MAP,TPS_raw_halfpercent,EMAP,baro,map_load,tps_load,ratio_load,pressure_mode,includeAFR,incorporateAFR,egoType,runSecs,target,pulse_us,secondary_ve\n";
 for(unsigned map:{50,100})for(unsigned tps:{20,100})for(unsigned emap:{80,200}){
  current.MAP=map;current.TPS=tps;current.EMAP=emap;current.baro=80;
  std::cout<<"coordinate,"<<map<<','<<tps<<','<<emap<<",80,"<<getLoad(LOAD_SOURCE_MAP,current)<<','<<getLoad(LOAD_SOURCE_TPS,current)<<','<<getLoad(LOAD_SOURCE_IMAPEMAP,current)<<",,,,,,,,\n";
 }
 auto p2=configPage2;auto p6=configPage6;auto p10=configPage10;p2.reqFuel=100;p2.injOpen=9;p2.dutyLim=80;p2.stoich=147;p6.ego_sdelay=5;
 afrTable.values.fill(120);current.MAP=50;current.TPS=100;current.EMAP=200;current.baro=80;
 for(unsigned pressure:{0,1,2})for(unsigned afrcase:{0,1,2,3,4,5}){
  p2.multiplyMAP=pressure;p2.includeAFR=afrcase>=2&&afrcase!=5;p2.incorporateAFR=afrcase==1||afrcase==3||afrcase==4;p6.egoType=afrcase==0||afrcase==1||afrcase==4?EGO_TYPE_OFF:EGO_TYPE_WIDE;current.runSecs=afrcase==5?0:10;current.afrTarget=177;current.fuelLoad=getLoad(LOAD_SOURCE_TPS,current);
  current.afrTarget=calculateAfrTarget(afrTable,current,p2,p6);auto pw=computePulseWidths(p2,p6,p10,current);
  std::cout<<"pulse,50,100,200,80,50,200,25,"<<pressure<<','<<unsigned(p2.includeAFR)<<','<<unsigned(p2.incorporateAFR)<<','<<unsigned(p6.egoType)<<','<<unsigned(current.runSecs)<<','<<unsigned(current.afrTarget)<<','<<pw.primary<<",\n";
 }
 for(unsigned mode:{0,1,2,3,4})for(unsigned rpm:{1000,1001}){
  p10.fuel2Mode=mode;p10.fuel2Algorithm=LOAD_SOURCE_TPS;p10.fuel2SwitchVariable=FUEL2_CONDITION_RPM;p10.fuel2SwitchValue=1000;p10.fuel2InputPolarity=1;pinNumbers.pinFuel2Input=25;pins[25]=1;fuelTable2.values.fill(50);current.RPM=rpm;current.VE1=current.VE=85;current.fuelLoad=50;
  calculateSecondaryFuel(p10,fuelTable2,current);
  std::cout<<"secondary_mode"<<mode<<"_rpm"<<rpm<<",50,100,200,80,50,200,25,,,,,,,,"<<unsigned(current.VE)<<'\n';
 }
 for(unsigned row=0;row<16;++row)for(unsigned col=0;col<16;++col)afrTable.values[row*16+col]=100+3*row;
 invalidate_cache(&afrTable.get_value_cache);p2.includeAFR=0;p2.incorporateAFR=1;p6.egoType=EGO_TYPE_OFF;current.RPM=1000;current.fuelLoad=50;current.VE1=current.VE=85;p10.fuel2Mode=FUEL2_MODE_INPUT_SWITCH;
 const auto before=calculateAfrTarget(afrTable,current,p2,p6);calculateSecondaryFuel(p10,fuelTable2,current);const auto after=calculateAfrTarget(afrTable,current,p2,p6);
 std::cout<<"lambda_before_secondary,50,100,200,80,50,200,25,0,0,1,0,10,"<<unsigned(before)<<",,"<<unsigned(current.VE)<<'\n';
 std::cout<<"lambda_after_secondary,50,100,200,80,50,200,25,0,0,1,0,10,"<<unsigned(after)<<",,"<<unsigned(current.VE)<<'\n';
 current.fuelLoad=200;const auto other=calculateAfrTarget(afrTable,current,p2,p6);std::cout<<"lambda_secondary_as_primary,50,100,200,80,50,200,25,0,0,1,0,10,"<<unsigned(other)<<",,"<<unsigned(current.VE)<<'\n';
 if(before!=after||before==other)return 2;

}
'''
(OUT/'reference_probe.cpp').write_text(source)
cache=ROOT/'.cache/engine/speeduino-sim';manifest=json.loads((cache/'build-manifest.json').read_text());obj=OUT/'reference_probe.o';binary=OUT/'reference_probe'
subprocess.run(['c++',*manifest['compile_flags'],'-c',str(OUT/'reference_probe.cpp'),'-o',str(obj)],check=True)
objects=[p for p in sorted((cache/'obj').glob('*.o')) if p.name!='tools_speeduino_sim.cpp.o'];libs=sorted(p for p in (ROOT.parent/'speeduino/.pio/build/native_code_coverage').rglob('*.a') if p.name not in ('libArduinoFake.a','libUnity.a'))
subprocess.run(['c++',*map(str,objects),str(obj),'-Wl,--start-group',*map(str,libs),'-Wl,--end-group','-lgcov','-pthread','-o',str(binary)],check=True)
run=subprocess.run([str(binary)],capture_output=True,text=True,check=True);(OUT/'reference-probe.csv').write_text(run.stdout)
report=dict(compile_flags=manifest['compile_flags'],profile={'MAP_kpa':50,'baro_kpa':80,'TPS_raw_halfpercent':100,'EMAP_kpa':200,'VE_primary':100,'reqFuel_raw_0_1ms_full_cycle':100,'injection_open_raw_0_1ms':9,'O2_raw_AFR_x10':160,'AFR_target_raw_x10':120,'stoich_raw_AFR_x10':147,'corrections_pct':100,'sensor_input':'controlled status values, no sampled ADC loop'},scope='Actual pinned getLoad/calculateAfrTarget/computePulseWidths/calculateSecondaryFuel at controlled status values; no native loop/plant/physical claims',reference_commit=manifest['speeduino_sha'],binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),output=run.stdout)
(OUT/'reference-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(run.stdout)
