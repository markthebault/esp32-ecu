// Cache-only frozen JSON contract oracle, not firmware implementation.
#include "ecu/engine_json.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
int main(int argc,char**argv){
 if(argc!=2)return 2;std::ifstream file(argv[1]);std::string body{std::istreambuf_iterator<char>{file},std::istreambuf_iterator<char>{}};
 bool safe=ecu::web::safe_json(body.c_str(),body.size(),ecu::engine::tune_maximum);
 cJSON*j=safe?cJSON_ParseWithLength(body.c_str(),body.size()+1):nullptr;
 ecu::engine::Tune tune;bool accepted=j&&ecu::engine::parse_tune(j,tune);cJSON_Delete(j);
 std::cout<<(accepted?"accepted":"rejected")<<'\n';return 0;
}
