"""Compact boost-groundwork checkpoint, excluding linked reference binaries."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[3]
CACHE=ROOT/'.cache/engine/boost-001'
OUT=ROOT/'reports/engine/boost-groundwork'
def sha(body):return hashlib.sha256(body).hexdigest()
def read(p):return json.loads(p.read_text())
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')

review_root=CACHE/'independent-review-001';review=read(review_root/'review.json')
assert not review['unresolved_blockers_within_reviewed_scope']
for n,h in review['reviewed_source_sha256'].items():assert sha((ROOT/n).read_bytes())==h,n
matrix=CACHE/'paired-probes-003';results=read(matrix/'results.json')
assert results['status']=='complete' and results['complete'] and len(results['cases'])==14
assert results['planned_cases']==results['completed_cases']
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'README.md').write_text((CACHE/'published-README-001.md').read_text())
archives={}

def pack(name,files):
    records={}
    with tarfile.open(OUT/name,'x:xz',preset=6) as t:
        for n,p in sorted(files.items()):
            assert not Path(n).is_absolute() and '..' not in Path(n).parts and 'AGENTS.md' not in Path(n).parts
            body=p.read_bytes();item=tarfile.TarInfo(n);item.size=len(body);item.mode=0o644;item.mtime=0
            t.addfile(item,io.BytesIO(body));records[n]=dict(bytes=len(body),sha256=sha(body))
    with tarfile.open(OUT/name,'r:xz') as t:
        assert set(t.getnames())==set(records)
        for item in t:
            body=t.extractfile(item).read();assert records[item.name]==dict(bytes=len(body),sha256=sha(body))
    body=(OUT/name).read_bytes();archives[name]=dict(bytes=len(body),sha256=sha(body),members=records)

source_inputs=read(CACHE/'firmware-a3-001/sources-before.json')
sources={};recovered='firmware/tests/boost_control_test.cpp'
for n,h in source_inputs.items():
    p=ROOT/n
    if sha(p.read_bytes())!=h:
        assert n==recovered;p=CACHE/'recovered-build-inputs'/n;assert sha(p.read_bytes())==h
    sources['firmware-build-inputs/'+n]=p
for n in review['reviewed_source_sha256']:sources['current/'+n]=ROOT/n
sources['reproduction/publish.py']=Path(__file__)
pack('sources.tar.xz',sources)

probe_files={str(p.relative_to(matrix)):p for p in matrix.rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl','.txt','.log')}
probe_files['reference-build-manifest.json']=CACHE/'reference-004/build-manifest.json'
probe_files['reference-build.log']=CACHE/'reference-build-004.log'
for n in ('command-1.log','command-2.log','command-3.log'):probe_files['reference-build/'+n]=CACHE/'reference-004'/n
probe_files['architecture-tests.log']=CACHE/'architecture-tests-001.log'
pack('paired-probes.tar.xz',probe_files)

whitelist=read(review_root/'archive-whitelist.json');files={}
for record in whitelist['files']:
    p=ROOT/record['path'];body=p.read_bytes();assert len(body)==record['bytes'] and sha(body)==record['sha256']
    files[record['review_relative_path']]=p
files['archive-whitelist.json']=review_root/'archive-whitelist.json'
pack('independent-review.tar.xz',files)
(OUT/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n')

firmware={};builds=[]
for n in ('firmware-a3-001','firmware-n16-001','firmware-flex-dev-001'):
    folder=CACHE/n;summary=read(folder/'summary.json')
    assert summary['exit_code']==0 and summary['source_inputs_unchanged'] and summary['default_cache_unchanged'] and not summary['flashed']
    assert read(folder/'sources-before.json')==source_inputs
    for a in summary['artifacts']:
        p=folder/a['path'];body=p.read_bytes();assert len(body)==a['bytes'] and sha(body)==a['sha256']
        if p.suffix=='.bin':firmware[n+'/'+a['path']]=p
    for a in summary['elf_archives']:
        p=folder/a['path'];body=p.read_bytes();assert len(body)==a['bytes'] and sha(body)==a['sha256']
        elf=gzip.decompress(body);assert len(elf)==a['elf_bytes'] and sha(elf)==a['elf_sha256']
        firmware[n+'/'+a['path']]=p
    for meta in ('summary.json','sources-before.json','sources-after.json','default-cache-before.json','default-cache-after.json'):
        firmware[n+'/'+meta]=folder/meta
    builds.append(dict(path=n,summary=summary))
pack('firmware.tar.xz',firmware)
write('results.json',results)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def rows(case,side):return [json.loads(l) for l in (matrix/case/(side+'.jsonl')).read_text().splitlines()]
fig,axes=plt.subplots(3,1,figsize=(10,8),layout='constrained')
for side,color,label in [('reference','#b65c34','Pinned production / native HAL'),('own','#19856c','Portable kernel / authored RPM')]:
    sample=[r for r in rows('closed-feedforward',side) if r['kind']=='sample'];x=[r['time_us']/1e6 for r in sample]
    axes[0].step(x,[r['boost_target_kpa'] for r in sample],where='post',label=label,color=color)
    axes[1].step(x,[r['boost_duty_pct'] for r in sample],where='post',label=label+' request',color=color)
    data=rows('closed-feedforward',side);edges=[r for r in data if r['kind']=='boost_edge']
    cycles=[]
    for a,b,c in zip(edges,edges[1:],edges[2:]):
        if a['high'] and not b['high'] and c['high']:cycles.append((a['time_us']/1e6,100*(b['time_us']-a['time_us'])/(c['time_us']-a['time_us'])))
    axes[1].plot([t for t,d in cycles],[d for t,d in cycles],'.',ms=3,label=label+' executed cycle',color=color)
    over=[r for r in rows('overboost',side) if r['kind']=='sample']
    axes[2].step([r['time_us']/1e6 for r in over],[r['boost_duty_pct'] for r in over],where='post',label=label,color=color)
axes[0].set_ylabel('Reported target (kPa)\nreference0 = not updated')
axes[1].set_ylabel('Closed-loop duty (%)');axes[2].set_ylabel('Overboost valve duty (%)')
axes[0].set_title('Closed-loop timing under the declared native-loop cadence')
axes[2].set_title('Both protection paths request engine cuts; valve policy differs')
axes[2].axvline(.601,color='#555',ls=':',label='Authored high-pressure step')
for ax in axes:ax.grid(alpha=.2);ax.legend(loc='best',fontsize=7);ax.set_xlabel('Replay time (s)')
fig.suptitle('Isolated boost groundwork: conditional software/native-HAL observations\nNo full Engine/turbo plant or physical execution',fontsize=11)
fig.savefig(OUT/'comparison.png',dpi=150);plt.close(fig)
write('manifest.json',dict(schema_version=1,source_base_commit='c780c3ada8bc8c74415bbb04a86b0bc4ab9ea564',
    current_sources=review['reviewed_source_sha256'],archives=archives,firmware_builds=builds,
    firmware_source_followup=dict(path=recovered,build_source_sha256=source_inputs[recovered],
        current_sha256=sha((ROOT/recovered).read_bytes()),reason='Only3 assertions added to a native test not compiled into the ESP images; exact earlier test bytes retained by their recorded hash.'),
    files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(OUT.iterdir()) if p.is_file()},
    plot_matplotlib=matplotlib.__version__,physical_outputs_inhibited=True,physical_qualification=False,
    scope='Isolated portable boost kernel/PWM plus production-source fixtures; full ECU integration remains open',
    excluded=['Linked Speeduino executables/objects/upstream source','Full feature/engine/turbo plant/physical qualification']))
print(json.dumps(dict(output=str(OUT),archives={n:a['bytes'] for n,a in archives.items()},paired_cases=14)))
