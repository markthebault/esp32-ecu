#include "ecu/boost_control.hpp"
#include "ecu/boost_pwm.hpp"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
#include <tuple>
#include <vector>
namespace b=ecu::boost;
struct IO {bool high=false;std::uint64_t now=0;std::vector<std::pair<std::uint64_t,bool>> edges;bool write(bool v){high=v;edges.emplace_back(now,v);return true;}void all_low(){if(high)edges.emplace_back(now,false);high=false;}};
int main(){
 unsigned long checks=0;auto check=[&](bool yes){++checks;assert(yes);};
 b::Table t;
 for(unsigned row=0;row<b::bins;++row)for(unsigned col=0;col<b::bins;++col)t.cells[row*b::bins+col]=float(.001*t.rpm[col]+.5*t.axis[row]);
 for(double rpm:{0.,500.,750.,1500.,3500.,7999.,8000.,12000.})for(double axis:{-10.,0.,2.5,10.,30.,99.,100.,200.})
  check(std::abs(b::lookup(t,rpm,axis)-(.001*std::clamp(rpm,500.,8000.)+.5*std::clamp(axis,0.,100.)))<1e-5);
 b::Config c;c.pressure_enabled=true;c.mode=b::Mode::ClosedLoop;
 b::Input in;in.map_qualified=in.tps_qualified=in.baro_qualified=in.running=true;in.map_kpa=120;in.rpm=2000;in.tps_pct=50;
 b::Controller ctl;
 auto sample=[&](std::uint64_t now){in.sampled_us=now;return ctl.step(c,in,now);};
 auto a=sample(0);check(a.reason==b::Reason::Ready&&a.duty_pct==0);
 in.sampled_us=0;a=ctl.step(c,in,20000);check(!a.inhibit_engine); // Inclusive kernel freshness boundary.
 a=ctl.step(c,in,20001);check(a.reason==b::Reason::Stale&&a.inhibit_engine&&a.duty_pct==0);
 ctl.reset();in.map_kpa=221;a=sample(0);check(a.inhibit_engine&&a.overboost_events==1);
 in.map_kpa=210;a=sample(1000);check(a.inhibit_engine);
 in.map_kpa=210;in.sampled_us=1000;a=ctl.step(c,in,21002);check(a.reason==b::Reason::Stale&&a.inhibit_engine&&(a.flags&b::OverboostLatched));
 for(std::uint64_t now=25000;now<=270000;now+=5000){a=sample(now);check(a.inhibit_engine);}
 a=sample(275000);check(!a.inhibit_engine);
 ctl.reset();in.map_kpa=221;sample(0);in.map_kpa=210;sample(5000);
 a=sample(105001);check(a.reason==b::Reason::Clock&&a.inhibit_engine&&(a.flags&b::OverboostLatched));
 for(std::uint64_t now=110000;now<360000;now+=5000){a=sample(now);check(a.inhibit_engine);}
 check(!sample(360000).inhibit_engine);
 // Distinct heartbeat and PID sample periods, and bounds/slew under changing
 // pressure/load, include saturated positive and negative P/I/D requests.
 std::mt19937_64 rng(0x5acdef1356702489ULL);
 for(unsigned run=0;run<100;++run){
  ctl.reset();c=b::Config{};c.pressure_enabled=true;c.mode=b::Mode::ClosedLoop;c.kp=float(rng()%100)/10;c.ki=float(rng()%100)/10;c.kd=float(rng()%100)/10;
  c.slew_pct_s=1+rng()%2000;c.min_pct=rng()%20;c.max_pct=50+rng()%51;c.integral_limit_pct=rng()%101;c.derivative_filter_s=float(rng()%21)/10;
  c.feedforward.cells.fill(float(rng()%101));c.control_period_ms=20+rng()%231;
  in.map_kpa=120;in.baro_kpa=50;in.rpm=2000;in.tps_pct=50;
  auto prev=sample(0);check(prev.reason==b::Reason::Ready);
  for(std::uint64_t now=5000;now<=5000000;now+=5000){
   if(now%100000==0)in.map_kpa=100+rng()%111;
   a=sample(now);check(a.reason==b::Reason::Ready&&!a.inhibit_engine);
   check(std::isfinite(a.duty_pct)&&std::isfinite(a.demand_pct)&&std::isfinite(a.p_term)&&std::isfinite(a.i_term)&&std::isfinite(a.d_term));
   check(a.duty_pct>=0&&a.duty_pct<=c.max_pct);
   check(std::abs(a.duty_pct-prev.duty_pct)<=c.slew_pct_s*.005+1e-9);
   check(std::abs(a.i_term)<=c.integral_limit_pct+1e-9);
   prev=a;
  }
 }
 // Dedicated instances retain independent deadlines, sequences and latches.
 b::PwmExecutor p;ecu::idle::PwmExecutor idle;IO io,ii;b::PwmCommand cmd;
 cmd.sequence=cmd.tune_revision=cmd.sensor_revision=1;cmd.enabled=true;cmd.period_us=100000;cmd.high_us=100000;
 check(p.submit(cmd,0,io)&&io.high);auto ic=cmd;ic.period_us=2500;ic.high_us=1250;check(idle.submit(ic,0,ii)&&ii.high);
 ii.now=1276;idle.dispatch(ii.now,ii);check(idle.stats().fault==b::PwmCause::LateInterrupt&&!ii.high);
 cmd.sequence=2;cmd.command_us=cmd.sampled_us=19999;io.now=19999;check(p.submit(cmd,io.now,io)&&io.high&&p.stats().fault==b::PwmCause::None);
 io.now=39999;p.dispatch(io.now,io);check(p.stats().fault==b::PwmCause::CommandExpired&&!io.high);
 b::PwmExecutor exact;IO ei;cmd.sequence=1;cmd.command_us=cmd.sampled_us=0;check(!exact.submit(cmd,20000,ei)&&exact.stats().fault==b::PwmCause::InvalidCommand);
 b::PwmExecutor late;IO li;cmd.high_us=500;check(late.submit(cmd,0,li));li.now=525;late.dispatch(li.now,li);check(!li.high&&late.stats().fault==b::PwmCause::None);
 std::cout<<"Independent kernel/table/PWM property checks: "<<checks<<" passed; native execution only\n";
}
