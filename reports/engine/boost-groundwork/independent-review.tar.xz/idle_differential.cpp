#include "ecu/idle_pwm.hpp"
#include "frozen_idle_namespace.hpp"
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <random>
#include <tuple>
#include <vector>

struct IO {
 bool high=false,fail=false;
 std::uint64_t now=0,writes=0,clears=0;
 std::vector<std::pair<std::uint64_t,bool>> edges;
 bool write(bool v){++writes;if(fail)return false;high=v;edges.emplace_back(now,v);return true;}
 void all_low(){++clears;if(high)edges.emplace_back(now,false);high=false;}
};
template<class S> auto stats(const S&s){
 return std::make_tuple(s.accepted,s.rejected,s.cycles,s.rises,s.falls,s.faults,s.cuts,s.recoveries,s.max_lateness_us,s.sequence,s.pending_sequence,s.observed_us,s.tune_revision,s.sensor_revision,s.pending_tune_revision,s.pending_sensor_revision,s.period_us,s.high_us,s.active,s.high,int(s.fault),int(s.last_cause));
}
template<class C> auto command(const C&c){
 return std::make_tuple(c.sequence,c.command_us,c.sampled_us,c.tune_revision,c.sensor_revision,c.period_us,c.high_us,c.enabled,c.supervised_stop);
}
std::uint64_t comparisons=0;
struct Pair {
 ecu::idle::PwmExecutor current;
 ecu::frozen_idle::PwmExecutor frozen;
 IO a,b;
 void verify(){
  ++comparisons;
  assert(stats(current.stats())==stats(frozen.stats()));
  assert(command(current.command())==command(frozen.command()));
  assert(current.next_alarm()==frozen.next_alarm());
  assert(std::tie(a.high,a.fail,a.now,a.writes,a.clears,a.edges)==std::tie(b.high,b.fail,b.now,b.writes,b.clears,b.edges));
 }
 void time(std::uint64_t now){a.now=b.now=now;}
 bool submit(ecu::idle::PwmCommand c,std::uint64_t now){
  time(now);ecu::frozen_idle::PwmCommand old;
  old.sequence=c.sequence;old.command_us=c.command_us;old.sampled_us=c.sampled_us;
  old.tune_revision=c.tune_revision;old.sensor_revision=c.sensor_revision;old.period_us=c.period_us;old.high_us=c.high_us;old.enabled=c.enabled;old.supervised_stop=c.supervised_stop;
  const bool aa=current.submit(c,now,a),bb=frozen.submit(old,now,b);assert(aa==bb);verify();return aa;
 }
 void dispatch(std::uint64_t now){time(now);current.dispatch(now,a);frozen.dispatch(now,b);verify();}
 void config(std::uint64_t now){time(now);current.configuration(now,a);frozen.configuration(now,b);verify();}
 void stop(std::uint64_t now,unsigned why,bool trip){time(now);if(trip){current.trip(now,ecu::idle::PwmCause(why),a);frozen.trip(now,ecu::frozen_idle::PwmCause(why),b);}else{current.stop(now,ecu::idle::PwmCause(why),a);frozen.stop(now,ecu::frozen_idle::PwmCause(why),b);}verify();}
};
int main(){
 static_assert(sizeof(ecu::idle::PwmExecutor)==sizeof(ecu::frozen_idle::PwmExecutor));
 const std::array<std::uint32_t,15> periods={0,1,999,1000,2499,2500,2501,10000,49999,50000,50001,99999,100000,100001,UINT32_MAX};
 const std::array<std::uint64_t,8> times={0,1,20000,1000000,UINT64_MAX-50001,UINT64_MAX-50000,UINT64_MAX-49999,UINT64_MAX};
 std::uint64_t boundary_cases=0;
 for(auto period:periods)for(auto now:times)for(unsigned edge=0;edge<5;++edge)for(unsigned age: {0u,19999u,20000u,20001u})for(unsigned mode=0;mode<4;++mode){
  Pair p;ecu::idle::PwmCommand c;c.sequence=c.tune_revision=c.sensor_revision=1;c.period_us=period;
  c.high_us=edge==0?0:edge==1?1:edge==2?(period?period-1:0):edge==3?period:(period==UINT32_MAX?period:period+1);
  c.command_us=c.sampled_us=now>=age?now-age:now+1;c.enabled=bool(mode&1);c.supervised_stop=bool(mode&2);
  p.submit(c,now);++boundary_cases;
 }
 std::mt19937_64 rng(0x5b1367f290ac87e1ULL);
 for(unsigned scenario=0;scenario<500;++scenario){
  Pair p;std::uint64_t now=0,seq=0;
  for(unsigned event=0;event<1500;++event){
   const unsigned action=rng()%100;
   if(action<60){
    now+=rng()%6000;ecu::idle::PwmCommand c;c.sequence=++seq;c.tune_revision=c.sensor_revision=1;
    c.command_us=c.sampled_us=now;c.period_us=periods[rng()%periods.size()];
    if(rng()%4)c.period_us=2500+rng()%47501;
    c.enabled=rng()%5;c.supervised_stop=!c.enabled&&(rng()%2);c.high_us=c.enabled?rng()%(std::uint64_t(c.period_us)+1):0;
    switch(rng()%30){case 0:c.sequence=0;break;case 1:c.sequence=seq-1;break;case 2:c.tune_revision=0;break;case 3:c.sensor_revision=0;break;case 4:c.command_us=now+1;break;case 5:c.sampled_us=now+1;break;case 6:c.command_us=now>20000?now-20000:0;break;case 7:c.sampled_us=now>20000?now-20000:0;break;case 8:c.supervised_stop=true;break;case 9:c.high_us=UINT32_MAX;break;default:break;}
    p.submit(c,now);
   }else if(action<85){
    const auto alarm=p.current.next_alarm();
    if(alarm!=UINT64_MAX&&rng()%2)now=alarm+(rng()%4==0?26:rng()%26);else now+=rng()%22000;
    p.dispatch(now);
   }else if(action<90){p.config(now);}
   else if(action<94){p.stop(now,rng()%10,rng()%2);}
   else if(action<97){p.a.fail=p.b.fail=bool(rng()%2);p.verify();}
   else{if(now)now-=rng()%now;p.dispatch(now);}
  }
 }
 std::cout<<"Frozen HEAD/current idle differential: "<<boundary_cases<<" isolated boundary cases, "<<comparisons<<" full observations equal; sizeof="<<sizeof(ecu::idle::PwmExecutor)<<" bytes\n";
}
